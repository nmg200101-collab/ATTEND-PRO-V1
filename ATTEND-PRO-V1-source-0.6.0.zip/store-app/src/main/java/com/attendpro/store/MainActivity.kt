package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var eventsView: TextView
    private lateinit var scanButton: Button
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        scanner = BleEmployeeScanner(this, ::handleBlePayload) { msg -> runOnUiThread { status.text = msg } }
        buildUi()
        refreshDashboard()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 42, 32, 42)
        }
        root.addView(TextView(this).apply {
            text = "ATTEND PRO\nجهاز المحل"
            textSize = 30f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "الإصدار 0.6.0 • BLE + حضور محلي + Offline Sync"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
        })
        counts = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 18) }
        root.addView(counts)

        scanButton = Button(this).apply {
            text = "بدء البحث عن هواتف الموظفين"
            setOnClickListener {
                if (scanner.isScanning()) { scanner.stop(); text = "بدء البحث عن هواتف الموظفين" }
                else { scanner.start(); text = "إيقاف البحث" }
            }
        }
        root.addView(scanButton)
        root.addView(Button(this).apply { text = "ربط موظف جديد"; setOnClickListener { showPairEmployeeDialog() } })
        root.addView(Button(this).apply { text = "تسجيل عبر PIN احتياطي"; setOnClickListener { showPinDialog() } })
        root.addView(Button(this).apply { text = "إعداد الدوام والسماح"; setOnClickListener { showShiftDialog() } })
        root.addView(Button(this).apply { text = "إعداد/اختبار جهاز البصمة الشبكي"; setOnClickListener { showFingerprintDialog() } })
        root.addView(Button(this).apply { text = "إعداد الخادم والمزامنة"; setOnClickListener { showSyncDialog() } })

        status = TextView(this).apply { text = "جاهز"; textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 12) }
        root.addView(status)
        nearbyView = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 18) }
        root.addView(nearbyView)
        eventsView = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 18) }
        root.addView(eventsView)
        root.addView(TextView(this).apply {
            text = "ملاحظة جهاز البصمة الخارجي: النسخة الحالية تختبر الاتصال TCP عبر LAN/Wi-Fi. جلب سجلات البصمة يحتاج Driver خاص بالشركة/الموديل، وسيتم إضافته دون تغيير محرك الحضور الأساسي."
            textSize = 14f
            gravity = Gravity.CENTER
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun handleBlePayload(payload: BleProtocol.Payload, rssi: Int) {
        val employees = repo.employees().filter { BleProtocol.employeeHash(it.employeeId) == payload.employeeHash }
        for (employee in employees) {
            val secret = SecretCodec.decode(employee.pairingSecret) ?: continue
            if (!BleProtocol.verify(payload, employee.employeeId, secret)) continue
            nearby[employee.employeeId] = System.currentTimeMillis() to rssi
            if (payload.verified) maybeRecordVerified(employee, payload.token)
            runOnUiThread { refreshDashboard() }
            return
        }
    }

    private fun maybeRecordVerified(employee: PairedEmployee, token: Int) {
        if (repo.lastProofToken(employee.employeeId) == token) return
        val last = repo.lastEvent(employee.employeeId)
        if (last != null && System.currentTimeMillis() - last.timestampEpochMillis < 60_000L) return
        val action = nextAction(employee.employeeId)
        repo.addEvent(AttendanceEvent(
            employeeId = employee.employeeId,
            employeeName = employee.displayName,
            branchId = employee.branchId,
            timestampEpochMillis = System.currentTimeMillis(),
            action = action,
            method = AttendanceMethod.PHONE_BLE_BIOMETRIC,
            deviceId = deviceId(),
            verified = true
        ))
        repo.setLastProofToken(employee.employeeId, token)
        runOnUiThread { status.text = "✓ ${employee.displayName}: ${if (action == AttendanceAction.CHECK_IN) "تم تسجيل الحضور" else "تم تسجيل الانصراف"}" }
    }

    private fun nextAction(employeeId: String): AttendanceAction {
        val lastToday = repo.lastEventToday(employeeId, dayStartMillis())
        return if (lastToday?.action == AttendanceAction.CHECK_IN) AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN
    }

    private fun refreshDashboard() {
        val now = System.currentTimeMillis()
        nearby.entries.removeIf { now - it.value.first > 45_000L }
        val employees = repo.employees()
        val events = repo.events().filter { it.timestampEpochMillis >= dayStartMillis() }
        val presentIds = employees.mapNotNull { e ->
            val last = events.lastOrNull { it.employeeId.equals(e.employeeId, true) }
            if (last?.action == AttendanceAction.CHECK_IN) e.employeeId else null
        }.toSet()
        val lateIds = employees.mapNotNull { e ->
            val firstIn = events.firstOrNull { it.employeeId.equals(e.employeeId, true) && it.action == AttendanceAction.CHECK_IN }
            if (firstIn != null && firstIn.timestampEpochMillis > shiftCutoffMillis()) e.employeeId else null
        }.toSet()
        val absent = (employees.size - presentIds.size).coerceAtLeast(0)
        counts.text = "المسجلون: ${employees.size}   الحاضرون: ${presentIds.size}   المتأخرون: ${lateIds.size}   غير الحاضرين: $absent"
        nearbyView.text = if (nearby.isEmpty()) "لا توجد هواتف موظفين موثوقة قريبة حالياً" else buildString {
            append("هواتف قريبة:\n")
            nearby.forEach { (id, data) ->
                val name = employees.firstOrNull { it.employeeId.equals(id, true) }?.displayName ?: id
                append("• $name  RSSI ${data.second}\n")
            }
        }
        val recent = repo.events().takeLast(10).reversed()
        eventsView.text = if (recent.isEmpty()) "لا توجد عمليات حضور مسجلة بعد" else buildString {
            append("آخر العمليات:\n")
            val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            recent.forEach { e -> append("• ${e.employeeName.ifBlank { e.employeeId }} — ${if (e.action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))}${if (!e.synced) " • غير مزامن" else ""}\n") }
        }
    }

    private fun showPairEmployeeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = field("رقم الموظف")
        val name = field("اسم الموظف")
        val branch = field("الفرع (مثال MAIN)")
        val secret = field("رمز الربط من تطبيق الموظف")
        val pin = field("PIN احتياطي", true)
        listOf(id, name, branch, secret, pin).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("ربط موظف").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val secretText = secret.text.toString().trim()
                if (id.text.toString().trim().isBlank() || name.text.toString().trim().isBlank() || !SecretCodec.isValid(secretText)) {
                    status.text = "بيانات الربط غير مكتملة أو رمز الربط غير صحيح"
                } else {
                    repo.upsertEmployee(PairedEmployee(id.text.toString().trim(), name.text.toString().trim(), branch.text.toString().trim().ifBlank { "MAIN" }, secretText, pin.text.toString().trim()))
                    status.text = "تم ربط ${name.text.toString().trim()}"
                    refreshDashboard()
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showPinDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = field("رقم الموظف")
        val pin = field("PIN", true)
        box.addView(id); box.addView(pin)
        AlertDialog.Builder(this).setTitle("تسجيل احتياطي عبر PIN").setView(box)
            .setPositiveButton("تسجيل") { _, _ ->
                val employee = repo.employees().firstOrNull { it.employeeId.equals(id.text.toString().trim(), true) }
                if (employee == null || employee.pin.isBlank() || employee.pin != pin.text.toString().trim()) status.text = "رقم الموظف أو PIN غير صحيح"
                else {
                    val action = nextAction(employee.employeeId)
                    repo.addEvent(AttendanceEvent(employeeId = employee.employeeId, employeeName = employee.displayName, branchId = employee.branchId, timestampEpochMillis = System.currentTimeMillis(), action = action, method = AttendanceMethod.PIN, deviceId = deviceId(), verified = true))
                    status.text = "تم التسجيل عبر PIN: ${employee.displayName}"
                    refreshDashboard()
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showShiftDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val hour = field("ساعة بداية الدوام 0-23", true).apply { setText(repo.shiftHour.toString()) }
        val minute = field("الدقيقة 0-59", true).apply { setText(repo.shiftMinute.toString()) }
        val grace = field("دقائق السماح", true).apply { setText(repo.graceMinutes.toString()) }
        listOf(hour, minute, grace).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("إعداد الدوام").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                repo.shiftHour = hour.text.toString().toIntOrNull() ?: 8
                repo.shiftMinute = minute.text.toString().toIntOrNull() ?: 0
                repo.graceMinutes = grace.text.toString().toIntOrNull() ?: 10
                status.text = "تم حفظ إعداد الدوام"
                refreshDashboard()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showFingerprintDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val host = field("IP جهاز البصمة").apply { setText(repo.fingerprintHost) }
        val port = field("Port").apply { setText(repo.fingerprintPort.toString()) }
        box.addView(host); box.addView(port)
        AlertDialog.Builder(this).setTitle("جهاز البصمة عبر الشبكة").setView(box)
            .setPositiveButton("حفظ واختبار") { _, _ ->
                repo.fingerprintHost = host.text.toString()
                repo.fingerprintPort = port.text.toString().toIntOrNull() ?: 4370
                status.text = "جاري اختبار الاتصال..."
                Thread {
                    val result = NetworkTools.probeTcp(repo.fingerprintHost, repo.fingerprintPort)
                    runOnUiThread { status.text = if (result.isSuccess) "✓ جهاز/منفذ الشبكة يستجيب" else "تعذر الاتصال: ${result.exceptionOrNull()?.message ?: "خطأ"}" }
                }.start()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun showSyncDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val url = field("https://server.example.com").apply { setText(repo.serverUrl) }
        val tenant = field("Tenant / Business ID").apply { setText(repo.tenantId) }
        val token = field("Activation token").apply { setText(repo.activationToken) }
        listOf(url, tenant, token).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("الخادم والمزامنة").setView(box)
            .setPositiveButton("حفظ ومزامنة") { _, _ ->
                repo.serverUrl = url.text.toString(); repo.tenantId = tenant.text.toString(); repo.activationToken = token.text.toString()
                val pending = repo.pendingEvents()
                if (pending.isEmpty()) { status.text = "لا توجد أحداث بانتظار المزامنة"; return@setPositiveButton }
                status.text = "جاري مزامنة ${pending.size} عملية..."
                Thread {
                    val result = NetworkTools.syncEvents(repo.serverUrl, repo.tenantId, repo.activationToken, pending)
                    runOnUiThread {
                        if (result.isSuccess) {
                            repo.markSynced(result.getOrThrow()); status.text = "✓ تمت مزامنة ${result.getOrThrow().size} عملية"; refreshDashboard()
                        } else status.text = "فشلت المزامنة: ${result.exceptionOrNull()?.message ?: "خطأ"}"
                    }
                }.start()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun field(hintText: String, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText
        textSize = 16f
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun dayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun shiftCutoffMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, repo.shiftHour); set(Calendar.MINUTE, repo.shiftMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.MINUTE, repo.graceMinutes)
    }.timeInMillis

    private fun deviceId(): String {
        val prefs = getSharedPreferences("device", MODE_PRIVATE)
        val old = prefs.getString("id", null)
        if (old != null) return old
        val id = "STORE-${UUID.randomUUID()}"
        prefs.edit().putString("id", id).apply()
        return id
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == BleEmployeeScanner.REQUEST_PERMISSIONS) {
            status.text = if (grantResults.isNotEmpty() && grantResults.all { it == android.content.pm.PackageManager.PERMISSION_GRANTED }) "تم منح الصلاحيات. اضغط بدء البحث." else "يلزم منح صلاحيات البلوتوث/الموقع."
        }
    }

    override fun onDestroy() {
        scanner.stop()
        super.onDestroy()
    }
}
