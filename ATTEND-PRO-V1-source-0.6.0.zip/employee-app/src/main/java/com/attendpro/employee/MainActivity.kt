package com.attendpro.employee

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.EmployeeIdentityStore

class MainActivity : Activity() {
    private lateinit var identity: EmployeeIdentityStore
    private lateinit var advertiser: BlePresenceAdvertiser
    private lateinit var status: TextView
    private lateinit var employeeId: EditText
    private lateinit var employeeName: EditText
    private lateinit var branchId: EditText
    private lateinit var pin: EditText
    private lateinit var pairingCode: TextView
    private lateinit var presenceButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identity = EmployeeIdentityStore(this)
        advertiser = BlePresenceAdvertiser(this) { message -> runOnUiThread { status.text = message } }
        buildUi()
        loadIdentity()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 48)
        }
        root.addView(TextView(this).apply {
            text = "ATTEND PRO\nتطبيق الموظف"
            textSize = 30f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "الإصدار 0.6.0 • حضور ذكي عبر BLE + بصمة/وجه"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        })

        employeeId = field("رقم الموظف")
        employeeName = field("اسم الموظف")
        branchId = field("رمز الفرع")
        pin = field("PIN احتياطي", true)
        root.addView(employeeId); root.addView(employeeName); root.addView(branchId); root.addView(pin)

        root.addView(Button(this).apply {
            text = "حفظ بيانات الموظف"
            setOnClickListener { saveIdentity() }
        })

        pairingCode = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(12, 24, 12, 16)
            setTextIsSelectable(true)
        }
        root.addView(pairingCode)
        root.addView(Button(this).apply {
            text = "نسخ رمز الربط"
            setOnClickListener { copyPairingCode() }
        })
        root.addView(Button(this).apply {
            text = "توليد رمز ربط جديد"
            setOnClickListener {
                identity.regenerateSecret()
                refreshPairingCode()
                status.text = "تم إنشاء رمز جديد. أعد ربط الموظف بجهاز المحل."
            }
        })

        presenceButton = Button(this).apply {
            text = "تشغيل الظهور للمحل عبر BLE"
            setOnClickListener {
                if (advertiser.isRunning()) {
                    advertiser.stop(); text = "تشغيل الظهور للمحل عبر BLE"
                } else {
                    saveIdentity()
                    advertiser.start(identity.employeeId, identity.pairingSecret)
                    text = "إيقاف الظهور للمحل"
                }
            }
        }
        root.addView(presenceButton)

        root.addView(Button(this).apply {
            text = "تأكيد الحضور بالبصمة / الوجه"
            setOnClickListener {
                if (!advertiser.isRunning()) {
                    status.text = "شغّل الظهور للمحل أولاً"
                } else requestBiometric()
            }
        })

        status = TextView(this).apply {
            text = "جاهز"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 18)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "طريقة العمل: جهاز المحل يكتشف هاتفك فقط بعد الربط. عند نجاح البصمة/الوجه يبث الهاتف إثباتاً متغيراً لمدة قصيرة، ولا يتم إرسال صورة البصمة أو قالبها."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun field(hintText: String, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText
        textSize = 17f
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 12
        }
    }

    private fun loadIdentity() {
        employeeId.setText(identity.employeeId)
        employeeName.setText(identity.displayName)
        branchId.setText(identity.branchId)
        pin.setText(identity.pin)
        refreshPairingCode()
    }

    private fun saveIdentity() {
        if (employeeId.text.toString().trim().isBlank() || employeeName.text.toString().trim().isBlank()) {
            status.text = "أدخل رقم الموظف والاسم"
            return
        }
        identity.employeeId = employeeId.text.toString()
        identity.displayName = employeeName.text.toString()
        identity.branchId = branchId.text.toString()
        identity.pin = pin.text.toString()
        refreshPairingCode()
        status.text = "تم حفظ بيانات الموظف"
    }

    private fun refreshPairingCode() {
        pairingCode.text = "رمز الربط بجهاز المحل:\n${identity.pairingSecret}"
    }

    private fun copyPairingCode() {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("Attend Pro pairing code", identity.pairingSecret))
        status.text = "تم نسخ رمز الربط"
    }

    private fun requestBiometric() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "يلزم Android 9 أو أحدث للمصادقة البيومترية"
            return
        }
        val prompt = BiometricPrompt.Builder(this)
            .setTitle("تأكيد الحضور")
            .setSubtitle("استخدم البصمة أو وسيلة القياسات الحيوية المسجلة في الهاتف")
            .setNegativeButton("إلغاء", mainExecutor) { _, _ -> status.text = "تم إلغاء التحقق" }
            .build()
        prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                advertiser.markVerified(30_000L)
                status.text = "✓ تم التحقق. أُرسل إثبات مؤقت لجهاز المحل."
            }
            override fun onAuthenticationFailed() { status.text = "لم يتم التعرف على الهوية، حاول مرة أخرى" }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                status.text = "تعذر التحقق: ${errString ?: "خطأ غير معروف"}"
            }
        })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == BlePresenceAdvertiser.REQUEST_BLUETOOTH) {
            status.text = if (grantResults.isNotEmpty() && grantResults.all { it == android.content.pm.PackageManager.PERMISSION_GRANTED })
                "تم السماح بالبلوتوث. اضغط تشغيل الظهور للمحل." else "يلزم السماح بالبلوتوث لتفعيل الحضور الذكي."
        }
    }

    override fun onDestroy() {
        advertiser.stop()
        super.onDestroy()
    }
}
