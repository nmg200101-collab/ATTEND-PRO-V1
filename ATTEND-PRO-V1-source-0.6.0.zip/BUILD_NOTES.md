# ATTEND-PRO 0.6.0 test sequence

1. Install both APKs built from this source.
2. Employee app: enter employee ID/name/branch/PIN and save.
3. Copy pairing code.
4. Store app: Pair employee and paste the exact pairing code.
5. Enable Bluetooth on both phones.
6. Employee app: Start BLE presence.
7. Store app: Start employee scan and grant Bluetooth permissions.
8. Confirm the employee appears under nearby phones.
9. Employee app: tap biometric confirmation and authenticate.
10. Store app should record CHECK_IN within seconds.
11. Wait at least 60 seconds before testing another biometric event; the next accepted proof toggles to CHECK_OUT.
12. Test PIN fallback from store app.
13. Configure shift/grace and confirm late count behavior.
14. External fingerprint: enter device IP/port and test LAN reachability.
15. Sync: use an HTTPS ATTEND PRO backend implementing POST `/api/v1/attendance/events/batch`.
