# ATTEND-PRO-V1 Android Source 0.6.0

Large consolidated mobile milestone to reduce update cycles.

## Included now

### Employee app
- Employee onboarding: employee ID, name, branch and fallback PIN.
- Persistent pairing secret generated locally.
- Copy/regenerate pairing code.
- BLE presence advertising.
- Android biometric authentication (fingerprint/face/device biometric supported by the phone).
- After biometric success, a short-lived rotating proof is advertised to the store device.
- No fingerprint image/template is extracted or stored by ATTEND PRO.

### Store / kiosk app
- Pair employees using ID + name + branch + pairing secret + optional fallback PIN.
- BLE scan for trusted paired employee phones.
- Rotating HMAC proof verification with a small clock-drift tolerance.
- Automatic check-in/check-out toggle after verified phone biometric proof.
- Duplicate/proof replay throttling and 60-second attendance cooldown.
- Nearby employee list with RSSI.
- Persistent offline attendance log (up to last 1000 events).
- Dashboard counts for registered, present, late and not-present employees.
- Shift start + grace configuration.
- PIN fallback attendance.
- Last 10 events display and pending-sync marker.
- HTTPS batch sync contract to `/api/v1/attendance/events/batch`.
- Tenant ID and activation token fields ready for server licensing.
- External fingerprint device LAN/Wi-Fi TCP host/port probe.

### Core/security architecture
- Shared attendance event schema.
- BLE protocol with rotating HMAC-SHA256 token.
- Paired-employee local repository.
- Network sync utility.
- FingerprintDeviceAdapter contract retained for vendor-specific SDK/protocol drivers.

## Important production notes
- The pairing flow in 0.6.0 uses a manually copied pairing secret. Production hardening should replace this with QR/device-certificate provisioning and server-issued device trust.
- External fingerprint event download is vendor/model specific. This milestone can test LAN reachability but does not pretend to support unknown vendor protocols.
- Server sync is implemented client-side but requires the ATTEND PRO backend endpoint and licensing service to be deployed.
- BLE behavior can differ by Android vendor power-saving policies. Field testing on the intended store/employee phones is required.

## Build
Modules:
- `employee-app`
- `store-app`
- `core`

Compile/target SDK 35, min SDK 26, JDK 17, Kotlin 2.0.21, AGP 8.7.3.
