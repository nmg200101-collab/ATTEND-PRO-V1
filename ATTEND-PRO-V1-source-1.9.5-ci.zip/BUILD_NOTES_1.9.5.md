# ATTEND PRO 1.9.5 — Android hardening

- Secure employee discovery: BLE plus authenticated LAN/Wi-Fi/Hotspot broadcast using the rotating HMAC payload already bound to the paired employee secret.
- BLE advertising restart gap and scanner unfiltered compatibility fallback.
- Employee native Android biometric confirmation remains the identity confirmation source; proof is sent only after success.
- Fresh GPS acquisition with timeout/fallback, mock-location rejection, and configured store radius.
- Real local acoustic voiceprint capture using AudioRecord + spectral features; no dependency on speech-to-text service for attendance verification.
- Voiceprint template/quality/timestamp stored per employee.
- Central server client retries transient failures only for safe/idempotent operations and keeps signed nonces per attempt.
- Version 1.9.5 / versionCode 25.
