package com.attendpro.core

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

object LanPresenceProtocol {
    const val PORT = 47991
    private val MAGIC = byteArrayOf(0x41, 0x50, 0x4E, 0x32) // APN2

    fun packet(payload: ByteArray): ByteArray = MAGIC + payload
    fun parse(bytes: ByteArray, length: Int): BleProtocol.Payload? {
        if (length < MAGIC.size + 10) return null
        for (i in MAGIC.indices) if (bytes[i] != MAGIC[i]) return null
        return BleProtocol.parse(bytes.copyOfRange(MAGIC.size, MAGIC.size + 10))
    }
}

class LanPresenceBroadcaster(
    private val payloadProvider: () -> ByteArray,
    private val onStatus: (String) -> Unit = {}
) {
    private val running = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        worker = Thread({
            var announced = false
            while (running.get()) {
                val ok = runCatching { sendNow() }.getOrDefault(false)
                if (ok && !announced) { announced = true; onStatus("Wi‑Fi/Hotspot جاهز لاكتشاف الهاتف") }
                try { Thread.sleep(4_000L) } catch (_: InterruptedException) { break }
            }
        }, "attend-lan-presence").apply { isDaemon = true; start() }
    }

    fun pulse() { if (running.get()) Thread({ runCatching { sendNow() } }, "attend-lan-pulse").apply { isDaemon = true; start() } }
    fun stop() { running.set(false); worker?.interrupt(); worker = null }

    private fun sendNow(): Boolean {
        val data = LanPresenceProtocol.packet(payloadProvider())
        val targets = linkedSetOf<InetAddress>()
        targets += InetAddress.getByName("255.255.255.255")
        runCatching {
            Collections.list(NetworkInterface.getNetworkInterfaces()).forEach { nif ->
                if (!nif.isUp || nif.isLoopback) return@forEach
                nif.interfaceAddresses.mapNotNullTo(targets) { it.broadcast }
            }
        }
        if (targets.isEmpty()) return false
        DatagramSocket().use { socket ->
            socket.broadcast = true
            var sent = false
            targets.forEach { address ->
                runCatching { socket.send(DatagramPacket(data, data.size, address, LanPresenceProtocol.PORT)); sent = true }
            }
            return sent
        }
    }
}

class LanPresenceListener(
    private val onPayload: (BleProtocol.Payload, Int) -> Unit,
    private val onStatus: (String) -> Unit = {}
) {
    private val running = AtomicBoolean(false)
    @Volatile private var socket: DatagramSocket? = null
    @Volatile private var worker: Thread? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        worker = Thread({
            try {
                val s = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    soTimeout = 2_000
                    bind(InetSocketAddress(LanPresenceProtocol.PORT))
                }
                socket = s
                onStatus("البحث عبر Wi‑Fi/Hotspot يعمل")
                val buffer = ByteArray(64)
                while (running.get()) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        s.receive(packet)
                        LanPresenceProtocol.parse(packet.data, packet.length)?.let { onPayload(it, -45) }
                    } catch (_: SocketTimeoutException) { /* loop so stop is responsive */ }
                }
            } catch (t: Throwable) {
                if (running.get()) onStatus("تعذر مستمع Wi‑Fi/Hotspot: ${t.message ?: "خطأ"}")
            } finally { runCatching { socket?.close() }; socket = null; running.set(false) }
        }, "attend-lan-listener").apply { isDaemon = true; start() }
    }

    fun stop() { running.set(false); runCatching { socket?.close() }; worker?.interrupt(); worker = null }
    fun isRunning(): Boolean = running.get()
}
