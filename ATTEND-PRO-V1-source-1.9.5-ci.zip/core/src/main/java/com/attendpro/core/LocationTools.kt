package com.attendpro.core

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper

object LocationTools {
    private const val MAX_FALLBACK_AGE = 3 * 60_000L

    fun hasPermission(activity: Activity): Boolean =
        activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun getFreshLocation(activity: Activity, timeoutMillis: Long = 12_000L, callback: (Location?) -> Unit) {
        if (!hasPermission(activity)) { callback(null); return }
        val manager = activity.getSystemService(LocationManager::class.java) ?: run { callback(null); return }
        val provider = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .firstOrNull { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }

        if (provider == null) { callback(bestRecent(manager)); return }
        val main = Handler(Looper.getMainLooper())
        var finished = false
        fun finish(location: Location?) {
            if (finished) return
            finished = true
            main.post { callback(location ?: bestRecent(manager)) }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val cancel = CancellationSignal()
            main.postDelayed({ if (!finished) { cancel.cancel(); finish(null) } }, timeoutMillis)
            runCatching {
                manager.getCurrentLocation(provider, cancel, activity.mainExecutor) { finish(it) }
            }.onFailure { finish(null) }
            return
        }

        @Suppress("DEPRECATION")
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) { runCatching { manager.removeUpdates(this) }; finish(location) }
            override fun onProviderDisabled(provider: String) {}
            override fun onProviderEnabled(provider: String) {}
            @Deprecated("Deprecated in API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        main.postDelayed({ if (!finished) { runCatching { manager.removeUpdates(listener) }; finish(null) } }, timeoutMillis)
        runCatching { @Suppress("DEPRECATION") manager.requestSingleUpdate(provider, listener, Looper.getMainLooper()) }
            .onFailure { finish(null) }
    }

    @SuppressLint("MissingPermission")
    private fun bestRecent(manager: LocationManager): Location? {
        val now = System.currentTimeMillis()
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
            .filter { it.time > 0L && now - it.time <= MAX_FALLBACK_AGE }
            .maxByOrNull { it.time }
    }
}
