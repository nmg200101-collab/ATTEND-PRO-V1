package com.attendpro.store

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object VoicePrintEngine {
    private const val SAMPLE_RATE = 16_000
    private const val PREFIX = "vp2:"
    private val frequencies = doubleArrayOf(120.0, 180.0, 260.0, 380.0, 520.0, 700.0, 930.0, 1200.0, 1500.0, 1850.0, 2250.0, 2700.0, 3250.0, 3900.0)

    data class Result(
        val template: String = "",
        val quality: Int = 0,
        val durationMillis: Long = 0L,
        val voicedRatio: Float = 0f,
        val error: String = ""
    )

    @SuppressLint("MissingPermission")
    fun capture(durationMillis: Long = 4_200L, callback: (Result) -> Unit) {
        Thread({
            val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) { callback(Result(error = "الميكروفون لا يوفر إعداد تسجيل صالح")); return@Thread }
            val recorder = runCatching {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuffer * 2, 8192))
            }.getOrNull()
            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder?.release(); callback(Result(error = "تعذر تهيئة الميكروفون")); return@Thread
            }
            val wanted = ((SAMPLE_RATE.toLong() * durationMillis) / 1000L).toInt()
            val samples = ShortArray(wanted)
            var offset = 0
            try {
                recorder.startRecording()
                while (offset < wanted) {
                    val n = recorder.read(samples, offset, min(2048, wanted - offset), AudioRecord.READ_BLOCKING)
                    if (n < 0) { callback(Result(error = "فشل التقاط الصوت (رمز $n)")); return@Thread }
                    if (n == 0) continue
                    offset += n
                }
            } catch (t: Throwable) {
                callback(Result(error = "تعذر التسجيل: ${t.message ?: "خطأ"}")); return@Thread
            } finally {
                runCatching { recorder.stop() }; recorder.release()
            }
            callback(analyze(samples.copyOf(offset)))
        }, "attend-voiceprint").apply { isDaemon = true; start() }
    }

    fun similarity(a: String, b: String): Float {
        val x = decode(a) ?: return 0f; val y = decode(b) ?: return 0f
        if (x.size != y.size || x.isEmpty()) return 0f
        var dot = 0.0; var nx = 0.0; var ny = 0.0
        for (i in x.indices) { dot += x[i] * y[i]; nx += x[i] * x[i]; ny += y[i] * y[i] }
        if (nx <= 1e-12 || ny <= 1e-12) return 0f
        return (dot / sqrt(nx * ny)).toFloat().coerceIn(-1f, 1f)
    }

    private fun analyze(samples: ShortArray): Result {
        if (samples.size < SAMPLE_RATE * 2) return Result(error = "العينة قصيرة جدًا")
        val frame = 400 // 25ms
        val hop = 200
        val rms = mutableListOf<Double>()
        val frames = mutableListOf<Int>()
        var clipped = 0
        for (s in samples) if (abs(s.toInt()) > 32000) clipped++
        var pos = 0
        while (pos + frame <= samples.size) {
            var sum = 0.0
            for (i in pos until pos + frame) { val v = samples[i].toDouble(); sum += v * v }
            rms += sqrt(sum / frame)
            frames += pos
            pos += hop
        }
        if (rms.isEmpty()) return Result(error = "لم تصل عينة صوتية كافية")
        val sorted = rms.sorted()
        val noise = sorted[(sorted.size * 0.20).toInt().coerceIn(0, sorted.lastIndex)]
        val gate = max(220.0, noise * 2.15)
        val voiced = frames.indices.filter { rms[it] >= gate }
        val voicedRatio = voiced.size.toFloat() / frames.size
        if (voicedRatio < 0.22f) return Result(quality = (voicedRatio * 100).toInt(), voicedRatio = voicedRatio, error = "الصوت منخفض أو لم يتم التقاط كلام واضح")

        val all = Array(frequencies.size) { mutableListOf<Double>() }
        var zcrSum = 0.0
        voiced.forEach { idx ->
            val start = frames[idx]
            var crossings = 0
            for (i in 1 until frame) if ((samples[start + i - 1] >= 0) != (samples[start + i] >= 0)) crossings++
            zcrSum += crossings.toDouble() / frame
            val logs = DoubleArray(frequencies.size) { k -> ln(1.0 + goertzel(samples, start, frame, frequencies[k])) }
            val mean = logs.average()
            val sd = sqrt(logs.sumOf { (it - mean) * (it - mean) } / logs.size).coerceAtLeast(1e-6)
            logs.indices.forEach { k -> all[k] += (logs[k] - mean) / sd }
        }
        val features = ArrayList<Float>(frequencies.size * 2 + 2)
        for (band in all) features += band.average().toFloat()
        for (band in all) {
            val m = band.average(); features += sqrt(band.sumOf { (it - m) * (it - m) } / max(1, band.size)).toFloat()
        }
        features += (zcrSum / voiced.size).toFloat()
        features += voicedRatio
        normalize(features)

        val clipRatio = clipped.toFloat() / samples.size
        val quality = (45 + voicedRatio * 45f - clipRatio * 200f).toInt().coerceIn(0, 100)
        if (quality < 45) return Result(quality = quality, voicedRatio = voicedRatio, error = "جودة العينة منخفضة؛ تكلم بوضوح وبعيدًا عن الضوضاء")
        return Result(encode(features.toFloatArray()), quality, samples.size * 1000L / SAMPLE_RATE, voicedRatio)
    }

    private fun goertzel(samples: ShortArray, start: Int, length: Int, freq: Double): Double {
        val omega = 2.0 * Math.PI * freq / SAMPLE_RATE
        val coeff = 2.0 * cos(omega)
        var s0 = 0.0; var s1 = 0.0; var s2 = 0.0
        for (i in 0 until length) {
            val w = 0.54 - 0.46 * cos(2.0 * Math.PI * i / (length - 1))
            s0 = samples[start + i] * w + coeff * s1 - s2
            s2 = s1; s1 = s0
        }
        return s1 * s1 + s2 * s2 - coeff * s1 * s2
    }

    private fun normalize(values: MutableList<Float>) {
        var n = 0.0; values.forEach { n += it * it }; val inv = if (n > 1e-9) (1.0 / sqrt(n)).toFloat() else 1f
        for (i in values.indices) values[i] *= inv
    }

    private fun encode(values: FloatArray): String {
        val bb = ByteBuffer.allocate(values.size * 4).order(ByteOrder.LITTLE_ENDIAN); values.forEach { bb.putFloat(it) }
        return PREFIX + Base64.encodeToString(bb.array(), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }

    private fun decode(text: String): FloatArray? = runCatching {
        if (!text.startsWith(PREFIX)) return@runCatching null
        val bytes = Base64.decode(text.removePrefix(PREFIX), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
        if (bytes.isEmpty() || bytes.size % 4 != 0) return@runCatching null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        FloatArray(bytes.size / 4) { bb.float }
    }.getOrNull()
}
