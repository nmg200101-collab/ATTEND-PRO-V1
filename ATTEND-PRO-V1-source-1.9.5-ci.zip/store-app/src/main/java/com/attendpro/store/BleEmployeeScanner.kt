package com.attendpro.store

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.BleProtocol
import com.attendpro.core.LanPresenceListener

class BleEmployeeScanner(
    private val activity: Activity,
    private val onPayload: (BleProtocol.Payload, Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object { const val REQUEST_PERMISSIONS = 5101 }
    private val manager = activity.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var bleScanning = false
    private var unfilteredFallback = false
    private val lan = LanPresenceListener(onPayload) { msg -> if (running) onStatus(msg) }

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) { consume(result) }
        override fun onBatchScanResults(results: MutableList<ScanResult>) { results.forEach(::consume) }
        override fun onScanFailed(errorCode: Int) {
            bleScanning = false
            if (!running) return
            if (!unfilteredFallback) {
                unfilteredFallback = true
                onStatus("إعادة محاولة BLE بوضع توافق — Wi‑Fi/Hotspot مستمر")
                handler.postDelayed({ startBle(filtered = false) }, 700L)
            } else onStatus("تعذر BLE (رمز $errorCode) — Wi‑Fi/Hotspot ما زال يعمل")
        }
    }

    private fun consume(result: ScanResult) {
        val bytes = result.scanRecord?.getServiceData(BleProtocol.SERVICE_UUID) ?: return
        BleProtocol.parse(bytes)?.let { onPayload(it, result.rssi) }
    }

    fun hasPermissions(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun requestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        activity.requestPermissions(permissions, REQUEST_PERMISSIONS)
    }

    fun start() {
        running = true
        lan.start()
        if (!hasPermissions()) {
            requestPermissions()
            onStatus("Wi‑Fi/Hotspot يعمل؛ اسمح بالبلوتوث/الأجهزة القريبة لإضافة BLE")
            return
        }
        startBle(filtered = true)
    }

    @SuppressLint("MissingPermission")
    private fun startBle(filtered: Boolean) {
        if (!running || !hasPermissions() || bleScanning) return
        val bt = adapter
        if (bt == null || !bt.isEnabled) { onStatus("Bluetooth مغلق — البحث مستمر عبر Wi‑Fi/Hotspot"); return }
        val scanner = bt.bluetoothLeScanner ?: run { onStatus("BLE Scan غير مدعوم — يستخدم Wi‑Fi/Hotspot"); return }
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        val filters = if (filtered) listOf(ScanFilter.Builder().setServiceUuid(BleProtocol.SERVICE_UUID).build()) else emptyList()
        runCatching { scanner.startScan(filters, settings, callback) }
            .onSuccess { bleScanning = true; unfilteredFallback = !filtered; onStatus("جاري اكتشاف هواتف الموظفين عبر BLE + Wi‑Fi/Hotspot") }
            .onFailure { onStatus("تعذر BLE: ${it.message ?: "خطأ"} — Wi‑Fi/Hotspot مستمر") }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (bleScanning && hasPermissions()) runCatching { adapter?.bluetoothLeScanner?.stopScan(callback) }
        bleScanning = false; unfilteredFallback = false
        lan.stop()
        onStatus("تم إيقاف البحث")
    }

    fun isScanning(): Boolean = running
}
