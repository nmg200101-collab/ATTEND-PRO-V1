package com.attendpro.employee

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.PairingProtocol
import com.attendpro.core.LocationTools
import com.attendpro.core.QrScannerActivity
import com.attendpro.core.SecretCodec
import com.attendpro.core.UiKit
import java.util.Locale

class MainActivity : Activity() {
    companion object { private const val REQUEST_SCAN_PROVISION = 8103; private const val REQUEST_GPS_PERMISSION = 8104 }

    private lateinit var identity: EmployeeIdentityStore
    private lateinit var advertiser: BlePresenceAdvertiser
    private lateinit var status: TextView
    private lateinit var profile: TextView
    private lateinit var presenceSwitch: Switch
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identity = EmployeeIdentityStore(this)
        advertiser = BlePresenceAdvertiser(this) { msg -> runOnUiThread { if (::status.isInitialized) status.text = msg } }
        buildUi()
        refreshProfile()
        if (identity.autoPresence && identity.isConfigured) startPresence()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,30)); setBackgroundColor(p.bg)
        }
        val header = UiKit.heroCard(this,p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_attend_pro); layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,76),UiKit.dp(this@MainActivity,76)) })
        header.addView(UiKit.title(this,p,"ATTEND PRO",27f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this,p,"تطبيق الموظف المساند • الإصدار 1.9.5").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        header.addView(UiKit.subtitle(this,p,"اختياري — جهاز المحل هو النظام الأساسي").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(215,255,255,255)) })
        root.addView(header)

        val state = UiKit.card(this,p)
        state.addView(UiKit.sectionLabel(this,p,"الحساب المرتبط"))
        profile = TextView(this).apply { textSize = 16f; setTextColor(p.text); setTypeface(typeface,Typeface.BOLD); gravity = Gravity.CENTER }
        status = TextView(this).apply { text="جاهز"; textSize=14f; setTextColor(p.muted); gravity=Gravity.CENTER; setPadding(0,UiKit.dp(this@MainActivity,8),0,0) }
        state.addView(profile); state.addView(status)
        root.addView(state)

        val link = UiKit.card(this,p)
        link.addView(UiKit.sectionLabel(this,p,"الربط مع جهاز المحل"))
        link.addView(UiKit.subtitle(this,p,"يضيف مسؤول المحل بياناتك كاملة، ثم يعرض لك QR واحدًا. امسحه هنا ولا تحتاج لإدخال أي بيانات يدويًا."))
        link.addView(UiKit.button(this,p,"مسح باركود الموظف من جهاز المحل").apply { setOnClickListener { scanProvision() } })
        link.addView(UiKit.button(this,p,"إلغاء الربط من هذا الهاتف",false).apply { setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle("إلغاء الربط").setMessage("سيظل الموظف موجودًا في جهاز المحل، وسيتم فقط فصل هذا الهاتف.")
                .setPositiveButton("إلغاء الربط"){_,_->advertiser.stop(); identity.clearStoreLink(); refreshProfile(); status.text="تم فصل الهاتف"}
                .setNegativeButton("رجوع",null).show()
        }})
        root.addView(link)

        val attend = UiKit.card(this,p)
        attend.addView(UiKit.sectionLabel(this,p,"ميزة الهاتف الإضافية"))
        presenceSwitch = Switch(this).apply {
            text="التعرف التلقائي عبر BLE + Wi‑Fi/Hotspot"; textSize=15f; setTextColor(p.text); isChecked=identity.autoPresence
            setOnCheckedChangeListener { _,checked -> identity.autoPresence=checked; if(checked) startPresence() else advertiser.stop() }
        }
        attend.addView(presenceSwitch)
        attend.addView(UiKit.button(this,p,"تأكيد الحضور ببصمة/وجه الهاتف").apply { setOnClickListener { requestBiometric() } })
        attend.addView(UiKit.button(this,p,"تأكيد الحضور عبر GPS", false).apply { setOnClickListener { requestGpsProof() } })
        attend.addView(UiKit.subtitle(this,p,"GPS يتحقق من وجود الهاتف داخل نطاق المحل ولا يُعد بصمة هوية. يرسل إثباتًا مؤقتًا آمنًا إلى جهاز المحل عبر BLE أو الشبكة المحلية/Hotspot. جهاز المحل يظل النظام الأساسي."))
        root.addView(attend)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun refreshProfile() {
        profile.text = if (!identity.isConfigured) "غير مرتبط" else buildString {
            append(identity.displayName).append(" • ").append(identity.employeeId).append("\n")
            if(identity.jobTitle.isNotBlank()) append(identity.jobTitle).append(" • ")
            append(identity.trustedStoreName.ifBlank { "جهاز المحل" }).append(" / ").append(identity.branchId).append("\n")
            append(String.format(Locale.getDefault(), "الدوام %02d:%02d - %02d:%02d", identity.shiftStartHour, identity.shiftStartMinute, identity.shiftEndHour, identity.shiftEndMinute))
        }
    }

    private fun scanProvision() {
        val intent = Intent(this,QrScannerActivity::class.java).putExtra(QrScannerActivity.EXTRA_PROMPT,"امسح QR الموظف الذي أنشأه جهاز المحل")
        status.text="جاري فتح الكاميرا..."
        runCatching { startActivityForResult(intent,REQUEST_SCAN_PROVISION) }.onFailure { status.text="تعذر فتح الماسح: ${it.message ?: "خطأ"}" }
    }

    private fun acceptProvision(text:String) {
        val p = PairingProtocol.decodeEmployeeProvision(text)
        if(p==null) { status.text="هذا ليس رمز موظف ATTEND PRO صالحًا"; return }
        if(p.expiresAt <= System.currentTimeMillis()) { status.text="انتهت صلاحية الرمز. اطلب رمزًا جديدًا من جهاز المحل"; return }
        if(!SecretCodec.isValid(p.pairingSecret)) { status.text="بيانات الربط غير صالحة"; return }
        identity.applyProvision(p)
        refreshProfile()
        status.text="✓ تم ربط الهاتف تلقائيًا بـ ${p.storeName}"
        if(identity.autoPresence) startPresence()
    }

    private fun startPresence() {
        if(!identity.isConfigured) { status.text="امسح باركود الموظف من جهاز المحل أولًا"; return }
        advertiser.start(identity.employeeId,identity.pairingSecret)
    }

    private fun requestBiometric() {
        if(!identity.isConfigured) { status.text="اربط الهاتف بجهاز المحل أولًا"; return }
        if(!identity.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC)) { status.text="مالك العمل لم يسمح بالحضور ببصمة/وجه الهاتف لهذا الموظف"; return }
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status.text="يلزم Android 9 أو أحدث"; return }
        if(!advertiser.isRunning()) startPresence()
        val prompt = BiometricPrompt.Builder(this).setTitle("تأكيد الحضور").setSubtitle("استخدم نظام المصادقة الحيوية الأصلي لهذا الهاتف (بصمة/وجه)")
            .setNegativeButton("إلغاء",mainExecutor){_,_->status.text="تم إلغاء التحقق"}.build()
        prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult?) { advertiser.markVerified(45_000L); status.text="✓ تم التحقق بنظام الهاتف الأصلي — أُرسل إثبات آمن لجهاز المحل" }
            override fun onAuthenticationFailed(){ status.text="لم يتم التعرف، حاول مرة أخرى" }
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence?){ status.text="تعذر التحقق: ${errString ?: "خطأ"}" }
        })
    }

    private fun requestGpsProof() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.GPS)) { status.text = "مالك العمل لم يسمح بطريقة GPS لهذا الموظف"; return }
        if (!identity.isTrustedStoreGpsConfigured) { status.text = "موقع المحل غير مضمّن في الربط. اطلب QR جديدًا بعد ضبط GPS في قسم مالك العمل"; return }
        if (!LocationTools.hasPermission(this)) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_GPS_PERMISSION)
            status.text = "اسمح بالموقع ثم أعد الضغط على GPS"
            return
        }
        status.text = "جاري الحصول على موقع حديث..."
        LocationTools.getFreshLocation(this) { location ->
            if (location == null) { status.text = "تعذر الحصول على موقع حديث. فعّل GPS وخدمة الموقع ثم أعد المحاولة"; return@getFreshLocation }
            if (isMockLocation(location)) { status.text = "تم رفض موقع تجريبي/مزيف"; return@getFreshLocation }
            val target = Location("ATTEND_PRO_STORE").apply { latitude = identity.trustedStoreLatitude; longitude = identity.trustedStoreLongitude }
            val distance = location.distanceTo(target)
            if (distance > identity.trustedStoreGpsRadius) {
                status.text = "أنت خارج نطاق المحل (${distance.toInt()}م، المسموح ${identity.trustedStoreGpsRadius}م)"
                return@getFreshLocation
            }
            if (!advertiser.isRunning()) startPresence()
            if (!advertiser.isRunning()) { status.text = "تعذر تشغيل قناة اكتشاف آمنة لإرسال إثبات GPS"; return@getFreshLocation }
            advertiser.markVerified(45_000L, BleProtocol.FLAG_GPS)
            status.text = "✓ GPS حديث (${distance.toInt()}م) — أُرسل الإثبات عبر BLE/Wi‑Fi/Hotspot"
        }
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider


    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        if(requestCode==REQUEST_SCAN_PROVISION) {
            if(resultCode==RESULT_OK) acceptProvision(data?.getStringExtra(QrScannerActivity.EXTRA_RESULT).orEmpty())
            else status.text=data?.getStringExtra(QrScannerActivity.EXTRA_ERROR) ?: "تم إلغاء المسح"
            return
        }
        super.onActivityResult(requestCode,resultCode,data)
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        when(requestCode) {
            BlePresenceAdvertiser.REQUEST_BLUETOOTH -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}) startPresence()
                else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"
            }
            REQUEST_GPS_PERMISSION -> {
                status.text = if(grantResults.any{it==PackageManager.PERMISSION_GRANTED}) "تم منح صلاحية الموقع — اضغط GPS مرة أخرى" else "لم يتم السماح بالموقع"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::advertiser.isInitialized && identity.autoPresence && identity.isConfigured && !advertiser.isRunning()) startPresence()
    }

    override fun onDestroy(){advertiser.stop();super.onDestroy()}
}
