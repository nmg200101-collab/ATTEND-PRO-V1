package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.BleProtocol
import com.attendpro.core.LanPresenceBroadcaster
import com.attendpro.core.SecretCodec

class BlePresenceAdvertiser(
    private val activity: Activity,
    private val onStatus: (String) -> Unit
) {
    companion object { const val REQUEST_BLUETOOTH = 4101 }

    private val handler = Handler(Looper.getMainLooper())
    private val manager = activity.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private var running = false
    private var bleAdvertising = false
    private var employeeId = ""
    private var secret = ByteArray(0)
    private var proofUntil = 0L
    private var proofFlags = 0
    private val lan = LanPresenceBroadcaster({ currentPayload() }) { msg -> if (running) onStatus(msg) }

    private val callback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            bleAdvertising = true
            onStatus(if (currentFlags() != 0) "تم بث إثبات التحقق عبر BLE + Wi‑Fi/Hotspot" else "الهاتف ظاهر للمحل عبر BLE + Wi‑Fi/Hotspot")
        }
        override fun onStartFailure(errorCode: Int) {
            bleAdvertising = false
            // LAN remains active even when a phone cannot advertise over BLE.
            onStatus("BLE غير متاح الآن (رمز $errorCode) — يستمر الاكتشاف عبر Wi‑Fi/Hotspot")
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (!running) return
            refreshBle()
            lan.pulse()
            handler.postDelayed(this, 12_000L)
        }
    }

    fun hasPermissions(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT), REQUEST_BLUETOOTH)
        }
    }

    fun start(employeeId: String, secretText: String) {
        val decoded = SecretCodec.decode(secretText)
        if (employeeId.isBlank() || decoded == null) { onStatus("أكمل بيانات الموظف أولاً"); return }
        this.employeeId = employeeId
        this.secret = decoded
        running = true
        lan.start()
        handler.removeCallbacks(refresher)
        handler.removeCallbacksAndMessages(BLE_REFRESH_TOKEN)
        if (hasPermissions()) refreshBle() else {
            requestPermissions()
            onStatus("Wi‑Fi/Hotspot يعمل؛ اسمح بالأجهزة القريبة لتفعيل BLE أيضًا")
        }
        handler.postDelayed(refresher, 12_000L)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(refresher)
        handler.removeCallbacksAndMessages(BLE_REFRESH_TOKEN)
        stopBleInternal()
        lan.stop()
        onStatus("تم إيقاف ظهور الهاتف للمحل")
    }

    fun markVerified(durationMillis: Long = 45_000L, proofType: Int = BleProtocol.FLAG_BIOMETRIC) {
        proofUntil = System.currentTimeMillis() + durationMillis
        proofFlags = BleProtocol.FLAG_VERIFIED or proofType
        lan.pulse()
        if (running && hasPermissions()) refreshBle()
    }

    fun isRunning(): Boolean = running
    private fun currentFlags(): Int = if (System.currentTimeMillis() < proofUntil) proofFlags else 0
    private fun currentPayload(): ByteArray = BleProtocol.buildPayload(employeeId, secret, currentFlags())

    @SuppressLint("MissingPermission")
    private fun refreshBle() {
        if (!running || !hasPermissions()) return
        val bt = adapter
        if (bt == null || !bt.isEnabled) { onStatus("فعّل Bluetooth؛ يستمر Wi‑Fi/Hotspot إن كان الهاتف على نفس الشبكة"); return }
        if (bt.bluetoothLeAdvertiser == null) { onStatus("الهاتف لا يدعم BLE Advertising؛ يستخدم Wi‑Fi/Hotspot بدلًا منه"); return }
        stopBleInternal()
        // Some Android stacks need a short gap after stopAdvertising before a restart.
        handler.removeCallbacksAndMessages(BLE_REFRESH_TOKEN)
        handler.postAtTime({ if (running && hasPermissions()) startBleInternal() }, BLE_REFRESH_TOKEN, android.os.SystemClock.uptimeMillis() + 220L)
    }

    @SuppressLint("MissingPermission")
    private fun startBleInternal() {
        val advertiser = adapter?.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false).setTimeout(0).build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false).setIncludeTxPowerLevel(false)
            .addServiceData(BleProtocol.SERVICE_UUID, currentPayload()).build()
        runCatching { advertiser.startAdvertising(settings, data, callback) }
            .onFailure { onStatus("تعذر تشغيل BLE: ${it.message ?: "خطأ"} — يستمر Wi‑Fi/Hotspot") }
    }

    @SuppressLint("MissingPermission")
    private fun stopBleInternal() {
        if (!hasPermissions()) return
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback) }
        bleAdvertising = false
    }

    private object BLE_REFRESH_TOKEN
}
