package com.attendpro.store

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt

object VoiceSignatureEngine {
    data class Capture(val template: String = "", val quality: Int = 0, val error: String = "")
    private const val RATE = 16_000

    @SuppressLint("MissingPermission")
    fun capture(callback: (Capture) -> Unit) {
        thread(name = "attend-voice-capture", isDaemon = true) {
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { callback(Capture(error = "الميكروفون غير متاح")); return@thread }
            val recorder = runCatching { AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192)) }.getOrNull()
                ?: run { callback(Capture(error = "تعذر فتح الميكروفون")); return@thread }
            val samples = ShortArray(RATE * 3)
            var offset = 0
            try {
                recorder.startRecording()
                while (offset < samples.size) {
                    val n = recorder.read(samples, offset, minOf(2048, samples.size - offset))
                    if (n <= 0) break else offset += n
                }
            } catch (e: Exception) {
                callback(Capture(error = e.message ?: "فشل تسجيل الصوت")); return@thread
            } finally {
                runCatching { recorder.stop() }; recorder.release()
            }
            if (offset < RATE) { callback(Capture(error = "التسجيل قصير جدًا")); return@thread }
            val data = samples.copyOf(offset)
            val rms = sqrt(data.sumOf { it.toDouble() * it } / data.size) / 32768.0
            if (rms < 0.012) { callback(Capture(error = "الصوت منخفض جدًا؛ اقترب من الميكروفون")); return@thread }
            val clipping = data.count { kotlin.math.abs(it.toInt()) >= 32000 }.toDouble() / data.size
            if (clipping > 0.04) { callback(Capture(error = "الصوت مرتفع ومشوّه؛ ابتعد قليلًا عن الميكروفون")); return@thread }
            val vector = signature(data)
            val quality = ((rms.coerceAtMost(0.12) / 0.12 * 70) + ((1.0 - clipping / 0.04).coerceIn(0.0, 1.0) * 30)).toInt().coerceIn(1, 100)
            callback(Capture(encode(vector), quality))
        }
    }

    fun appendTemplate(existing: String, fresh: String, maxTemplates: Int = 3): String {
        val all = (unpack(existing) + unpack(fresh)).takeLast(maxTemplates)
        return if (all.size <= 1) all.firstOrNull().orEmpty() else "vm1:" + all.joinToString("~")
    }

    fun similarity(a: String, b: String): Float = unpack(a).flatMap { x -> unpack(b).map { y -> cosine(decode(x), decode(y)) } }.maxOrNull() ?: 0f

    private fun signature(data: ShortArray): FloatArray {
        val frequencies = doubleArrayOf(120.0, 170.0, 230.0, 300.0, 380.0, 470.0, 580.0, 710.0, 860.0, 1030.0,
            1220.0, 1440.0, 1690.0, 1980.0, 2310.0, 2680.0, 3100.0, 3550.0)
        val values = FloatArray(frequencies.size + 2)
        frequencies.forEachIndexed { i, f -> values[i] = ln(1.0 + goertzel(data, f)).toFloat() }
        var crossings = 0
        for (i in 1 until data.size) if ((data[i - 1] < 0) != (data[i] < 0)) crossings++
        values[frequencies.size] = crossings.toFloat() / data.size
        values[frequencies.size + 1] = sqrt(data.sumOf { it.toDouble() * it } / data.size).toFloat() / 32768f
        val mean = values.average().toFloat(); var norm = 0.0
        for (i in values.indices) { values[i] -= mean; norm += values[i] * values[i] }
        val scale = sqrt(norm).toFloat().takeIf { it > 1e-6f } ?: 1f
        for (i in values.indices) values[i] /= scale
        return values
    }

    private fun goertzel(data: ShortArray, frequency: Double): Double {
        val coeff = 2.0 * cos(2.0 * PI * frequency / RATE); var s0: Double; var s1 = 0.0; var s2 = 0.0
        val step = maxOf(1, data.size / 24000)
        var i = 0
        while (i < data.size) { s0 = data[i] / 32768.0 + coeff * s1 - s2; s2 = s1; s1 = s0; i += step }
        return (s1 * s1 + s2 * s2 - coeff * s1 * s2).coerceAtLeast(0.0)
    }

    private fun unpack(value: String): List<String> = when {
        value.startsWith("vm1:") -> value.removePrefix("vm1:").split('~').filter { it.startsWith("vs1:") }
        value.startsWith("vs1:") -> listOf(value)
        else -> emptyList()
    }
    private fun encode(v: FloatArray): String { val b = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN); v.forEach { b.putFloat(it) }; return "vs1:" + Base64.encodeToString(b.array(), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING) }
    private fun decode(v: String): FloatArray? = runCatching { val raw = Base64.decode(v.removePrefix("vs1:"), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING); val b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN); FloatArray(raw.size / 4) { b.float } }.getOrNull()
    private fun cosine(a: FloatArray?, b: FloatArray?): Float { if (a == null || b == null || a.size != b.size) return 0f; var dot=0.0; var x=0.0; var y=0.0; for(i in a.indices){dot+=a[i]*b[i];x+=a[i]*a[i];y+=b[i]*b[i]}; return if(x<=0||y<=0)0f else (dot/sqrt(x*y)).toFloat().coerceIn(-1f,1f) }
}
