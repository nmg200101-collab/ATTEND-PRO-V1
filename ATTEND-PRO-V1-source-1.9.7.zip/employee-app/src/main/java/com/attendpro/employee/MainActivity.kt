package com.attendpro.employee

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrScannerActivity
import com.attendpro.core.SecretCodec
import com.attendpro.core.UiKit
import java.util.Locale

class MainActivity : Activity() {
    companion object { private const val REQUEST_SCAN_PROVISION = 8103; private const val REQUEST_GPS_PERMISSION = 8104 }

    private lateinit var identity: EmployeeIdentityStore
    private lateinit var advertiser: BlePresenceAdvertiser
    private lateinit var status: TextView
    private lateinit var profile: TextView
    private lateinit var presenceSwitch: Switch
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identity = EmployeeIdentityStore(this)
        advertiser = BlePresenceAdvertiser(this) { msg -> runOnUiThread { if (::status.isInitialized) status.text = msg } }
        buildUi()
        refreshProfile()
        if (identity.autoPresence && identity.isConfigured) startPresence()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,30)); setBackgroundColor(p.bg)
        }
        val header = UiKit.heroCard(this,p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_attend_pro); layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,76),UiKit.dp(this@MainActivity,76)) })
        header.addView(UiKit.title(this,p,"ATTEND PRO",27f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this,p,"تطبيق الموظف المساند • الإصدار 1.9.7").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        header.addView(UiKit.subtitle(this,p,"اختياري — جهاز المحل هو النظام الأساسي").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(215,255,255,255)) })
        root.addView(header)

        val state = UiKit.card(this,p)
        state.addView(UiKit.sectionLabel(this,p,"الحساب المرتبط"))
        profile = TextView(this).apply { textSize = 16f; setTextColor(p.text); setTypeface(typeface,Typeface.BOLD); gravity = Gravity.CENTER }
        status = TextView(this).apply { text="جاهز"; textSize=14f; setTextColor(p.muted); gravity=Gravity.CENTER; setPadding(0,UiKit.dp(this@MainActivity,8),0,0) }
        state.addView(profile); state.addView(status)
        root.addView(state)

        val link = UiKit.card(this,p)
        link.addView(UiKit.sectionLabel(this,p,"الربط مع جهاز المحل"))
        link.addView(UiKit.subtitle(this,p,"يضيف مسؤول المحل بياناتك كاملة، ثم يعرض لك QR واحدًا. امسحه هنا ولا تحتاج لإدخال أي بيانات يدويًا."))
        link.addView(UiKit.button(this,p,"مسح باركود الموظف من جهاز المحل").apply { setOnClickListener { scanProvision() } })
        link.addView(UiKit.button(this,p,"إلغاء الربط من هذا الهاتف",false).apply { setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle("إلغاء الربط").setMessage("سيظل الموظف موجودًا في جهاز المحل، وسيتم فقط فصل هذا الهاتف.")
                .setPositiveButton("إلغاء الربط"){_,_->advertiser.stop(); identity.clearStoreLink(); refreshProfile(); status.text="تم فصل الهاتف"}
                .setNegativeButton("رجوع",null).show()
        }})
        root.addView(link)

        val attend = UiKit.card(this,p)
        attend.addView(UiKit.sectionLabel(this,p,"ميزة الهاتف الإضافية"))
        presenceSwitch = Switch(this).apply {
            text="التعرف التلقائي قرب جهاز المحل عبر BLE"; textSize=15f; setTextColor(p.text); isChecked=identity.autoPresence
            setOnCheckedChangeListener { _,checked -> identity.autoPresence=checked; if(checked) startPresence() else advertiser.stop() }
        }
        attend.addView(presenceSwitch)
        attend.addView(UiKit.button(this,p,"التعرف الحيوي الأصلي للهاتف (وجه/بصمة)").apply { setOnClickListener { requestBiometric() } })
        attend.addView(UiKit.button(this,p,"إعادة تشغيل اكتشاف جهاز المحل", false).apply { setOnClickListener { advertiser.stop(); startPresence() } })
        attend.addView(UiKit.button(this,p,"تأكيد الحضور برمز الهاتف", false).apply { setOnClickListener { confirmWithLocalCredential() } })
        attend.addView(UiKit.button(this,p,"إعداد PIN / كلمة مرور الهاتف", false).apply { setOnClickListener { setupLocalCredentials() } })
        attend.addView(UiKit.button(this,p,"تأكيد الحضور عبر GPS", false).apply { setOnClickListener { requestGpsProof() } })
        attend.addView(UiKit.subtitle(this,p,"GPS يتحقق من وجود الهاتف داخل نطاق المحل ولا يُعد بصمة هوية. يرسل إثباتًا مؤقتًا إلى جهاز المحل عبر BLE. جهاز المحل يظل النظام الأساسي."))
        root.addView(attend)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun refreshProfile() {
        profile.text = if (!identity.isConfigured) "غير مرتبط" else buildString {
            append(identity.displayName).append(" • ").append(identity.employeeId).append("\n")
            if(identity.jobTitle.isNotBlank()) append(identity.jobTitle).append(" • ")
            append(identity.trustedStoreName.ifBlank { "جهاز المحل" }).append(" / ").append(identity.branchId).append("\n")
            append(String.format(Locale.getDefault(), "الدوام %02d:%02d - %02d:%02d", identity.shiftStartHour, identity.shiftStartMinute, identity.shiftEndHour, identity.shiftEndMinute))
        }
    }

    private fun scanProvision() {
        val intent = Intent(this,QrScannerActivity::class.java).putExtra(QrScannerActivity.EXTRA_PROMPT,"امسح QR الموظف الذي أنشأه جهاز المحل")
        status.text="جاري فتح الكاميرا..."
        runCatching { startActivityForResult(intent,REQUEST_SCAN_PROVISION) }.onFailure { status.text="تعذر فتح الماسح: ${it.message ?: "خطأ"}" }
    }

    private fun acceptProvision(text:String) {
        val p = PairingProtocol.decodeEmployeeProvision(text)
        if(p==null) { status.text="هذا ليس رمز موظف ATTEND PRO صالحًا"; return }
        if(p.expiresAt <= System.currentTimeMillis()) { status.text="انتهت صلاحية الرمز. اطلب رمزًا جديدًا من جهاز المحل"; return }
        if(!SecretCodec.isValid(p.pairingSecret)) { status.text="بيانات الربط غير صالحة"; return }
        identity.applyProvision(p)
        refreshProfile()
        status.text="✓ تم ربط الهاتف تلقائيًا بـ ${p.storeName}"
        if(identity.autoPresence) startPresence()
    }

    private fun startPresence() {
        if(!identity.isConfigured) { status.text="امسح باركود الموظف من جهاز المحل أولًا"; return }
        advertiser.start(identity.employeeId,identity.pairingSecret)
    }

    private fun requestBiometric() {
        if(!identity.isConfigured) { status.text="اربط الهاتف بجهاز المحل أولًا"; return }
        if(!identity.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC)) { status.text="مالك العمل لم يسمح بالحضور ببصمة/وجه الهاتف لهذا الموظف"; return }
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status.text="يلزم Android 9 أو أحدث"; return }
        if(!advertiser.isRunning()) startPresence()
        runCatching {
            val prompt = BiometricPrompt.Builder(this).setTitle("تأكيد الحضور أو الانصراف").setSubtitle("استخدم وسيلة التعرف الحيوي المسجلة في نظام الهاتف")
                .setNegativeButton("إلغاء",mainExecutor){_,_->status.text="تم إلغاء التحقق"}.build()
            prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult?) { advertiser.markVerified(45_000L); status.text="✓ تم التحقق — قرّب الهاتف من جهاز المحل" }
                override fun onAuthenticationFailed(){ status.text="لم يتم التعرف، حاول مرة أخرى" }
                override fun onAuthenticationError(errorCode:Int,errString:CharSequence?){ status.text="تعذر التحقق: ${errString ?: "لم تُسجل وسيلة حيوية في إعدادات الهاتف"}" }
            })
        }.onFailure { status.text = "تعذر فتح التعرف الحيوي: ${it.message ?: "سجّل بصمة أو وجهًا في إعدادات الهاتف"}" }
    }

    override fun onResume() {
        super.onResume()
        if (::identity.isInitialized && identity.autoPresence && identity.isConfigured && !advertiser.isRunning()) startPresence()
    }

    private fun setupLocalCredentials() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.PHONE_BIOMETRIC)) { status.text = "مالك العمل لم يسمح بتأكيد الرمز من هاتف الموظف"; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val pin = UiKit.field(this, p, "PIN جديد من 4 إلى 8 أرقام", true)
        val password = UiKit.field(this, p, "كلمة مرور جديدة - 6 أحرف على الأقل").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(pin); box.addView(password)
        val dialog = AlertDialog.Builder(this).setTitle("حماية تأكيد الحضور على هذا الهاتف").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val pinText = pin.text.toString().trim(); val passwordText = password.text.toString()
            if (pinText.isNotBlank() && !pinText.matches(Regex("\\d{4,8}"))) { pin.error = "استخدم 4-8 أرقام"; return@setOnClickListener }
            if (passwordText.isNotBlank() && passwordText.length < 6) { password.error = "استخدم 6 أحرف على الأقل"; return@setOnClickListener }
            if (pinText.isBlank() && passwordText.isBlank()) { pin.error = "أدخل PIN أو كلمة مرور"; return@setOnClickListener }
            if (pinText.isNotBlank()) identity.confirmationPinHash = PairingProtocol.pinHash(pinText)
            if (passwordText.isNotBlank()) identity.confirmationPasswordHash = PairingProtocol.pinHash(passwordText)
            status.text = "✓ تم حفظ وسيلة التأكيد محليًا على هذا الهاتف"; dialog.dismiss()
        } }
        dialog.show()
    }

    private fun confirmWithLocalCredential() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.PHONE_BIOMETRIC)) { status.text = "مالك العمل لم يسمح بتأكيد الرمز من هاتف الموظف"; return }
        if (identity.confirmationPinHash.isBlank() && identity.confirmationPasswordHash.isBlank()) { setupLocalCredentials(); return }
        val value = UiKit.field(this, p, "أدخل PIN أو كلمة المرور").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val dialog = AlertDialog.Builder(this).setTitle("تأكيد الحضور من هاتف الموظف").setView(value).setPositiveButton("تأكيد", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val entered = value.text.toString()
            val valid = (identity.confirmationPinHash.isNotBlank() && PairingProtocol.matchesPin(identity.confirmationPinHash, entered)) ||
                (identity.confirmationPasswordHash.isNotBlank() && PairingProtocol.matchesPin(identity.confirmationPasswordHash, entered))
            if (!valid) { value.error = "الرمز أو كلمة المرور غير صحيحة"; return@setOnClickListener }
            if (!advertiser.isRunning()) startPresence()
            if (!advertiser.isRunning()) { status.text = "تعذر تشغيل BLE لإرسال التأكيد"; return@setOnClickListener }
            advertiser.markVerified(60_000L, BleProtocol.FLAG_CREDENTIAL)
            status.text = "✓ تم التأكيد — قرّب الهاتف من جهاز المحل"; dialog.dismiss()
        } }
        dialog.show()
    }

    private fun requestGpsProof() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.GPS)) { status.text = "مالك العمل لم يسمح بطريقة GPS لهذا الموظف"; return }
        if (!identity.isTrustedStoreGpsConfigured) { status.text = "موقع المحل غير مضمّن في الربط. اطلب QR جديدًا بعد ضبط GPS في قسم مالك العمل"; return }
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_GPS_PERMISSION)
            status.text = "اسمح بالموقع ثم أعد الضغط على GPS"
            return
        }
        val manager = getSystemService(LocationManager::class.java)
        if (manager == null) { status.text = "خدمة الموقع غير متاحة على هذا الهاتف"; return }
        status.text = "جاري طلب موقع حديث ودقيق..."
        requestFreshLocation(manager) { location, error ->
            if (location == null) { status.text = error ?: "تعذر الحصول على موقع حديث"; return@requestFreshLocation }
            if (isMockLocation(location)) { status.text = "تم رفض موقع تجريبي/مزيف"; return@requestFreshLocation }
            val target = Location("ATTEND_PRO_STORE").apply { latitude = identity.trustedStoreLatitude; longitude = identity.trustedStoreLongitude }
            val distance = location.distanceTo(target)
            val accuracyAllowance = location.accuracy.takeIf { it.isFinite() }?.coerceIn(0f, 100f) ?: 0f
            if (distance > identity.trustedStoreGpsRadius + accuracyAllowance) {
                status.text = "أنت خارج نطاق المحل (${distance.toInt()}م، النطاق ${identity.trustedStoreGpsRadius}م، دقة الهاتف ${location.accuracy.toInt()}م)"
                return@requestFreshLocation
            }
            if (!advertiser.isRunning()) startPresence()
            if (!advertiser.isRunning()) { status.text = "تعذر تشغيل BLE لإرسال إثبات GPS"; return@requestFreshLocation }
            advertiser.markVerified(45_000L, BleProtocol.FLAG_GPS)
            status.text = "✓ تم التحقق من GPS (${distance.toInt()}م، دقة ${location.accuracy.toInt()}م) — قرّب الهاتف من جهاز المحل"
        }
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider

    private fun bestLastLocation(manager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }

    @Suppress("MissingPermission")
    private fun requestFreshLocation(manager: LocationManager, callback: (Location?, String?) -> Unit) {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) { callback(null, "فعّل الموقع واختر الدقة العالية ثم أعد المحاولة"); return }
        val delivered = java.util.concurrent.atomic.AtomicBoolean(false)
        var best: Location? = null
        lateinit var listener: LocationListener
        fun finish(location: Location?, error: String? = null) {
            if (delivered.compareAndSet(false, true)) {
                runCatching { manager.removeUpdates(listener) }
                runOnUiThread { callback(location, error) }
            }
        }
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (System.currentTimeMillis() - location.time > 2 * 60_000L) return
                if (best == null || location.accuracy < best!!.accuracy) best = location
                if (location.hasAccuracy() && location.accuracy <= 35f) finish(location)
            }
            @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
            override fun onProviderEnabled(provider: String) = Unit
            override fun onProviderDisabled(provider: String) = Unit
        }
        providers.forEach { provider -> runCatching { manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper()) } }
        Handler(Looper.getMainLooper()).postDelayed({
            val fallback = best ?: bestLastLocation(manager)?.takeIf { System.currentTimeMillis() - it.time <= 10 * 60_000L }
            finish(fallback, if (fallback == null) "لم يصل موقع صالح. فعّل دقة الموقع العالية وافتح GPS خارج المبنى للحظات" else null)
        }, 25_000L)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        if(requestCode==REQUEST_SCAN_PROVISION) {
            if(resultCode==RESULT_OK) acceptProvision(data?.getStringExtra(QrScannerActivity.EXTRA_RESULT).orEmpty())
            else status.text=data?.getStringExtra(QrScannerActivity.EXTRA_ERROR) ?: "تم إلغاء المسح"
            return
        }
        super.onActivityResult(requestCode,resultCode,data)
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        when(requestCode) {
            BlePresenceAdvertiser.REQUEST_BLUETOOTH -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}) startPresence()
                else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"
            }
            REQUEST_GPS_PERMISSION -> {
                status.text = if(grantResults.any{it==PackageManager.PERMISSION_GRANTED}) "تم منح صلاحية الموقع — اضغط GPS مرة أخرى" else "لم يتم السماح بالموقع"
            }
        }
    }

    override fun onDestroy(){advertiser.stop();super.onDestroy()}
}
