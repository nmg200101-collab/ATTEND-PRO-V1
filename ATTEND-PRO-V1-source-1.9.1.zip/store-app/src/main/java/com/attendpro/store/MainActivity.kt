package com.attendpro.store

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.content.FileProvider
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.CentralServerClient
import com.attendpro.core.DeviceIdentity
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var storeSummary: TextView
    private var pendingFaceEmployeeId: String? = null
    private var pendingFaceRecognition: Boolean = false
    private var pendingFaceCapturePath: String? = null
    private var pendingVoiceEmployeeId: String? = null
    private var pendingVoiceChallenge: String? = null
    private val autoPresenceRecorded = mutableSetOf<String>()
    @Volatile private var syncInProgress = false
    private var employeeManagerMode = false
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        val employeeManagerRequested = intent?.getBooleanExtra(EXTRA_EMPLOYEE_MANAGER, false) == true
        employeeManagerMode = employeeManagerRequested && repo.validateStoreAdminSession(intent?.getStringExtra(EXTRA_STORE_ADMIN_SESSION).orEmpty())
        pendingFaceEmployeeId = savedInstanceState?.getString("pendingFaceEmployeeId")
        pendingFaceRecognition = savedInstanceState?.getBoolean("pendingFaceRecognition", false) ?: false
        pendingFaceCapturePath = savedInstanceState?.getString("pendingFaceCapturePath")
        pendingVoiceEmployeeId = savedInstanceState?.getString("pendingVoiceEmployeeId")
        pendingVoiceChallenge = savedInstanceState?.getString("pendingVoiceChallenge")
        scanner = BleEmployeeScanner(this, ::handleBlePayload) { msg ->
            runOnUiThread { if (::status.isInitialized) status.text = msg }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingFaceEmployeeId?.let { outState.putString("pendingFaceEmployeeId", it) }
        outState.putBoolean("pendingFaceRecognition", pendingFaceRecognition)
        pendingFaceCapturePath?.let { outState.putString("pendingFaceCapturePath", it) }
        pendingVoiceEmployeeId?.let { outState.putString("pendingVoiceEmployeeId", it) }
        pendingVoiceChallenge?.let { outState.putString("pendingVoiceChallenge", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (!repo.isCentralActivationActive()) {
            runCatching { scanner.stop() }
            buildActivationLockUi()
            if (repo.hasCentralCredentials() && repo.serverUrl.isNotBlank()) validateCentralActivation(silent = true)
            return
        }
        if (employeeManagerMode) {
            buildEmployeeManagerUi()
            refreshDashboard()
            validateCentralActivation(silent = true)
            return
        }
        buildUi()
        refreshDashboard()
        if (repo.allowEmployeeCompanion && repo.autoScan && repo.employees().any { it.active && it.companionEnabled }) {
            runCatching { scanner.start() }.onFailure { if (::status.isInitialized) status.text = "تعذر تشغيل BLE: ${it.message ?: "خطأ"}" }
        }
        validateCentralActivation(silent = true)
        autoSyncIfReady()
    }

    private fun buildActivationLockUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val hero = UiKit.heroCard(this, p)
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 72), UiKit.dp(this@MainActivity, 72)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        hero.addView(UiKit.title(this, p, "ATTEND PRO", 28f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        hero.addView(UiKit.subtitle(this, p, "تفعيل مركزي محمي • الإصدار 1.9.1").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        root.addView(hero)

        val lock = UiKit.card(this, p)
        lock.addView(UiKit.statusBadge(this, p, "المحل غير مفعّل", false))
        lock.addView(UiKit.title(this, p, "يتطلب موافقة صاحب النظام", 23f).apply { gravity = Gravity.CENTER })
        val reason = when {
            repo.centralClockRollbackDetected() -> "تم اكتشاف اختلاف غير آمن في ساعة الجهاز. صحح التاريخ والوقت ثم أعد التحقق من الخادم."
            repo.centralServerStatus == "SUSPENDED" -> "تم تعليق هذا المحل مركزيًا من صاحب النظام. لا يمكن تسجيل حضور أو إدارة الموظفين حتى إعادة التفعيل."
            repo.centralServerStatus == "EXPIRED" -> "انتهت مدة التفعيل المركزي لهذا المحل. يلزم تجديدها من صاحب النظام."
            repo.hasCentralCredentials() && repo.centralLeaseUntil <= System.currentTimeMillis() -> "انتهت مهلة العمل دون اتصال. يلزم الاتصال بالخادم للتحقق من صلاحية المحل."
            repo.centralActivationRequestId.isNotBlank() -> "تم إرسال طلب التفعيل وهو بانتظار اعتماد صاحب النظام."
            else -> "لن تعمل الحضور والموظفون والتقارير التشغيلية قبل اعتماد هذا الجهاز من الخادم المركزي."
        }
        lock.addView(UiKit.subtitle(this, p, reason).apply { gravity = Gravity.CENTER; setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0) })
        root.addView(lock)

        val identity = UiKit.card(this, p)
        identity.addView(UiKit.sectionLabel(this, p, "بيانات طلب التفعيل"))
        identity.addView(UiKit.title(this, p, repo.storeName, 20f))
        identity.addView(UiKit.subtitle(this, p, "الفرع: ${repo.branchId}\nمعرف الجهاز: ${repo.storeId}\nالخادم: ${repo.serverUrl.ifBlank { "غير محدد" }}"))
        identity.addView(UiKit.button(this, p, "إعداد بيانات المحل والخادم", false).apply { setOnClickListener { editActivationSetup() } })
        root.addView(identity)

        val activation = UiKit.card(this, p)
        activation.addView(UiKit.sectionLabel(this, p, "التفعيل المركزي"))
        if (repo.centralActivationRequestId.isBlank() && !repo.hasCentralCredentials()) {
            activation.addView(UiKit.button(this, p, "إرسال طلب التفعيل لصاحب النظام").apply { setOnClickListener { requestCentralActivation() } })
        } else if (repo.centralActivationRequestId.isNotBlank()) {
            activation.addView(UiKit.button(this, p, "فحص موافقة صاحب النظام").apply { setOnClickListener { checkCentralActivation() } })
            activation.addView(UiKit.subtitle(this, p, "رقم الطلب: ${repo.centralActivationRequestId}"))
        }
        if (repo.hasCentralCredentials()) {
            activation.addView(UiKit.button(this, p, "التحقق من صلاحية المحل الآن").apply { setOnClickListener { validateCentralActivation(silent = false) } })
        }
        status = TextView(this).apply { text = "بانتظار التفعيل المركزي"; textSize = 15f; setTextColor(p.muted); gravity = Gravity.CENTER; setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0) }
        activation.addView(status)
        root.addView(activation)

        val receiverCard = UiKit.card(this, p, 13)
        receiverCard.addView(UiKit.sectionLabel(this, p, "هاتف المراقبة"))
        receiverCard.addView(UiKit.subtitle(this, p, "يمكن استخدام هذا الهاتف لاستلام تقارير محل آخر دون تفعيله كجهاز محل."))
        receiverCard.addView(UiKit.button(this, p, "فتح استلام التقارير", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportReceiverActivity::class.java)) } })
        root.addView(receiverCard)

        val systemOwner = UiKit.card(this, p, 12)
        systemOwner.addView(UiKit.sectionLabel(this, p, "صاحب نظام ATTEND PRO"))
        systemOwner.addView(UiKit.subtitle(this, p, "إدارة الاعتمادات المركزية تتطلب مفتاح إدارة الخادم، وهي منفصلة عن صلاحيات صاحب المحل."))
        systemOwner.addView(UiKit.button(this, p, "دخول إدارة صاحب النظام", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, SystemSettingsActivity::class.java)) } })
        root.addView(systemOwner)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun editActivationSetup() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), 0) }
        val name = UiKit.field(this, p, "اسم المحل").apply { setText(if (repo.storeName == "جهاز المحل") "" else repo.storeName) }
        val branch = UiKit.field(this, p, "اسم / رمز الفرع").apply { setText(repo.branchId) }
        val server = UiKit.field(this, p, "https://your-server.example.com").apply { setText(repo.serverUrl) }
        box.addView(name); box.addView(branch); box.addView(server)
        val d = AlertDialog.Builder(this).setTitle("إعداد التفعيل المركزي").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val n = name.text.toString().trim(); val b = branch.text.toString().trim(); val u = server.text.toString().trim()
            if (n.length < 2) { name.error = "أدخل اسم المحل"; return@setOnClickListener }
            if (b.isBlank()) { branch.error = "أدخل الفرع"; return@setOnClickListener }
            if (!u.startsWith("https://")) { server.error = "الخادم يجب أن يستخدم HTTPS"; return@setOnClickListener }
            repo.storeName = n; repo.branchId = b; repo.serverUrl = u
            d.dismiss(); buildActivationLockUi()
        } }
        d.show()
    }

    private fun validateCentralActivation(silent: Boolean) {
        if (repo.serverUrl.isBlank() || !repo.hasCentralCredentials()) { if (!silent) info("التفعيل المركزي", "بيانات الخادم أو الترخيص المركزي غير مكتملة."); return }
        if (::status.isInitialized && !silent) status.text = "جاري التحقق الآمن من الخادم..."
        Thread {
            val result = CentralServerClient.validateStore(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this))
            runOnUiThread {
                if (result.isFailure) {
                    if (!silent && ::status.isInitialized) status.text = "تعذر التحقق: ${result.exceptionOrNull()?.message ?: "خطأ اتصال"}"
                    return@runOnUiThread
                }
                val v = result.getOrThrow()
                if (v.status.equals("ACTIVE", true)) {
                    val wasLocked = !repo.isCentralActivationActive()
                    repo.refreshCentralLease("ACTIVE", v.expiresAt, v.maxEmployees, v.leaseUntil, v.serverTime)
                    if (!repo.isCentralActivationActive()) {
                        repo.markCentralInactive("VALIDATION_REQUIRED", v.serverTime)
                        buildActivationLockUi()
                        if (!silent) info("التفعيل المركزي", "استجابة الخادم لم تمنح مهلة تشغيل صالحة. حدّث الخادم المركزي إلى الإصدار المتوافق مع 1.9.1.")
                    } else if (wasLocked || !silent) {
                        employeeManagerMode = false
                        buildUi(); refreshDashboard()
                        if (!silent) info("التفعيل المركزي", "تم التحقق من صلاحية المحل بنجاح.")
                    }
                } else {
                    repo.markCentralInactive(v.status, v.serverTime)
                    runCatching { scanner.stop() }
                    buildActivationLockUi()
                    if (!silent) info("تم إيقاف التشغيل", v.reason.ifBlank { "حالة المحل على الخادم: ${v.status}" })
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val header = UiKit.heroCard(this, p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 64), UiKit.dp(this@MainActivity, 64))
        })
        header.addView(UiKit.title(this, p, "ATTEND PRO", 27f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this, p, "نظام حضور المحل • الإصدار 1.9.1").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        storeSummary = UiKit.subtitle(this, p, storeSummaryText()).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(235,255,255,255)); setPadding(0, UiKit.dp(this@MainActivity, 5), 0, 0) }
        header.addView(storeSummary)
        root.addView(header)

        if (!repo.isStoreProfileComplete) {
            val setup = UiKit.card(this, p, 13)
            setup.addView(UiKit.sectionLabel(this, p, "إكمال إعداد المحل"))
            setup.addView(UiKit.subtitle(this, p, "أكمل معلومات المحل من «قسم مالك العمل» قبل التشغيل الفعلي.").apply { gravity = Gravity.CENTER })
            setup.addView(UiKit.button(this, p, "فتح قسم مالك العمل", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, StoreSettingsActivity::class.java)) } })
            root.addView(setup)
        }

        val dash = UiKit.card(this, p)
        dash.addView(UiKit.sectionLabel(this, p, "ملخص اليوم"))
        counts = TextView(this).apply { textSize = 18f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        dash.addView(counts)
        root.addView(dash)

        val attendanceHub = UiKit.card(this, p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        attendanceHub.addView(UiKit.sectionLabel(this, p, "مركز الحضور الذكي"))
        attendanceHub.addView(UiKit.subtitle(this, p, "اضغط على موضع البصمة ثم اختر الطريقة المسموح بها للموظف. يمكن للهاتف الموثوق أن يتعرف تلقائيًا عبر BLE حسب إعدادات مالك العمل.").apply { gravity = Gravity.CENTER })
        val attendanceButton = TextView(this).apply {
            text = "◎\nبصمة الحضور\nاضغط للتسجيل"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(p.primary)
                setStroke(UiKit.dp(this@MainActivity, 4), p.accent)
            }
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 220), UiKit.dp(this@MainActivity, 220)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = UiKit.dp(this@MainActivity, 14)
                bottomMargin = UiKit.dp(this@MainActivity, 14)
            }
            setOnClickListener { showAttendanceMethods() }
        }
        attendanceHub.addView(attendanceButton)
        attendanceHub.addView(UiKit.subtitle(this, p, "وجه • تحقق صوتي • بصمة خارجية • بصمة/وجه الهاتف • GPS • PIN • كلمة مرور • نقش").apply { gravity = Gravity.CENTER })
        attendanceHub.addView(UiKit.sectionLabel(this, p, "اختصارات طرق الحضور"))
        fun quickRow(vararg items: Pair<String, () -> Unit>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            items.forEach { (label, action) ->
                row.addView(UiKit.button(this, p, label, false).apply {
                    layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 52), 1f).apply { marginStart = UiKit.dp(this@MainActivity, 4); marginEnd = UiKit.dp(this@MainActivity, 4); bottomMargin = UiKit.dp(this@MainActivity, 8) }
                    setOnClickListener { action() }
                })
            }
            attendanceHub.addView(row)
        }
        val quickMethods = mutableListOf<Pair<String, () -> Unit>>()
        if (repo.allowFaceEnrollment) quickMethods += "بصمة الوجه" to { requestFaceRecognition() }
        if (repo.allowVoiceVerification) quickMethods += "التحقق الصوتي" to { showVoiceDialog() }
        if (repo.allowGpsVerification) quickMethods += "GPS" to { showGpsDialog() }
        if (repo.allowPinFallback) quickMethods += "PIN" to { showPinDialog() }
        if (repo.allowPasswordFallback) quickMethods += "كلمة مرور" to { showPasswordDialog() }
        if (repo.allowPatternFallback) quickMethods += "النقش" to { showPatternDialog() }
        if (repo.allowExternalFingerprint) quickMethods += "بصمة خارجية" to { quickFingerprintCheck() }
        if (repo.allowEmployeeCompanion) quickMethods += "هاتف الموظف" to {
            if (scanner.isScanning()) { scanner.stop(); status.text = "تم إيقاف البحث عن هواتف الموظفين" }
            else { scanner.start(); status.text = if (repo.requirePhoneBiometric) "جاري البحث — يحتاج الموظف تأكيد بصمة/وجه هاتفه" else "جاري البحث عن الهواتف الموثوقة" }
        }
        quickMethods.chunked(2).forEach { pair -> quickRow(*pair.toTypedArray()) }
        attendanceHub.addView(UiKit.button(this, p, "عرض جميع طرق الحضور", false).apply { setOnClickListener { showAttendanceMethods() } })
        root.addView(attendanceHub)

        val quick = UiKit.card(this, p, 12)
        quick.addView(UiKit.sectionLabel(this, p, "الوصول السريع"))
        quick.addView(UiKit.button(this, p, "التقارير", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportsActivity::class.java)) } })
        quick.addView(UiKit.button(this, p, "استلام التقارير على هذا الهاتف", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportReceiverActivity::class.java)) } })
        root.addView(quick)

        val admin = UiKit.card(this, p)
        admin.addView(UiKit.sectionLabel(this, p, "قسم مالك العمل"))
        admin.addView(UiKit.subtitle(this, p, "قسم محمي لصاحب المحل لإدارة معلومات المحل والموظفين وطرق الحضور والتقارير والمشاركة والمزامنة."))
        admin.addView(UiKit.button(this, p, "قسم مالك العمل 🔒").apply { setOnClickListener { startActivity(Intent(this@MainActivity, StoreSettingsActivity::class.java)) } })
        root.addView(admin)

        val activation = UiKit.card(this, p, 13)
        activation.addView(UiKit.sectionLabel(this, p, "التفعيل والمزامنة"))
        val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(repo.centralActivationExpiresAt))
        val lease = if (repo.centralLeaseUntil > 0L) SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(repo.centralLeaseUntil)) else "-"
        activation.addView(UiKit.statusBadge(this, p, "مفعّل مركزيًا", true))
        activation.addView(UiKit.subtitle(this, p, "الصلاحية حتى $date • مهلة العمل دون اتصال حتى $lease • حد الموظفين ${repo.centralMaxEmployees} • المزامنة المعلقة ${repo.pendingEvents().size}").apply { gravity = Gravity.CENTER })
        activation.addView(UiKit.button(this, p, "بيانات التفعيل المركزي", false).apply { setOnClickListener { showLicenseDetails() } })
        root.addView(activation)

        val live = UiKit.card(this, p)
        live.addView(UiKit.sectionLabel(this, p, "حالة النظام"))
        status = TextView(this).apply { text = "جاهز"; textSize = 16f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { textSize = 14f; setTextColor(p.muted); setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0); gravity = Gravity.CENTER }
        live.addView(status); live.addView(nearbyView)
        root.addView(live)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun buildEmployeeManagerUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 28)); setBackgroundColor(p.bg)
        }
        val header = UiKit.card(this, p)
        header.addView(UiKit.sectionLabel(this, p, "قسم مالك العمل"))
        header.addView(UiKit.title(this, p, "الموظفون وملفات التعرف", 24f))
        header.addView(UiKit.subtitle(this, p, "إضافة وتعديل الموظفين وتحديد طرق حضور مستقلة لكل موظف: PIN، كلمة مرور، نقش، تحقق صوتي، GPS، بصمة خارجية، الوجه، وهاتف الموظف."))
        root.addView(header)

        val summaryCard = UiKit.card(this, p)
        counts = TextView(this).apply { textSize = 17f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        summaryCard.addView(counts)
        root.addView(summaryCard)

        val actions = UiKit.card(this, p)
        actions.addView(UiKit.button(this, p, "＋ إضافة موظف جديد").apply { setOnClickListener { showEmployeeEditor(null) } })
        actions.addView(UiKit.button(this, p, "عرض الموظفين وتعديلهم", false).apply { setOnClickListener { showEmployeesDialog() } })
        actions.addView(UiKit.button(this, p, "شرح طرق التعرف", false).apply { setOnClickListener { showFaceEngineInfo() } })
        root.addView(actions)

        val recognitions = UiKit.card(this, p)
        val employees = repo.employees().filter { it.active }
        recognitions.addView(UiKit.sectionLabel(this, p, "جاهزية طرق التعرف"))
        recognitions.addView(UiKit.subtitle(this, p, "PIN ${employees.count { it.pin.isNotBlank() }} • كلمة مرور ${employees.count { it.passwordHash.isNotBlank() }} • نقش ${employees.count { it.patternHash.isNotBlank() }} • صوت ${employees.count { it.voicePhraseHash.isNotBlank() }}\nوجه أولي ${employees.count { it.faceProfileRef.isNotBlank() }} • بصمة خارجية ${employees.count { it.externalFingerprintId.isNotBlank() }} • هاتف ${employees.count { it.companionEnabled }}"))
        root.addView(recognitions)

        val state = UiKit.card(this, p, 10)
        status = TextView(this).apply { text = "جاهز لإدارة الموظفين"; textSize = 15f; setTextColor(p.text); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { text = ""; textSize = 13f; setTextColor(p.muted); gravity = Gravity.CENTER }
        state.addView(status); state.addView(nearbyView)
        state.addView(UiKit.button(this, p, "رجوع إلى إعدادات المحل", false).apply { setOnClickListener { finish() } })
        root.addView(state)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun autoSyncIfReady() {
        if (!repo.reportAutoSync || syncInProgress || repo.serverUrl.isBlank() || !repo.isCentralActivationActive()) return
        val pending = repo.pendingEvents()
        syncInProgress = true
        Thread {
            val result = CentralServerClient.syncEventsCentral(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this), pending.take(200))
            if (repo.isCentralActivationActive()) {
                CentralServerClient.confirmedTransfers(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this)).getOrNull()?.forEach { repo.confirmReportTransferTrusted(it) }
            }
            runOnUiThread {
                syncInProgress = false
                if (result.isSuccess) {
                    repo.markSynced(result.getOrThrow())
                    repo.lastSyncAt = System.currentTimeMillis()
                    repo.lastSyncMessage = "تمت المزامنة"
                    if (::status.isInitialized && result.getOrThrow().isNotEmpty()) status.text = "✓ تمت مزامنة ${result.getOrThrow().size} عملية"
                } else {
                    val message = result.exceptionOrNull()?.message ?: "خطأ"
                    repo.lastSyncMessage = "فشلت: $message"
                    if (message.contains("موقوف") || message.contains("غير صالح") || message.contains("انتهت")) {
                        repo.markCentralInactive(if (message.contains("انتهت")) "EXPIRED" else "SUSPENDED")
                        runCatching { scanner.stop() }
                        buildActivationLockUi()
                    }
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun storeSummaryText(): String {
        val parts = mutableListOf<String>()
        parts.add(repo.storeName)
        parts.add("فرع ${repo.branchId}")
        if (repo.storePhone.isNotBlank()) parts.add(repo.storePhone)
        return parts.joinToString(" • ")
    }

    private fun showActivationCenter() {
        val items = mutableListOf<String>()
        if (repo.centralActivationRequestId.isBlank() && !repo.hasCentralCredentials()) items.add("إرسال طلب تفعيل مركزي")
        if (repo.centralActivationRequestId.isNotBlank()) items.add("فحص موافقة صاحب النظام")
        if (repo.hasCentralCredentials()) items.add("التحقق من صلاحية المحل الآن")
        if (repo.isCentralActivationActive()) items.add("عرض بيانات التفعيل المركزي")
        items.add("إعداد بيانات المحل والخادم")
        items.add("نسخ معرّف جهاز المحل")
        AlertDialog.Builder(this).setTitle("التفعيل المركزي — ATTEND PRO").setItems(items.toTypedArray()) { _, which ->
            when (items[which]) {
                "إرسال طلب تفعيل مركزي" -> requestCentralActivation()
                "فحص موافقة صاحب النظام" -> checkCentralActivation()
                "التحقق من صلاحية المحل الآن" -> validateCentralActivation(silent = false)
                "عرض بيانات التفعيل المركزي" -> showLicenseDetails()
                "إعداد بيانات المحل والخادم" -> editActivationSetup()
                "نسخ معرّف جهاز المحل" -> copyActivationText(repo.storeId, "تم نسخ معرّف الجهاز")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun requestCentralActivation() {
        if (repo.serverUrl.isBlank()) {
            val field = UiKit.field(this, p, "https://server.example.com")
            val d = AlertDialog.Builder(this).setTitle("عنوان الخادم المركزي").setMessage("أدخل رابط HTTPS الذي زودك به مدير نظام ATTEND PRO.").setView(field).setPositiveButton("متابعة", null).setNegativeButton("إلغاء", null).create()
            d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val url = field.text.toString().trim()
                if (!url.startsWith("https://")) { field.error = "يجب استخدام HTTPS"; return@setOnClickListener }
                repo.serverUrl = url; d.dismiss(); submitCentralActivationRequest()
            } }
            d.show(); return
        }
        submitCentralActivationRequest()
    }

    private fun submitCentralActivationRequest() {
        status.text = "جاري إرسال طلب التفعيل المركزي..."
        Thread {
            val r = CentralServerClient.requestActivation(repo.serverUrl, repo.storeId, repo.storeName, repo.branchId, DeviceIdentity(this))
            runOnUiThread {
                if (r.isSuccess) {
                    val x = r.getOrThrow(); repo.centralActivationRequestId = x.requestId; repo.centralActivationPollSecret = x.pollSecret
                    status.text = "✓ تم إرسال طلب التفعيل المركزي"
                    AlertDialog.Builder(this).setTitle("تم إرسال الطلب").setMessage("رقم الطلب: ${x.requestId}\n\nسيظهر الطلب في لوحة صاحب النظام. بعد اعتماده اضغط «فحص حالة طلب التفعيل المركزي». لا ترسل سر الطلب لأي شخص.").setPositiveButton("حسنًا", null).show()
                    buildActivationLockUi()
                } else {
                    status.text = "تعذر إرسال طلب التفعيل"
                    AlertDialog.Builder(this).setTitle("تعذر الاتصال بالخادم").setMessage(r.exceptionOrNull()?.message ?: "خطأ").setPositiveButton("حسنًا", null).show()
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun checkCentralActivation() {
        val requestId = repo.centralActivationRequestId; val pollSecret = repo.centralActivationPollSecret
        if (requestId.isBlank() || pollSecret.isBlank()) { AlertDialog.Builder(this).setTitle("التفعيل المركزي").setMessage("لا يوجد طلب مركزي محفوظ على هذا الجهاز.").setPositiveButton("حسنًا", null).show(); return }
        status.text = "جاري التحقق من التفعيل..."
        Thread {
            val r = CentralServerClient.activationStatus(repo.serverUrl, requestId, pollSecret, repo.storeId, DeviceIdentity(this))
            runOnUiThread {
                if (r.isFailure) { status.text = "تعذر فحص التفعيل"; AlertDialog.Builder(this).setTitle("الخادم المركزي").setMessage(r.exceptionOrNull()?.message ?: "خطأ").setPositiveButton("حسنًا", null).show(); return@runOnUiThread }
                val x = r.getOrThrow()
                when (x.status.uppercase(Locale.US)) {
                    "APPROVED", "ACTIVE" -> {
                        if (x.accessToken.isBlank() || x.licenseId.isBlank() || x.leaseUntil <= System.currentTimeMillis() || x.serverTime <= 0L) {
                            status.text = "استجابة تفعيل غير مكتملة"
                            AlertDialog.Builder(this).setTitle("تحديث الخادم مطلوب").setMessage("الخادم لم يرسل مهلة تشغيل آمنة. استخدم خادم ATTEND PRO المركزي المتوافق مع الإصدار 1.9.1.").setPositiveButton("حسنًا", null).show()
                            return@runOnUiThread
                        }
                        repo.saveCentralActivation(x.licenseId, x.accessToken, x.expiresAt, x.maxEmployees, x.leaseUntil, x.serverTime)
                        status.text = "✓ تم تفعيل المحل مركزيًا"; buildUi(); refreshDashboard()
                        AlertDialog.Builder(this).setTitle("تم التفعيل المركزي ✓").setMessage("أصبح هذا الجهاز مرتبطًا بالخادم. ستعمل مزامنة الحضور والتقارير عن بعد مع استمرار التسجيل محليًا عند انقطاع الإنترنت.").setPositiveButton("حسنًا", null).show()
                    }
                    "REJECTED", "SUSPENDED" -> { status.text = "طلب التفعيل غير نشط"; AlertDialog.Builder(this).setTitle("حالة التفعيل").setMessage(x.reason.ifBlank { x.status }).setPositiveButton("حسنًا", null).show() }
                    else -> { status.text = "طلب التفعيل بانتظار اعتماد صاحب النظام"; AlertDialog.Builder(this).setTitle("بانتظار الاعتماد").setMessage("لم يعتمد صاحب النظام الطلب بعد.").setPositiveButton("حسنًا", null).show() }
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun showLicenseDetails() {
        if (!repo.hasCentralCredentials()) {
            AlertDialog.Builder(this).setTitle("حالة التفعيل").setMessage("لا يوجد تفعيل مركزي محفوظ على هذا الجهاز.").setPositiveButton("حسنًا", null).show()
            return
        }
        val expires = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(repo.centralActivationExpiresAt))
        val lease = if (repo.centralLeaseUntil > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(repo.centralLeaseUntil)) else "غير متاح"
        AlertDialog.Builder(this).setTitle("بيانات التفعيل المركزي")
            .setMessage("المحل: ${repo.storeName}\nالفرع: ${repo.branchId}\nرقم الترخيص: ${repo.centralLicenseId}\nالحالة: ${repo.centralServerStatus}\nانتهاء الاشتراك: $expires\nمهلة العمل دون اتصال: $lease\nحد الموظفين: ${repo.centralMaxEmployees}\nالجهاز: ${repo.storeId}\nالخادم: ${repo.serverUrl}\n\nرمز الوصول محفوظ مشفرًا داخل Android Keystore ولا يظهر في الواجهة.")
            .setPositiveButton("تحقق الآن") { _, _ -> validateCentralActivation(silent = false) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun copyActivationText(text: String, message: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("ATTEND PRO", text))
        if (::status.isInitialized) status.text = message
    }

    private fun showAttendanceMethods(){
        val actions=mutableListOf<Pair<String,()->Unit>>()
        if(repo.allowPinFallback) actions.add("PIN" to { showPinDialog() })
        if(repo.allowPasswordFallback) actions.add("كلمة المرور" to { showPasswordDialog() })
        if(repo.allowPatternFallback) actions.add("النقش 3×3" to { showPatternDialog() })
        if(repo.allowVoiceVerification) actions.add("بصمة الصوت / العبارة الصوتية" to { showVoiceDialog() })
        if(repo.allowGpsVerification) actions.add("GPS + PIN" to { showGpsDialog() })
        if(repo.allowEmployeeCompanion) actions.add("التعرف على هاتف الموظف" to {
            if(scanner.isScanning()){scanner.stop();status.text="تم إيقاف البحث عن هواتف الموظفين"}
            else{scanner.start();status.text=if(repo.requirePhoneBiometric)"جاري البحث — يحتاج الموظف تأكيد بصمة/وجه هاتفه" else "جاري البحث — سيتم تسجيل الهاتف الموثوق مرة واحدة عند الاقتراب"}
        })
        if(repo.allowExternalFingerprint) actions.add("بصمة الإصبع عبر الجهاز الخارجي" to { quickFingerprintCheck() })
        if(repo.allowFaceEnrollment) actions.add("بصمة الوجه" to { requestFaceRecognition() })
        if(actions.isEmpty()) {
            AlertDialog.Builder(this).setTitle("طرق الحضور").setMessage("لا توجد طريقة حضور مفعلة. افتح قسم مالك العمل ← طرق الحضور والتحقق.").setPositiveButton("حسنًا",null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("اختر طريقة الحضور").setItems(actions.map{it.first}.toTypedArray()){_,which->actions[which].second()}.setNegativeButton("إغلاق",null).show()
    }

    private fun showFaceEngineInfo(){
        AlertDialog.Builder(this).setTitle("التعرف بالوجه على جهاز المحل")
            .setMessage("في 1.9.1 تُفتح الكاميرا بصلاحية واضحة وصورة كاملة، ويشترط النظام وجود وجه واحد وجودة مناسبة ثم ينشئ قالبًا محليًا للمطابقة. عند الحضور يقارن الوجه بالقوالب المسجلة ويقبل فقط الدرجة الواضحة غير الملتبسة. هذا تحسين فعلي محلي، لكنه لا يحل محل نموذج FaceNet/MobileFaceNet وفحص حيوية احترافي في النسخة التجارية النهائية.")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun quickFingerprintCheck(){
        if(repo.fingerprintHost.isBlank()){status.text="أدخل بيانات قارئ البصمة من قسم مالك العمل أولًا";return}
        status.text="جاري اختبار قارئ البصمة..."
        Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{
            status.text=if(r.isSuccess)"✓ قارئ البصمة متصل — استيراد البصمات يحتاج Driver الموديل" else "تعذر الاتصال بالقارئ: ${r.exceptionOrNull()?.message ?: "خطأ"}"
        }}.start()
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees()
        val labels=mutableListOf("＋ إضافة موظف جديد")
        labels.addAll(employees.map{"${if(it.active)"●" else "○"} ${it.displayName} (${it.employeeId})${if(it.jobTitle.isNotBlank())" • ${it.jobTitle}" else ""}"})
        AlertDialog.Builder(this).setTitle("الموظفون (${employees.size})").setItems(labels.toTypedArray()){_,which->
            if(which==0) showEmployeeEditor(null) else showEmployeeDetails(employees[which-1])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showEmployeeEditor(existing: PairedEmployee?) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)

        box.addView(UiKit.subtitle(this, p, "حدد بيانات الموظف ثم طرق الحضور المسموح بها له. الحقول الجديدة الفارغة عند التعديل تُبقي بيانات التحقق الحالية دون تغيير."))
        val id = UiKit.field(this, p, "رقم الموظف").apply { setText(existing?.employeeId.orEmpty()); isEnabled = existing == null }
        val name = UiKit.field(this, p, "اسم الموظف").apply { setText(existing?.displayName.orEmpty()) }
        val phone = UiKit.field(this, p, "رقم الهاتف - اختياري").apply { setText(existing?.phone.orEmpty()) }
        val job = UiKit.field(this, p, "المسمى الوظيفي").apply { setText(existing?.jobTitle.orEmpty()) }
        val department = UiKit.field(this, p, "القسم / الإدارة - اختياري").apply { setText(existing?.department.orEmpty()) }
        val nationalId = UiKit.field(this, p, "رقم الهوية - اختياري").apply { setText(existing?.nationalId.orEmpty()) }
        val hireDate = UiKit.field(this, p, "تاريخ التعيين - اختياري").apply { setText(existing?.hireDate.orEmpty()) }
        val branch = UiKit.field(this, p, "الفرع").apply { setText(existing?.branchId ?: repo.branchId) }
        listOf(id, name, phone, job, department, nationalId, hireDate, branch).forEach { box.addView(it) }

        box.addView(UiKit.sectionLabel(this, p, "وقت دوام الموظف"))
        val customShift = CheckBox(this).apply {
            text = "استخدام دوام مستقل لهذا الموظف"; setTextColor(p.text); isChecked = existing?.useCustomShift ?: false
        }
        val startHour = UiKit.field(this, p, "ساعة بداية الدوام 0-23", true).apply { setText((existing?.shiftStartHour ?: repo.shiftHour).toString()) }
        val startMinute = UiKit.field(this, p, "دقيقة البداية", true).apply { setText((existing?.shiftStartMinute ?: repo.shiftMinute).toString()) }
        val endHour = UiKit.field(this, p, "ساعة انتهاء الدوام 0-23", true).apply { setText((existing?.shiftEndHour ?: repo.shiftEndHour).toString()) }
        val endMinute = UiKit.field(this, p, "دقيقة الانتهاء", true).apply { setText((existing?.shiftEndMinute ?: repo.shiftEndMinute).toString()) }
        box.addView(customShift); listOf(startHour, startMinute, endHour, endMinute).forEach { box.addView(it) }
        box.addView(UiKit.subtitle(this, p, "إذا لم تفعل الدوام المستقل سيستخدم الموظف وقت الدوام العام للمحل."))

        box.addView(UiKit.sectionLabel(this, p, "بيانات التحقق"))
        val pin = UiKit.field(this, p, "PIN جديد 4-8 أرقام - اتركه فارغًا للإبقاء الحالي", true)
        val password = UiKit.field(this, p, "كلمة مرور جديدة - اتركها فارغة للإبقاء الحالي").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val pattern = UiKit.field(this, p, "نقش 3×3 كتسلسل 1-9 مثل 12589 - اتركه فارغًا للإبقاء الحالي", true)
        val voicePhrase = UiKit.field(this, p, "عبارة التحقق الصوتي الجديدة - اتركها فارغة للإبقاء الحالي")
        val fingerprint = UiKit.field(this, p, "معرف الموظف في قارئ البصمة - اختياري").apply { setText(existing?.externalFingerprintId.orEmpty()) }
        listOf(pin, password, pattern, voicePhrase, fingerprint).forEach { box.addView(it) }
        box.addView(UiKit.subtitle(this, p, "التحقق الصوتي يستخدم العبارة المسجلة مع كلمة تحدٍ متغيرة وثقة التعرف لتقليل إعادة تشغيل تسجيل قديم. ملف الوجه أصبح يفحص وجود وجه واحد وجودة الصورة ويكوّن قالب مطابقة محليًا. للمستوى التجاري الأعلى سيظل من الأفضل لاحقًا إضافة نموذج FaceNet/MobileFaceNet وSpeaker Verification متخصص."))

        box.addView(UiKit.sectionLabel(this, p, "طرق الحضور المسموح بها لهذا الموظف"))
        fun currentAllowed(method: AttendanceMethod, globalEnabled: Boolean): Boolean {
            if (!globalEnabled) return false
            return existing?.let { it.allowedMethods.isEmpty() || it.allows(method) } ?: true
        }
        fun methodCheck(label: String, method: AttendanceMethod, globalEnabled: Boolean): CheckBox = CheckBox(this).apply {
            text = label; setTextColor(p.text); isChecked = currentAllowed(method, globalEnabled); isEnabled = globalEnabled
            if (!globalEnabled) text = "$label — معطل من إعدادات المحل"
        }
        val methodChecks = linkedMapOf(
            AttendanceMethod.PIN to methodCheck("PIN", AttendanceMethod.PIN, repo.allowPinFallback),
            AttendanceMethod.PASSWORD to methodCheck("كلمة المرور", AttendanceMethod.PASSWORD, repo.allowPasswordFallback),
            AttendanceMethod.PATTERN to methodCheck("النقش 3×3", AttendanceMethod.PATTERN, repo.allowPatternFallback),
            AttendanceMethod.VOICE_PHRASE to methodCheck("بصمة الصوت / العبارة الصوتية", AttendanceMethod.VOICE_PHRASE, repo.allowVoiceVerification),
            AttendanceMethod.GPS to methodCheck("GPS + PIN", AttendanceMethod.GPS, repo.allowGpsVerification),
            AttendanceMethod.SHARED_DEVICE_FACE to methodCheck("ملف الوجه على جهاز المحل", AttendanceMethod.SHARED_DEVICE_FACE, repo.allowFaceEnrollment),
            AttendanceMethod.EXTERNAL_FINGERPRINT to methodCheck("بصمة الإصبع عبر الجهاز الخارجي", AttendanceMethod.EXTERNAL_FINGERPRINT, repo.allowExternalFingerprint),
            AttendanceMethod.PHONE_BLE_BIOMETRIC to methodCheck("بصمة/وجه هاتف الموظف", AttendanceMethod.PHONE_BLE_BIOMETRIC, repo.allowEmployeeCompanion),
            AttendanceMethod.PHONE_PROXIMITY to methodCheck("التعرف التلقائي على هاتف الموظف", AttendanceMethod.PHONE_PROXIMITY, repo.allowEmployeeCompanion)
        )
        methodChecks.values.forEach { box.addView(it) }

        val faceEnroll = CheckBox(this).apply {
            text = if (existing?.faceProfileRef.isNullOrBlank()) "تسجيل بصمة الوجه بعد الحفظ" else "تحديث بصمة الوجه بعد الحفظ"
            setTextColor(p.text); isChecked = false; isEnabled = repo.allowFaceEnrollment
        }
        val companion = CheckBox(this).apply {
            text = "السماح بربط تطبيق الموظف بهذا الهاتف"; setTextColor(p.text)
            isChecked = (existing?.companionEnabled ?: true) && repo.allowEmployeeCompanion
            isEnabled = repo.allowEmployeeCompanion
        }
        box.addView(faceEnroll); box.addView(companion)
        val notes = UiKit.field(this, p, "ملاحظات - اختياري").apply { setText(existing?.notes.orEmpty()); minLines = 2 }
        box.addView(notes)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة موظف" else "تعديل الموظف")
            .setView(scroll).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employeeId = id.text.toString().trim(); val displayName = name.text.toString().trim()
                if (employeeId.isBlank() || displayName.isBlank()) {
                    id.error = if (employeeId.isBlank()) "مطلوب" else null; name.error = if (displayName.isBlank()) "مطلوب" else null; return@setOnClickListener
                }
                if (existing == null && repo.employees().size >= repo.effectiveEmployeeLimit()) {
                    AlertDialog.Builder(this).setTitle("حد الموظفين").setMessage("الترخيص الحالي يسمح بحد أقصى ${repo.effectiveEmployeeLimit()} موظفين.").setPositiveButton("حسنًا", null).show(); return@setOnClickListener
                }
                if (existing == null && repo.employees().any { it.employeeId.equals(employeeId, true) }) { id.error = "رقم الموظف مستخدم بالفعل"; return@setOnClickListener }
                val newPin = pin.text.toString().trim()
                if (newPin.isNotBlank() && (newPin.length !in 4..8 || newPin.any { !it.isDigit() })) { pin.error = "استخدم 4 إلى 8 أرقام"; return@setOnClickListener }
                val newPassword = password.text.toString()
                if (newPassword.isNotBlank() && newPassword.length < 4) { password.error = "استخدم 4 أحرف/أرقام على الأقل"; return@setOnClickListener }
                val sh = startHour.text.toString().toIntOrNull(); val sm = startMinute.text.toString().toIntOrNull()
                val eh = endHour.text.toString().toIntOrNull(); val em = endMinute.text.toString().toIntOrNull()
                if (sh == null || sh !in 0..23) { startHour.error = "0 إلى 23"; return@setOnClickListener }
                if (sm == null || sm !in 0..59) { startMinute.error = "0 إلى 59"; return@setOnClickListener }
                if (eh == null || eh !in 0..23) { endHour.error = "0 إلى 23"; return@setOnClickListener }
                if (em == null || em !in 0..59) { endMinute.error = "0 إلى 59"; return@setOnClickListener }
                val newPattern = pattern.text.toString().trim()
                if (newPattern.isNotBlank() && (newPattern.length !in 4..9 || newPattern.any { it !in '1'..'9' } || newPattern.toSet().size != newPattern.length)) {
                    pattern.error = "استخدم 4-9 نقاط مختلفة من 1 إلى 9"; return@setOnClickListener
                }
                val selectedMethods = methodChecks.filterValues { it.isChecked }.keys.map { it.name }.toSet()
                if (selectedMethods.isEmpty()) { info("طرق الحضور", "فعّل طريقة حضور واحدة على الأقل لهذا الموظف."); return@setOnClickListener }

                val secret = existing?.pairingSecret?.takeIf { SecretCodec.isValid(it) } ?: SecretCodec.encode(SecretCodec.generate())
                val pinHash = if (newPin.isBlank()) existing?.pin.orEmpty() else PairingProtocol.pinHash(newPin)
                val passwordHash = if (newPassword.isBlank()) existing?.passwordHash.orEmpty() else PairingProtocol.pinHash(newPassword)
                val patternHash = if (newPattern.isBlank()) existing?.patternHash.orEmpty() else PairingProtocol.pinHash(newPattern)
                val phraseNormalized = normalizeVoicePhrase(voicePhrase.text.toString())
                val voiceHash = if (phraseNormalized.isBlank()) existing?.voicePhraseHash.orEmpty() else PairingProtocol.pinHash(phraseNormalized)
                if (AttendanceMethod.PIN.name in selectedMethods && pinHash.isBlank()) { pin.error = "أدخل PIN لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.PASSWORD.name in selectedMethods && passwordHash.isBlank()) { password.error = "أدخل كلمة مرور لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.PATTERN.name in selectedMethods && patternHash.isBlank()) { pattern.error = "أدخل نقشًا لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.VOICE_PHRASE.name in selectedMethods && voiceHash.isBlank()) { voicePhrase.error = "أدخل العبارة الصوتية لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.EXTERNAL_FINGERPRINT.name in selectedMethods && fingerprint.text.toString().trim().isBlank()) { fingerprint.error = "أدخل معرف البصمة الخارجية أو عطّل هذه الطريقة مؤقتًا"; return@setOnClickListener }
                val phoneMethodSelected = AttendanceMethod.PHONE_BLE_BIOMETRIC.name in selectedMethods || AttendanceMethod.PHONE_PROXIMITY.name in selectedMethods
                if (phoneMethodSelected && !companion.isChecked) { info("هاتف الموظف", "فعّل «السماح بربط تطبيق الموظف» لأن إحدى طرق الهاتف مفعلة لهذا الموظف."); return@setOnClickListener }
                if (AttendanceMethod.GPS.name in selectedMethods && !companion.isChecked && pinHash.isBlank()) { pin.error = "GPS على جهاز المحل يحتاج PIN؛ أو فعّل تطبيق الموظف لاستخدام GPS من هاتفه"; return@setOnClickListener }
                val employee = PairedEmployee(
                    employeeId = employeeId, displayName = displayName,
                    branchId = branch.text.toString().trim().ifBlank { repo.branchId }, pairingSecret = secret,
                    pin = pinHash, phone = phone.text.toString().trim(), jobTitle = job.text.toString().trim(),
                    externalFingerprintId = fingerprint.text.toString().trim(), faceProfileRef = existing?.faceProfileRef.orEmpty(),
                    companionEnabled = companion.isChecked, active = existing?.active ?: true,
                    department = department.text.toString().trim(), nationalId = nationalId.text.toString().trim(), hireDate = hireDate.text.toString().trim(),
                    notes = notes.text.toString().trim(), faceCapturedAt = existing?.faceCapturedAt ?: 0L,
                    passwordHash = passwordHash, patternHash = patternHash, voicePhraseHash = voiceHash, allowedMethods = selectedMethods,
                    useCustomShift = customShift.isChecked, shiftStartHour = sh, shiftStartMinute = sm, shiftEndHour = eh, shiftEndMinute = em,
                    faceTemplate = existing?.faceTemplate.orEmpty(), faceQualityScore = existing?.faceQualityScore ?: 0
                )
                repo.upsertEmployee(employee); status.text = "✓ تم حفظ ${employee.displayName}"; refreshDashboard(); dialog.dismiss()
                when { faceEnroll.isChecked -> requestFaceCapture(employee); employee.companionEnabled -> askShowProvision(employee) }
            }
        }
        dialog.show()
    }

    private fun askShowProvision(e:PairedEmployee){
        AlertDialog.Builder(this).setTitle("تم حفظ الموظف").setMessage("هل تريد الآن عرض QR تطبيق الموظف؟ هذه الخطوة اختيارية؛ الموظف مسجل في جهاز المحل حتى لو لم يستخدم التطبيق.")
            .setPositiveButton("عرض QR"){_,_->showProvisionQr(e)}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showEmployeeDetails(e: PairedEmployee) {
        val faceDate = if (e.faceCapturedAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(e.faceCapturedAt)) else ""
        val msg = buildString {
            append("الرقم: ${e.employeeId}\nالاسم: ${e.displayName}\nالفرع: ${e.branchId}")
            append("\nالدوام: ${employeeShiftLabel(e)}")
            if (e.jobTitle.isNotBlank()) append("\nالمسمى: ${e.jobTitle}")
            if (e.department.isNotBlank()) append("\nالقسم: ${e.department}")
            if (e.phone.isNotBlank()) append("\nالهاتف: ${e.phone}")
            if (e.nationalId.isNotBlank()) append("\nالهوية: ${e.nationalId}")
            if (e.hireDate.isNotBlank()) append("\nتاريخ التعيين: ${e.hireDate}")
            append("\nPIN: ${if (e.pin.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nكلمة المرور: ${if (e.passwordHash.isBlank()) "غير مضافة" else "مضافة"}")
            append("\nالنقش: ${if (e.patternHash.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nالتحقق الصوتي: ${if (e.voicePhraseHash.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nقارئ البصمة: ${e.externalFingerprintId.ifBlank { "غير مربوط" }}")
            append("\nالوجه: ${if (e.faceProfileRef.isBlank()) "غير مسجل" else "مسجل${if (faceDate.isNotBlank()) " • $faceDate" else ""}${if (e.faceTemplate.isNotBlank()) " • قالب جاهز ${e.faceQualityScore}/100" else " • يحتاج تحديث"}"}")
            append("\nتطبيق الموظف: ${if (e.companionEnabled) "مسموح" else "معطل"}")
            append("\nطرق الحضور: ${allowedMethodsArabic(e)}")
            append("\nالحالة: ${if (e.active) "نشط" else "موقوف"}")
            if (e.notes.isNotBlank()) append("\nملاحظات: ${e.notes}")
        }

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 12))
        }
        scroll.addView(box)
        box.addView(UiKit.subtitle(this, p, msg).apply {
            setPadding(0, 0, 0, UiKit.dp(this@MainActivity, 10))
        })

        lateinit var dialog: AlertDialog
        fun addAction(label: String, primary: Boolean = false, action: () -> Unit) {
            box.addView(UiKit.button(this, p, label, primary).apply {
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            })
        }

        addAction("✎ تعديل بيانات الموظف", true) { showEmployeeEditor(e) }
        if (repo.allowFaceEnrollment && e.allows(AttendanceMethod.SHARED_DEVICE_FACE)) addAction("تسجيل / تحديث بصمة الوجه") { requestFaceCapture(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("عرض صورة بصمة الوجه") { showFaceReference(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("حذف بصمة الوجه") { deleteFaceReference(e) }
        if (e.companionEnabled) addAction("عرض QR تطبيق الموظف") { showProvisionQr(e) }
        addAction("تسجيل يدوي بإشراف") { recordManual(e) }
        addAction(if (e.active) "إيقاف الموظف" else "تفعيل الموظف") {
            repo.upsertEmployee(e.copy(active = !e.active))
            status.text = "تم تحديث حالة ${e.displayName}"
            refreshDashboard()
        }
        addAction("حذف الموظف") {
            AlertDialog.Builder(this).setTitle("حذف الموظف").setMessage("حذف ${e.displayName} من جهاز المحل؟ لن تحذف سجلات الحضور السابقة.")
                .setPositiveButton("حذف") { _, _ ->
                    deleteFaceFile(e.faceProfileRef)
                    repo.removeEmployee(e.employeeId)
                    status.text = "تم حذف الموظف"
                    refreshDashboard()
                }
                .setNegativeButton("إلغاء", null).show()
        }

        dialog = AlertDialog.Builder(this)
            .setTitle("ملف الموظف — ${e.displayName}")
            .setView(scroll)
            .setNegativeButton("إغلاق", null)
            .create()
        dialog.show()
    }

    private fun requestFaceCapture(employee: PairedEmployee) {
        pendingFaceEmployeeId = employee.employeeId
        pendingFaceRecognition = false
        ensureCameraAndLaunch()
    }

    private fun requestFaceRecognition() {
        val candidates = repo.employees().filter { it.active && it.allows(AttendanceMethod.SHARED_DEVICE_FACE) && it.faceTemplate.isNotBlank() }
        if (candidates.isEmpty()) {
            info("بصمة الوجه", "لا يوجد موظف لديه قالب وجه جاهز. افتح قسم مالك العمل ← الموظفون ثم حدّث وجه الموظف مرة واحدة على الأقل.")
            return
        }
        pendingFaceEmployeeId = null
        pendingFaceRecognition = true
        ensureCameraAndLaunch()
    }

    private fun ensureCameraAndLaunch() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
            if (::status.isInitialized) status.text = "اسمح بالكاميرا لإكمال بصمة الوجه"
            return
        }
        launchFaceCamera()
    }

    private fun launchFaceCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val dir = File(cacheDir, "face_capture").apply { mkdirs() }
        val file = File(dir, "face_${System.currentTimeMillis()}.jpg")
        pendingFaceCapturePath = file.absolutePath
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        cameraIntent.clipData = ClipData.newRawUri("ATTEND PRO face capture", uri)
        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // بعض تطبيقات الكاميرا تتجاهل اختيار العدسة؛ هذه الإشارة تفضّل الأمامية دون الاعتماد عليها.
        cameraIntent.putExtra("android.intent.extras.CAMERA_FACING", 1)
        runCatching { startActivityForResult(cameraIntent, REQUEST_FACE_CAPTURE) }.onFailure {
            clearPendingFaceCapture()
            if (::status.isInitialized) status.text = "تعذر فتح الكاميرا: ${it.message ?: "خطأ"}"
            info("تعذر تسجيل الوجه", "لم يتمكن Android من فتح تطبيق الكاميرا. تحقق من وجود تطبيق كاميرا ومنح الصلاحية ثم أعد المحاولة. لم تتأثر بيانات الموظف.")
        }
    }

    private fun clearPendingFaceCapture(deleteTemp: Boolean = true) {
        if (deleteTemp) pendingFaceCapturePath?.let { runCatching { File(it).delete() } }
        pendingFaceCapturePath = null
        pendingFaceEmployeeId = null
        pendingFaceRecognition = false
    }

    private fun decodeFaceBitmap(path: String): Bitmap? {
        val bitmap = BitmapFactory.decodeFile(path) ?: return null
        val orientation = runCatching { android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL) }.getOrDefault(android.media.ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bitmap
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun showFaceReference(employee: PairedEmployee) {
        val path = employee.faceProfileRef
        val bitmap = if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        if (bitmap == null) {
            status.text = "صورة الوجه غير متاحة"
            return
        }
        val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; setPadding(12, 12, 12, 12) }
        AlertDialog.Builder(this).setTitle("بصمة الوجه — ${employee.displayName}").setView(image)
            .setMessage("هذه الصورة المرجعية محفوظة محليًا وتُستخدم مع قالب الوجه للمطابقة المحلية. جودة المطابقة تعتمد على الإضاءة وزاوية الوجه، ولا تُعد بديلًا عن محرك عصبي مع فحص حيوية في النسخة التجارية النهائية.")
            .setPositiveButton("إغلاق", null).show()
    }

    private fun deleteFaceReference(employee: PairedEmployee) {
        deleteFaceFile(employee.faceProfileRef)
        repo.upsertEmployee(employee.copy(faceProfileRef = "", faceCapturedAt = 0L, faceTemplate = "", faceQualityScore = 0))
        status.text = "تم حذف بصمة الوجه لـ ${employee.displayName}"
    }

    private fun deleteFaceFile(path: String) {
        if (path.isNotBlank()) runCatching { File(path).takeIf { it.exists() }?.delete() }
    }

    private fun showProvisionQr(employee:PairedEmployee){
        val provision=repo.newProvision(employee)
        val content=PairingProtocol.encodeEmployeeProvision(provision)
        val qr=runCatching{QrCodeTools.bitmap(content,680)}.getOrElse{status.text="تعذر إنشاء QR: ${it.message ?: "خطأ"}";return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(20,12,20,8)}
        box.addView(TextView(this).apply{text="افتح تطبيق الموظف → مسح باركود الموظف. سيتم إدخال البيانات والربط تلقائيًا. الرمز صالح 30 دقيقة.";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.text)})
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        AlertDialog.Builder(this).setTitle("رمز ${employee.displayName}").setView(box).setPositiveButton("إغلاق",null).show()
    }

    private fun recordManual(e:PairedEmployee){
        if (!ensureOperationalActivation()) return
        val action=nextAction(e.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=e.employeeId,employeeName=e.displayName,branchId=e.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.SUPERVISOR_OVERRIDE,deviceId=deviceId(),verified=true))
        status.text="✓ ${e.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} بإشراف";refreshDashboard()
    }

    private fun showPinDialog() {
        showCredentialDialog("التسجيل عبر PIN", "PIN", AttendanceMethod.PIN) { e -> e.pin }
    }

    private fun showPasswordDialog() {
        showCredentialDialog("التسجيل بكلمة المرور", "كلمة المرور", AttendanceMethod.PASSWORD) { e -> e.passwordHash }
    }

    private fun showPatternDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val entered = StringBuilder()
        val pointButtons = mutableListOf<android.widget.Button>()
        val indicator = TextView(this).apply {
            text = "النقش: لم يُدخل بعد"; textSize = 16f; setTextColor(p.text); gravity = Gravity.CENTER
            setPadding(0, UiKit.dp(this@MainActivity, 8), 0, UiKit.dp(this@MainActivity, 8))
        }
        fun refreshPattern() {
            indicator.error = null
            indicator.text = if (entered.isEmpty()) "النقش: لم يُدخل بعد" else "النقش: " + "● ".repeat(entered.length).trim()
        }
        box.addView(UiKit.subtitle(this, p, "اضغط نقاط الشبكة بالترتيب. كل نقطة تستخدم مرة واحدة، مثل نقش قفل الهاتف."))
        box.addView(id); box.addView(indicator)
        for (row in 0..2) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            for (col in 0..2) {
                val number = row * 3 + col + 1
                val button = UiKit.button(this, p, "●", false).apply {
                    contentDescription = "النقطة $number"
                    layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 52), 1f).apply {
                        marginStart = UiKit.dp(this@MainActivity, 4); marginEnd = UiKit.dp(this@MainActivity, 4); bottomMargin = UiKit.dp(this@MainActivity, 8)
                    }
                    setOnClickListener {
                        val c = ('0'.code + number).toChar()
                        if (c !in entered) { entered.append(c); isEnabled = false; refreshPattern() }
                    }
                }
                pointButtons.add(button); line.addView(button)
            }
            box.addView(line)
        }
        box.addView(UiKit.button(this, p, "مسح النقش", false).apply {
            setOnClickListener { entered.clear(); pointButtons.forEach { it.isEnabled = true }; refreshPattern() }
        })
        val dialog = AlertDialog.Builder(this).setTitle("التسجيل بالنقش").setView(box).setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.PATTERN)) { id.error = "النقش غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.patternHash.isBlank()) { id.error = "لم يتم تعيين نقش لهذا الموظف"; return@setOnClickListener }
                if (entered.length !in 4..9) { indicator.error = "أدخل 4 نقاط على الأقل"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(employee.patternHash, entered.toString())) { indicator.error = "النقش غير صحيح"; return@setOnClickListener }
                recordVerified(employee, AttendanceMethod.PATTERN); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showCredentialDialog(title: String, credentialLabel: String, method: AttendanceMethod, stored: (PairedEmployee) -> String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val credential = UiKit.field(this, p, credentialLabel, method == AttendanceMethod.PIN).apply {
            if (method == AttendanceMethod.PASSWORD) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(id); box.addView(credential)
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(method)) { credential.error = "هذه الطريقة غير مسموحة لهذا الموظف"; return@setOnClickListener }
                val saved = stored(employee)
                if (saved.isBlank()) { credential.error = "لم يتم إعداد $credentialLabel لهذا الموظف"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(saved, credential.text.toString())) { credential.error = "$credentialLabel غير صحيح"; return@setOnClickListener }
                recordVerified(employee, method); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showVoiceDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        box.addView(UiKit.subtitle(this, p, "سيطلب Android نطق العبارة المسجلة ثم كلمة تحدٍ متغيرة. يتحقق النظام من العبارة والتحدي وثقة التعرف لتقليل قبول تسجيل صوتي قديم. هذا تحقّق صوتي محسّن، وليس بعدُ محرك Speaker Verification عصبيًا مستقلاً."))
        box.addView(id)
        val dialog = AlertDialog.Builder(this).setTitle("بصمة الصوت / العبارة الصوتية").setView(box).setPositiveButton("بدء الاستماع", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.VOICE_PHRASE)) { id.error = "التحقق الصوتي غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.voicePhraseHash.isBlank()) { id.error = "لم يتم إعداد عبارة صوتية لهذا الموظف"; return@setOnClickListener }
                pendingVoiceEmployeeId = employee.employeeId
                val challenge = listOf("شمس", "قمر", "نهر", "باب", "نور", "كتاب").random()
                pendingVoiceChallenge = challenge
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "انطق عبارتك المسجلة ثم قل كلمة: $challenge")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }
                runCatching { startActivityForResult(intent, REQUEST_VOICE_VERIFY) }.onSuccess { dialog.dismiss() }.onFailure {
                    pendingVoiceEmployeeId = null
                    info("التحقق الصوتي", "لا توجد خدمة تعرف صوتي متاحة على هذا الجهاز: ${it.message ?: "خطأ"}")
                }
            }
        }
        dialog.show()
    }

    private fun showGpsDialog() {
        if (!repo.isGpsConfigured) {
            info("GPS غير مضبوط", "افتح قسم مالك العمل ← إعداد GPS وموقع المحل، ثم أدخل إحداثيات المحل ونطاق السماح.")
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val pin = UiKit.field(this, p, "PIN", true)
        box.addView(UiKit.subtitle(this, p, "GPS يثبت الموقع فقط ولا يثبت هوية الشخص، لذلك يستخدم هنا مع PIN الموظف."))
        box.addView(id); box.addView(pin)
        val dialog = AlertDialog.Builder(this).setTitle("الحضور عبر GPS + PIN").setView(box).setPositiveButton("تحقق وتسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.GPS)) { pin.error = "GPS غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.pin.isBlank() || !PairingProtocol.matchesPin(employee.pin, pin.text.toString())) { pin.error = "PIN غير صحيح أو غير مضاف"; return@setOnClickListener }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_GPS_PERMISSION)
                    status.text = "اسمح بالموقع ثم أعد محاولة GPS"
                    return@setOnClickListener
                }
                val locationManager = getSystemService(LocationManager::class.java) ?: run {
                    pin.error = "خدمة الموقع غير متاحة على هذا الجهاز"
                    return@setOnClickListener
                }
                val location = bestLastLocation(locationManager)
                if (location == null) {
                    pin.error = "تعذر الحصول على الموقع. فعّل GPS وانتظر قليلًا ثم حاول مجددًا"
                    return@setOnClickListener
                }
                if (System.currentTimeMillis() - location.time > 10 * 60_000L) {
                    pin.error = "الموقع المتاح قديم. افتح خدمة الموقع وانتظر تحديث GPS ثم أعد المحاولة"
                    return@setOnClickListener
                }
                if (isMockLocation(location)) { pin.error = "تم رفض موقع تجريبي/مزيف"; return@setOnClickListener }
                val target = Location("ATTEND_PRO_STORE").apply { latitude = repo.storeLatitude; longitude = repo.storeLongitude }
                val distance = location.distanceTo(target)
                if (distance > repo.gpsRadiusMeters) {
                    pin.error = "أنت خارج نطاق المحل (${distance.toInt()}م، المسموح ${repo.gpsRadiusMeters}م)"
                    return@setOnClickListener
                }
                recordVerified(employee, AttendanceMethod.GPS, "GPS ${distance.toInt()}م")
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun bestLastLocation(manager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider

    private fun findActiveEmployee(rawId: String): PairedEmployee? = repo.employees().firstOrNull { it.active && it.employeeId.equals(rawId.trim(), true) }


    private fun ensureOperationalActivation(): Boolean {
        if (repo.isCentralActivationActive()) return true
        runCatching { scanner.stop() }
        buildActivationLockUi()
        info("التشغيل موقوف", "يتطلب تسجيل الحضور تفعيلًا مركزيًا صالحًا من صاحب النظام. إذا كان الجهاز غير متصل بالإنترنت، أعد الاتصال للتحقق من الصلاحية.")
        return false
    }

    private fun recordVerified(employee: PairedEmployee, method: AttendanceMethod, extra: String = "") {
        if (!ensureOperationalActivation()) return
        val now = System.currentTimeMillis()
        val previous = repo.lastEvent(employee.employeeId)
        if (previous != null && now - previous.timestampEpochMillis < 30_000L) {
            status.text = "تم تجاهل محاولة مكررة لـ ${employee.displayName} — انتظر 30 ثانية"
            return
        }
        val action = nextAction(employee.employeeId)
        repo.addEvent(AttendanceEvent(employeeId = employee.employeeId, employeeName = employee.displayName, branchId = employee.branchId,
            timestampEpochMillis = now, action = action, method = method, deviceId = deviceId(), verified = true, evidence = extra))
        status.text = "✓ ${employee.displayName}: ${if (action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"} — ${methodLabel(method)}${if (extra.isNotBlank()) " • $extra" else ""}"
        refreshDashboard()
    }

    private fun showReportsDialog(){
        val recent=repo.events().takeLast(30).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        val text=if(recent.isEmpty())"لا توجد عمليات بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))} — ${e.method.name}\n")}}
        AlertDialog.Builder(this).setTitle("السجل والتقارير").setMessage(text).setPositiveButton("مشاركة CSV"){_,_->shareTodayCsv()}.setNegativeButton("إغلاق",null).show()
    }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int){
        if(!repo.allowEmployeeCompanion) return
        val employees=repo.employees().filter{it.active&&it.companionEnabled&&BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){
            val secret=SecretCodec.decode(employee.pairingSecret)?:continue
            if(!BleProtocol.verify(payload,employee.employeeId,secret))continue
            nearby[employee.employeeId]=System.currentTimeMillis() to rssi
            if (payload.verified) {
                when {
                    payload.gpsProof && repo.allowGpsVerification && employee.allows(AttendanceMethod.GPS) ->
                        maybeRecordPhoneProof(employee, payload.token, AttendanceMethod.GPS)
                    (payload.biometricProof || payload.version == BleProtocol.LEGACY_VERSION) && employee.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC) ->
                        maybeRecordPhoneProof(employee, payload.token, AttendanceMethod.PHONE_BLE_BIOMETRIC)
                }
            } else if (!repo.requirePhoneBiometric && employee.allows(AttendanceMethod.PHONE_PROXIMITY) && employee.employeeId !in autoPresenceRecorded) {
                autoPresenceRecorded.add(employee.employeeId)
                runOnUiThread { recordVerified(employee, AttendanceMethod.PHONE_PROXIMITY) }
            }
            runOnUiThread{refreshDashboard()}
            return
        }
    }

    private fun maybeRecordPhoneProof(employee:PairedEmployee,token:Int,method:AttendanceMethod){
        if(!employee.allows(method)) return
        if(repo.lastProofToken(employee.employeeId)==token)return
        val last=repo.lastEvent(employee.employeeId)
        if(last!=null&&System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return
        repo.setLastProofToken(employee.employeeId,token)
        runOnUiThread{recordVerified(employee, method, if (method == AttendanceMethod.GPS) "GPS من هاتف الموظف" else "تحقق بيومتري من هاتف الموظف") }
    }

    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        if (::storeSummary.isInitialized) storeSummary.text = storeSummaryText()
        val now=System.currentTimeMillis()
        val stale=nearby.filterValues{now-it.first>45_000L}.keys.toList()
        stale.forEach { nearby.remove(it); autoPresenceRecorded.remove(it) }
        val employees=repo.employees().filter{it.active}
        val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()}
        val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet()
        val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis(e, first.timestampEpochMillis))e.employeeId else null}.toSet()
        val early=employees.mapNotNull { e ->
            val lastOut = events.lastOrNull { it.employeeId.equals(e.employeeId, true) && it.action == AttendanceAction.CHECK_OUT }
            if (lastOut != null && lastOut.timestampEpochMillis < shiftEndMillis(e, lastOut.timestampEpochMillis)) e.employeeId else null
        }.toSet()
        if(::counts.isInitialized) counts.text="الموظفون ${employees.size}   •   الحاضرون ${present.size}\nمتأخرون ${late.size}   •   انصراف مبكر ${early.size}\nغير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}"
        if(::nearbyView.isInitialized) nearbyView.text=if(nearby.isEmpty())"لا توجد هواتف موظفين قريبة الآن" else "هواتف قريبة: ${nearby.keys.joinToString("، "){id->employees.firstOrNull{it.employeeId==id}?.displayName?:id}}"
    }

    private fun shareTodayCsv(){val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))}
    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis(employee: PairedEmployee, baseTime: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
        timeInMillis = baseTime
        set(Calendar.HOUR_OF_DAY, if (employee.useCustomShift) employee.shiftStartHour else repo.shiftHour)
        set(Calendar.MINUTE, if (employee.useCustomShift) employee.shiftStartMinute else repo.shiftMinute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MINUTE, repo.graceMinutes)
    }.timeInMillis
    private fun shiftEndMillis(employee: PairedEmployee, baseTime: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
        timeInMillis = baseTime
        set(Calendar.HOUR_OF_DAY, if (employee.useCustomShift) employee.shiftEndHour else repo.shiftEndHour)
        set(Calendar.MINUTE, if (employee.useCustomShift) employee.shiftEndMinute else repo.shiftEndMinute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    private fun employeeShiftLabel(employee: PairedEmployee): String {
        val sh = if (employee.useCustomShift) employee.shiftStartHour else repo.shiftHour
        val sm = if (employee.useCustomShift) employee.shiftStartMinute else repo.shiftMinute
        val eh = if (employee.useCustomShift) employee.shiftEndHour else repo.shiftEndHour
        val em = if (employee.useCustomShift) employee.shiftEndMinute else repo.shiftEndMinute
        return String.format(Locale.getDefault(), "%02d:%02d - %02d:%02d%s", sh, sm, eh, em, if (employee.useCustomShift) " • خاص" else " • عام")
    }
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (!repo.isCentralActivationActive()) { buildActivationLockUi(); return }
        if (requestCode == REQUEST_VOICE_VERIFY) {
            if (!::status.isInitialized) { buildUi(); refreshDashboard() }
            val employeeId = pendingVoiceEmployeeId
            val challenge = pendingVoiceChallenge
            pendingVoiceEmployeeId = null; pendingVoiceChallenge = null
            if (resultCode != RESULT_OK || employeeId.isNullOrBlank() || challenge.isNullOrBlank()) { status.text = "تم إلغاء التحقق الصوتي"; return }
            val employee = findActiveEmployee(employeeId)
            if (employee == null || employee.voicePhraseHash.isBlank() || !employee.allows(AttendanceMethod.VOICE_PHRASE)) { status.text = "بيانات التحقق الصوتي غير متاحة"; return }
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty()
            val confidence = data?.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES)
            var acceptedConfidence = -1f
            val matched = results.indices.any { i ->
                val normalized = normalizeVoicePhrase(results[i])
                val challengeNorm = normalizeVoicePhrase(challenge)
                if (!normalized.contains(challengeNorm)) return@any false
                val phraseOnly = normalized.replace(challengeNorm, " ").replace(Regex("\\s+"), " ").trim()
                val phraseMatch = PairingProtocol.matchesPin(employee.voicePhraseHash, phraseOnly)
                val c = confidence?.getOrNull(i) ?: -1f
                val confidenceOk = c < 0f || c >= 0.52f
                if (phraseMatch && confidenceOk) { acceptedConfidence = c; true } else false
            }
            if (matched) recordVerified(employee, AttendanceMethod.VOICE_PHRASE, if (acceptedConfidence >= 0f) "تحدي صوتي • ثقة ${(acceptedConfidence * 100).toInt()}%" else "تحدي صوتي")
            else info("لم ينجح التحقق الصوتي", "لم تتطابق العبارة مع كلمة التحدي أو كانت ثقة التعرف منخفضة. حاول في مكان أقل ضوضاء.")
            return
        }
        if (requestCode != REQUEST_FACE_CAPTURE) return
        if (!::status.isInitialized) { buildUi(); refreshDashboard() }
        val employeeId = pendingFaceEmployeeId
        val recognitionMode = pendingFaceRecognition
        val tempPath = pendingFaceCapturePath
        pendingFaceEmployeeId = null; pendingFaceRecognition = false; pendingFaceCapturePath = null
        if (resultCode != RESULT_OK || tempPath.isNullOrBlank()) {
            tempPath?.let { runCatching { File(it).delete() } }
            status.text = "تم إلغاء بصمة الوجه — لم تتغير البيانات"
            return
        }
        val bitmap = runCatching { decodeFaceBitmap(tempPath) }.getOrNull()
        runCatching { File(tempPath).delete() }
        if (bitmap == null) { info("بصمة الوجه", "لم تصل صورة صالحة من الكاميرا. أعد المحاولة."); return }
        val analysis = FaceSignatureEngine.analyze(bitmap)
        if (analysis.template.isBlank()) {
            info("جودة الوجه", analysis.error.ifBlank { "تعذر تكوين قالب وجه صالح." }); return
        }
        if (recognitionMode) {
            val candidates = repo.employees().filter { it.active && it.allows(AttendanceMethod.SHARED_DEVICE_FACE) && it.faceTemplate.isNotBlank() }
            val ranked = candidates.map { it to FaceSignatureEngine.similarity(analysis.template, it.faceTemplate) }.sortedByDescending { it.second }
            val best = ranked.firstOrNull()
            val second = ranked.getOrNull(1)?.second ?: 0f
            if (best == null || best.second < 0.79f || (ranked.size > 1 && best.second - second < 0.025f)) {
                info("لم يتم التعرف بثقة كافية", "لم يطابق الوجه أي موظف بدرجة آمنة. أفضل درجة ${(best?.second?.times(100)?.toInt() ?: 0)}%. أعد المحاولة بإضاءة جيدة أو حدّث ملف وجه الموظف.")
                return
            }
            recordVerified(best.first, AttendanceMethod.SHARED_DEVICE_FACE, "مطابقة وجه محلية ${(best.second * 100).toInt()}% • جودة ${analysis.quality}/100")
            return
        }
        if (employeeId.isNullOrBlank()) return
        val employee = repo.employees().firstOrNull { it.employeeId.equals(employeeId, true) } ?: return
        runCatching {
            val dir = File(filesDir, "face_profiles").apply { mkdirs() }
            val safeId = employee.employeeId.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(dir, "$safeId.jpg")
            val saveBitmap = analysis.faceCrop ?: bitmap
            file.outputStream().use { out -> if (!saveBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) error("تعذر ضغط الصورة") }
            deleteFaceFile(employee.faceProfileRef.takeIf { it != file.absolutePath }.orEmpty())
            repo.upsertEmployee(employee.copy(faceProfileRef = file.absolutePath, faceCapturedAt = System.currentTimeMillis(), faceTemplate = analysis.template, faceQualityScore = analysis.quality))
            status.text = "✓ تم إعداد بصمة الوجه لـ ${employee.displayName} • جودة ${analysis.quality}/100"
            info("تم إعداد الوجه", "تم اكتشاف وجه واحد واضح وتكوين قالب مطابقة محلي. يمكن الآن اختيار «بصمة الوجه» من الشاشة الرئيسية لمحاولة التعرف التلقائي. لتحسين الدقة أكثر لاحقًا سنضيف نموذج تعرّف عصبي متخصص مع فحص حيوية متقدم.")
        }.onFailure { status.text = "تعذر حفظ بصمة الوجه: ${it.message ?: "خطأ"}" }
        return
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        when(requestCode){
            BleEmployeeScanner.REQUEST_PERMISSIONS -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}){status.text="تم منح صلاحيات BLE";if(repo.autoScan)scanner.start()}
                else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"
            }
            REQUEST_GPS_PERMISSION -> {
                status.text = if(grantResults.any{it==PackageManager.PERMISSION_GRANTED}) "تم منح صلاحية الموقع — أعد اختيار GPS لإكمال الحضور" else "لم يتم السماح بالموقع"
            }
            REQUEST_CAMERA_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    status.text = "تم منح صلاحية الكاميرا"
                    launchFaceCamera()
                } else {
                    clearPendingFaceCapture()
                    status.text = "يلزم السماح بالكاميرا لاستخدام بصمة الوجه"
                }
            }
        }
    }
    private fun normalizeVoicePhrase(value: String): String = value.trim().lowercase(Locale.getDefault())
        .replace(Regex("[\\p{Punct}\\s]+"), " ").trim()

    private fun methodLabel(method: AttendanceMethod): String = when(method){
        AttendanceMethod.PIN -> "PIN"
        AttendanceMethod.PASSWORD -> "كلمة المرور"
        AttendanceMethod.PATTERN -> "النقش"
        AttendanceMethod.VOICE_PHRASE -> "التحقق الصوتي"
        AttendanceMethod.GPS -> "GPS"
        AttendanceMethod.EXTERNAL_FINGERPRINT -> "بصمة خارجية"
        AttendanceMethod.SHARED_DEVICE_FACE -> "الوجه"
        AttendanceMethod.PHONE_BLE_BIOMETRIC -> "هاتف + بصمة/وجه"
        AttendanceMethod.PHONE_PROXIMITY -> "التعرف على الهاتف"
        AttendanceMethod.PHONE_BIOMETRIC -> "بيومتري الهاتف"
        AttendanceMethod.SUPERVISOR_OVERRIDE -> "بإشراف"
        AttendanceMethod.MANUAL_ADMIN -> "إداري"
    }

    private fun allowedMethodsArabic(employee: PairedEmployee): String {
        val methods = if (employee.allowedMethods.isEmpty()) {
            listOf(AttendanceMethod.PIN, AttendanceMethod.PASSWORD, AttendanceMethod.PATTERN, AttendanceMethod.VOICE_PHRASE,
                AttendanceMethod.GPS, AttendanceMethod.EXTERNAL_FINGERPRINT, AttendanceMethod.PHONE_BLE_BIOMETRIC, AttendanceMethod.PHONE_PROXIMITY)
        } else employee.allowedMethods.mapNotNull { runCatching { AttendanceMethod.valueOf(it) }.getOrNull() }
        return methods.joinToString("، ") { methodLabel(it) }.ifBlank { "غير محددة" }
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }

    override fun onDestroy(){scanner.stop();super.onDestroy()}
    companion object {
        const val EXTRA_EMPLOYEE_MANAGER = "open_employee_manager"
        const val EXTRA_STORE_ADMIN_SESSION = "store_admin_session"
        private const val REQUEST_FACE_CAPTURE = 6201
        private const val REQUEST_VOICE_VERIFY = 6203
        private const val REQUEST_GPS_PERMISSION = 6204
        private const val REQUEST_CAMERA_PERMISSION = 6205
    }

}
