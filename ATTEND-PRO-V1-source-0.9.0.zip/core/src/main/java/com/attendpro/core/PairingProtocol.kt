package com.attendpro.core

import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

object PairingProtocol {
    private const val PREFIX_STORE = "ATTENDPRO1:S:"
    private const val PREFIX_EMPLOYEE = "ATTENDPRO1:E:"
    const val DEFAULT_TTL_MILLIS = 5 * 60_000L

    data class StoreInvite(
        val storeId: String,
        val storeName: String,
        val branchId: String,
        val nonce: String,
        val expiresAt: Long
    )

    data class EmployeeResponse(
        val storeId: String,
        val nonce: String,
        val employeeId: String,
        val displayName: String,
        val branchId: String,
        val pairingSecret: String,
        val pinHash: String,
        val expiresAt: Long
    )

    fun randomNonce(): String = SecretCodec.encode(ByteArray(12).also { SecureRandom().nextBytes(it) })

    fun encodeStoreInvite(invite: StoreInvite): String = PREFIX_STORE + encodeJson(JSONObject().apply {
        put("v", 1); put("storeId", invite.storeId); put("storeName", invite.storeName)
        put("branchId", invite.branchId); put("nonce", invite.nonce); put("expiresAt", invite.expiresAt)
    })

    fun decodeStoreInvite(text: String): StoreInvite? = runCatching {
        if (!text.startsWith(PREFIX_STORE)) return null
        val o = decodeJson(text.removePrefix(PREFIX_STORE))
        StoreInvite(
            storeId = o.getString("storeId"),
            storeName = o.optString("storeName", "جهاز المحل"),
            branchId = o.optString("branchId", "MAIN"),
            nonce = o.getString("nonce"),
            expiresAt = o.getLong("expiresAt")
        )
    }.getOrNull()

    fun encodeEmployeeResponse(response: EmployeeResponse): String = PREFIX_EMPLOYEE + encodeJson(JSONObject().apply {
        put("v", 1); put("storeId", response.storeId); put("nonce", response.nonce)
        put("employeeId", response.employeeId); put("displayName", response.displayName)
        put("branchId", response.branchId); put("pairingSecret", response.pairingSecret)
        put("pinHash", response.pinHash); put("expiresAt", response.expiresAt)
    })

    fun decodeEmployeeResponse(text: String): EmployeeResponse? = runCatching {
        if (!text.startsWith(PREFIX_EMPLOYEE)) return null
        val o = decodeJson(text.removePrefix(PREFIX_EMPLOYEE))
        EmployeeResponse(
            storeId = o.getString("storeId"), nonce = o.getString("nonce"),
            employeeId = o.getString("employeeId"), displayName = o.optString("displayName", o.getString("employeeId")),
            branchId = o.optString("branchId", "MAIN"), pairingSecret = o.getString("pairingSecret"),
            pinHash = o.optString("pinHash", ""), expiresAt = o.getLong("expiresAt")
        )
    }.getOrNull()

    fun pinHash(pin: String): String {
        if (pin.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(pin.trim().toByteArray(Charsets.UTF_8))
        return "sha256:" + Base64.encodeToString(digest, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }

    fun matchesPin(stored: String, entered: String): Boolean {
        if (stored.isBlank() || entered.isBlank()) return false
        return if (stored.startsWith("sha256:")) stored == pinHash(entered) else stored == entered.trim()
    }

    private fun encodeJson(o: JSONObject): String = Base64.encodeToString(
        o.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
    )

    private fun decodeJson(text: String): JSONObject {
        val bytes = Base64.decode(text, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
        return JSONObject(bytes.toString(Charsets.UTF_8))
    }
}
