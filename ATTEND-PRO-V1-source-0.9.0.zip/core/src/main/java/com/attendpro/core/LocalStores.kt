package com.attendpro.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class EmployeeIdentityStore(context: Context) {
    private val prefs = context.getSharedPreferences("employee_identity", Context.MODE_PRIVATE)

    var employeeId: String
        get() = prefs.getString("employeeId", "") ?: ""
        set(value) = prefs.edit().putString("employeeId", value.trim()).apply()
    var displayName: String
        get() = prefs.getString("displayName", "") ?: ""
        set(value) = prefs.edit().putString("displayName", value.trim()).apply()
    var branchId: String
        get() = prefs.getString("branchId", "MAIN") ?: "MAIN"
        set(value) = prefs.edit().putString("branchId", value.trim().ifBlank { "MAIN" }).apply()
    var pin: String
        get() = prefs.getString("pin", "") ?: ""
        set(value) = prefs.edit().putString("pin", value.trim()).apply()
    var pairingSecret: String
        get() {
            val existing = prefs.getString("pairingSecret", "") ?: ""
            if (SecretCodec.isValid(existing)) return existing
            val generated = SecretCodec.encode(SecretCodec.generate())
            prefs.edit().putString("pairingSecret", generated).apply()
            return generated
        }
        set(value) = prefs.edit().putString("pairingSecret", value).apply()

    var trustedStoreId: String
        get() = prefs.getString("trustedStoreId", "") ?: ""
        set(value) = prefs.edit().putString("trustedStoreId", value.trim()).apply()
    var trustedStoreName: String
        get() = prefs.getString("trustedStoreName", "") ?: ""
        set(value) = prefs.edit().putString("trustedStoreName", value.trim()).apply()
    var trustedStoreBranch: String
        get() = prefs.getString("trustedStoreBranch", "") ?: ""
        set(value) = prefs.edit().putString("trustedStoreBranch", value.trim()).apply()
    var pendingNonce: String
        get() = prefs.getString("pendingNonce", "") ?: ""
        set(value) = prefs.edit().putString("pendingNonce", value.trim()).apply()
    var pendingExpiresAt: Long
        get() = prefs.getLong("pendingExpiresAt", 0L)
        set(value) = prefs.edit().putLong("pendingExpiresAt", value).apply()
    var autoPresence: Boolean
        get() = prefs.getBoolean("autoPresence", true)
        set(value) = prefs.edit().putBoolean("autoPresence", value).apply()

    val isConfigured: Boolean get() = employeeId.isNotBlank() && displayName.isNotBlank()
    val hasPendingInvite: Boolean get() = trustedStoreId.isNotBlank() && pendingNonce.isNotBlank() && pendingExpiresAt > System.currentTimeMillis()

    fun regenerateSecret(): String {
        val generated = SecretCodec.encode(SecretCodec.generate())
        pairingSecret = generated
        return generated
    }

    fun acceptInvite(invite: PairingProtocol.StoreInvite) {
        trustedStoreId = invite.storeId
        trustedStoreName = invite.storeName
        trustedStoreBranch = invite.branchId
        pendingNonce = invite.nonce
        pendingExpiresAt = invite.expiresAt
    }

    fun clearStoreLink() {
        trustedStoreId = ""; trustedStoreName = ""; trustedStoreBranch = ""; pendingNonce = ""; pendingExpiresAt = 0L
    }
}

class StoreRepository(context: Context) {
    private val prefs = context.getSharedPreferences("store_repository", Context.MODE_PRIVATE)

    val storeId: String
        get() {
            val old = prefs.getString("storeId", "") ?: ""
            if (old.isNotBlank()) return old
            val id = "STORE-${UUID.randomUUID()}"
            prefs.edit().putString("storeId", id).apply(); return id
        }
    var storeName: String
        get() = prefs.getString("storeName", "جهاز المحل") ?: "جهاز المحل"
        set(value) = prefs.edit().putString("storeName", value.trim().ifBlank { "جهاز المحل" }).apply()
    var branchId: String
        get() = prefs.getString("branchId", "MAIN") ?: "MAIN"
        set(value) = prefs.edit().putString("branchId", value.trim().ifBlank { "MAIN" }).apply()
    var pairingNonce: String
        get() = prefs.getString("pairingNonce", "") ?: ""
        set(value) = prefs.edit().putString("pairingNonce", value).apply()
    var pairingExpiresAt: Long
        get() = prefs.getLong("pairingExpiresAt", 0L)
        set(value) = prefs.edit().putLong("pairingExpiresAt", value).apply()
    var autoScan: Boolean
        get() = prefs.getBoolean("autoScan", true)
        set(value) = prefs.edit().putBoolean("autoScan", value).apply()

    fun newPairingInvite(): PairingProtocol.StoreInvite {
        pairingNonce = PairingProtocol.randomNonce()
        pairingExpiresAt = System.currentTimeMillis() + PairingProtocol.DEFAULT_TTL_MILLIS
        return PairingProtocol.StoreInvite(storeId, storeName, branchId, pairingNonce, pairingExpiresAt)
    }

    fun isValidPairingResponse(response: PairingProtocol.EmployeeResponse): Boolean =
        response.storeId == storeId && response.nonce == pairingNonce &&
            pairingExpiresAt > System.currentTimeMillis() && response.expiresAt > System.currentTimeMillis()

    fun employees(): List<PairedEmployee> {
        val array = JSONArray(prefs.getString("employees", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                PairedEmployee(
                    employeeId = o.getString("employeeId"),
                    displayName = o.optString("displayName", o.getString("employeeId")),
                    branchId = o.optString("branchId", "MAIN"),
                    pairingSecret = o.getString("pairingSecret"),
                    pin = o.optString("pinHash", o.optString("pin", ""))
                )
            }.getOrNull()
        }
    }

    fun upsertEmployee(employee: PairedEmployee) {
        val items = employees().toMutableList()
        val index = items.indexOfFirst { it.employeeId.equals(employee.employeeId, true) }
        if (index >= 0) items[index] = employee else items.add(employee)
        val array = JSONArray()
        items.forEach { e -> array.put(JSONObject().apply {
            put("employeeId", e.employeeId); put("displayName", e.displayName); put("branchId", e.branchId)
            put("pairingSecret", e.pairingSecret); put("pinHash", e.pin)
        }) }
        prefs.edit().putString("employees", array.toString()).apply()
    }

    fun removeEmployee(employeeId: String) {
        val remaining = employees().filterNot { it.employeeId.equals(employeeId, true) }
        val array = JSONArray()
        remaining.forEach { e -> array.put(JSONObject().apply {
            put("employeeId", e.employeeId); put("displayName", e.displayName); put("branchId", e.branchId)
            put("pairingSecret", e.pairingSecret); put("pinHash", e.pin)
        }) }
        prefs.edit().putString("employees", array.toString()).apply()
    }

    fun events(): List<AttendanceEvent> {
        val array = JSONArray(prefs.getString("events", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i -> runCatching { AttendanceEvent.fromJson(array.getJSONObject(i)) }.getOrNull() }.sortedBy { it.timestampEpochMillis }
    }
    fun addEvent(event: AttendanceEvent) { val current = events().toMutableList(); current.add(event); saveEvents(current.takeLast(3000)) }
    fun markSynced(ids: Set<String>) { saveEvents(events().map { if (it.eventId in ids) it.copy(synced = true) else it }) }
    fun pendingEvents(): List<AttendanceEvent> = events().filter { !it.synced }
    private fun saveEvents(items: List<AttendanceEvent>) { val array = JSONArray(); items.forEach { array.put(it.toJson()) }; prefs.edit().putString("events", array.toString()).apply() }
    fun lastEvent(employeeId: String): AttendanceEvent? = events().lastOrNull { it.employeeId.equals(employeeId, true) }
    fun lastEventToday(employeeId: String, dayStart: Long): AttendanceEvent? = events().lastOrNull { it.employeeId.equals(employeeId, true) && it.timestampEpochMillis >= dayStart }
    fun lastProofToken(employeeId: String): Int = prefs.getInt("proof_${employeeId.lowercase()}", Int.MIN_VALUE)
    fun setLastProofToken(employeeId: String, token: Int) = prefs.edit().putInt("proof_${employeeId.lowercase()}", token).apply()

    var shiftHour: Int get() = prefs.getInt("shiftHour", 8); set(value) = prefs.edit().putInt("shiftHour", value.coerceIn(0,23)).apply()
    var shiftMinute: Int get() = prefs.getInt("shiftMinute", 0); set(value) = prefs.edit().putInt("shiftMinute", value.coerceIn(0,59)).apply()
    var graceMinutes: Int get() = prefs.getInt("graceMinutes", 10); set(value) = prefs.edit().putInt("graceMinutes", value.coerceIn(0,180)).apply()
    var serverUrl: String get() = prefs.getString("serverUrl", "") ?: ""; set(value) = prefs.edit().putString("serverUrl", value.trim()).apply()
    var tenantId: String get() = prefs.getString("tenantId", "") ?: ""; set(value) = prefs.edit().putString("tenantId", value.trim()).apply()
    var activationToken: String get() = prefs.getString("activationToken", "") ?: ""; set(value) = prefs.edit().putString("activationToken", value.trim()).apply()
    var fingerprintHost: String get() = prefs.getString("fingerprintHost", "") ?: ""; set(value) = prefs.edit().putString("fingerprintHost", value.trim()).apply()
    var fingerprintPort: Int get() = prefs.getInt("fingerprintPort", 4370); set(value) = prefs.edit().putInt("fingerprintPort", value.coerceIn(1,65535)).apply()
}
