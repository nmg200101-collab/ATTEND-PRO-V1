package com.attendpro.core

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object UiKit {
    data class Palette(val bg:Int,val surface:Int,val surface2:Int,val text:Int,val muted:Int,val primary:Int,val accent:Int,val success:Int,val danger:Int)

    fun palette(context: Context): Palette {
        val dark = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        return if (dark) Palette(
            Color.rgb(3,18,31), Color.rgb(9,35,55), Color.rgb(14,47,70), Color.WHITE,
            Color.rgb(181,205,220), Color.rgb(12,137,218), Color.rgb(34,207,203), Color.rgb(36,190,112), Color.rgb(239,82,82)
        ) else Palette(
            Color.rgb(244,248,251), Color.WHITE, Color.rgb(233,242,248), Color.rgb(20,42,58),
            Color.rgb(91,111,124), Color.rgb(11,119,196), Color.rgb(19,174,173), Color.rgb(28,154,91), Color.rgb(213,64,64)
        )
    }

    fun dp(context: Context, value:Int): Int = (value * context.resources.displayMetrics.density).toInt()
    fun round(color:Int, radius:Int, context: Context, stroke:Int?=null): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(context, radius).toFloat(); if (stroke != null) setStroke(dp(context,1), stroke)
    }
    fun card(context: Context, palette:Palette, padding:Int=16): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(context,padding),dp(context,padding),dp(context,padding),dp(context,padding))
        background = round(palette.surface,18,context, if (palette.bg == Color.rgb(244,248,251)) Color.rgb(219,230,237) else Color.rgb(28,64,86))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=dp(context,12) }
    }
    fun title(context: Context, palette:Palette, text:String, size:Float=21f): TextView = TextView(context).apply {
        this.text=text; textSize=size; setTextColor(palette.text); setTypeface(typeface, Typeface.BOLD); gravity=Gravity.START
    }
    fun subtitle(context: Context, palette:Palette, text:String): TextView = TextView(context).apply {
        this.text=text; textSize=14f; setTextColor(palette.muted); gravity=Gravity.START
    }
    fun field(context: Context, palette:Palette, hintText:String, numeric:Boolean=false): EditText = EditText(context).apply {
        hint=hintText; textSize=16f; setTextColor(palette.text); setHintTextColor(palette.muted)
        background = round(palette.surface2,14,context)
        setPadding(dp(context,14),dp(context,12),dp(context,14),dp(context,12))
        inputType = if(numeric) android.text.InputType.TYPE_CLASS_NUMBER else android.text.InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=dp(context,10) }
    }
    fun button(context: Context, palette:Palette, label:String, primary:Boolean=true): Button = Button(context).apply {
        text=label; textSize=15f; isAllCaps=false; setTextColor(if(primary) Color.WHITE else palette.text)
        background = round(if(primary) palette.primary else palette.surface2,14,context)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(context,52)).apply { bottomMargin=dp(context,9) }
    }
    fun sectionLabel(context: Context, palette:Palette, label:String): TextView = TextView(context).apply {
        text=label; textSize=13f; setTextColor(palette.accent); setTypeface(typeface,Typeface.BOLD); setPadding(0,dp(context,6),0,dp(context,8))
    }
}
