package com.attendpro.core

import android.os.ParcelUuid
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object BleProtocol {
    const val VERSION: Byte = 1
    const val FLAG_VERIFIED: Int = 0x01
    const val WINDOW_MILLIS: Long = 15_000L
    val SERVICE_UUID: ParcelUuid = ParcelUuid.fromString("0000A771-0000-1000-8000-00805F9B34FB")

    data class Payload(
        val version: Int,
        val verified: Boolean,
        val employeeHash: Int,
        val token: Int
    )

    fun employeeHash(employeeId: String): Int {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(employeeId.trim().lowercase().toByteArray(Charsets.UTF_8))
        return ByteBuffer.wrap(digest.copyOfRange(0, 4)).int
    }

    fun currentWindow(nowMillis: Long = System.currentTimeMillis()): Long = nowMillis / WINDOW_MILLIS

    fun token(secret: ByteArray, employeeHash: Int, verified: Boolean, window: Long): Int {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret, "HmacSHA256"))
        val data = ByteBuffer.allocate(13)
            .putInt(employeeHash)
            .putLong(window)
            .put(if (verified) 1.toByte() else 0.toByte())
            .array()
        val output = mac.doFinal(data)
        return ByteBuffer.wrap(output.copyOfRange(0, 4)).int
    }

    fun buildPayload(employeeId: String, secret: ByteArray, verified: Boolean, nowMillis: Long = System.currentTimeMillis()): ByteArray {
        val hash = employeeHash(employeeId)
        val token = token(secret, hash, verified, currentWindow(nowMillis))
        return ByteBuffer.allocate(10)
            .put(VERSION)
            .put(if (verified) FLAG_VERIFIED.toByte() else 0)
            .putInt(hash)
            .putInt(token)
            .array()
    }

    fun parse(bytes: ByteArray?): Payload? {
        if (bytes == null || bytes.size < 10) return null
        val buffer = ByteBuffer.wrap(bytes)
        val version = buffer.get().toInt() and 0xFF
        val flags = buffer.get().toInt() and 0xFF
        return Payload(
            version = version,
            verified = flags and FLAG_VERIFIED != 0,
            employeeHash = buffer.int,
            token = buffer.int
        )
    }

    fun verify(
        payload: Payload,
        employeeId: String,
        secret: ByteArray,
        nowMillis: Long = System.currentTimeMillis()
    ): Boolean {
        if (payload.version != VERSION.toInt()) return false
        val expectedHash = employeeHash(employeeId)
        if (payload.employeeHash != expectedHash) return false
        val window = currentWindow(nowMillis)
        for (candidate in (window - 1)..(window + 1)) {
            if (payload.token == token(secret, expectedHash, payload.verified, candidate)) return true
        }
        return false
    }
}
