package com.attendpro.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

object NetworkTools {
    fun probeTcp(host: String, port: Int, timeoutMillis: Int = 2500): Result<Unit> = runCatching {
        Socket().use { socket -> socket.connect(InetSocketAddress(host, port), timeoutMillis) }
    }

    fun syncEvents(
        serverUrl: String,
        tenantId: String,
        activationToken: String,
        events: List<AttendanceEvent>
    ): Result<Set<String>> = runCatching {
        require(serverUrl.startsWith("https://")) { "عنوان الخادم يجب أن يبدأ بـ https://" }
        if (events.isEmpty()) return@runCatching emptySet()
        val endpoint = serverUrl.trimEnd('/') + "/api/v1/attendance/events/batch"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("X-Tenant-Id", tenantId)
            if (activationToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $activationToken")
        }
        val body = JSONObject().apply {
            val array = JSONArray()
            events.forEach { array.put(it.toJson()) }
            put("events", array)
        }
        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = connection.responseCode
        if (code !in 200..299) error("HTTP $code")
        connection.disconnect()
        events.map { it.eventId }.toSet()
    }
}
