package com.attendpro.employee

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.UiKit
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

class MainActivity : Activity() {
    private lateinit var identity: EmployeeIdentityStore
    private lateinit var advertiser: BlePresenceAdvertiser
    private lateinit var status: TextView
    private lateinit var employeeId: android.widget.EditText
    private lateinit var employeeName: android.widget.EditText
    private lateinit var branchId: android.widget.EditText
    private lateinit var pin: android.widget.EditText
    private lateinit var linkedStore: TextView
    private lateinit var presenceSwitch: Switch
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identity = EmployeeIdentityStore(this)
        advertiser = BlePresenceAdvertiser(this) { message -> runOnUiThread { status.text = message } }
        buildUi(); loadIdentity()
        if (identity.isConfigured && identity.trustedStoreId.isNotBlank() && identity.autoPresence) startPresence()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,30)); setBackgroundColor(p.bg)
        }
        val header = UiKit.card(this,p).apply { gravity=Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply { setImageResource(com.attendpro.employee.R.drawable.ic_attend_pro); layoutParams=LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,76),UiKit.dp(this@MainActivity,76)) })
        header.addView(UiKit.title(this,p,"ATTEND PRO",27f).apply { gravity=Gravity.CENTER })
        header.addView(UiKit.subtitle(this,p,"تطبيق الموظف • الإصدار 0.9.0").apply { gravity=Gravity.CENTER })
        header.addView(UiKit.subtitle(this,p,"ربط QR آمن + BLE + بصمة/وجه + عمل بدون إنترنت").apply { gravity=Gravity.CENTER; setPadding(0,UiKit.dp(this@MainActivity,5),0,0) })
        root.addView(header)

        val stateCard=UiKit.card(this,p)
        stateCard.addView(UiKit.sectionLabel(this,p,"حالة النظام"))
        status=TextView(this).apply { text="جاهز"; textSize=17f; setTextColor(p.text); setTypeface(typeface,Typeface.BOLD) }
        stateCard.addView(status); root.addView(stateCard)

        val profile=UiKit.card(this,p)
        profile.addView(UiKit.sectionLabel(this,p,"بيانات الموظف"))
        employeeId=UiKit.field(this,p,"رقم الموظف")
        employeeName=UiKit.field(this,p,"اسم الموظف")
        branchId=UiKit.field(this,p,"الفرع - مثال MAIN")
        pin=UiKit.field(this,p,"PIN احتياطي",true)
        listOf(employeeId,employeeName,branchId,pin).forEach { profile.addView(it) }
        profile.addView(UiKit.button(this,p,"حفظ البيانات").apply { setOnClickListener { saveIdentity() } })
        root.addView(profile)

        val pair=UiKit.card(this,p)
        pair.addView(UiKit.sectionLabel(this,p,"الربط الأول مع جهاز المحل"))
        linkedStore=UiKit.subtitle(this,p,"غير مرتبط")
        pair.addView(linkedStore)
        pair.addView(UiKit.button(this,p,"1. مسح QR من جهاز المحل").apply { setOnClickListener { scanStoreInvite() } })
        pair.addView(UiKit.button(this,p,"2. عرض QR استجابة الموظف",false).apply { setOnClickListener { showEmployeeResponseQr() } })
        pair.addView(UiKit.button(this,p,"إلغاء ارتباط جهاز المحل",false).apply { setOnClickListener { identity.clearStoreLink(); refreshLinkInfo(); status.text="تم إلغاء ارتباط جهاز المحل" } })
        root.addView(pair)

        val attend=UiKit.card(this,p)
        attend.addView(UiKit.sectionLabel(this,p,"الحضور الذكي"))
        presenceSwitch=Switch(this).apply { text="الاكتشاف التلقائي عبر BLE"; textSize=16f; setTextColor(p.text); isChecked=identity.autoPresence
            setOnCheckedChangeListener { _, checked -> identity.autoPresence=checked; if(checked) startPresence() else advertiser.stop() } }
        attend.addView(presenceSwitch)
        attend.addView(UiKit.button(this,p,"تأكيد الحضور بالبصمة / الوجه").apply { setOnClickListener { if(!advertiser.isRunning()) startPresence(); requestBiometric() } })
        attend.addView(UiKit.subtitle(this,p,"لا تُرسل صورة البصمة أو الوجه. Android يعيد للتطبيق نتيجة نجاح التحقق فقط، ثم يرسل الهاتف إثبات حضور مؤقتًا ومشفّرًا عبر BLE."))
        root.addView(attend)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun loadIdentity() {
        employeeId.setText(identity.employeeId); employeeName.setText(identity.displayName); branchId.setText(identity.branchId); pin.setText(identity.pin); refreshLinkInfo()
    }
    private fun saveIdentity(): Boolean {
        val id=employeeId.text.toString().trim(); val name=employeeName.text.toString().trim()
        if(id.isBlank() || name.isBlank()) { status.text="أدخل رقم الموظف والاسم"; return false }
        identity.employeeId=id; identity.displayName=name; identity.branchId=branchId.text.toString(); identity.pin=pin.text.toString(); status.text="✓ تم حفظ بيانات الموظف"; return true
    }
    private fun refreshLinkInfo() {
        linkedStore.text = if(identity.trustedStoreId.isBlank()) "غير مرتبط بجهاز محل" else "مرتبط: ${identity.trustedStoreName.ifBlank { "جهاز المحل" }} • الفرع ${identity.trustedStoreBranch.ifBlank { identity.branchId }}${if(identity.hasPendingInvite) " • بانتظار إكمال المسح من جهاز المحل" else ""}"
    }
    private fun scanStoreInvite() {
        if(!saveIdentity()) return
        IntentIntegrator(this).apply { setDesiredBarcodeFormats(IntentIntegrator.QR_CODE); setPrompt("وجّه الكاميرا إلى QR الظاهر في جهاز المحل"); setBeepEnabled(true); setOrientationLocked(false) }.initiateScan()
    }
    private fun showEmployeeResponseQr() {
        if(!saveIdentity()) return
        if(!identity.hasPendingInvite) { status.text="امسح QR جهاز المحل أولاً أو أعد إنشاء رمز الربط من جهاز المحل"; return }
        val response=PairingProtocol.EmployeeResponse(
            storeId=identity.trustedStoreId, nonce=identity.pendingNonce, employeeId=identity.employeeId,
            displayName=identity.displayName, branchId=identity.branchId, pairingSecret=identity.pairingSecret,
            pinHash=PairingProtocol.pinHash(identity.pin), expiresAt=identity.pendingExpiresAt
        )
        val qr=QrCodeTools.bitmap(PairingProtocol.encodeEmployeeResponse(response),760)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(24,16,24,8) }
        box.addView(TextView(this).apply { text="اعرض هذا الرمز أمام كاميرا جهاز المحل لإكمال الربط"; textSize=16f; gravity=Gravity.CENTER; setTextColor(p.text) })
        box.addView(ImageView(this).apply { setImageBitmap(qr); adjustViewBounds=true; layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330)) })
        AlertDialog.Builder(this).setTitle("QR استجابة الموظف").setView(box).setPositiveButton("تم",null).show()
        startPresence(); status.text="QR جاهز. بعد مسحه من جهاز المحل سيبدأ الاكتشاف التلقائي عبر BLE."
    }
    private fun startPresence() {
        if(!identity.isConfigured) { status.text="أكمل بيانات الموظف أولاً"; return }
        if(identity.trustedStoreId.isBlank()) { status.text="اربط الهاتف بجهاز المحل عبر QR أولاً"; return }
        advertiser.start(identity.employeeId,identity.pairingSecret)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:android.content.Intent?) {
        val result:IntentResult?=IntentIntegrator.parseActivityResult(requestCode,resultCode,data)
        if(result!=null) {
            if(result.contents==null) { status.text="تم إلغاء المسح"; return }
            val invite=PairingProtocol.decodeStoreInvite(result.contents)
            if(invite==null) { status.text="هذا الرمز ليس رمز ربط ATTEND PRO صالحًا"; return }
            if(invite.expiresAt <= System.currentTimeMillis()) { status.text="انتهت صلاحية رمز جهاز المحل. أنشئ رمزًا جديدًا"; return }
            identity.acceptInvite(invite); if(branchId.text.toString().isBlank()) identity.branchId=invite.branchId; refreshLinkInfo(); status.text="✓ تم التعرف على جهاز المحل. الآن اضغط: عرض QR استجابة الموظف"; showEmployeeResponseQr(); return
        }
        super.onActivityResult(requestCode,resultCode,data)
    }
    private fun requestBiometric() {
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status.text="يلزم Android 9 أو أحدث"; return }
        val prompt=BiometricPrompt.Builder(this).setTitle("تأكيد الحضور").setSubtitle("استخدم البصمة أو الوجه المسجلين في هاتفك").setNegativeButton("إلغاء",mainExecutor){_,_->status.text="تم إلغاء التحقق"}.build()
        prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult?) { advertiser.markVerified(45_000L); status.text="✓ تم التحقق وإرسال إثبات حضور مؤقت لجهاز المحل" }
            override fun onAuthenticationFailed(){ status.text="لم يتم التعرف على الهوية، حاول مرة أخرى" }
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence?){ status.text="تعذر التحقق: ${errString ?: "خطأ"}" }
        })
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==BlePresenceAdvertiser.REQUEST_BLUETOOTH){ if(grantResults.isNotEmpty() && grantResults.all{it==android.content.pm.PackageManager.PERMISSION_GRANTED}) startPresence() else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث" }
    }
    override fun onDestroy(){ advertiser.stop(); super.onDestroy() }
}
