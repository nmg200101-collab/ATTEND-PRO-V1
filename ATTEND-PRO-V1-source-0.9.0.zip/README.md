# ATTEND PRO 0.9.0

Android attendance platform with two apps:
- Employee app: first-time QR pairing, employee identity, BLE presence, phone biometrics, PIN fallback data.
- Store app: secure two-step QR pairing, automatic BLE detection, local check-in/out, late/absent counters, offline queue, CSV report sharing, server sync settings and external fingerprint TCP probe.

## Pairing flow
1. Store: **ربط موظف جديد عبر QR**.
2. Employee: **مسح QR من جهاز المحل**.
3. Employee automatically displays **QR استجابة الموظف**.
4. Store scans the response and saves the employee trust key.
5. BLE discovery can run automatically. Biometrics on the employee phone produce only a short-lived cryptographic attendance proof; biometric images/templates never leave Android.

## Remaining integration-specific work
- Cloud activation/licensing enforcement needs a real owner backend endpoint.
- External fingerprint event import needs the vendor/model-specific driver/protocol.
