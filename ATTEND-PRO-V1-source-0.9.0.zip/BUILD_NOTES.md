# ATTEND PRO 0.9.0 — Build notes

Major update focused on reducing future update cycles.

Included:
- QR-first secure pairing between Store and Employee apps.
- Five-minute store invite with nonce; employee response must match the current store session.
- Automatic BLE presence after pairing.
- Phone biometric attendance proof remains short-lived and does not expose biometric templates.
- PIN fallback uses SHA-256 proof in QR pairing instead of transferring the raw PIN.
- Improved responsive Arabic UI, status cards, grouping and app branding/icon.
- Registered employee management/unpairing.
- Today dashboard, recent event log and CSV share report.
- Offline event queue and server sync settings.
- Store/branch settings, shift/grace settings.
- External fingerprint LAN/Wi-Fi TCP connectivity test and retained adapter architecture.
- Automatic newest source ZIP selection is already supported by the repository workflow.

Remaining items require external integration details:
1. Cloud owner activation/licensing enforcement needs an actual backend/service endpoint.
2. External fingerprint event import needs vendor/model-specific protocol or SDK.
