package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var eventsView: TextView
    private lateinit var scanButton: android.widget.Button
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo=StoreRepository(this)
        scanner=BleEmployeeScanner(this,::handleBlePayload){msg->runOnUiThread{status.text=msg}}
        buildUi(); refreshDashboard()
        if(repo.autoScan && repo.employees().isNotEmpty()) scanner.start()
    }

    private fun buildUi() {
        window.statusBarColor=p.bg
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,30)); setBackgroundColor(p.bg)
        }
        val header=UiKit.card(this,p).apply{gravity=Gravity.CENTER_HORIZONTAL}
        header.addView(ImageView(this).apply{setImageResource(com.attendpro.store.R.drawable.ic_attend_pro); layoutParams=LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,76),UiKit.dp(this@MainActivity,76))})
        header.addView(UiKit.title(this,p,"ATTEND PRO",27f).apply{gravity=Gravity.CENTER})
        header.addView(UiKit.subtitle(this,p,"جهاز المحل • الإصدار 0.9.0").apply{gravity=Gravity.CENTER})
        header.addView(UiKit.subtitle(this,p,"QR آمن + BLE تلقائي + Offline Sync + تقارير").apply{gravity=Gravity.CENTER;setPadding(0,UiKit.dp(this@MainActivity,5),0,0)})
        root.addView(header)

        val dash=UiKit.card(this,p)
        dash.addView(UiKit.sectionLabel(this,p,"ملخص اليوم"))
        counts=TextView(this).apply{textSize=17f;setTextColor(p.text);setTypeface(typeface,Typeface.BOLD);gravity=Gravity.CENTER}
        dash.addView(counts); root.addView(dash)

        val actions=UiKit.card(this,p)
        actions.addView(UiKit.sectionLabel(this,p,"التشغيل السريع"))
        actions.addView(UiKit.button(this,p,"ربط موظف جديد عبر QR").apply{setOnClickListener{showPairingQr()}})
        scanButton=UiKit.button(this,p,"بدء البحث التلقائي عن الموظفين").apply{setOnClickListener{toggleScan()}}
        actions.addView(scanButton)
        actions.addView(UiKit.button(this,p,"الموظفون المسجلون",false).apply{setOnClickListener{showEmployeesDialog()}})
        actions.addView(UiKit.button(this,p,"تسجيل احتياطي عبر PIN",false).apply{setOnClickListener{showPinDialog()}})
        root.addView(actions)

        val live=UiKit.card(this,p)
        live.addView(UiKit.sectionLabel(this,p,"الحالة المباشرة"))
        status=TextView(this).apply{text="جاهز";textSize=17f;setTextColor(p.text);setTypeface(typeface,Typeface.BOLD);gravity=Gravity.CENTER}
        nearbyView=TextView(this).apply{textSize=14f;setTextColor(p.muted);setPadding(0,UiKit.dp(this@MainActivity,10),0,0)}
        live.addView(status); live.addView(nearbyView); root.addView(live)

        val reports=UiKit.card(this,p)
        reports.addView(UiKit.sectionLabel(this,p,"السجل والتقارير"))
        eventsView=TextView(this).apply{textSize=14f;setTextColor(p.text)}
        reports.addView(eventsView)
        reports.addView(UiKit.button(this,p,"مشاركة تقرير اليوم CSV",false).apply{setOnClickListener{shareTodayCsv()}})
        root.addView(reports)

        val settings=UiKit.card(this,p)
        settings.addView(UiKit.sectionLabel(this,p,"الإعدادات والتكامل"))
        settings.addView(UiKit.button(this,p,"بيانات المحل والفرع",false).apply{setOnClickListener{showStoreSettings()}})
        settings.addView(UiKit.button(this,p,"إعداد الدوام والسماح",false).apply{setOnClickListener{showShiftDialog()}})
        settings.addView(UiKit.button(this,p,"إعداد/اختبار جهاز البصمة الشبكي",false).apply{setOnClickListener{showFingerprintDialog()}})
        settings.addView(UiKit.button(this,p,"إعداد التفعيل والخادم والمزامنة",false).apply{setOnClickListener{showSyncDialog()}})
        val auto=Switch(this).apply{text="تشغيل البحث BLE تلقائيًا";textSize=15f;setTextColor(p.text);isChecked=repo.autoScan;setOnCheckedChangeListener{_,c->repo.autoScan=c;if(c && repo.employees().isNotEmpty())scanner.start() else if(!c)scanner.stop()}}
        settings.addView(auto)
        root.addView(settings)

        root.addView(UiKit.subtitle(this,p,"جهاز البصمة الخارجي: تم تجهيز الاتصال عبر LAN/Wi‑Fi واختبار المنفذ. استيراد سجلات البصمة نفسه يحتاج تعريف Driver حسب شركة وموديل الجهاز."))
        setContentView(ScrollView(this).apply{setBackgroundColor(p.bg);addView(root)})
    }

    private fun showPairingQr() {
        val invite=repo.newPairingInvite(); val content=PairingProtocol.encodeStoreInvite(invite); val qr=QrCodeTools.bitmap(content,760)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(24,12,24,8)}
        box.addView(TextView(this).apply{text="1) افتح تطبيق الموظف واضغط مسح QR جهاز المحل\n2) بعد ظهور QR الاستجابة في هاتف الموظف اضغط هنا «مسح استجابة الموظف»";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.text)})
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        AlertDialog.Builder(this).setTitle("ربط موظف جديد").setView(box)
            .setPositiveButton("مسح استجابة الموظف"){_,_->scanEmployeeResponse()}
            .setNegativeButton("إغلاق",null).show()
        status.text="تم إنشاء QR ربط صالح لمدة 5 دقائق"
    }

    private fun scanEmployeeResponse() {
        IntentIntegrator(this).apply{setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);setPrompt("امسح QR استجابة الموظف");setBeepEnabled(true);setOrientationLocked(false)}.initiateScan()
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        val result:IntentResult?=IntentIntegrator.parseActivityResult(requestCode,resultCode,data)
        if(result!=null) {
            if(result.contents==null){status.text="تم إلغاء المسح";return}
            val response=PairingProtocol.decodeEmployeeResponse(result.contents)
            if(response==null){status.text="هذا الرمز ليس استجابة ربط ATTEND PRO صالحة";return}
            if(!repo.isValidPairingResponse(response)){status.text="رمز الاستجابة لا يطابق جلسة الربط الحالية أو انتهت صلاحيته";return}
            if(!SecretCodec.isValid(response.pairingSecret)){status.text="مفتاح الموظف غير صالح";return}
            repo.upsertEmployee(PairedEmployee(response.employeeId,response.displayName,response.branchId,response.pairingSecret,response.pinHash))
            repo.pairingNonce="";repo.pairingExpiresAt=0L
            status.text="✓ تم ربط ${response.displayName} (${response.employeeId}) بنجاح"
            refreshDashboard(); if(repo.autoScan) scanner.start(); return
        }
        super.onActivityResult(requestCode,resultCode,data)
    }

    private fun toggleScan(){ if(scanner.isScanning()){scanner.stop();scanButton.text="بدء البحث التلقائي عن الموظفين"}else{scanner.start();scanButton.text="إيقاف البحث"} }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int){
        val employees=repo.employees().filter{BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){ val secret=SecretCodec.decode(employee.pairingSecret)?:continue; if(!BleProtocol.verify(payload,employee.employeeId,secret))continue
            nearby[employee.employeeId]=System.currentTimeMillis() to rssi; if(payload.verified)maybeRecordVerified(employee,payload.token);runOnUiThread{refreshDashboard()};return }
    }
    private fun maybeRecordVerified(employee:PairedEmployee,token:Int){
        if(repo.lastProofToken(employee.employeeId)==token)return
        val last=repo.lastEvent(employee.employeeId);if(last!=null && System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return
        val action=nextAction(employee.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PHONE_BLE_BIOMETRIC,deviceId=deviceId(),verified=true))
        repo.setLastProofToken(employee.employeeId,token);runOnUiThread{status.text="✓ ${employee.displayName}: ${if(action==AttendanceAction.CHECK_IN)"تم تسجيل الحضور" else "تم تسجيل الانصراف"}"}
    }
    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        val now=System.currentTimeMillis();nearby.entries.removeIf{now-it.value.first>45_000L};val employees=repo.employees();val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()}
        val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet()
        val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis())e.employeeId else null}.toSet()
        counts.text="المسجلون ${employees.size}   •   الحاضرون ${present.size}\nالمتأخرون ${late.size}   •   غير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}"
        nearbyView.text=if(nearby.isEmpty())"لا توجد هواتف موثوقة قريبة حاليًا" else buildString{append("قريبون الآن:\n");nearby.forEach{(id,d)->append("• ${employees.firstOrNull{it.employeeId.equals(id,true)}?.displayName?:id}  • RSSI ${d.second}\n")}}
        val recent=repo.events().takeLast(12).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        eventsView.text=if(recent.isEmpty())"لا توجد عمليات حضور بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))}${if(!e.synced)" • غير مزامن" else ""}\n")}}
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees();if(employees.isEmpty()){status.text="لا يوجد موظفون مربوطون";return}
        val names=employees.map{"${it.displayName} (${it.employeeId}) • ${it.branchId}"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("الموظفون المسجلون (${employees.size})").setItems(names){_,which->
            val e=employees[which];AlertDialog.Builder(this).setTitle(e.displayName).setMessage("رقم الموظف: ${e.employeeId}\nالفرع: ${e.branchId}").setNegativeButton("إغلاق",null).setPositiveButton("إلغاء الربط"){_,_->repo.removeEmployee(e.employeeId);status.text="تم إلغاء ربط ${e.displayName}";refreshDashboard()}.show()
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showPinDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val id=UiKit.field(this,p,"رقم الموظف");val pin=UiKit.field(this,p,"PIN",true);box.addView(id);box.addView(pin)
        AlertDialog.Builder(this).setTitle("تسجيل احتياطي عبر PIN").setView(box).setPositiveButton("تسجيل"){_,_->
            val employee=repo.employees().firstOrNull{it.employeeId.equals(id.text.toString().trim(),true)}
            if(employee==null||!PairingProtocol.matchesPin(employee.pin,pin.text.toString()))status.text="رقم الموظف أو PIN غير صحيح" else {val action=nextAction(employee.employeeId);repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PIN,deviceId=deviceId(),verified=true));status.text="✓ تم التسجيل الاحتياطي لـ ${employee.displayName}";refreshDashboard()}
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun showStoreSettings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val name=UiKit.field(this,p,"اسم المحل / الفرع").apply{setText(repo.storeName)};val branch=UiKit.field(this,p,"رمز الفرع").apply{setText(repo.branchId)};box.addView(name);box.addView(branch)
        AlertDialog.Builder(this).setTitle("بيانات جهاز المحل").setView(box).setPositiveButton("حفظ"){_,_->repo.storeName=name.text.toString();repo.branchId=branch.text.toString();status.text="✓ تم حفظ بيانات المحل"}.setNegativeButton("إلغاء",null).show()
    }

    private fun showShiftDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val hour=UiKit.field(this,p,"ساعة بداية الدوام 0-23",true).apply{setText(repo.shiftHour.toString())};val minute=UiKit.field(this,p,"الدقيقة",true).apply{setText(repo.shiftMinute.toString())};val grace=UiKit.field(this,p,"دقائق السماح",true).apply{setText(repo.graceMinutes.toString())};listOf(hour,minute,grace).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("إعداد الدوام").setView(box).setPositiveButton("حفظ"){_,_->repo.shiftHour=hour.text.toString().toIntOrNull()?:8;repo.shiftMinute=minute.text.toString().toIntOrNull()?:0;repo.graceMinutes=grace.text.toString().toIntOrNull()?:10;status.text="✓ تم تحديث الدوام والسماح";refreshDashboard()}.setNegativeButton("إلغاء",null).show()
    }

    private fun showFingerprintDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val host=UiKit.field(this,p,"IP جهاز البصمة").apply{setText(repo.fingerprintHost)};val port=UiKit.field(this,p,"Port مثل 4370",true).apply{setText(repo.fingerprintPort.toString())};box.addView(host);box.addView(port)
        AlertDialog.Builder(this).setTitle("جهاز البصمة الشبكي").setView(box).setPositiveButton("حفظ واختبار"){_,_->repo.fingerprintHost=host.text.toString();repo.fingerprintPort=port.text.toString().toIntOrNull()?:4370;status.text="جاري اختبار الاتصال...";Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{status.text=if(r.isSuccess)"✓ الجهاز/المنفذ يستجيب" else "تعذر الاتصال: ${r.exceptionOrNull()?.message?:"خطأ"}"}}.start()}.setNegativeButton("إلغاء",null).show()
    }

    private fun showSyncDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val url=UiKit.field(this,p,"https://server.example.com").apply{setText(repo.serverUrl)};val tenant=UiKit.field(this,p,"Business / Tenant ID").apply{setText(repo.tenantId)};val token=UiKit.field(this,p,"رمز التفعيل من المالك").apply{setText(repo.activationToken)};listOf(url,tenant,token).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("التفعيل والخادم والمزامنة").setView(box).setPositiveButton("حفظ ومزامنة"){_,_->repo.serverUrl=url.text.toString();repo.tenantId=tenant.text.toString();repo.activationToken=token.text.toString();val pending=repo.pendingEvents();if(pending.isEmpty()){status.text="تم حفظ الإعدادات، ولا توجد أحداث معلقة";return@setPositiveButton};status.text="جاري مزامنة ${pending.size} عملية...";Thread{val r=NetworkTools.syncEvents(repo.serverUrl,repo.tenantId,repo.activationToken,pending);runOnUiThread{if(r.isSuccess){repo.markSynced(r.getOrThrow());status.text="✓ تمت مزامنة ${r.getOrThrow().size} عملية";refreshDashboard()}else status.text="فشلت المزامنة: ${r.exceptionOrNull()?.message?:"خطأ"}"}}.start()}.setNegativeButton("إلغاء",null).show()
    }

    private fun shareTodayCsv(){
        val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}}
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))
    }

    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,repo.shiftHour);set(Calendar.MINUTE,repo.shiftMinute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);add(Calendar.MINUTE,repo.graceMinutes)}.timeInMillis
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==BleEmployeeScanner.REQUEST_PERMISSIONS){if(grantResults.isNotEmpty()&&grantResults.all{it==android.content.pm.PackageManager.PERMISSION_GRANTED}){status.text="تم منح الصلاحيات";if(repo.autoScan)scanner.start()}else status.text="يلزم منح صلاحيات الأجهزة القريبة/البلوتوث"}}
    override fun onDestroy(){scanner.stop();super.onDestroy()}
}
