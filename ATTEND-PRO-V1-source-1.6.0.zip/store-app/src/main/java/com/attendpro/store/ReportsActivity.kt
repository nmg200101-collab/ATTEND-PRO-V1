package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.NetworkTools
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ReportsActivity : Activity() {
    private lateinit var repo: StoreRepository
    private val p by lazy { UiKit.palette(this) }
    private var period = Period.TODAY
    @Volatile private var syncInProgress = false

    private enum class Period(val title: String) {
        TODAY("اليوم"), WEEK("آخر 7 أيام"), MONTH("هذا الشهر"), ALL("كل السجلات")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        period = savedInstanceState?.getString("period")?.let { runCatching { Period.valueOf(it) }.getOrNull() } ?: Period.TODAY
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        buildUi()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("period", period.name)
        super.onSaveInstanceState(outState)
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@ReportsActivity, 16), UiKit.dp(this@ReportsActivity, 18), UiKit.dp(this@ReportsActivity, 16), UiKit.dp(this@ReportsActivity, 28))
            setBackgroundColor(p.bg)
        }

        val header = UiKit.card(this, p)
        header.addView(UiKit.sectionLabel(this, p, "تقارير ATTEND PRO"))
        header.addView(UiKit.title(this, p, repo.storeName, 25f))
        header.addView(UiKit.subtitle(this, p, "${period.title} • الفرع ${repo.branchId}"))
        root.addView(header)

        val filter = UiKit.card(this, p, 12)
        filter.addView(UiKit.sectionLabel(this, p, "الفترة"))
        filter.addView(UiKit.button(this, p, "تقرير اليوم", period == Period.TODAY).apply { setOnClickListener { period = Period.TODAY; buildUi() } })
        filter.addView(UiKit.button(this, p, "آخر 7 أيام", period == Period.WEEK).apply { setOnClickListener { period = Period.WEEK; buildUi() } })
        filter.addView(UiKit.button(this, p, "هذا الشهر", period == Period.MONTH).apply { setOnClickListener { period = Period.MONTH; buildUi() } })
        filter.addView(UiKit.button(this, p, "كل السجلات", period == Period.ALL).apply { setOnClickListener { period = Period.ALL; buildUi() } })
        root.addView(filter)

        val events = selectedEvents()
        val summary = summary(events)
        val stats = UiKit.card(this, p)
        stats.addView(UiKit.sectionLabel(this, p, "الملخص"))
        stats.addView(UiKit.title(this, p, "${summary.uniqueEmployees} موظف • ${events.size} حركة", 20f))
        stats.addView(UiKit.subtitle(this, p, "حضور ${summary.checkIns} • انصراف ${summary.checkOuts} • متأخرون ${summary.lateEmployees}"))
        root.addView(stats)

        val recent = UiKit.card(this, p)
        recent.addView(UiKit.sectionLabel(this, p, "السجل"))
        recent.addView(UiKit.subtitle(this, p, reportPreview(events)))
        root.addView(recent)

        val share = UiKit.card(this, p)
        share.addView(UiKit.sectionLabel(this, p, "المشاركة"))
        share.addView(UiKit.button(this, p, "مشاركة ملخص التقرير").apply { setOnClickListener { shareSummary(events) } })
        share.addView(UiKit.button(this, p, "مشاركة التقرير بصيغة CSV", false).apply { setOnClickListener { shareCsv(events) } })
        root.addView(share)

        val remote = UiKit.card(this, p)
        remote.addView(UiKit.sectionLabel(this, p, "المراقبة عن بُعد"))
        remote.addView(UiKit.subtitle(this, p, remoteStatusText()))
        val auto = CheckBox(this).apply {
            text = "المزامنة التلقائية عند توفر الخادم والإنترنت"
            setTextColor(p.text)
            isChecked = repo.reportAutoSync
            setOnCheckedChangeListener { _, checked -> repo.reportAutoSync = checked }
        }
        remote.addView(auto)
        remote.addView(UiKit.button(this, p, if (syncInProgress) "جاري المزامنة..." else "مزامنة الآن", false).apply {
            isEnabled = !syncInProgress
            setOnClickListener { syncNow() }
        })
        remote.addView(UiKit.subtitle(this, p, "المشاركة تعمل فورًا. أما مشاهدة صاحب المحل للبيانات تلقائيًا من هاتف آخر فتحتاج خادم ATTEND PRO مركزيًا؛ عند ربط الخادم ستنتقل أحداث الحضور إليه تلقائيًا حسب هذا الخيار."))
        root.addView(remote)

        val bottom = UiKit.card(this, p, 10)
        bottom.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        root.addView(bottom)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private data class Summary(val uniqueEmployees: Int, val checkIns: Int, val checkOuts: Int, val lateEmployees: Int)

    private fun summary(events: List<AttendanceEvent>): Summary {
        val employees = events.map { it.employeeId }.toSet().size
        val ins = events.count { it.action == AttendanceAction.CHECK_IN }
        val outs = events.count { it.action == AttendanceAction.CHECK_OUT }
        val late = events.filter { it.action == AttendanceAction.CHECK_IN }.groupBy { it.employeeId }.count { (_, list) ->
            val first = list.minByOrNull { it.timestampEpochMillis }
            first != null && first.timestampEpochMillis > cutoffFor(first.timestampEpochMillis)
        }
        return Summary(employees, ins, outs, late)
    }

    private fun selectedEvents(): List<AttendanceEvent> {
        val all = repo.events()
        val start = when (period) {
            Period.TODAY -> dayStart(System.currentTimeMillis())
            Period.WEEK -> dayStart(System.currentTimeMillis()) - 6L * 24L * 60L * 60L * 1000L
            Period.MONTH -> Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            Period.ALL -> Long.MIN_VALUE
        }
        return all.filter { it.timestampEpochMillis >= start }
    }

    private fun reportPreview(events: List<AttendanceEvent>): String {
        if (events.isEmpty()) return "لا توجد عمليات في الفترة المحددة."
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val rows = events.takeLast(80).reversed().joinToString("\n") { e ->
            val action = if (e.action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"
            "• ${e.employeeName.ifBlank { e.employeeId }} — $action — ${fmt.format(Date(e.timestampEpochMillis))} — ${methodAr(e.method.name)}"
        }
        val more = (events.size - 80).coerceAtLeast(0)
        return if (more > 0) "$rows\n… و $more حركة أقدم" else rows
    }

    private fun methodAr(name: String): String = when (name) {
        "PIN" -> "PIN"
        "PHONE_BLE_BIOMETRIC" -> "هاتف + بصمة/وجه"
        "EXTERNAL_FINGERPRINT" -> "قارئ بصمة"
        "FACE" -> "وجه"
        "SUPERVISOR_OVERRIDE" -> "بإشراف"
        else -> name
    }

    private fun shareSummary(events: List<AttendanceEvent>) {
        val s = summary(events)
        val text = buildString {
            append("ATTEND PRO — ${repo.storeName}\n")
            append("الفترة: ${period.title}\n")
            append("الفرع: ${repo.branchId}\n")
            append("الموظفون في التقرير: ${s.uniqueEmployees}\n")
            append("الحضور: ${s.checkIns}\n")
            append("الانصراف: ${s.checkOuts}\n")
            append("المتأخرون: ${s.lateEmployees}\n")
            append("إجمالي الحركات: ${events.size}\n")
            append("أُنشئ في: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}")
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "ATTEND PRO - تقرير ${period.title}")
            putExtra(Intent.EXTRA_TEXT, text)
        }, "مشاركة التقرير"))
    }

    private fun shareCsv(events: List<AttendanceEvent>) {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val csv = buildString {
            append("employee_id,employee_name,branch,time,action,method,verified,synced\n")
            events.forEach { e ->
                append(csvCell(e.employeeId)); append(',')
                append(csvCell(e.employeeName)); append(',')
                append(csvCell(e.branchId)); append(',')
                append(csvCell(fmt.format(Date(e.timestampEpochMillis)))); append(',')
                append(e.action.name); append(','); append(e.method.name); append(','); append(e.verified); append(','); append(e.synced); append('\n')
            }
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "ATTEND PRO - ${repo.storeName} - ${period.title}")
            putExtra(Intent.EXTRA_TEXT, csv)
        }, "مشاركة CSV"))
    }

    private fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun remoteStatusText(): String {
        val last = if (repo.lastSyncAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(repo.lastSyncAt)) else "لم تتم بعد"
        val server = if (repo.serverUrl.isBlank()) "غير مربوط" else "مضبوط"
        val license = if (repo.isActivationActive()) "نشط" else "غير مفعل مركزيًا"
        return "الخادم: $server • الترخيص: $license\nعمليات تنتظر المزامنة: ${repo.pendingEvents().size} • آخر مزامنة: $last${if (repo.lastSyncMessage.isNotBlank()) "\n${repo.lastSyncMessage}" else ""}"
    }

    private fun syncNow() {
        if (syncInProgress) return
        if (repo.serverUrl.isBlank()) {
            info("المزامنة", "لم يتم ربط خادم ATTEND PRO المركزي بعد. يمكنك استخدام مشاركة التقرير الآن، والمراقبة التلقائية ستعمل بعد ربط الخادم.")
            return
        }
        val license = repo.activeLicense()
        if (license == null) {
            info("المزامنة", "فعّل جهاز المحل أولًا قبل المزامنة المركزية.")
            return
        }
        val pending = repo.pendingEvents()
        if (pending.isEmpty()) {
            info("المزامنة", "لا توجد عمليات جديدة تحتاج مزامنة.")
            return
        }
        syncInProgress = true
        buildUi()
        Thread {
            val result = NetworkTools.syncEvents(repo.serverUrl, license.licenseId, repo.licenseToken, pending.take(500))
            runOnUiThread {
                syncInProgress = false
                if (result.isSuccess) {
                    repo.markSynced(result.getOrThrow())
                    repo.lastSyncAt = System.currentTimeMillis()
                    repo.lastSyncMessage = "تمت المزامنة بنجاح"
                    info("تمت المزامنة", "تم إرسال ${result.getOrThrow().size} حركة إلى الخادم.")
                } else {
                    repo.lastSyncMessage = "فشلت المزامنة: ${result.exceptionOrNull()?.message ?: "خطأ"}"
                    info("تعذر المزامنة", repo.lastSyncMessage)
                }
                buildUi()
            }
        }.apply { isDaemon = true }.start()
    }

    private fun dayStart(time: Long): Long = Calendar.getInstance().apply {
        timeInMillis = time
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun cutoffFor(time: Long): Long = Calendar.getInstance().apply {
        timeInMillis = time
        set(Calendar.HOUR_OF_DAY, repo.shiftHour); set(Calendar.MINUTE, repo.shiftMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.MINUTE, repo.graceMinutes)
    }.timeInMillis

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }
}
