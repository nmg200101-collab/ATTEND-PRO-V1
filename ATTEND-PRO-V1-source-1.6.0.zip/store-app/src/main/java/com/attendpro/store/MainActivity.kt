package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.ActivationProtocol
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.QrScannerActivity
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var storeSummary: TextView
    private var pendingFaceEmployeeId: String? = null
    @Volatile private var syncInProgress = false
    private var employeeManagerMode = false
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        employeeManagerMode = intent?.getBooleanExtra(EXTRA_EMPLOYEE_MANAGER, false) == true
        pendingFaceEmployeeId = savedInstanceState?.getString("pendingFaceEmployeeId")
        scanner = BleEmployeeScanner(this, ::handleBlePayload) { msg ->
            runOnUiThread { if (::status.isInitialized) status.text = msg }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingFaceEmployeeId?.let { outState.putString("pendingFaceEmployeeId", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (employeeManagerMode) {
            buildEmployeeManagerUi()
            refreshDashboard()
            return
        }
        buildUi()
        refreshDashboard()
        if (repo.autoScan && repo.employees().any { it.active && it.companionEnabled }) {
            runCatching { scanner.start() }.onFailure { if (::status.isInitialized) status.text = "تعذر تشغيل BLE: ${it.message ?: "خطأ"}" }
        }
        autoSyncIfReady()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val header = UiKit.card(this, p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 64), UiKit.dp(this@MainActivity, 64))
        })
        header.addView(UiKit.title(this, p, "ATTEND PRO", 27f).apply { gravity = Gravity.CENTER })
        header.addView(UiKit.subtitle(this, p, "نظام حضور المحل • الإصدار 1.6.0").apply { gravity = Gravity.CENTER })
        storeSummary = UiKit.subtitle(this, p, storeSummaryText()).apply { gravity = Gravity.CENTER; setPadding(0, UiKit.dp(this@MainActivity, 5), 0, 0) }
        header.addView(storeSummary)
        root.addView(header)

        if (!repo.isStoreProfileComplete) {
            val setup = UiKit.card(this, p, 13)
            setup.addView(UiKit.sectionLabel(this, p, "إكمال إعداد المحل"))
            setup.addView(UiKit.subtitle(this, p, "أكمل معلومات المحل من «إعدادات نظام المحل» قبل التشغيل الفعلي.").apply { gravity = Gravity.CENTER })
            setup.addView(UiKit.button(this, p, "فتح إعدادات نظام المحل", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, StoreSettingsActivity::class.java)) } })
            root.addView(setup)
        }

        val dash = UiKit.card(this, p)
        dash.addView(UiKit.sectionLabel(this, p, "ملخص اليوم"))
        counts = TextView(this).apply { textSize = 18f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        dash.addView(counts)
        root.addView(dash)

        val daily = UiKit.card(this, p)
        daily.addView(UiKit.sectionLabel(this, p, "التشغيل اليومي"))
        daily.addView(UiKit.button(this, p, "تسجيل حضور / انصراف").apply { setOnClickListener { showAttendanceMethods() } })
        daily.addView(UiKit.button(this, p, "سجل اليوم", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportsActivity::class.java)) } })
        daily.addView(UiKit.button(this, p, "التقارير والمراقبة", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportsActivity::class.java)) } })
        root.addView(daily)

        val admin = UiKit.card(this, p)
        admin.addView(UiKit.sectionLabel(this, p, "إدارة المحل"))
        admin.addView(UiKit.subtitle(this, p, "معلومات المحل والموظفون وطرق التعرف والدوام والتقارير في قسم مستقل يمكن لصاحب المحل حمايته برمز خاص."))
        admin.addView(UiKit.button(this, p, "إعدادات نظام المحل 🔒").apply { setOnClickListener { startActivity(Intent(this@MainActivity, StoreSettingsActivity::class.java)) } })
        root.addView(admin)

        val activation = UiKit.card(this, p, 13)
        val validation = repo.currentLicenseValidation()
        val license = validation.license
        activation.addView(UiKit.sectionLabel(this, p, "الترخيص والمزامنة"))
        if (validation.valid && license != null) {
            val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(license.expiresAt))
            activation.addView(UiKit.subtitle(this, p, "✓ مفعل حتى $date • حد الموظفين ${license.maxEmployees} • المزامنة المعلقة ${repo.pendingEvents().size}").apply { gravity = Gravity.CENTER })
            activation.addView(UiKit.button(this, p, "بيانات التفعيل", false).apply { setOnClickListener { showLicenseDetails() } })
        } else {
            activation.addView(UiKit.subtitle(this, p, "وضع تجريبي محلي • ${validation.reason} • حد الموظفين ${repo.effectiveEmployeeLimit()}").apply { gravity = Gravity.CENTER })
            activation.addView(UiKit.button(this, p, "تفعيل هذا الجهاز", false).apply { setOnClickListener { showActivationCenter() } })
        }
        root.addView(activation)

        val live = UiKit.card(this, p)
        live.addView(UiKit.sectionLabel(this, p, "حالة النظام"))
        status = TextView(this).apply { text = "جاهز"; textSize = 16f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { textSize = 14f; setTextColor(p.muted); setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0); gravity = Gravity.CENTER }
        live.addView(status); live.addView(nearbyView)
        root.addView(live)

        val platform = UiKit.card(this, p, 10)
        platform.addView(UiKit.subtitle(this, p, "إدارة منصة ATTEND PRO والوكلاء والتراخيص منفصلة عن رمز صاحب المحل.").apply { gravity = Gravity.CENTER })
        platform.addView(UiKit.button(this, p, "إدارة ATTEND PRO العليا", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, SystemSettingsActivity::class.java)) } })
        root.addView(platform)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun buildEmployeeManagerUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 28)); setBackgroundColor(p.bg)
        }
        val header = UiKit.card(this, p)
        header.addView(UiKit.sectionLabel(this, p, "إعدادات نظام المحل"))
        header.addView(UiKit.title(this, p, "الموظفون وملفات التعرف", 24f))
        header.addView(UiKit.subtitle(this, p, "إضافة وتعديل الموظفين وضبط الوجه الأولي وPIN والبصمة الخارجية وربط هاتف الموظف."))
        root.addView(header)

        val summaryCard = UiKit.card(this, p)
        counts = TextView(this).apply { textSize = 17f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        summaryCard.addView(counts)
        root.addView(summaryCard)

        val actions = UiKit.card(this, p)
        actions.addView(UiKit.button(this, p, "＋ إضافة موظف جديد").apply { setOnClickListener { showEmployeeEditor(null) } })
        actions.addView(UiKit.button(this, p, "عرض الموظفين وتعديلهم", false).apply { setOnClickListener { showEmployeesDialog() } })
        actions.addView(UiKit.button(this, p, "شرح طرق التعرف", false).apply { setOnClickListener { showFaceEngineInfo() } })
        root.addView(actions)

        val recognitions = UiKit.card(this, p)
        val employees = repo.employees().filter { it.active }
        recognitions.addView(UiKit.sectionLabel(this, p, "جاهزية طرق التعرف"))
        recognitions.addView(UiKit.subtitle(this, p, "وجه أولي ${employees.count { it.faceProfileRef.isNotBlank() }} • PIN ${employees.count { it.pin.isNotBlank() }} • بصمة خارجية ${employees.count { it.externalFingerprintId.isNotBlank() }} • هاتف ${employees.count { it.companionEnabled }}"))
        root.addView(recognitions)

        val state = UiKit.card(this, p, 10)
        status = TextView(this).apply { text = "جاهز لإدارة الموظفين"; textSize = 15f; setTextColor(p.text); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { text = ""; textSize = 13f; setTextColor(p.muted); gravity = Gravity.CENTER }
        state.addView(status); state.addView(nearbyView)
        state.addView(UiKit.button(this, p, "رجوع إلى إعدادات المحل", false).apply { setOnClickListener { finish() } })
        root.addView(state)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun autoSyncIfReady() {
        if (!repo.reportAutoSync || syncInProgress || repo.serverUrl.isBlank() || !repo.isActivationActive()) return
        val pending = repo.pendingEvents()
        if (pending.isEmpty()) return
        val license = repo.activeLicense() ?: return
        syncInProgress = true
        Thread {
            val result = NetworkTools.syncEvents(repo.serverUrl, license.licenseId, repo.licenseToken, pending.take(200))
            runOnUiThread {
                syncInProgress = false
                if (result.isSuccess) {
                    repo.markSynced(result.getOrThrow())
                    repo.lastSyncAt = System.currentTimeMillis()
                    repo.lastSyncMessage = "تمت المزامنة"
                    if (::status.isInitialized) status.text = "✓ تمت مزامنة ${result.getOrThrow().size} عملية"
                } else {
                    repo.lastSyncMessage = "فشلت: ${result.exceptionOrNull()?.message ?: "خطأ"}"
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun storeSummaryText(): String {
        val parts = mutableListOf<String>()
        parts.add(repo.storeName)
        parts.add("فرع ${repo.branchId}")
        if (repo.storePhone.isNotBlank()) parts.add(repo.storePhone)
        return parts.joinToString(" • ")
    }

    private fun showActivationCenter() {
        val validation = repo.currentLicenseValidation()
        val items = mutableListOf("إنشاء طلب تفعيل للمالك", "مسح QR التفعيل", "إدخال رمز التفعيل")
        if (validation.valid) items.add("عرض بيانات الترخيص")
        items.add("نسخ معرّف جهاز المحل")
        AlertDialog.Builder(this).setTitle("تفعيل ATTEND PRO").setItems(items.toTypedArray()) { _, which ->
            when (items[which]) {
                "إنشاء طلب تفعيل للمالك" -> showActivationRequest()
                "مسح QR التفعيل" -> scanActivationToken()
                "إدخال رمز التفعيل" -> enterActivationToken()
                "عرض بيانات الترخيص" -> showLicenseDetails()
                "نسخ معرّف جهاز المحل" -> copyActivationText(repo.storeId, "تم نسخ معرّف الجهاز")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showActivationRequest() {
        val request = ActivationProtocol.createRequest(repo.storeId, repo.storeName, repo.branchId)
        val qr = runCatching { QrCodeTools.bitmap(request, 720) }.getOrNull()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 10, 18, 10) }
        box.addView(UiKit.subtitle(this, p, "على جهاز المالك: إعدادات النظام ← المالك ← التراخيص ← مسح QR طلب التفعيل").apply { gravity = Gravity.CENTER })
        if (qr != null) box.addView(ImageView(this).apply {
            setImageBitmap(qr); adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 330))
        })
        AlertDialog.Builder(this).setTitle("طلب تفعيل المحل").setView(box)
            .setPositiveButton("نسخ الطلب") { _, _ -> copyActivationText(request, "تم نسخ طلب التفعيل") }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun scanActivationToken() {
        runCatching {
            startActivityForResult(
                Intent(this, QrScannerActivity::class.java).putExtra(QrScannerActivity.EXTRA_PROMPT, "امسح QR التفعيل الصادر من جهاز المالك"),
                REQUEST_ACTIVATION_QR
            )
        }.onFailure {
            if (::status.isInitialized) status.text = "تعذر فتح ماسح التفعيل: ${it.message ?: "خطأ"}"
        }
    }

    private fun enterActivationToken() {
        val input = UiKit.field(this, p, "الصق رمز التفعيل الصادر من المالك").apply {
            minLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val dialog = AlertDialog.Builder(this).setTitle("تفعيل هذا الجهاز").setView(input)
            .setPositiveButton("تفعيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val validation = applyActivationToken(input.text.toString())
                if (!validation.valid) { input.error = validation.reason; return@setOnClickListener }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun applyActivationToken(token: String): ActivationProtocol.LicenseValidation {
        val validation = repo.saveLicense(token)
        if (!validation.valid) return validation
        validation.license?.let { lic ->
            repo.storeName = if (repo.storeName == "جهاز المحل") lic.storeName else repo.storeName
            repo.branchId = if (repo.branchId.isBlank() || repo.branchId == "MAIN") lic.branchId else repo.branchId
        }
        buildUi(); refreshDashboard()
        AlertDialog.Builder(this).setTitle("تم التفعيل ✓")
            .setMessage("تم ربط الترخيص بهذا الجهاز بنجاح. يمكن متابعة العمل دون إنترنت، وعند تجهيز الخادم المركزي ستتم المزامنة تلقائيًا.")
            .setPositiveButton("حسنًا", null).show()
        return validation
    }

    private fun showLicenseDetails() {
        val validation = repo.currentLicenseValidation()
        val lic = validation.license
        if (!validation.valid || lic == null) {
            AlertDialog.Builder(this).setTitle("حالة التفعيل").setMessage(validation.reason).setPositiveButton("حسنًا", null).show()
            return
        }
        val issued = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(lic.issuedAt))
        val expires = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(lic.expiresAt))
        AlertDialog.Builder(this).setTitle("بيانات الترخيص")
            .setMessage("المحل: ${lic.storeName}\nالفرع: ${lic.branchId}\nرقم الترخيص: ${lic.licenseId}\nالإصدار: $issued\nالانتهاء: $expires\nحد الموظفين: ${lic.maxEmployees}\nالجهاز: ${repo.storeId}")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun copyActivationText(text: String, message: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("ATTEND PRO", text))
        if (::status.isInitialized) status.text = message
    }

    private fun showAttendanceMethods(){
        val actions=mutableListOf<Pair<String,()->Unit>>()
        if(repo.allowPinFallback) actions.add("تسجيل عبر PIN" to { showPinDialog() })
        if(repo.allowEmployeeCompanion) actions.add("التعرف من هاتف الموظف عبر BLE" to { if(scanner.isScanning()){scanner.stop();status.text="تم إيقاف البحث عن هواتف الموظفين"}else{scanner.start();status.text="جاري البحث عن هواتف الموظفين الموثوقة"} })
        actions.add("قارئ البصمة الخارجي" to { quickFingerprintCheck() })
        actions.add("بصمة الوجه على جهاز المحل" to { showFaceEngineInfo() })
        AlertDialog.Builder(this).setTitle("طريقة تسجيل الحضور").setItems(actions.map{it.first}.toTypedArray()){_,which->actions[which].second()}.setNegativeButton("إغلاق",null).show()
    }

    private fun showFaceEngineInfo(){
        AlertDialog.Builder(this).setTitle("التعرف بالوجه على جهاز المحل")
            .setMessage("يمكن الآن تسجيل صورة وجه أولية اختيارية لكل موظف من ملفه. الصورة تحفظ داخل مساحة التطبيق الخاصة لتجهيز ملف الوجه، لكن المطابقة التلقائية للهوية لن تُفعّل إلا بعد إضافة محرك تعرف وجوه موثوق. لذلك لن يسجل النظام حضورًا بالوجه اعتمادًا على صورة فقط.")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun quickFingerprintCheck(){
        if(repo.fingerprintHost.isBlank()){status.text="أدخل بيانات قارئ البصمة من إدارة النظام أولًا";return}
        status.text="جاري اختبار قارئ البصمة..."
        Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{
            status.text=if(r.isSuccess)"✓ قارئ البصمة متصل — استيراد البصمات يحتاج Driver الموديل" else "تعذر الاتصال بالقارئ: ${r.exceptionOrNull()?.message ?: "خطأ"}"
        }}.start()
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees()
        val labels=mutableListOf("＋ إضافة موظف جديد")
        labels.addAll(employees.map{"${if(it.active)"●" else "○"} ${it.displayName} (${it.employeeId})${if(it.jobTitle.isNotBlank())" • ${it.jobTitle}" else ""}"})
        AlertDialog.Builder(this).setTitle("الموظفون (${employees.size})").setItems(labels.toTypedArray()){_,which->
            if(which==0) showEmployeeEditor(null) else showEmployeeDetails(employees[which-1])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showEmployeeEditor(existing: PairedEmployee?) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)

        val id = UiKit.field(this, p, "رقم الموظف").apply { setText(existing?.employeeId.orEmpty()); isEnabled = existing == null }
        val name = UiKit.field(this, p, "اسم الموظف").apply { setText(existing?.displayName.orEmpty()) }
        val phone = UiKit.field(this, p, "رقم الهاتف - اختياري").apply { setText(existing?.phone.orEmpty()) }
        val job = UiKit.field(this, p, "المسمى الوظيفي").apply { setText(existing?.jobTitle.orEmpty()) }
        val department = UiKit.field(this, p, "القسم / الإدارة - اختياري").apply { setText(existing?.department.orEmpty()) }
        val nationalId = UiKit.field(this, p, "رقم الهوية - اختياري").apply { setText(existing?.nationalId.orEmpty()) }
        val hireDate = UiKit.field(this, p, "تاريخ التعيين - اختياري").apply { setText(existing?.hireDate.orEmpty()) }
        val branch = UiKit.field(this, p, "الفرع").apply { setText(existing?.branchId ?: repo.branchId) }
        val pin = UiKit.field(this, p, "PIN احتياطي جديد - اتركه فارغًا للإبقاء الحالي", true)
        val fingerprint = UiKit.field(this, p, "معرف الموظف في قارئ البصمة - اختياري").apply { setText(existing?.externalFingerprintId.orEmpty()) }
        val notes = UiKit.field(this, p, "ملاحظات - اختياري").apply { setText(existing?.notes.orEmpty()); minLines = 2 }
        val faceEnroll = CheckBox(this).apply {
            text = if (existing?.faceProfileRef.isNullOrBlank()) "تسجيل صورة الوجه الأولية بعد الحفظ — اختياري" else "تحديث صورة الوجه الأولية بعد الحفظ — اختياري"
            setTextColor(p.text)
            isChecked = false
        }
        val companion = CheckBox(this).apply { text = "السماح بتطبيق الموظف المساند"; setTextColor(p.text); isChecked = existing?.companionEnabled ?: true }
        listOf(id, name, phone, job, department, nationalId, hireDate, branch, pin, fingerprint, notes).forEach { box.addView(it) }
        box.addView(faceEnroll)
        box.addView(companion)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة موظف" else "تعديل الموظف")
            .setView(scroll)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employeeId = id.text.toString().trim()
                val displayName = name.text.toString().trim()
                if (employeeId.isBlank() || displayName.isBlank()) {
                    status.text = "رقم الموظف والاسم مطلوبان"
                    id.error = if (employeeId.isBlank()) "مطلوب" else null
                    name.error = if (displayName.isBlank()) "مطلوب" else null
                    return@setOnClickListener
                }
                if (existing == null && repo.employees().size >= repo.effectiveEmployeeLimit()) {
                    status.text = "وصلت إلى الحد المسموح للموظفين (${repo.effectiveEmployeeLimit()})"
                    AlertDialog.Builder(this).setTitle("حد الموظفين").setMessage("الترخيص الحالي يسمح بحد أقصى ${repo.effectiveEmployeeLimit()} موظفين. فعّل أو جدّد الترخيص لزيادة الحد.").setPositiveButton("حسنًا", null).show()
                    return@setOnClickListener
                }
                if (existing == null && repo.employees().any { it.employeeId.equals(employeeId, true) }) {
                    id.error = "رقم الموظف مستخدم بالفعل"
                    return@setOnClickListener
                }
                val secret = existing?.pairingSecret?.takeIf { SecretCodec.isValid(it) } ?: SecretCodec.encode(SecretCodec.generate())
                val pinHash = if (pin.text.toString().isBlank()) existing?.pin.orEmpty() else PairingProtocol.pinHash(pin.text.toString())
                val employee = PairedEmployee(
                    employeeId = employeeId,
                    displayName = displayName,
                    branchId = branch.text.toString().trim().ifBlank { repo.branchId },
                    pairingSecret = secret,
                    pin = pinHash,
                    phone = phone.text.toString().trim(),
                    jobTitle = job.text.toString().trim(),
                    externalFingerprintId = fingerprint.text.toString().trim(),
                    faceProfileRef = existing?.faceProfileRef.orEmpty(),
                    companionEnabled = companion.isChecked,
                    active = existing?.active ?: true,
                    department = department.text.toString().trim(),
                    nationalId = nationalId.text.toString().trim(),
                    hireDate = hireDate.text.toString().trim(),
                    notes = notes.text.toString().trim(),
                    faceCapturedAt = existing?.faceCapturedAt ?: 0L
                )
                repo.upsertEmployee(employee)
                status.text = "✓ تم حفظ ${employee.displayName}"
                refreshDashboard()
                dialog.dismiss()
                when {
                    faceEnroll.isChecked -> requestFaceCapture(employee)
                    employee.companionEnabled -> askShowProvision(employee)
                }
            }
        }
        dialog.show()
    }

    private fun askShowProvision(e:PairedEmployee){
        AlertDialog.Builder(this).setTitle("تم حفظ الموظف").setMessage("هل تريد الآن عرض QR تطبيق الموظف؟ هذه الخطوة اختيارية؛ الموظف مسجل في جهاز المحل حتى لو لم يستخدم التطبيق.")
            .setPositiveButton("عرض QR"){_,_->showProvisionQr(e)}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showEmployeeDetails(e: PairedEmployee) {
        val faceDate = if (e.faceCapturedAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(e.faceCapturedAt)) else ""
        val msg = buildString {
            append("الرقم: ${e.employeeId}\nالاسم: ${e.displayName}\nالفرع: ${e.branchId}")
            if (e.jobTitle.isNotBlank()) append("\nالمسمى: ${e.jobTitle}")
            if (e.department.isNotBlank()) append("\nالقسم: ${e.department}")
            if (e.phone.isNotBlank()) append("\nالهاتف: ${e.phone}")
            if (e.nationalId.isNotBlank()) append("\nالهوية: ${e.nationalId}")
            if (e.hireDate.isNotBlank()) append("\nتاريخ التعيين: ${e.hireDate}")
            append("\nPIN: ${if (e.pin.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nقارئ البصمة: ${e.externalFingerprintId.ifBlank { "غير مربوط" }}")
            append("\nالوجه الأولي: ${if (e.faceProfileRef.isBlank()) "غير مسجل" else "مسجل${if (faceDate.isNotBlank()) " • $faceDate" else ""}"}")
            append("\nتطبيق الموظف: ${if (e.companionEnabled) "مسموح" else "معطل"}")
            append("\nالحالة: ${if (e.active) "نشط" else "موقوف"}")
            if (e.notes.isNotBlank()) append("\nملاحظات: ${e.notes}")
        }

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 12))
        }
        scroll.addView(box)
        box.addView(UiKit.subtitle(this, p, msg).apply {
            setPadding(0, 0, 0, UiKit.dp(this@MainActivity, 10))
        })

        lateinit var dialog: AlertDialog
        fun addAction(label: String, primary: Boolean = false, action: () -> Unit) {
            box.addView(UiKit.button(this, p, label, primary).apply {
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            })
        }

        addAction("✎ تعديل بيانات الموظف", true) { showEmployeeEditor(e) }
        addAction("تسجيل / تحديث الوجه الأولي") { requestFaceCapture(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("عرض صورة الوجه الأولية") { showFaceReference(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("حذف صورة الوجه الأولية") { deleteFaceReference(e) }
        if (e.companionEnabled) addAction("عرض QR تطبيق الموظف") { showProvisionQr(e) }
        addAction("تسجيل يدوي بإشراف") { recordManual(e) }
        addAction(if (e.active) "إيقاف الموظف" else "تفعيل الموظف") {
            repo.upsertEmployee(e.copy(active = !e.active))
            status.text = "تم تحديث حالة ${e.displayName}"
            refreshDashboard()
        }
        addAction("حذف الموظف") {
            AlertDialog.Builder(this).setTitle("حذف الموظف").setMessage("حذف ${e.displayName} من جهاز المحل؟ لن تحذف سجلات الحضور السابقة.")
                .setPositiveButton("حذف") { _, _ ->
                    deleteFaceFile(e.faceProfileRef)
                    repo.removeEmployee(e.employeeId)
                    status.text = "تم حذف الموظف"
                    refreshDashboard()
                }
                .setNegativeButton("إلغاء", null).show()
        }

        dialog = AlertDialog.Builder(this)
            .setTitle("ملف الموظف — ${e.displayName}")
            .setView(scroll)
            .setNegativeButton("إغلاق", null)
            .create()
        dialog.show()
    }

    private fun requestFaceCapture(employee: PairedEmployee) {
        pendingFaceEmployeeId = employee.employeeId
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
        }
        val canOpen = cameraIntent.resolveActivity(packageManager) != null
        if (!canOpen) {
            pendingFaceEmployeeId = null
            status.text = "لا يوجد تطبيق كاميرا متاح"
            AlertDialog.Builder(this).setTitle("تعذر فتح الكاميرا").setMessage("لا يوجد تطبيق كاميرا متوافق على هذا الجهاز. يمكنك متابعة استخدام الموظف بدون تسجيل الوجه.").setPositiveButton("حسنًا", null).show()
            return
        }
        runCatching { startActivityForResult(cameraIntent, REQUEST_FACE_CAPTURE) }.onFailure {
            pendingFaceEmployeeId = null
            status.text = "تعذر فتح الكاميرا: ${it.message ?: "خطأ"}"
            AlertDialog.Builder(this).setTitle("تعذر تسجيل الوجه").setMessage("لم يتم فتح الكاميرا. لم تتأثر بيانات الموظف ويمكن المحاولة مرة أخرى لاحقًا.").setPositiveButton("حسنًا", null).show()
        }
    }

    private fun showFaceReference(employee: PairedEmployee) {
        val path = employee.faceProfileRef
        val bitmap = if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        if (bitmap == null) {
            status.text = "صورة الوجه غير متاحة"
            return
        }
        val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; setPadding(12, 12, 12, 12) }
        AlertDialog.Builder(this).setTitle("صورة الوجه الأولية — ${employee.displayName}").setView(image)
            .setMessage("هذه صورة مرجعية أولية محفوظة محليًا داخل التطبيق وليست مطابقة بيومترية نهائية بحد ذاتها.")
            .setPositiveButton("إغلاق", null).show()
    }

    private fun deleteFaceReference(employee: PairedEmployee) {
        deleteFaceFile(employee.faceProfileRef)
        repo.upsertEmployee(employee.copy(faceProfileRef = "", faceCapturedAt = 0L))
        status.text = "تم حذف صورة الوجه الأولية لـ ${employee.displayName}"
    }

    private fun deleteFaceFile(path: String) {
        if (path.isNotBlank()) runCatching { File(path).takeIf { it.exists() }?.delete() }
    }

    private fun showProvisionQr(employee:PairedEmployee){
        val provision=repo.newProvision(employee)
        val content=PairingProtocol.encodeEmployeeProvision(provision)
        val qr=runCatching{QrCodeTools.bitmap(content,680)}.getOrElse{status.text="تعذر إنشاء QR: ${it.message ?: "خطأ"}";return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(20,12,20,8)}
        box.addView(TextView(this).apply{text="افتح تطبيق الموظف → مسح باركود الموظف. سيتم إدخال البيانات والربط تلقائيًا. الرمز صالح 30 دقيقة.";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.text)})
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        AlertDialog.Builder(this).setTitle("رمز ${employee.displayName}").setView(box).setPositiveButton("إغلاق",null).show()
    }

    private fun recordManual(e:PairedEmployee){
        val action=nextAction(e.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=e.employeeId,employeeName=e.displayName,branchId=e.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.SUPERVISOR_OVERRIDE,deviceId=deviceId(),verified=true))
        status.text="✓ ${e.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} بإشراف";refreshDashboard()
    }

    private fun showPinDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val pin = UiKit.field(this, p, "PIN", true)
        box.addView(id); box.addView(pin)
        val dialog = AlertDialog.Builder(this).setTitle("التسجيل عبر PIN").setView(box)
            .setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = repo.employees().firstOrNull { it.active && it.employeeId.equals(id.text.toString().trim(), true) }
                if (employee == null) { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (employee.pin.isBlank()) { pin.error = "لم يتم تعيين PIN لهذا الموظف"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(employee.pin, pin.text.toString())) { pin.error = "PIN غير صحيح"; return@setOnClickListener }
                val action = nextAction(employee.employeeId)
                repo.addEvent(AttendanceEvent(employeeId = employee.employeeId, employeeName = employee.displayName, branchId = employee.branchId, timestampEpochMillis = System.currentTimeMillis(), action = action, method = AttendanceMethod.PIN, deviceId = deviceId(), verified = true))
                status.text = "✓ ${employee.displayName}: ${if (action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"}"
                refreshDashboard()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showReportsDialog(){
        val recent=repo.events().takeLast(30).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        val text=if(recent.isEmpty())"لا توجد عمليات بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))} — ${e.method.name}\n")}}
        AlertDialog.Builder(this).setTitle("السجل والتقارير").setMessage(text).setPositiveButton("مشاركة CSV"){_,_->shareTodayCsv()}.setNegativeButton("إغلاق",null).show()
    }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int){
        val employees=repo.employees().filter{it.active&&it.companionEnabled&&BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){val secret=SecretCodec.decode(employee.pairingSecret)?:continue;if(!BleProtocol.verify(payload,employee.employeeId,secret))continue;nearby[employee.employeeId]=System.currentTimeMillis() to rssi;if(payload.verified)maybeRecordVerified(employee,payload.token);runOnUiThread{refreshDashboard()};return}
    }

    private fun maybeRecordVerified(employee:PairedEmployee,token:Int){
        if(repo.lastProofToken(employee.employeeId)==token)return;val last=repo.lastEvent(employee.employeeId);if(last!=null&&System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return;val action=nextAction(employee.employeeId);repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PHONE_BLE_BIOMETRIC,deviceId=deviceId(),verified=true));repo.setLastProofToken(employee.employeeId,token);runOnUiThread{status.text="✓ ${employee.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"}"}
    }

    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        if (::storeSummary.isInitialized) storeSummary.text = storeSummaryText()
        val now=System.currentTimeMillis();nearby.entries.removeIf{now-it.value.first>45_000L};val employees=repo.employees().filter{it.active};val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet();val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis())e.employeeId else null}.toSet();if(::counts.isInitialized) counts.text="الموظفون ${employees.size}   •   الحاضرون ${present.size}\nالمتأخرون ${late.size}   •   غير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}";if(::nearbyView.isInitialized) nearbyView.text=if(nearby.isEmpty())"لا توجد هواتف موظفين قريبة الآن" else "هواتف قريبة: ${nearby.keys.joinToString("، "){id->employees.firstOrNull{it.employeeId==id}?.displayName?:id}}"
    }

    private fun shareTodayCsv(){val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))}
    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,repo.shiftHour);set(Calendar.MINUTE,repo.shiftMinute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);add(Calendar.MINUTE,repo.graceMinutes)}.timeInMillis
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ACTIVATION_QR) {
            if (!::status.isInitialized) { buildUi(); refreshDashboard() }
            if (resultCode == RESULT_OK) {
                val token = data?.getStringExtra(QrScannerActivity.EXTRA_RESULT).orEmpty()
                val validation = applyActivationToken(token)
                if (!validation.valid) status.text = "فشل التفعيل: ${validation.reason}"
            } else {
                status.text = data?.getStringExtra(QrScannerActivity.EXTRA_ERROR) ?: "تم إلغاء مسح التفعيل"
            }
            return
        }
        if (requestCode != REQUEST_FACE_CAPTURE) return
        if (!::status.isInitialized) { buildUi(); refreshDashboard() }
        val employeeId = pendingFaceEmployeeId
        pendingFaceEmployeeId = null
        if (resultCode != RESULT_OK || employeeId.isNullOrBlank()) {
            status.text = "تم إلغاء تسجيل الوجه — لم تتغير بيانات الموظف"
            return
        }
        val bitmap = runCatching { data?.extras?.get("data") as? Bitmap }.getOrNull()
        if (bitmap == null) {
            status.text = "لم تصل صورة صالحة من الكاميرا"
            AlertDialog.Builder(this).setTitle("لم يتم حفظ الوجه").setMessage("لم تُرجع الكاميرا صورة صالحة. لم تتأثر بيانات الموظف ويمكن المحاولة مرة أخرى.").setPositiveButton("حسنًا", null).show()
            return
        }
        val employee = repo.employees().firstOrNull { it.employeeId.equals(employeeId, true) }
        if (employee == null) {
            status.text = "تعذر العثور على الموظف بعد التقاط الصورة"
            return
        }
        runCatching {
            val dir = File(filesDir, "face_profiles").apply { mkdirs() }
            val safeId = employee.employeeId.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(dir, "$safeId.jpg")
            file.outputStream().use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) error("تعذر ضغط الصورة")
            }
            deleteFaceFile(employee.faceProfileRef.takeIf { it != file.absolutePath }.orEmpty())
            repo.upsertEmployee(employee.copy(faceProfileRef = file.absolutePath, faceCapturedAt = System.currentTimeMillis()))
            status.text = "✓ تم تسجيل صورة الوجه الأولية لـ ${employee.displayName}"
            AlertDialog.Builder(this).setTitle("تم تسجيل الوجه الأولي").setMessage("تم حفظ الصورة داخل مساحة ATTEND PRO الخاصة. هذه الخطوة اختيارية ولا تمنع بقية طرق الحضور. المطابقة التلقائية بالوجه ستُفعّل فقط عند إضافة محرك التعرف الموثوق.").setPositiveButton("حسنًا", null).show()
        }.onFailure {
            status.text = "تعذر حفظ صورة الوجه: ${it.message ?: "خطأ"}"
        }
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==BleEmployeeScanner.REQUEST_PERMISSIONS){if(grantResults.isNotEmpty()&&grantResults.all{it==android.content.pm.PackageManager.PERMISSION_GRANTED}){status.text="تم منح صلاحيات BLE";if(repo.autoScan)scanner.start()}else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"}}
    override fun onDestroy(){scanner.stop();super.onDestroy()}
    companion object {
        const val EXTRA_EMPLOYEE_MANAGER = "open_employee_manager"
        private const val REQUEST_FACE_CAPTURE = 6201
        private const val REQUEST_ACTIVATION_QR = 6202
    }

}
