package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.NetworkTools
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit

class StoreSettingsActivity : Activity() {
    private lateinit var repo: StoreRepository
    private val p by lazy { UiKit.palette(this) }
    private var authenticated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        authenticated = savedInstanceState?.getBoolean("authenticated", false) ?: false
        showGateOrDashboard()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("authenticated", authenticated)
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (authenticated || !repo.hasStoreAdminPin) showDashboard()
    }

    private fun showGateOrDashboard() {
        if (!repo.hasStoreAdminPin) {
            authenticated = true
            showDashboard()
            return
        }
        if (repo.storeAdminLockUntil > System.currentTimeMillis()) {
            val remaining = ((repo.storeAdminLockUntil - System.currentTimeMillis()) / 1000L).coerceAtLeast(1)
            showLockedScreen("تم إيقاف المحاولات مؤقتًا. حاول بعد $remaining ثانية.")
            return
        }
        showLogin()
    }

    private fun showLogin() {
        window.statusBarColor = p.bg
        val root = baseRoot()
        val card = UiKit.card(this, p)
        card.addView(UiKit.sectionLabel(this, p, "إعدادات نظام المحل"))
        card.addView(UiKit.title(this, p, "دخول صاحب المحل", 24f))
        card.addView(UiKit.subtitle(this, p, "أدخل رمز الحماية الخاص بهذا المحل للوصول إلى الموظفين وطرق الحضور والتقارير والإعدادات."))
        val pin = UiKit.field(this, p, "رمز القسم", true).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        card.addView(pin)
        card.addView(UiKit.button(this, p, "دخول").apply {
            setOnClickListener {
                val entered = pin.text.toString()
                if (repo.verifyStoreAdminPin(entered)) {
                    authenticated = true
                    showDashboard()
                } else {
                    pin.error = if (repo.storeAdminLockUntil > System.currentTimeMillis()) "تم القفل لمدة دقيقة" else "الرمز غير صحيح"
                }
            }
        })
        card.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        root.addView(card)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showLockedScreen(message: String) {
        window.statusBarColor = p.bg
        val root = baseRoot()
        val card = UiKit.card(this, p)
        card.addView(UiKit.title(this, p, "القسم محمي", 23f))
        card.addView(UiKit.subtitle(this, p, message))
        card.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        root.addView(card)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showDashboard() {
        window.statusBarColor = p.bg
        val root = baseRoot()

        val header = UiKit.card(this, p)
        header.addView(UiKit.sectionLabel(this, p, "إعدادات نظام المحل"))
        header.addView(UiKit.title(this, p, repo.storeName, 25f))
        header.addView(UiKit.subtitle(this, p, "الفرع: ${repo.branchId} • الموظفون: ${repo.employees().count { it.active }} • الإصدار 1.6.0"))
        root.addView(header)

        val securityNotice = UiKit.card(this, p, 13)
        securityNotice.addView(UiKit.sectionLabel(this, p, "حماية القسم"))
        securityNotice.addView(UiKit.subtitle(this, p, if (repo.hasStoreAdminPin) "✓ هذا القسم محمي برمز صاحب المحل." else "القسم غير محمي حاليًا. يمكنك إنشاء رمز خاص بصاحب المحل."))
        securityNotice.addView(UiKit.button(this, p, if (repo.hasStoreAdminPin) "تغيير رمز قسم المحل" else "إنشاء رمز حماية", false).apply {
            setOnClickListener { changeStorePin() }
        })
        root.addView(securityNotice)

        val store = UiKit.card(this, p)
        store.addView(UiKit.sectionLabel(this, p, "المحل والموظفون"))
        store.addView(UiKit.button(this, p, "معلومات المحل").apply { setOnClickListener { editStoreProfile() } })
        store.addView(UiKit.button(this, p, "الموظفون وملفات التعرف", false).apply {
            setOnClickListener {
                startActivity(Intent(this@StoreSettingsActivity, MainActivity::class.java).putExtra(MainActivity.EXTRA_EMPLOYEE_MANAGER, true))
            }
        })
        root.addView(store)

        val attendance = UiKit.card(this, p)
        attendance.addView(UiKit.sectionLabel(this, p, "طرق التعرف والحضور"))
        attendance.addView(UiKit.subtitle(this, p, recognitionSummary()))
        attendance.addView(UiKit.button(this, p, "ضبط طرق الحضور والتحقق").apply { setOnClickListener { attendanceMethodsSettings() } })
        attendance.addView(UiKit.button(this, p, "الدوام والسماح", false).apply { setOnClickListener { shiftSettings() } })
        attendance.addView(UiKit.button(this, p, "قارئ البصمة الخارجي", false).apply { setOnClickListener { fingerprintSettings() } })
        root.addView(attendance)

        val reports = UiKit.card(this, p)
        reports.addView(UiKit.sectionLabel(this, p, "التقارير والمراقبة"))
        reports.addView(UiKit.subtitle(this, p, "تقارير يومية وأسبوعية وشهرية، مشاركة مباشرة، ومزامنة أحداث الحضور إلى الخادم عند ربطه."))
        reports.addView(UiKit.button(this, p, "فتح التقارير والمراقبة").apply {
            setOnClickListener { startActivity(Intent(this@StoreSettingsActivity, ReportsActivity::class.java)) }
        })
        root.addView(reports)

        val maintenance = UiKit.card(this, p)
        maintenance.addView(UiKit.sectionLabel(this, p, "الصيانة والإدارة"))
        maintenance.addView(UiKit.button(this, p, "فحص جاهزية المحل", false).apply { setOnClickListener { healthCheck() } })
        maintenance.addView(UiKit.button(this, p, "إدارة ATTEND PRO العليا", false).apply {
            setOnClickListener { startActivity(Intent(this@StoreSettingsActivity, SystemSettingsActivity::class.java)) }
        })
        maintenance.addView(UiKit.button(this, p, "إغلاق إعدادات المحل", false).apply { setOnClickListener { finish() } })
        root.addView(maintenance)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun recognitionSummary(): String {
        val employees = repo.employees().filter { it.active }
        val face = employees.count { it.faceProfileRef.isNotBlank() }
        val pin = employees.count { it.pin.isNotBlank() }
        val ext = employees.count { it.externalFingerprintId.isNotBlank() }
        val phone = employees.count { it.companionEnabled }
        return "وجه أولي $face • PIN $pin • بصمة خارجية $ext • هاتف موظف $phone\n" +
            "صورة الوجه الأولية اختيارية. التعرف التلقائي بالوجه يحتاج محرك تعرف موثوق ولا يتم ادعاؤه اعتمادًا على صورة فقط."
    }

    private fun editStoreProfile() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)
        val name = UiKit.field(this, p, "اسم المحل").apply { setText(repo.storeName) }
        val branch = UiKit.field(this, p, "رمز الفرع").apply { setText(repo.branchId) }
        val phone = UiKit.field(this, p, "هاتف المحل - اختياري").apply { setText(repo.storePhone) }
        val address = UiKit.field(this, p, "العنوان - اختياري").apply { setText(repo.storeAddress) }
        val manager = UiKit.field(this, p, "اسم صاحب / مدير المحل - اختياري").apply { setText(repo.storeManagerName) }
        val commercial = UiKit.field(this, p, "السجل / المعرف التجاري - اختياري").apply { setText(repo.storeCommercialId) }
        val notes = UiKit.field(this, p, "ملاحظات المحل - اختياري").apply { setText(repo.storeNotes); minLines = 2 }
        listOf(name, branch, phone, address, manager, commercial, notes).forEach { box.addView(it) }
        val dialog = AlertDialog.Builder(this).setTitle("معلومات المحل").setView(scroll).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim(); val b = branch.text.toString().trim()
                if (n.isBlank() || b.isBlank()) {
                    name.error = if (n.isBlank()) "اسم المحل مطلوب" else null
                    branch.error = if (b.isBlank()) "رمز الفرع مطلوب" else null
                    return@setOnClickListener
                }
                repo.storeName = n; repo.branchId = b; repo.storePhone = phone.text.toString(); repo.storeAddress = address.text.toString()
                repo.storeManagerName = manager.text.toString(); repo.storeCommercialId = commercial.text.toString(); repo.storeNotes = notes.text.toString()
                repo.ensureCurrentStoreInManagement(); dialog.dismiss(); info("تم الحفظ", "تم تحديث معلومات المحل."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun attendanceMethodsSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val auto = CheckBox(this).apply { text = "التعرف على هاتف الموظف تلقائيًا عبر BLE"; setTextColor(p.text); isChecked = repo.autoScan }
        val companion = CheckBox(this).apply { text = "السماح بتطبيق الموظف"; setTextColor(p.text); isChecked = repo.allowEmployeeCompanion }
        val pin = CheckBox(this).apply { text = "السماح بـ PIN كطريقة احتياطية"; setTextColor(p.text); isChecked = repo.allowPinFallback }
        val bio = CheckBox(this).apply { text = "اشتراط بصمة/وجه هاتف الموظف عند الحضور بالجوال"; setTextColor(p.text); isChecked = repo.requirePhoneBiometric }
        box.addView(UiKit.subtitle(this, p, "يتم تحديد رقم PIN ومعرف قارئ البصمة وصورة الوجه لكل موظف من ملفه."))
        listOf(auto, companion, pin, bio).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("طرق الحضور والتحقق").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.autoScan = auto.isChecked; repo.allowEmployeeCompanion = companion.isChecked; repo.allowPinFallback = pin.isChecked; repo.requirePhoneBiometric = bio.isChecked
            info("تم", "تم حفظ طرق الحضور والتحقق.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun shiftSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val hour = UiKit.field(this, p, "ساعة بداية الدوام 0-23", true).apply { setText(repo.shiftHour.toString()) }
        val minute = UiKit.field(this, p, "الدقيقة", true).apply { setText(repo.shiftMinute.toString()) }
        val grace = UiKit.field(this, p, "دقائق السماح", true).apply { setText(repo.graceMinutes.toString()) }
        listOf(hour, minute, grace).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("الدوام والسماح").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.shiftHour = hour.text.toString().toIntOrNull() ?: 8
            repo.shiftMinute = minute.text.toString().toIntOrNull() ?: 0
            repo.graceMinutes = grace.text.toString().toIntOrNull() ?: 10
            info("تم", "تم تحديث وقت الدوام ودقائق السماح.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun fingerprintSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val host = UiKit.field(this, p, "IP جهاز البصمة").apply { setText(repo.fingerprintHost) }
        val port = UiKit.field(this, p, "Port مثل 4370", true).apply { setText(repo.fingerprintPort.toString()) }
        box.addView(UiKit.subtitle(this, p, "الاتصال الشبكي يعمل كاختبار عام. استيراد البصمات والسجلات يحتاج Driver/Protocol خاص بموديل جهاز البصمة."))
        box.addView(host); box.addView(port)
        AlertDialog.Builder(this).setTitle("قارئ البصمة الخارجي").setView(box).setPositiveButton("حفظ واختبار") { _, _ ->
            repo.fingerprintHost = host.text.toString(); repo.fingerprintPort = port.text.toString().toIntOrNull() ?: 4370
            Thread {
                val result = NetworkTools.probeTcp(repo.fingerprintHost, repo.fingerprintPort)
                runOnUiThread { info("نتيجة الاتصال", if (result.isSuccess) "✓ تم الوصول إلى الجهاز على الشبكة." else "تعذر الاتصال: ${result.exceptionOrNull()?.message ?: "خطأ"}") }
            }.start()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun changeStorePin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val pin = UiKit.field(this, p, "رمز جديد من 4 إلى 8 أرقام", true).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val confirm = UiKit.field(this, p, "تأكيد الرمز", true).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(pin); box.addView(confirm)
        val builder = AlertDialog.Builder(this).setTitle(if (repo.hasStoreAdminPin) "تغيير رمز قسم المحل" else "إنشاء رمز قسم المحل").setView(box)
            .setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null)
        if (repo.hasStoreAdminPin) builder.setNeutralButton("إزالة الحماية") { _, _ ->
            repo.clearStoreAdminPin(); authenticated = true; info("تم", "تمت إزالة رمز قسم المحل."); showDashboard()
        }
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = pin.text.toString(); val b = confirm.text.toString()
                if (a.length !in 4..8 || a.any { !it.isDigit() }) { pin.error = "استخدم 4 إلى 8 أرقام"; return@setOnClickListener }
                if (a != b) { confirm.error = "الرمزان غير متطابقين"; return@setOnClickListener }
                repo.setStoreAdminPin(a); authenticated = true; dialog.dismiss(); info("تم", "تم حفظ رمز قسم المحل."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun healthCheck() {
        val bt = getSystemService(BluetoothManager::class.java)?.adapter
        val bluetooth = when { bt == null -> "غير مدعوم"; !bt.isEnabled -> "متوقف"; else -> "يعمل" }
        val employees = repo.employees()
        val license = repo.currentLicenseValidation()
        val syncState = if (repo.serverUrl.isBlank()) "الخادم غير مربوط" else "الخادم مضبوط • ${repo.pendingEvents().size} عملية معلقة"
        val msg = "معلومات المحل: ${if (repo.isStoreProfileComplete) "مكتملة" else "تحتاج إكمال"}\n" +
            "Bluetooth: $bluetooth\n" +
            "الموظفون النشطون: ${employees.count { it.active }}\n" +
            "وجوه أولية: ${employees.count { it.faceProfileRef.isNotBlank() }}\n" +
            "PIN: ${employees.count { it.pin.isNotBlank() }}\n" +
            "بصمة خارجية: ${employees.count { it.externalFingerprintId.isNotBlank() }}\n" +
            "التفعيل: ${if (license.valid) "نشط" else license.reason}\n" + syncState
        info("فحص جاهزية المحل", msg)
    }

    private fun baseRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(UiKit.dp(this@StoreSettingsActivity, 16), UiKit.dp(this@StoreSettingsActivity, 18), UiKit.dp(this@StoreSettingsActivity, 16), UiKit.dp(this@StoreSettingsActivity, 28))
        setBackgroundColor(p.bg)
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }
}
