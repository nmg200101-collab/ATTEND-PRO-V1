ATTEND PRO 1.6.0 — BUILD NOTES

Target: Android 35
Min SDK: 26
JDK: 17
Gradle CI: 8.9

Versions:
- store-app: versionCode 17 / versionName 1.6.0
- employee-app: versionCode 17 / versionName 1.6.0

New store activities:
- StoreSettingsActivity: protected merchant/store-owner administration.
- ReportsActivity: report periods, sharing, sync status, manual sync.

Stability notes:
- Store-owner PIN has 5-attempt temporary lockout.
- Store PIN is separate from platform-owner code.
- Main attendance path remains in MainActivity.
- Auto sync runs only when enabled, server URL exists, and a valid license exists.
- Offline attendance events remain local until sync succeeds.
