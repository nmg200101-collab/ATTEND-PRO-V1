package com.attendpro.store

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import com.attendpro.core.NetworkTools
import com.attendpro.core.CentralServerClient
import com.attendpro.core.DeviceIdentity
import com.attendpro.core.QrScannerActivity
import com.attendpro.core.QrCodeTools
import com.attendpro.core.ReportProtocol
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit

class StoreSettingsActivity : Activity() {
    private lateinit var repo: StoreRepository
    private val p by lazy { UiKit.palette(this) }
    private var authenticated = false
    private var sessionToken = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        if (!repo.isCentralActivationActive()) { showCentralActivationRequired(); return }
        authenticated = savedInstanceState?.getBoolean("authenticated", false) ?: false
        sessionToken = savedInstanceState?.getString("sessionToken").orEmpty()
        showGateOrDashboard()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("authenticated", authenticated)
        outState.putString("sessionToken", sessionToken)
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (::repo.isInitialized && !repo.isCentralActivationActive()) { showCentralActivationRequired(); return }
        if (authenticated || !repo.hasStoreAdminPin) showDashboard()
    }

    private fun showCentralActivationRequired() {
        window.statusBarColor = p.bg
        val root = baseRoot()
        val card = UiKit.card(this, p)
        card.addView(UiKit.statusBadge(this, p, "التفعيل المركزي مطلوب", false))
        card.addView(UiKit.title(this, p, "قسم مالك العمل موقوف", 23f).apply { gravity = Gravity.CENTER })
        card.addView(UiKit.subtitle(this, p, "لا يمكن فتح إعدادات المحل أو إدارة الموظفين قبل اعتماد جهاز المحل من صاحب نظام ATTEND PRO عبر الخادم المركزي.").apply { gravity = Gravity.CENTER })
        card.addView(UiKit.button(this, p, "العودة لشاشة التفعيل", false).apply { setOnClickListener { finish() } })
        root.addView(card)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showGateOrDashboard() {
        if (!repo.hasStoreAdminPin) {
            authenticated = true
            sessionToken = repo.issueStoreAdminSession()
            showDashboard()
            return
        }
        if (repo.storeAdminLockUntil > System.currentTimeMillis()) {
            val remaining = ((repo.storeAdminLockUntil - System.currentTimeMillis()) / 1000L).coerceAtLeast(1)
            showLockedScreen("تم إيقاف المحاولات مؤقتًا. حاول بعد $remaining ثانية.")
            return
        }
        showLogin()
    }

    private fun showLogin() {
        window.statusBarColor = p.bg
        val root = baseRoot()
        val card = UiKit.card(this, p)
        card.addView(UiKit.sectionLabel(this, p, "قسم مالك العمل"))
        card.addView(UiKit.title(this, p, "دخول صاحب المحل", 24f))
        card.addView(UiKit.subtitle(this, p, "هذا القسم مخصص لمعلومات المحل والموظفين وطرق الحضور والتقارير. أدخل رمز الحماية للمتابعة."))
        val pin = UiKit.field(this, p, "رمز قسم مالك العمل", true).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        card.addView(pin)
        card.addView(UiKit.button(this, p, "دخول").apply {
            setOnClickListener {
                if (repo.verifyStoreAdminPin(pin.text.toString())) {
                    authenticated = true
                    sessionToken = repo.issueStoreAdminSession()
                    showDashboard()
                } else {
                    pin.error = if (repo.storeAdminLockUntil > System.currentTimeMillis()) "تم القفل لمدة دقيقة" else "الرمز غير صحيح"
                }
            }
        })
        card.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        root.addView(card)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showLockedScreen(message: String) {
        window.statusBarColor = p.bg
        val root = baseRoot()
        val card = UiKit.card(this, p)
        card.addView(UiKit.title(this, p, "قسم مالك العمل محمي", 23f))
        card.addView(UiKit.subtitle(this, p, message))
        card.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        root.addView(card)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showDashboard() {
        if (repo.hasStoreAdminPin && !repo.validateStoreAdminSession(sessionToken)) {
            authenticated = false
            sessionToken = ""
            showLogin()
            return
        }
        if (!repo.hasStoreAdminPin && !repo.validateStoreAdminSession(sessionToken)) sessionToken = repo.issueStoreAdminSession()
        window.statusBarColor = p.bg
        val root = baseRoot()

        val header = UiKit.heroCard(this, p)
        header.addView(UiKit.title(this, p, repo.storeName, 25f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this, p, "قسم مالك العمل • الفرع ${repo.branchId} • ${repo.employees().count { it.active }} موظف • الإصدار 1.9.5").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        root.addView(header)

        val security = UiKit.card(this, p, 13)
        security.addView(UiKit.sectionLabel(this, p, "الحماية والصلاحيات"))
        security.addView(UiKit.subtitle(this, p, if (repo.hasStoreAdminPin) "✓ قسم مالك العمل محمي برمز مستقل." else "القسم غير محمي حاليًا. أنشئ رمزًا لمنع وصول الموظفين إلى الإعدادات."))
        security.addView(UiKit.button(this, p, if (repo.hasStoreAdminPin) "تغيير رمز قسم مالك العمل" else "إنشاء رمز حماية", false).apply { setOnClickListener { changeStorePin() } })
        if (repo.hasStoreAdminPin) security.addView(UiKit.button(this, p, "قفل قسم مالك العمل الآن", false).apply {
            setOnClickListener { authenticated = false; repo.clearStoreAdminSession(); sessionToken = ""; showLogin() }
        })
        root.addView(security)

        val store = UiKit.card(this, p)
        store.addView(UiKit.sectionLabel(this, p, "المحل والموظفون"))
        store.addView(UiKit.button(this, p, "معلومات المحل").apply { setOnClickListener { editStoreProfile() } })
        store.addView(UiKit.button(this, p, "إضافة وإدارة الموظفين", false).apply {
            setOnClickListener { startActivity(Intent(this@StoreSettingsActivity, MainActivity::class.java).putExtra(MainActivity.EXTRA_EMPLOYEE_MANAGER, true).putExtra(MainActivity.EXTRA_STORE_ADMIN_SESSION, sessionToken)) }
        })
        root.addView(store)

        val attendance = UiKit.card(this, p)
        attendance.addView(UiKit.sectionLabel(this, p, "طرق الحضور والتحقق"))
        attendance.addView(UiKit.subtitle(this, p, recognitionSummary()))
        attendance.addView(UiKit.button(this, p, "تفعيل وتعطيل طرق الحضور").apply { setOnClickListener { attendanceMethodsSettings() } })
        attendance.addView(UiKit.button(this, p, "إعداد GPS وموقع المحل", false).apply { setOnClickListener { gpsSettings() } })
        attendance.addView(UiKit.button(this, p, "الدوام ودقائق السماح", false).apply { setOnClickListener { shiftSettings() } })
        attendance.addView(UiKit.button(this, p, "قارئ البصمة الخارجي", false).apply { setOnClickListener { fingerprintSettings() } })
        root.addView(attendance)

        val reports = UiKit.card(this, p)
        reports.addView(UiKit.sectionLabel(this, p, "التقارير والمراقبة"))
        reports.addView(UiKit.subtitle(this, p, "عرض التقارير، مشاركتها إلى جهاز ثانٍ، إنشاء رقم نقل ورمز تأكيد، ثم تثبيت حالة الاستلام من هذا القسم. المزامنة التلقائية تحتاج خادم ATTEND PRO عند نشره."))
        reports.addView(UiKit.button(this, p, "فتح التقارير والمشاركة").apply { setOnClickListener { startActivity(Intent(this@StoreSettingsActivity, ReportsActivity::class.java).putExtra(ReportsActivity.EXTRA_STORE_ADMIN_SESSION, sessionToken)) } })
        reports.addView(UiKit.button(this, p, "هواتف استلام التقارير والصلاحيات", false).apply { setOnClickListener { manageReportReceivers() } })
        root.addView(reports)

        val maintenance = UiKit.card(this, p)
        maintenance.addView(UiKit.sectionLabel(this, p, "الصيانة والإدارة"))
        maintenance.addView(UiKit.button(this, p, "فحص جاهزية المحل", false).apply { setOnClickListener { healthCheck() } })
        maintenance.addView(UiKit.button(this, p, "إدارة ATTEND PRO العليا", false).apply { setOnClickListener { startActivity(Intent(this@StoreSettingsActivity, SystemSettingsActivity::class.java)) } })
        maintenance.addView(UiKit.button(this, p, "إغلاق قسم مالك العمل", false).apply { setOnClickListener { authenticated = false; repo.clearStoreAdminSession(); sessionToken = ""; finish() } })
        root.addView(maintenance)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun recognitionSummary(): String {
        val employees = repo.employees().filter { it.active }
        val face = employees.count { it.faceTemplate.isNotBlank() && it.faceQualityScore >= 45 }
        val pin = employees.count { it.pin.isNotBlank() }
        val password = employees.count { it.passwordHash.isNotBlank() }
        val pattern = employees.count { it.patternHash.isNotBlank() }
        val voice = employees.count { it.voicePhraseHash.isNotBlank() }
        val ext = employees.count { it.externalFingerprintId.isNotBlank() }
        val phone = employees.count { it.companionEnabled }
        return "PIN $pin • كلمة مرور $password • نقش $pattern • تحقق صوتي $voice\n" +
            "قالب وجه جاهز $face • بصمة خارجية $ext • هاتف موظف $phone • GPS ${if (repo.isGpsConfigured) "مضبوط" else "غير مضبوط"}\n" +
            "الوجه: كشف وجه واحد + فحص جودة + قالب مطابقة محلي. الصوت: عبارة + كلمة تحدٍ متغيرة + ثقة التعرف. للمستوى التجاري الأعلى يمكن لاحقًا إضافة نماذج عصبية متخصصة للحيوية وهوية المتحدث."
    }

    private fun editStoreProfile() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)
        val name = UiKit.field(this, p, "اسم المحل").apply { setText(repo.storeName) }
        val branch = UiKit.field(this, p, "رمز الفرع").apply { setText(repo.branchId) }
        val phone = UiKit.field(this, p, "هاتف المحل - اختياري").apply { setText(repo.storePhone) }
        val address = UiKit.field(this, p, "العنوان - اختياري").apply { setText(repo.storeAddress) }
        val manager = UiKit.field(this, p, "اسم صاحب / مدير المحل - اختياري").apply { setText(repo.storeManagerName) }
        val commercial = UiKit.field(this, p, "السجل / المعرف التجاري - اختياري").apply { setText(repo.storeCommercialId) }
        val notes = UiKit.field(this, p, "ملاحظات المحل - اختياري").apply { setText(repo.storeNotes); minLines = 2 }
        listOf(name, branch, phone, address, manager, commercial, notes).forEach { box.addView(it) }
        val dialog = AlertDialog.Builder(this).setTitle("معلومات المحل").setView(scroll).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim(); val b = branch.text.toString().trim()
                if (n.isBlank() || b.isBlank()) {
                    name.error = if (n.isBlank()) "اسم المحل مطلوب" else null
                    branch.error = if (b.isBlank()) "رمز الفرع مطلوب" else null
                    return@setOnClickListener
                }
                repo.storeName = n; repo.branchId = b; repo.storePhone = phone.text.toString(); repo.storeAddress = address.text.toString()
                repo.storeManagerName = manager.text.toString(); repo.storeCommercialId = commercial.text.toString(); repo.storeNotes = notes.text.toString()
                repo.ensureCurrentStoreInManagement(); dialog.dismiss(); info("تم الحفظ", "تم تحديث معلومات المحل."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun attendanceMethodsSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        fun option(label: String, checked: Boolean) = CheckBox(this).apply { text = label; setTextColor(p.text); isChecked = checked }
        val auto = option("التعرف التلقائي على هاتف الموظف عبر BLE", repo.autoScan)
        val companion = option("السماح بتطبيق الموظف وربط الهاتف", repo.allowEmployeeCompanion)
        val phoneBio = option("اشتراط بصمة/وجه هاتف الموظف عند الحضور بالجوال", repo.requirePhoneBiometric)
        val pin = option("PIN", repo.allowPinFallback)
        val password = option("كلمة المرور", repo.allowPasswordFallback)
        val pattern = option("النقش 3×3", repo.allowPatternFallback)
        val voice = option("التحقق الصوتي (عبارة + تحدٍ متغير)", repo.allowVoiceVerification)
        val gps = option("GPS كعامل تحقق للموقع", repo.allowGpsVerification)
        val face = option("بصمة الوجه على جهاز المحل", repo.allowFaceEnrollment)
        val ext = option("قارئ بصمة الإصبع الخارجي", repo.allowExternalFingerprint)
        box.addView(UiKit.subtitle(this, p, "هذه هي الطرق العامة المتاحة في المحل. بعد ذلك تحدد لكل موظف الطرق المسموح بها من ملف الموظف."))
        listOf(auto, companion, phoneBio, pin, password, pattern, voice, gps, face, ext).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("طرق الحضور والتحقق").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.autoScan = auto.isChecked; repo.allowEmployeeCompanion = companion.isChecked; repo.requirePhoneBiometric = phoneBio.isChecked
            repo.allowPinFallback = pin.isChecked; repo.allowPasswordFallback = password.isChecked; repo.allowPatternFallback = pattern.isChecked
            repo.allowVoiceVerification = voice.isChecked; repo.allowGpsVerification = gps.isChecked; repo.allowFaceEnrollment = face.isChecked
            repo.allowExternalFingerprint = ext.isChecked
            info("تم", "تم حفظ طرق الحضور العامة. يمكنك الآن تخصيصها لكل موظف.")
            showDashboard()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun gpsSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val lat = UiKit.field(this, p, "خط العرض Latitude").apply { setText(if (repo.storeLatitude.isFinite()) repo.storeLatitude.toString() else "") }
        val lon = UiKit.field(this, p, "خط الطول Longitude").apply { setText(if (repo.storeLongitude.isFinite()) repo.storeLongitude.toString() else "") }
        val radius = UiKit.field(this, p, "نطاق السماح بالمتر", true).apply { setText(repo.gpsRadiusMeters.toString()) }
        box.addView(UiKit.subtitle(this, p, "أدخل إحداثيات موقع المحل مرة واحدة. يمكن التحقق من جهاز المحل عبر GPS + PIN، كما تُرسل الإحداثيات الموثوقة إلى تطبيق الموظف عند ربطه إذا سمحت له بطريقة GPS. GPS عامل موقع وليس بصمة هوية."))
        listOf(lat, lon, radius).forEach { box.addView(it) }
        box.addView(UiKit.button(this, p, "استخدام موقع هذا الجهاز الآن", false).apply {
            setOnClickListener {
                val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!fine && !coarse) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 9101)
                    info("صلاحية الموقع", "اسمح بالموقع ثم اضغط «استخدام موقع هذا الجهاز الآن» مرة أخرى.")
                    return@setOnClickListener
                }
                val manager = getSystemService(LocationManager::class.java)
                val location = manager?.let { bestLastLocation(it) }
                if (location == null || System.currentTimeMillis() - location.time > 10 * 60_000L) {
                    info("الموقع", "تعذر الحصول على موقع حديث. فعّل GPS وانتظر قليلًا ثم حاول مرة أخرى.")
                    return@setOnClickListener
                }
                if (isMockLocation(location)) { info("الموقع", "تم رفض موقع تجريبي/مزيف."); return@setOnClickListener }
                lat.setText(location.latitude.toString()); lon.setText(location.longitude.toString())
                info("تم التقاط الموقع", "تم وضع إحداثيات هذا الجهاز في الحقول. راجع نطاق السماح ثم اضغط حفظ.")
            }
        })
        val dialog = AlertDialog.Builder(this).setTitle("موقع المحل وGPS").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val la = lat.text.toString().toDoubleOrNull(); val lo = lon.text.toString().toDoubleOrNull(); val r = radius.text.toString().toIntOrNull()
                if (la == null || la !in -90.0..90.0) { lat.error = "خط عرض غير صالح"; return@setOnClickListener }
                if (lo == null || lo !in -180.0..180.0) { lon.error = "خط طول غير صالح"; return@setOnClickListener }
                if (r == null || r !in 20..5000) { radius.error = "استخدم 20 إلى 5000 متر"; return@setOnClickListener }
                repo.storeLatitude = la; repo.storeLongitude = lo; repo.gpsRadiusMeters = r
                dialog.dismiss(); info("تم", "تم حفظ موقع المحل ونطاق GPS. إذا كان موظف يستخدم GPS من هاتفه، اعرض له QR ربط جديدًا ليحصل على إعدادات الموقع المحدثة."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun shiftSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val hour = UiKit.field(this, p, "ساعة بداية الدوام 0-23", true).apply { setText(repo.shiftHour.toString()) }
        val minute = UiKit.field(this, p, "الدقيقة", true).apply { setText(repo.shiftMinute.toString()) }
        val endHour = UiKit.field(this, p, "ساعة انتهاء الدوام 0-23", true).apply { setText(repo.shiftEndHour.toString()) }
        val endMinute = UiKit.field(this, p, "دقيقة الانتهاء", true).apply { setText(repo.shiftEndMinute.toString()) }
        val grace = UiKit.field(this, p, "دقائق السماح", true).apply { setText(repo.graceMinutes.toString()) }
        box.addView(UiKit.subtitle(this, p, "هذا هو الدوام العام. يمكن إعطاء أي موظف وقت بداية وانتهاء مختلف من ملف الموظف."))
        listOf(hour, minute, endHour, endMinute, grace).forEach { box.addView(it) }
        val dialog = AlertDialog.Builder(this).setTitle("الدوام والسماح").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val sh = hour.text.toString().toIntOrNull(); val sm = minute.text.toString().toIntOrNull()
                val eh = endHour.text.toString().toIntOrNull(); val em = endMinute.text.toString().toIntOrNull(); val gr = grace.text.toString().toIntOrNull()
                if (sh == null || sh !in 0..23) { hour.error = "0 إلى 23"; return@setOnClickListener }
                if (sm == null || sm !in 0..59) { minute.error = "0 إلى 59"; return@setOnClickListener }
                if (eh == null || eh !in 0..23) { endHour.error = "0 إلى 23"; return@setOnClickListener }
                if (em == null || em !in 0..59) { endMinute.error = "0 إلى 59"; return@setOnClickListener }
                if (gr == null || gr !in 0..180) { grace.error = "0 إلى 180 دقيقة"; return@setOnClickListener }
                repo.shiftHour = sh; repo.shiftMinute = sm; repo.shiftEndHour = eh; repo.shiftEndMinute = em; repo.graceMinutes = gr
                dialog.dismiss(); info("تم", "تم تحديث وقت بداية وانتهاء الدوام العام ودقائق السماح."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun manageReportReceivers() {
        val receivers = repo.authorizedReportReceivers()
        val labels = mutableListOf("＋ إضافة هاتف استلام عبر QR")
        labels.addAll(receivers.map { "${if (it.active) "●" else "○"} ${it.name} • ${it.receiverId}" })
        AlertDialog.Builder(this).setTitle("هواتف استلام التقارير (${receivers.size})").setItems(labels.toTypedArray()) { _, which ->
            if (which == 0) {
                startActivityForResult(Intent(this, QrScannerActivity::class.java).putExtra(QrScannerActivity.EXTRA_PROMPT, "امسح QR هاتف استلام التقارير"), REQUEST_REPORT_RECEIVER_QR)
            } else {
                val r = receivers[which - 1]
                AlertDialog.Builder(this).setTitle(r.name).setMessage("المعرف: ${r.receiverId}\nالحالة: ${if (r.active) "مسموح" else "موقوف"}\nالاستلام عن بُعد: ${if (repo.isCentralActivationActive()) "متاح عبر الخادم" else "يحتاج تفعيل مركزي"}")
                    .setPositiveButton(if (r.active) "إيقاف الصلاحية" else "إعادة التفعيل") { _, _ ->
                        val next = !r.active; repo.setReportReceiverActive(r.receiverId, next)
                        if (repo.isCentralActivationActive() && repo.serverUrl.isNotBlank()) Thread { CentralServerClient.setReceiverActive(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this), r.receiverId, next) }.start()
                        manageReportReceivers()
                    }
                    .setNeutralButton("حذف") { _, _ ->
                        repo.setReportReceiverActive(r.receiverId, false)
                        if (repo.isCentralActivationActive() && repo.serverUrl.isNotBlank()) Thread { CentralServerClient.setReceiverActive(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this), r.receiverId, false) }.start()
                        repo.removeReportReceiver(r.receiverId); manageReportReceivers()
                    }
                    .setNegativeButton("إغلاق", null).show()
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_REPORT_RECEIVER_QR) return
        if (resultCode != RESULT_OK) { info("هواتف التقارير", data?.getStringExtra(QrScannerActivity.EXTRA_ERROR) ?: "تم إلغاء المسح"); return }
        val raw = data?.getStringExtra(QrScannerActivity.EXTRA_RESULT).orEmpty()
        val invite = ReportProtocol.decodeInvite(raw)
        if (invite == null || invite.expiresAt < System.currentTimeMillis()) { info("QR غير صالح", "رمز هاتف الاستلام غير صالح أو انتهت مدته."); return }
        if (!repo.authorizeReportReceiver(invite)) { info("تعذر منح الصلاحية", "لم يتم قبول رمز هاتف الاستلام."); return }
        if (repo.isCentralActivationActive() && repo.serverUrl.isNotBlank()) {
            info("جاري ربط الهاتف", "تمت الصلاحية محليًا، ويجري الآن تسجيل الهاتف في الخادم المركزي للاستلام عن بُعد.")
            Thread {
                val r = CentralServerClient.registerReceiver(repo.serverUrl, repo.centralAccessToken, repo.storeId, DeviceIdentity(this), invite.receiverId, invite.name, invite.secret)
                runOnUiThread {
                    if (r.isSuccess) showReceiverRemoteGrant(invite)
                    else info("صلاحية محلية فقط", "تم حفظ الهاتف محليًا، لكن تعذر تسجيله في الخادم: ${r.exceptionOrNull()?.message ?: "خطأ"}")
                }
            }.apply { isDaemon = true }.start()
        } else info("تم منح الصلاحية", "تم السماح للهاتف «${invite.name}» باستلام التقارير المشفرة محليًا. للاستلام عن بُعد فعّل المحل مركزيًا أولًا.")
    }

    private fun showReceiverRemoteGrant(invite: ReportProtocol.ReceiverInvite) {
        val grant = ReportProtocol.RemoteReceiverGrant(invite.receiverId, repo.serverUrl, repo.storeName, repo.branchId, System.currentTimeMillis() + 10 * 60_000L)
        val raw = ReportProtocol.encodeRemoteGrant(grant)
        val qr = runCatching { QrCodeTools.bitmap(raw, 700) }.getOrElse { info("تم منح الصلاحية ✓", "تم تسجيل الهاتف على الخادم، لكن تعذر إنشاء QR الربط. يمكن إدخال رابط الخادم يدويًا في هاتف المراقبة."); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(20, 12, 20, 8) }
        box.addView(UiKit.subtitle(this, p, "تم منح الصلاحية للهاتف «${invite.name}» محليًا وعبر الإنترنت. الآن من هاتف المالك: استلام التقارير ← مسح QR ربط الخادم.").apply { gravity = Gravity.CENTER })
        box.addView(ImageView(this).apply { setImageBitmap(qr); adjustViewBounds = true; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this@StoreSettingsActivity, 340)) })
        AlertDialog.Builder(this).setTitle("✓ ربط هاتف المراقبة بالخادم").setView(box).setPositiveButton("إغلاق", null).show()
    }

    private fun fingerprintSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val host = UiKit.field(this, p, "IP جهاز البصمة").apply { setText(repo.fingerprintHost) }
        val port = UiKit.field(this, p, "Port مثل 4370", true).apply { setText(repo.fingerprintPort.toString()) }
        box.addView(UiKit.subtitle(this, p, "الاتصال الشبكي هنا يختبر الوصول فقط. جلب قوالب البصمة والسجلات تلقائيًا يحتاج موصلًا خاصًا بموديل جهاز البصمة."))
        box.addView(host); box.addView(port)
        AlertDialog.Builder(this).setTitle("قارئ البصمة الخارجي").setView(box).setPositiveButton("حفظ واختبار") { _, _ ->
            repo.fingerprintHost = host.text.toString(); repo.fingerprintPort = port.text.toString().toIntOrNull() ?: 4370
            Thread {
                val result = NetworkTools.probeTcp(repo.fingerprintHost, repo.fingerprintPort)
                runOnUiThread { info("نتيجة الاتصال", if (result.isSuccess) "✓ تم الوصول إلى الجهاز على الشبكة." else "تعذر الاتصال: ${result.exceptionOrNull()?.message ?: "خطأ"}") }
            }.start()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun changeStorePin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val pin = UiKit.field(this, p, "رمز جديد من 4 إلى 8 أرقام", true).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val confirm = UiKit.field(this, p, "تأكيد الرمز", true).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(pin); box.addView(confirm)
        val builder = AlertDialog.Builder(this).setTitle(if (repo.hasStoreAdminPin) "تغيير رمز قسم مالك العمل" else "إنشاء رمز قسم مالك العمل").setView(box)
            .setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null)
        if (repo.hasStoreAdminPin) builder.setNeutralButton("إزالة الحماية") { _, _ -> repo.clearStoreAdminPin(); authenticated = true; info("تم", "تمت إزالة رمز الحماية."); showDashboard() }
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = pin.text.toString(); val b = confirm.text.toString()
                if (a.length !in 4..8 || a.any { !it.isDigit() }) { pin.error = "استخدم 4 إلى 8 أرقام"; return@setOnClickListener }
                if (a != b) { confirm.error = "الرمزان غير متطابقين"; return@setOnClickListener }
                repo.setStoreAdminPin(a); authenticated = true; sessionToken = repo.issueStoreAdminSession(); dialog.dismiss(); info("تم", "تم حفظ رمز قسم مالك العمل."); showDashboard()
            }
        }
        dialog.show()
    }

    private fun healthCheck() {
        val bt = getSystemService(BluetoothManager::class.java)?.adapter
        val bluetooth = when { bt == null -> "غير مدعوم"; !bt.isEnabled -> "متوقف"; else -> "يعمل" }
        val employees = repo.employees()
        val syncState = if (repo.serverUrl.isBlank()) "الخادم غير مربوط" else "الخادم مضبوط • ${repo.pendingEvents().size} عملية معلقة"
        val active = employees.filter { it.active }
        val customShiftCount = active.count { it.useCustomShift }
        val faceReady = active.count { it.faceTemplate.isNotBlank() && it.faceQualityScore >= 45 }
        val receivers = repo.authorizedReportReceivers()
        val msg = "معلومات المحل: ${if (repo.isStoreProfileComplete) "مكتملة" else "تحتاج إكمال"}\n" +
            "Bluetooth: $bluetooth\nGPS: ${if (repo.isGpsConfigured) "مضبوط • ${repo.gpsRadiusMeters}م" else "غير مضبوط"}\n" +
            "الدوام العام: ${String.format(java.util.Locale.getDefault(), "%02d:%02d - %02d:%02d", repo.shiftHour, repo.shiftMinute, repo.shiftEndHour, repo.shiftEndMinute)} • سماح ${repo.graceMinutes} د\n" +
            "الموظفون النشطون: ${active.size} • دوام خاص: $customShiftCount\n" +
            "PIN: ${active.count { it.pin.isNotBlank() }} • كلمة مرور: ${active.count { it.passwordHash.isNotBlank() }} • نقش: ${active.count { it.patternHash.isNotBlank() }}\n" +
            "تحقق صوتي: ${active.count { it.voicePhraseHash.isNotBlank() }} • قوالب وجه جاهزة: $faceReady • بصمة خارجية: ${active.count { it.externalFingerprintId.isNotBlank() }}\n" +
            "هواتف التقارير: ${receivers.count { it.active }} مصرح / ${receivers.size} مسجل\n" +
            "التفعيل: ${if (repo.isCentralActivationActive()) "مركزي نشط" else "مقفل • يتطلب اعتماد صاحب النظام عبر الخادم"}\n$syncState"
        info("فحص جاهزية المحل", msg)
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider

    private fun bestLastLocation(manager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }

    private fun baseRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(UiKit.dp(this@StoreSettingsActivity, 16), UiKit.dp(this@StoreSettingsActivity, 18), UiKit.dp(this@StoreSettingsActivity, 16), UiKit.dp(this@StoreSettingsActivity, 28)); setBackgroundColor(p.bg)
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }

    companion object { private const val REQUEST_REPORT_RECEIVER_QR = 9201 }

}
