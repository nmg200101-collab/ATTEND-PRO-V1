package com.attendpro.store

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.pm.PackageManager
import android.os.Build
import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface

class PairingBeacon(private val activity:Activity,private val status:(String)->Unit){
    companion object{const val REQUEST_ADVERTISE=5191;const val UDP_PORT=45993}
    private val adapter=activity.getSystemService(BluetoothManager::class.java)?.adapter
    @Volatile private var running=false
    private var socket:DatagramSocket?=null
    private var currentBleMessage=ByteArray(0)
    private var fallbackStarted=false
    private val callback=object:AdvertiseCallback(){
        override fun onStartSuccess(settingsInEffect:AdvertiseSettings?){status(if(fallbackStarted)"يبث الاقتران عبر Bluetooth المتوافق وHotspot" else "يبث الاقتران عبر Bluetooth وHotspot")}
        override fun onStartFailure(errorCode:Int){
            if(!fallbackStarted&&running&&currentBleMessage.isNotEmpty()){fallbackStarted=true;startCompatibleBleFallback()}
            else status("تعذر بث Bluetooth ($errorCode) — يستمر Hotspot والرمز")
        }
    }
    @SuppressLint("MissingPermission")
    fun start(code:String){
        stop();running=true;fallbackStarted=false
        val message="APPAIR:${code.uppercase()}".toByteArray()
        val bleMessage="P${code.uppercase()}".toByteArray();currentBleMessage=bleMessage
        Thread{runCatching{
            DatagramSocket().also{socket=it;it.broadcast=true;it.reuseAddress=true}.use{s->while(running){
                broadcastTargets().forEach{target->runCatching{s.send(DatagramPacket(message,message.size,target,UDP_PORT))}}
                Thread.sleep(700)
            }}
        }}.start()
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S&&activity.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE)!=PackageManager.PERMISSION_GRANTED){
            activity.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_ADVERTISE,Manifest.permission.BLUETOOTH_CONNECT),REQUEST_ADVERTISE);status("اسمح بالأجهزة القريبة؛ بث Hotspot يعمل الآن");return
        }
        val advertiser=adapter?.bluetoothLeAdvertiser?:run{status("Hotspot يعمل؛ بث BLE غير مدعوم في هذا الهاتف");return}
        // Publish the same short code in both manufacturer and service data.
        // Some OEM scanners expose only one of the two fields.
        val data=AdvertiseData.Builder().addManufacturerData(BleProtocol.MANUFACTURER_ID,bleMessage)
            .addServiceData(BleProtocol.SERVICE_UUID,bleMessage).setIncludeDeviceName(false).build()
        val settings=AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(false).setTimeout(0).setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH).build()
        runCatching{advertiser.startAdvertising(settings,data,callback)}.onSuccess{status("يبث الاقتران عبر Bluetooth وHotspot")}.onFailure{status("Hotspot يعمل؛ تعذر بدء Bluetooth")}
    }
    @SuppressLint("MissingPermission") private fun startCompatibleBleFallback(){
        val advertiser=adapter?.bluetoothLeAdvertiser?:return
        val data=AdvertiseData.Builder().addManufacturerData(BleProtocol.MANUFACTURER_ID,currentBleMessage).setIncludeDeviceName(false).build()
        val settings=AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(false).setTimeout(0).setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH).build()
        runCatching{advertiser.startAdvertising(settings,data,callback)}.onFailure{status("Hotspot والرمز يعملان؛ BLE غير متاح")}
    }
    private fun broadcastTargets():Set<InetAddress>{
        val result=linkedSetOf(InetAddress.getByName("255.255.255.255"))
        runCatching{NetworkInterface.getNetworkInterfaces()?.toList()?.forEach{network->
            if(network.isUp&&!network.isLoopback)network.interfaceAddresses.mapNotNullTo(result){it.broadcast}
        }}
        return result
    }
    @SuppressLint("MissingPermission") fun stop(){running=false;currentBleMessage=ByteArray(0);runCatching{socket?.close()};socket=null;runCatching{adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback)}}
}
