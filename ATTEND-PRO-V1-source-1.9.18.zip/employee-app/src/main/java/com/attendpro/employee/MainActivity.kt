package com.attendpro.employee

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import android.hardware.biometrics.BiometricPrompt
import android.hardware.fingerprint.FingerprintManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AppUpdateManager
import com.attendpro.core.BleProtocol
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrScannerActivity
import com.attendpro.core.SecretCodec
import com.attendpro.core.CentralServerClient
import com.attendpro.core.UiKit
import java.util.Locale

class MainActivity : Activity() {
    companion object { private const val REQUEST_SCAN_PROVISION = 8103; private const val REQUEST_GPS_PERMISSION = 8104 }

    private lateinit var identity: EmployeeIdentityStore
    private lateinit var advertiser: BlePresenceAdvertiser
    private lateinit var networkPresence: NetworkPresenceBroadcaster
    private lateinit var pairingDiscovery: PairingDiscovery
    private lateinit var status: TextView
    private lateinit var profile: TextView
    private lateinit var presenceSwitch: Switch
    private var pendingAction: AttendanceAction = AttendanceAction.CHECK_IN
    private var activeChallengeId: String = ""
    private var activeChallengeMethod: AttendanceMethod? = null
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        identity = EmployeeIdentityStore(this)
        advertiser = BlePresenceAdvertiser(this) { msg -> runOnUiThread { if (::status.isInitialized) status.text = msg } }
        networkPresence = NetworkPresenceBroadcaster { msg -> runOnUiThread { if (::status.isInitialized) status.text = msg } }
        pairingDiscovery = PairingDiscovery(this,{code,channel->status.text="تم التقاط جهاز المحل عبر $channel؛ جاري تثبيت الاقتران…";handlePairingInput("APPAIR:$code")},{msg->runOnUiThread{if(::status.isInitialized)status.text=msg}})
        buildUi()
        refreshProfile()
        if (identity.isConfigured) {
            if (identity.autoPresence) startPresence() else startBackgroundPresence()
        }
        AppUpdateManager.check(this, AppUpdateManager.DEFAULT_SERVER, "employee")
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),8105)
        val shared=if(intent?.action==Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
        if(shared.isNotBlank()) handlePairingInput(shared.trim())
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,30)); setBackgroundColor(p.bg)
        }
        val header = UiKit.heroCard(this,p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_attend_pro); layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,76),UiKit.dp(this@MainActivity,76)) })
        header.addView(UiKit.title(this,p,"ATTEND PRO",27f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this,p,"تطبيق الموظف المساند • الإصدار 1.9.18").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        header.addView(UiKit.subtitle(this,p,"اختياري — جهاز المحل هو النظام الأساسي").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(215,255,255,255)) })
        root.addView(header)

        val state = UiKit.card(this,p)
        state.addView(UiKit.sectionLabel(this,p,"الحساب المرتبط"))
        profile = TextView(this).apply { textSize = 16f; setTextColor(p.text); setTypeface(typeface,Typeface.BOLD); gravity = Gravity.CENTER }
        status = TextView(this).apply { text="جاهز"; textSize=14f; setTextColor(p.muted); gravity=Gravity.CENTER; setPadding(0,UiKit.dp(this@MainActivity,8),0,0) }
        state.addView(profile); state.addView(status)
        root.addView(state)

        val link = UiKit.card(this,p)
        link.addView(UiKit.sectionLabel(this,p,"الربط مع جهاز المحل"))
        link.addView(UiKit.subtitle(this,p,"اختر الطريقة المناسبة لهاتفك: مسح QR، لصق رمز الربط، أو فتح رابط الربط الذي يرسله مسؤول المحل. جميعها تنقل الملف نفسه وتؤكده مع الخادم."))
        link.addView(UiKit.button(this,p,"مسح باركود الموظف من جهاز المحل").apply { setOnClickListener { scanProvision() } })
        link.addView(UiKit.button(this,p,"إدخال أو لصق رمز الربط",false).apply { setOnClickListener { showManualProvision() } })
        link.addView(UiKit.button(this,p,"اقتران مباشر عبر Bluetooth أو نقطة الاتصال",false).apply { setOnClickListener { pairingDiscovery.start() } })
        link.addView(UiKit.subtitle(this,p,"للاقتران المباشر: افتح رمز الموظف في جهاز المحل، ثم اضغط هذا الزر. سيُلتقط جهاز المحل تلقائيًا عبر Bluetooth أو عند اتصال الهاتفين بالشبكة/نقطة الاتصال نفسها."))
        link.addView(UiKit.button(this,p,"إلغاء الربط من هذا الهاتف",false).apply { setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle("إلغاء الربط").setMessage("سيظل الموظف موجودًا في جهاز المحل، وسيتم فقط فصل هذا الهاتف.")
                .setPositiveButton("إلغاء الربط"){_,_->advertiser.stop(); networkPresence.stop(); stopBackgroundPresence(); identity.clearStoreLink(); refreshProfile(); status.text="تم فصل الهاتف"}
                .setNegativeButton("رجوع",null).show()
        }})
        root.addView(link)

        val attend = UiKit.card(this,p)
        attend.addView(UiKit.sectionLabel(this,p,"تسجيل الحضور من هاتف الموظف"))
        attend.addView(UiKit.subtitle(this,p,"بعد نجاح الربط اختر حضورًا أو انصرافًا، ثم استخدم إحدى الطرق التي سمح بها صاحب المحل."))
        attend.addView(UiKit.button(this,p,"تسجيل الحضور الآن").apply { setOnClickListener { chooseAttendanceMethod(AttendanceAction.CHECK_IN) } })
        attend.addView(UiKit.button(this,p,"تسجيل الانصراف الآن",false).apply { setOnClickListener { chooseAttendanceMethod(AttendanceAction.CHECK_OUT) } })
        presenceSwitch = Switch(this).apply {
            text="التعرف التلقائي عبر Wi‑Fi/نقطة الاتصال أو Bluetooth"; textSize=15f; setTextColor(p.text); isChecked=identity.autoPresence
            setOnCheckedChangeListener { _,checked -> identity.autoPresence=checked; if(checked) startPresence() else { advertiser.stop(); networkPresence.stop(); startBackgroundPresence() } }
        }
        attend.addView(presenceSwitch)
        attend.addView(UiKit.button(this,p,"التعرف الحيوي الأصلي للهاتف (وجه/بصمة)").apply { setOnClickListener { requestBiometric() } })
        attend.addView(UiKit.button(this,p,"فحص جاهزية الاتصال والبصمة", false).apply { setOnClickListener { showReadinessCheck() } })
        attend.addView(UiKit.button(this,p,"عرض حالة اتصالي بالمحل", false).apply { setOnClickListener { showConnectionStatus() } })
        attend.addView(UiKit.button(this,p,"اختبار بصمة/وجه الهاتف دون تسجيل حضور", false).apply { setOnClickListener { testBiometricOnly() } })
        attend.addView(UiKit.button(this,p,"إعادة تشغيل اكتشاف جهاز المحل", false).apply { setOnClickListener { advertiser.stop(); networkPresence.stop(); startPresence() } })
        attend.addView(UiKit.button(this,p,"تأكيد الحضور برمز الهاتف", false).apply { setOnClickListener { confirmWithLocalCredential() } })
        attend.addView(UiKit.button(this,p,"إعداد PIN / كلمة مرور الهاتف", false).apply { setOnClickListener { setupLocalCredentials() } })
        attend.addView(UiKit.button(this,p,"تأكيد الحضور عبر GPS", false).apply { setOnClickListener { requestGpsProof() } })
        attend.addView(UiKit.button(this,p,"فحص تحديث التطبيق", false).apply {
            setOnClickListener { AppUpdateManager.check(this@MainActivity, AppUpdateManager.DEFAULT_SERVER, "employee", manual = true) }
        })
        attend.addView(UiKit.subtitle(this,p,"إذا اتصل جهاز المحل بنقطة اتصال هذا الهاتف أو كان الجهازان على Wi‑Fi واحدة، يعمل الاكتشاف الشبكي الموقع تلقائيًا مع BLE. GPS يثبت الموقع ولا يثبت الهوية وحده."))
        root.addView(attend)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun refreshProfile() {
        profile.text = if (!identity.isConfigured) "غير مرتبط" else buildString {
            append(identity.displayName).append(" • ").append(identity.employeeId).append("\n")
            if(identity.jobTitle.isNotBlank()) append(identity.jobTitle).append(" • ")
            append(identity.trustedStoreName.ifBlank { "جهاز المحل" }).append(" / ").append(identity.branchId).append("\n")
            append(String.format(Locale.getDefault(), "الدوام %02d:%02d - %02d:%02d", identity.shiftStartHour, identity.shiftStartMinute, identity.shiftEndHour, identity.shiftEndMinute))
        }
    }

    private fun scanProvision() {
        val intent = Intent(this,QrScannerActivity::class.java).putExtra(QrScannerActivity.EXTRA_PROMPT,"امسح QR الموظف الذي أنشأه جهاز المحل")
        status.text="جاري فتح الكاميرا..."
        runCatching { startActivityForResult(intent,REQUEST_SCAN_PROVISION) }.onFailure { status.text="تعذر فتح الماسح: ${it.message ?: "خطأ"}" }
    }

    private fun showManualProvision() {
        val input = UiKit.field(this,p,"اكتب الرمز القصير من 8 خانات أو الصق رمز APPAIR / AP3P").apply {
            minLines = 3; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            val clip = (getSystemService(ClipboardManager::class.java)?.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()).orEmpty()
            if (clip.trim().startsWith("AP3P:") || clip.trim().startsWith("APPAIR:") || clip.trim().matches(Regex("[A-Za-z0-9]{8}"))) setText(clip.trim())
        }
        val dialog = AlertDialog.Builder(this).setTitle("الربط دون كاميرا").setView(input)
            .setPositiveButton("تحقق واربط",null).setNegativeButton("إلغاء",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val value = input.text.toString().trim()
            if (value.isBlank()) { input.error = "أدخل رمز الاقتران"; return@setOnClickListener }
            dialog.dismiss(); handlePairingInput(value)
        } }
        dialog.show()
    }

    private fun handlePairingInput(raw:String){
        val value=raw.trim()
        if(value.startsWith("AP3P:")){acceptProvision(value);return}
        val code=value.removePrefix("APPAIR:").replace(Regex("[^A-Za-z0-9]"),"").uppercase()
        if(code.length!=8){status.text="رمز الاقتران غير صحيح؛ يجب أن يكون 8 خانات";return}
        status.text="جاري استلام ملف الموظف الآمن من الخادم…"
        Thread {
            var result:Result<String>?=null
            for(attempt in 0 until 3) {
                result=CentralServerClient.claimEmployeePairingTicket(AppUpdateManager.DEFAULT_SERVER,code,identity.installationId)
                if(result?.isSuccess==true)break
                if(attempt<2)try{Thread.sleep(1_200L*(attempt+1))}catch(_:InterruptedException){return@Thread}
            }
            runOnUiThread { result?.onSuccess { acceptProvision(it) }
                ?.onFailure { status.text="فشل استلام الاقتران بعد إعادة المحاولة: ${it.message ?: "اطلب رمزًا جديدًا من جهاز المحل"}" } }
        }.start()
    }

    private fun acceptProvision(text:String) {
        val p = PairingProtocol.decodeEmployeeProvision(text)
        if(p==null) { status.text="هذا ليس رمز موظف ATTEND PRO صالحًا"; return }
        if(p.expiresAt <= System.currentTimeMillis()) { status.text="انتهت صلاحية الرمز. اطلب رمزًا جديدًا من جهاز المحل"; return }
        if(!SecretCodec.isValid(p.pairingSecret)) { status.text="بيانات الربط غير صالحة"; return }
        status.text="جاري تثبيت الارتباط الحقيقي مع الخادم..."
        Thread {
            var result:Result<CentralServerClient.EmployeeLinkResult>?=null
            for(attempt in 0 until 4) {
                result=CentralServerClient.registerEmployeePhone(p.serverUrl,p.storeId,p.employeeId,p.displayName,p.branchId,
                    p.pairingSecret,identity.installationId,p.allowedMethods)
                if(result?.getOrNull()?.linked==true)break
                if(attempt<3)try{Thread.sleep(1_500L*(attempt+1))}catch(_:InterruptedException){return@Thread}
            }
            runOnUiThread {
                result?.onSuccess { link ->
                    if(!link.linked){status.text="لم يؤكد الخادم الارتباط";return@onSuccess}
                    // Do not replace a previously working profile until the new
                    // phone has actually been committed by the central server.
                    identity.applyProvision(p)
                    identity.serverLinked = link.linked; identity.linkedAt = link.linkedAt
                    refreshProfile()
                    status.text = if (link.linked) "✓ تم ربط الهاتف فعليًا بالخادم وجهاز المحل" else "لم يؤكد الخادم الارتباط"
                    if (link.linked) { if(identity.autoPresence) startPresence() else startBackgroundPresence() }
                }?.onFailure { e -> status.text = "تعذر تثبيت الربط بعد 4 محاولات: ${e.message ?: "تحقق من الإنترنت وأعد إدخال الرمز نفسه"}" }
            }
        }.start()
    }

    private fun chooseAttendanceMethod(action: AttendanceAction) {
        if (!identity.isConfigured || !identity.serverLinked) { status.text = "يجب إكمال ربط الهاتف بالخادم أولًا"; return }
        pendingAction = action
        val labels = mutableListOf<String>(); val methods = mutableListOf<AttendanceMethod>()
        if (identity.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC)) { labels += "بصمة الإصبع أو الوجه الأصلي للهاتف"; methods += AttendanceMethod.PHONE_BLE_BIOMETRIC }
        if (identity.allows(AttendanceMethod.PHONE_FINGERPRINT)) { labels += "بصمة إصبع الهاتف فقط"; methods += AttendanceMethod.PHONE_FINGERPRINT }
        if (identity.allows(AttendanceMethod.PHONE_BIOMETRIC)) { labels += "PIN أو كلمة مرور الهاتف"; methods += AttendanceMethod.PHONE_BIOMETRIC }
        if (identity.allows(AttendanceMethod.GPS)) { labels += "الموقع GPS"; methods += AttendanceMethod.GPS }
        if (methods.isEmpty()) { status.text = "لم يسمح صاحب المحل بطريقة حضور تعمل من هاتف الموظف"; return }
        AlertDialog.Builder(this).setTitle(if(action==AttendanceAction.CHECK_IN) "طريقة تسجيل الحضور" else "طريقة تسجيل الانصراف")
            .setItems(labels.toTypedArray()) { _, index -> when(methods[index]) {
                AttendanceMethod.PHONE_BLE_BIOMETRIC -> requestBiometric()
                AttendanceMethod.PHONE_FINGERPRINT -> requestFingerprintOnly()
                AttendanceMethod.PHONE_BIOMETRIC -> confirmWithLocalCredential()
                AttendanceMethod.GPS -> requestGpsProof()
                else -> Unit
            }}.setNegativeButton("إلغاء",null).show()
    }

    private fun sendAttendanceToServer(method: AttendanceMethod, evidence: String) {
        status.text = "تم التحقق، جاري تسجيل العملية في الخادم..."
        Thread {
            val result = CentralServerClient.submitEmployeeAttendance(identity.serverUrl, identity.trustedStoreId,
                identity.employeeId, identity.displayName, identity.branchId, identity.pairingSecret,
                identity.installationId, pendingAction, method, evidence)
            runOnUiThread { result.onSuccess {
                status.text = "✓ تم تسجيل ${if(pendingAction==AttendanceAction.CHECK_IN) "الحضور" else "الانصراف"} في الخادم بنجاح"
            }.onFailure { e -> status.text = "فشل إرسال العملية للخادم: ${e.message ?: "تحقق من الإنترنت"}" } }
        }.start()
    }

    private fun startPresence() {
        if(!identity.isConfigured) { status.text="امسح باركود الموظف من جهاز المحل أولًا"; return }
        advertiser.start(identity.employeeId,identity.pairingSecret)
        networkPresence.start(identity.employeeId, identity.pairingSecret)
        startBackgroundPresence()
    }

    private fun startBackgroundPresence() {
        val intent = Intent(this, PresenceService::class.java).setAction(PresenceService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun stopBackgroundPresence() { startService(Intent(this,PresenceService::class.java).setAction(PresenceService.ACTION_STOP)) }

    private fun markPresenceVerified(durationMillis: Long, proofType: Int) {
        advertiser.markVerified(durationMillis, proofType)
        networkPresence.markVerified(durationMillis, proofType)
        val intent = Intent(this,PresenceService::class.java).setAction(PresenceService.ACTION_PROOF)
            .putExtra(PresenceService.EXTRA_DURATION,durationMillis).putExtra(PresenceService.EXTRA_FLAGS,proofType)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun requestBiometric() {
        if(!identity.isConfigured) { status.text="اربط الهاتف بجهاز المحل أولًا"; return }
        if(!identity.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC)) { status.text="مالك العمل لم يسمح بالحضور ببصمة/وجه الهاتف لهذا الموظف"; return }
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status.text="يلزم Android 9 أو أحدث"; return }
        if(!advertiser.isRunning()) startPresence()
        runCatching {
            val prompt = BiometricPrompt.Builder(this).setTitle("تأكيد الحضور أو الانصراف").setSubtitle("استخدم وسيلة التعرف الحيوي المسجلة في نظام الهاتف")
                .setNegativeButton("إلغاء",mainExecutor){_,_->status.text="تم إلغاء التحقق"}.build()
            prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult?) { markPresenceVerified(45_000L, BleProtocol.FLAG_BIOMETRIC); completeChallengeOrAttendance(AttendanceMethod.PHONE_BLE_BIOMETRIC,"تحقق حيوي أصلي من Android") }
                override fun onAuthenticationFailed(){ status.text="لم يتم التعرف، حاول مرة أخرى" }
                override fun onAuthenticationError(errorCode:Int,errString:CharSequence?){ status.text="تعذر التحقق: ${errString ?: "لم تُسجل وسيلة حيوية في إعدادات الهاتف"}" }
            })
        }.onFailure { status.text = "تعذر فتح التعرف الحيوي: ${it.message ?: "سجّل بصمة أو وجهًا في إعدادات الهاتف"}" }
    }

    @Suppress("DEPRECATION")
    private fun requestFingerprintOnly() {
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.M){status.text="هذا الهاتف لا يدعم بصمة الإصبع المطلوبة";return}
        val manager=getSystemService(FingerprintManager::class.java)
        if(manager?.isHardwareDetected!=true || !manager.hasEnrolledFingerprints()){status.text="لا توجد بصمة إصبع مسجلة أو المستشعر غير متاح";return}
        val cancel=CancellationSignal()
        AlertDialog.Builder(this).setTitle("بصمة الإصبع فقط").setMessage("ضع إصبعك المسجل على المستشعر. لن يُقبل الوجه أو الرمز في هذا الطلب.").setNegativeButton("إلغاء"){_,_->cancel.cancel()}.show()
        manager.authenticate(null,cancel,0,object:FingerprintManager.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:FingerprintManager.AuthenticationResult?){markPresenceVerified(45_000L,BleProtocol.FLAG_BIOMETRIC);completeChallengeOrAttendance(AttendanceMethod.PHONE_FINGERPRINT,"بصمة إصبع Android موثقة")}
            override fun onAuthenticationFailed(){status.text="لم تتطابق بصمة الإصبع؛ أعد المحاولة"}
            override fun onAuthenticationError(code:Int,message:CharSequence?){status.text="تعذر فحص بصمة الإصبع: ${message?:"خطأ"}"}
        },null)
    }

    private fun completeChallengeOrAttendance(method: AttendanceMethod,evidence:String){
        val challengeId=activeChallengeId
        if(challengeId.isBlank()){sendAttendanceToServer(method,evidence);return}
        if(activeChallengeMethod!=method){status.text="هذا الطلب لا يقبل إلا ${challengeMethodLabel(activeChallengeMethod)}";return}
        status.text="تم التحقق، جاري إرسال إثبات الوجود للمحل…"
        Thread { val result=CentralServerClient.completeEmployeePresenceChallenge(identity.serverUrl,identity.trustedStoreId,identity.employeeId,identity.pairingSecret,identity.installationId,challengeId,method,evidence)
            runOnUiThread { result.onSuccess { status.text="✓ تم إثبات وجودك لصاحب المحل";activeChallengeId="";activeChallengeMethod=null;identity.pendingChallengeId="";identity.pendingChallengeMethod="";identity.pendingChallengeExpiresAt=0L }
                .onFailure{status.text="فشل إرسال الإثبات: ${it.message?:"تحقق من الإنترنت"}"} }
        }.start()
    }

    private fun challengeMethodLabel(method:AttendanceMethod?):String=when(method){
        AttendanceMethod.PHONE_FINGERPRINT->"بصمة الإصبع";AttendanceMethod.PHONE_BLE_BIOMETRIC->"التحقق الحيوي للهاتف";AttendanceMethod.GPS->"GPS";AttendanceMethod.PHONE_BIOMETRIC->"PIN أو كلمة المرور";else->"الطريقة المحددة"
    }

    private fun openPendingChallenge() {
        val id=identity.pendingChallengeId;val expires=identity.pendingChallengeExpiresAt
        val method=runCatching{AttendanceMethod.valueOf(identity.pendingChallengeMethod)}.getOrNull()
        if(id.isBlank()||method==null||expires<=System.currentTimeMillis()||id==activeChallengeId)return
        activeChallengeId=id;activeChallengeMethod=method
        AlertDialog.Builder(this).setTitle("أثبت وجودك الآن").setMessage("طلب من ${identity.trustedStoreName}\nالطريقة الإلزامية: ${challengeMethodLabel(method)}\nلن يُقبل أي بديل آخر.")
            .setPositiveButton("ابدأ التحقق"){_,_->when(method){AttendanceMethod.PHONE_FINGERPRINT->requestFingerprintOnly();AttendanceMethod.PHONE_BLE_BIOMETRIC->requestBiometric();AttendanceMethod.GPS->requestGpsProof();AttendanceMethod.PHONE_BIOMETRIC->confirmWithLocalCredential();else->{status.text="الطريقة المطلوبة غير مدعومة من الهاتف"}}}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showConnectionStatus(){
        val cm=getSystemService(ConnectivityManager::class.java);val network=cm?.activeNetwork;val caps=network?.let{cm.getNetworkCapabilities(it)}
        val wifi=caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true
        val internet=caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true
        val bt=getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter
        val ble=when{bt==null->"غير مدعوم";!bt.isEnabled->"متوقف";advertiser.isAdvertising()->"يبث هوية الموظف الآن";else->"مفعّل، والقناة الشبكية بديل مستقل"}
        val lm=getSystemService(LocationManager::class.java)
        val gpsEnabled=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.P) lm?.isLocationEnabled==true else
            runCatching { lm?.isProviderEnabled(LocationManager.GPS_PROVIDER)==true || lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER)==true }.getOrDefault(false)
        AlertDialog.Builder(this).setTitle("حالة الاتصال بالمحل").setMessage("الخادم: ${if(identity.serverLinked&&internet)"متصل ✓" else if(identity.serverLinked)"مرتبط — الإنترنت غير متاح" else "غير مرتبط"}\nWi‑Fi/Hotspot: ${if(wifi)"متصل ✓" else "غير متصل"}\nBluetooth: $ble\nGPS: ${if(gpsEnabled)"مفعّل" else "متوقف"}\nآخر ربط بالخادم: ${if(identity.linkedAt>0)java.text.DateFormat.getDateTimeInstance().format(java.util.Date(identity.linkedAt)) else "لا يوجد"}")
            .setPositiveButton("حسنًا",null).show()
    }

    private fun showReadinessCheck() {
        val bt = getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter
        val bluetooth = when { bt == null -> "غير مدعوم"; !bt.isEnabled -> "متوقف"; !bt.isMultipleAdvertisementSupported -> "يعمل لكن الهاتف لا يدعم بث BLE"; advertiser.isAdvertising() -> "يبث هوية الموظف الآن"; else -> "يعمل وجاهز للبث" }
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
        val internet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val local = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val biometric = biometricReadiness()
        AlertDialog.Builder(this).setTitle("فحص جاهزية هاتف الموظف").setMessage(
            "الربط بالخادم: ${if(identity.serverLinked) "مؤكد ✓" else "غير مؤكد"}\n" +
            "Bluetooth: $bluetooth\n" +
            "Wi‑Fi/نقطة اتصال: ${if(local) "متصل ✓" else "غير متصل"}\n" +
            "الإنترنت: ${if(internet) "متاح" else "غير متاح — يظل Bluetooth والشبكة المحلية يعملان"}\n" +
            "بصمة/وجه Android: $biometric\n\n" +
            "الحضور دون إنترنت يعمل عندما يكون جهاز المحل قريبًا ويستقبل بث Bluetooth أو الشبكة المحلية. ومع الإنترنت يسجل الهاتف مباشرة في الخادم أيضًا."
        ).setPositiveButton("حسنًا",null).show()
    }

    @Suppress("DEPRECATION")
    private fun biometricReadiness(): String = try {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                val manager = getSystemService(android.hardware.biometrics.BiometricManager::class.java)
                if (manager?.canAuthenticate() == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS) "مسجل وجاهز ✓" else "غير مسجل أو غير متاح"
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                val manager = getSystemService(android.hardware.fingerprint.FingerprintManager::class.java)
                if (manager?.isHardwareDetected == true && manager.hasEnrolledFingerprints()) "بصمة مسجلة وجاهزة ✓" else "لا توجد بصمة مسجلة"
            }
            else -> "إصدار Android قديم"
        }
    } catch (_: Exception) { "تعذر فحص النظام" }

    private fun testBiometricOnly() {
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.P) { status.text="يلزم Android 9 أو أحدث"; return }
        runCatching {
            val prompt = BiometricPrompt.Builder(this).setTitle("اختبار بصمة/وجه الهاتف").setSubtitle("هذا اختبار فقط ولن يسجل حضورًا")
                .setNegativeButton("إلغاء",mainExecutor){_,_->status.text="تم إلغاء الاختبار"}.build()
            prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult?) { status.text="✓ نظام البصمة/الوجه في الهاتف يعمل بصورة صحيحة" }
                override fun onAuthenticationFailed(){ status.text="لم يتعرف الهاتف؛ نظف المستشعر أو أعد المحاولة" }
                override fun onAuthenticationError(errorCode:Int,errString:CharSequence?){ status.text="تعذر اختبار البصمة: ${errString ?: "غير متاحة"}" }
            })
        }.onFailure { status.text="تعذر فتح نظام البصمة/الوجه: ${it.message ?: "غير متاح"}" }
    }

    override fun onResume() {
        super.onResume()
        if (::identity.isInitialized && identity.isConfigured) {
            if(identity.autoPresence && !advertiser.isRunning()) startPresence() else if(!identity.autoPresence) startBackgroundPresence()
        }
        if(::identity.isInitialized) openPendingChallenge()
    }

    private fun setupLocalCredentials() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.PHONE_BIOMETRIC)) { status.text = "مالك العمل لم يسمح بتأكيد الرمز من هاتف الموظف"; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val pin = UiKit.field(this, p, "PIN جديد من 4 إلى 8 أرقام", true)
        val password = UiKit.field(this, p, "كلمة مرور جديدة - 6 أحرف على الأقل").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(pin); box.addView(password)
        val dialog = AlertDialog.Builder(this).setTitle("حماية تأكيد الحضور على هذا الهاتف").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val pinText = pin.text.toString().trim(); val passwordText = password.text.toString()
            if (pinText.isNotBlank() && !pinText.matches(Regex("\\d{4,8}"))) { pin.error = "استخدم 4-8 أرقام"; return@setOnClickListener }
            if (passwordText.isNotBlank() && passwordText.length < 6) { password.error = "استخدم 6 أحرف على الأقل"; return@setOnClickListener }
            if (pinText.isBlank() && passwordText.isBlank()) { pin.error = "أدخل PIN أو كلمة مرور"; return@setOnClickListener }
            if (pinText.isNotBlank()) identity.confirmationPinHash = PairingProtocol.pinHash(pinText)
            if (passwordText.isNotBlank()) identity.confirmationPasswordHash = PairingProtocol.pinHash(passwordText)
            status.text = "✓ تم حفظ وسيلة التأكيد محليًا على هذا الهاتف"; dialog.dismiss()
        } }
        dialog.show()
    }

    private fun confirmWithLocalCredential() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.PHONE_BIOMETRIC)) { status.text = "مالك العمل لم يسمح بتأكيد الرمز من هاتف الموظف"; return }
        if (identity.confirmationPinHash.isBlank() && identity.confirmationPasswordHash.isBlank()) { setupLocalCredentials(); return }
        val value = UiKit.field(this, p, "أدخل PIN أو كلمة المرور").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val dialog = AlertDialog.Builder(this).setTitle("تأكيد الحضور من هاتف الموظف").setView(value).setPositiveButton("تأكيد", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val entered = value.text.toString()
            val valid = (identity.confirmationPinHash.isNotBlank() && PairingProtocol.matchesPin(identity.confirmationPinHash, entered)) ||
                (identity.confirmationPasswordHash.isNotBlank() && PairingProtocol.matchesPin(identity.confirmationPasswordHash, entered))
            if (!valid) { value.error = "الرمز أو كلمة المرور غير صحيحة"; return@setOnClickListener }
            if (!advertiser.isRunning() && !networkPresence.isRunning()) startPresence()
            if (!advertiser.isRunning() && !networkPresence.isRunning()) { status.text = "تعذر تشغيل Wi‑Fi وBluetooth لإرسال التأكيد"; return@setOnClickListener }
            markPresenceVerified(60_000L, BleProtocol.FLAG_CREDENTIAL)
            dialog.dismiss(); completeChallengeOrAttendance(AttendanceMethod.PHONE_BIOMETRIC,"PIN/كلمة مرور محلية موثقة")
        } }
        dialog.show()
    }

    private fun requestGpsProof() {
        if (!identity.isConfigured) { status.text = "اربط الهاتف بجهاز المحل أولًا"; return }
        if (!identity.allows(AttendanceMethod.GPS)) { status.text = "مالك العمل لم يسمح بطريقة GPS لهذا الموظف"; return }
        if (!identity.isTrustedStoreGpsConfigured) { status.text = "موقع المحل غير مضمّن في الربط. اطلب QR جديدًا بعد ضبط GPS في قسم مالك العمل"; return }
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_GPS_PERMISSION)
            status.text = "اسمح بالموقع ثم أعد الضغط على GPS"
            return
        }
        val manager = getSystemService(LocationManager::class.java)
        if (manager == null) { status.text = "خدمة الموقع غير متاحة على هذا الهاتف"; return }
        status.text = "جاري طلب موقع حديث ودقيق..."
        requestFreshLocation(manager) { location, error ->
            if (location == null) { status.text = error ?: "تعذر الحصول على موقع حديث"; return@requestFreshLocation }
            if (isMockLocation(location)) { status.text = "تم رفض موقع تجريبي/مزيف"; return@requestFreshLocation }
            val target = Location("ATTEND_PRO_STORE").apply { latitude = identity.trustedStoreLatitude; longitude = identity.trustedStoreLongitude }
            val distance = location.distanceTo(target)
            val accuracyAllowance = location.accuracy.takeIf { it.isFinite() }?.coerceIn(0f, 100f) ?: 0f
            if (distance > identity.trustedStoreGpsRadius + accuracyAllowance) {
                status.text = "أنت خارج نطاق المحل (${distance.toInt()}م، النطاق ${identity.trustedStoreGpsRadius}م، دقة الهاتف ${location.accuracy.toInt()}م)"
                return@requestFreshLocation
            }
            if (!advertiser.isRunning() && !networkPresence.isRunning()) startPresence()
            if (!advertiser.isRunning() && !networkPresence.isRunning()) { status.text = "تعذر تشغيل قناة إرسال الإثبات"; return@requestFreshLocation }
            markPresenceVerified(45_000L, BleProtocol.FLAG_GPS)
            completeChallengeOrAttendance(AttendanceMethod.GPS,"GPS ${distance.toInt()}m accuracy ${location.accuracy.toInt()}m")
        }
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider

    private fun bestLastLocation(manager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }

    @Suppress("MissingPermission")
    private fun requestFreshLocation(manager: LocationManager, callback: (Location?, String?) -> Unit) {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) { callback(null, "فعّل الموقع واختر الدقة العالية ثم أعد المحاولة"); return }
        val delivered = java.util.concurrent.atomic.AtomicBoolean(false)
        var best: Location? = null
        lateinit var listener: LocationListener
        fun finish(location: Location?, error: String? = null) {
            if (delivered.compareAndSet(false, true)) {
                runCatching { manager.removeUpdates(listener) }
                runOnUiThread { callback(location, error) }
            }
        }
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (System.currentTimeMillis() - location.time > 2 * 60_000L) return
                if (best == null || location.accuracy < best!!.accuracy) best = location
                if (location.hasAccuracy() && location.accuracy <= 35f) finish(location)
            }
            @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
            override fun onProviderEnabled(provider: String) = Unit
            override fun onProviderDisabled(provider: String) = Unit
        }
        providers.forEach { provider -> runCatching { manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper()) } }
        Handler(Looper.getMainLooper()).postDelayed({
            val fallback = best ?: bestLastLocation(manager)?.takeIf { System.currentTimeMillis() - it.time <= 10 * 60_000L }
            finish(fallback, if (fallback == null) "لم يصل موقع صالح. فعّل دقة الموقع العالية وافتح GPS خارج المبنى للحظات" else null)
        }, 25_000L)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        if(requestCode==REQUEST_SCAN_PROVISION) {
            if(resultCode==RESULT_OK) handlePairingInput(data?.getStringExtra(QrScannerActivity.EXTRA_RESULT).orEmpty())
            else status.text=data?.getStringExtra(QrScannerActivity.EXTRA_ERROR) ?: "تم إلغاء المسح"
            return
        }
        super.onActivityResult(requestCode,resultCode,data)
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        when(requestCode) {
            BlePresenceAdvertiser.REQUEST_BLUETOOTH -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}) startPresence()
                else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"
            }
            REQUEST_GPS_PERMISSION -> {
                status.text = if(grantResults.any{it==PackageManager.PERMISSION_GRANTED}) "تم منح صلاحية الموقع — اضغط GPS مرة أخرى" else "لم يتم السماح بالموقع"
            }
            PairingDiscovery.REQUEST_SCAN -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}) pairingDiscovery.start()
                else status.text="Bluetooth مرفوض؛ يمكنك الاستمرار عبر Hotspot أو الرمز القصير"
            }
        }
    }

    override fun onDestroy(){advertiser.stop();networkPresence.stop();if(::pairingDiscovery.isInitialized)pairingDiscovery.stop();super.onDestroy()}
}
