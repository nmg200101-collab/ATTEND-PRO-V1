package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress

class PairingDiscovery(private val activity:Activity,private val found:(String,String)->Unit,private val status:(String)->Unit){
    companion object{const val REQUEST_SCAN=8110;const val UDP_PORT=45993}
    private val adapter=activity.getSystemService(BluetoothManager::class.java)?.adapter
    @Volatile private var running=false
    private var socket:DatagramSocket?=null
    private val callback=object:ScanCallback(){
        override fun onScanResult(type:Int,result:ScanResult){
            val record=result.scanRecord?:return
            val bytes=record.getManufacturerSpecificData(BleProtocol.MANUFACTURER_ID)
                ?:record.getServiceData(BleProtocol.SERVICE_UUID)?:return
            val text=bytes.toString(Charsets.UTF_8)
            if(text.startsWith("P")&&text.length>=9)accept("APPAIR:${text.substring(1,9)}","Bluetooth")
        }
        override fun onBatchScanResults(results:MutableList<ScanResult>){results.forEach{onScanResult(0,it)}}
        override fun onScanFailed(code:Int){status("تعذر بحث Bluetooth ($code) — يستمر بحث Hotspot")}
    }
    private fun accept(text:String,channel:String){
        val value=text.trim();if(!value.startsWith("APPAIR:"))return
        val code=value.removePrefix("APPAIR:").take(8);if(code.length==8){stop();activity.runOnUiThread{found(code,channel)}}
    }
    @SuppressLint("MissingPermission") fun start(){
        stop();running=true;status("جاري البحث عن جهاز المحل عبر Bluetooth وHotspot…")
        Thread{runCatching{DatagramSocket(null).also{socket=it;it.reuseAddress=true;it.bind(InetSocketAddress(UDP_PORT));it.soTimeout=1500}.use{s->val buffer=ByteArray(128);while(running){runCatching{val p=DatagramPacket(buffer,buffer.size);s.receive(p);accept(String(p.data,0,p.length),"Wi‑Fi/Hotspot")}}}}}.start()
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S&&activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){activity.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),REQUEST_SCAN);return}
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.S&&activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){activity.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),REQUEST_SCAN);return}
        if(adapter?.isEnabled!=true){status("Bluetooth مغلق — يستمر بحث Wi‑Fi/Hotspot");return}
        val scanner=adapter.bluetoothLeScanner?:run{status("BLE غير مدعوم — يستمر بحث Wi‑Fi/Hotspot");return}
        scanner.startScan(null,ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),callback)
    }
    @SuppressLint("MissingPermission") fun stop(){running=false;runCatching{socket?.close()};socket=null;runCatching{adapter?.bluetoothLeScanner?.stopScan(callback)}}
}
