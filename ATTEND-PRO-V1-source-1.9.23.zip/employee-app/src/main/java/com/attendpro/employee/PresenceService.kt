package com.attendpro.employee

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import com.attendpro.core.CentralServerClient
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.AttendanceMethod

class PresenceService : Service() {
    companion object {
        const val ACTION_START = "com.attendpro.employee.PRESENCE_START"
        const val ACTION_PROOF = "com.attendpro.employee.PRESENCE_PROOF"
        const val ACTION_STOP = "com.attendpro.employee.PRESENCE_STOP"
        const val EXTRA_FLAGS = "flags"
        const val EXTRA_DURATION = "duration"
        private const val CHANNEL = "attend_presence"
        private const val NOTIFICATION_ID = 771
        private const val CHALLENGE_NOTIFICATION_ID = 772
    }
    private lateinit var identity: EmployeeIdentityStore
    private lateinit var network: NetworkPresenceBroadcaster
    private lateinit var bluetooth: BlePresenceAdvertiser
    private lateinit var localChallenges: LocalChallengeListener
    private val handler = Handler(Looper.getMainLooper())
    private val challengePoller = object : Runnable {
        override fun run() {
            ensurePresenceChannels()
            if (identity.isConfigured && identity.serverLinked) pollChallenge()
            handler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate(); identity = EmployeeIdentityStore(this)
        network = NetworkPresenceBroadcaster { }
        bluetooth = BlePresenceAdvertiser(this) { }
        localChallenges = LocalChallengeListener { id, method, expires -> receiveLocalChallenge(id, method, expires) }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL,"اكتشاف جهاز المحل",NotificationManager.IMPORTANCE_LOW).apply {
            description = "يحافظ على التعرف الآمن على هاتف الموظف عبر الشبكة المحلية"
        })
        manager.createNotificationChannel(NotificationChannel("attend_challenges","طلبات إثبات الوجود",NotificationManager.IMPORTANCE_HIGH).apply {
            description = "تنبيه الموظف عندما يطلب صاحب المحل إثبات وجوده"
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !identity.isConfigured) {
            network.stop(); bluetooth.stop(); localChallenges.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification())
        if (identity.autoPresence) {
            network.start(identity.employeeId, identity.pairingSecret)
            bluetooth.start(identity.employeeId, identity.pairingSecret)
            localChallenges.start(identity.employeeId, identity.pairingSecret)
        } else {
            network.stop(); bluetooth.stop(); localChallenges.stop()
        }
        handler.removeCallbacks(challengePoller); handler.post(challengePoller)
        if (intent?.action == ACTION_PROOF) {
            val duration = intent.getLongExtra(EXTRA_DURATION,45_000L)
            val proof = intent.getIntExtra(EXTRA_FLAGS,0)
            network.markVerified(duration, proof)
            bluetooth.markVerified(duration, proof)
        }
        return START_STICKY
    }

    private fun ensurePresenceChannels() {
        if (!identity.isConfigured || !identity.autoPresence) return
        if (!network.isRunning()) network.start(identity.employeeId, identity.pairingSecret)
        if (!bluetooth.isRunning()) bluetooth.start(identity.employeeId, identity.pairingSecret)
        if (!localChallenges.isRunning()) localChallenges.start(identity.employeeId, identity.pairingSecret)
    }

    private fun receiveLocalChallenge(id: String, method: AttendanceMethod, expires: Long) {
        if (id == identity.pendingChallengeId || expires <= System.currentTimeMillis()) return
        identity.pendingChallengeId = id
        identity.pendingChallengeMethod = method.name
        identity.pendingChallengeExpiresAt = expires
        val open = PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java).putExtra("open_presence_challenge",true),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this,"attend_challenges").setSmallIcon(R.drawable.ic_attend_pro)
            .setContentTitle("أثبت وجودك الآن")
            .setContentText("طلب محلي من ${identity.trustedStoreName}: ${method.name}")
            .setContentIntent(open).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(CHALLENGE_NOTIFICATION_ID,n)
    }

    private fun pollChallenge() {
        Thread {
            val challenge=CentralServerClient.pollEmployeePresenceChallenge(identity.serverUrl,identity.trustedStoreId,identity.employeeId,identity.pairingSecret,identity.installationId).getOrNull() ?: return@Thread
            if(challenge.challengeId==identity.pendingChallengeId || challenge.expiresAt<=System.currentTimeMillis()) return@Thread
            identity.pendingChallengeId=challenge.challengeId;identity.pendingChallengeMethod=challenge.requiredMethod.name;identity.pendingChallengeExpiresAt=challenge.expiresAt
            val open=PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java).putExtra("open_presence_challenge",true),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val label=when(challenge.requiredMethod.name){"PHONE_FINGERPRINT"->"بصمة الإصبع";"PHONE_BLE_BIOMETRIC"->"التحقق الحيوي للهاتف";"GPS"->"الموقع GPS";"PHONE_BIOMETRIC"->"PIN أو كلمة المرور";else->"الطريقة المحددة"}
            val n=Notification.Builder(this,"attend_challenges").setSmallIcon(R.drawable.ic_attend_pro).setContentTitle("أثبت وجودك الآن")
                .setContentText("طلب ${identity.trustedStoreName}: تحقق عبر $label").setContentIntent(open).setAutoCancel(true).build()
            getSystemService(NotificationManager::class.java).notify(CHALLENGE_NOTIFICATION_ID,n)
        }.start()
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_attend_pro)
            .setContentTitle("ATTEND PRO — هاتف الموظف")
            .setContentText(if(identity.autoPresence) "Bluetooth وWi‑Fi وطلبات إثبات الوجود تعمل" else "طلبات إثبات الوجود مفعلة لهذا الهاتف")
            .setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy(){handler.removeCallbacks(challengePoller);network.stop();bluetooth.stop();localChallenges.stop();super.onDestroy()}
    override fun onBind(intent: Intent?): IBinder? = null
}
