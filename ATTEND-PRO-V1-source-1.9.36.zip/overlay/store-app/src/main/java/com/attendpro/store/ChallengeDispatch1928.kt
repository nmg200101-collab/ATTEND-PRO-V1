package com.attendpro.store

import android.app.Activity
import com.attendpro.core.AttendanceMethod

object ChallengeDispatch1928 {
    fun send(activity: Activity, employeeId: String, secret: ByteArray, method: AttendanceMethod): Boolean {
        val expiresAt = System.currentTimeMillis() + 60_000L
        BleChallengeBroadcaster.broadcast(activity, employeeId, secret, method, expiresAt)
        AttendanceQrPresenter.show(activity, employeeId, secret, method, expiresAt)
        return LocalChallengeSender.send(employeeId, secret, method)
    }
}
