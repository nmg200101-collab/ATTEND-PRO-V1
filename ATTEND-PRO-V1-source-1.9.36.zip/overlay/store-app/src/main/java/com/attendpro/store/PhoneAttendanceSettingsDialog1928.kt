package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import com.attendpro.core.StoreRepository

object PhoneAttendanceSettingsDialog1928 {
    fun show(activity: Activity, repo: StoreRepository) {
        val density = activity.resources.displayMetrics.density
        fun pad(v: Int) = (v * density).toInt()
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad(20), pad(10), pad(20), pad(8))
        }
        root.addView(TextView(activity).apply {
            text = "طرق الحضور المعتمدة"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, pad(6), 0, pad(4))
        })
        root.addView(TextView(activity).apply {
            text = "خمس طرق واضحة فقط. GPS والقرب يعملان كطبقات حماية ولا يظهران كرموز حضور مستقلة."
            textSize = 13f
            gravity = Gravity.RIGHT
            alpha = .72f
            setPadding(0, 0, 0, pad(10))
        })
        fun check(title: String, subtitle: String, checked: Boolean): CheckBox {
            val box = CheckBox(activity).apply {
                text = "$title\n$subtitle"
                textSize = 15f
                isChecked = checked
                gravity = Gravity.RIGHT
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(pad(6), pad(8), pad(6), pad(8))
            }
            root.addView(box)
            return box
        }
        val face = check("◉  التعرف بالوجه", "كاميرا جهاز المحل + فحص حيوية", repo.allowFaceEnrollment)
        val voice = check("◖  بصمة الصوت", "نبرة الموظف + العبارة + تحدٍ متغير", repo.allowVoiceVerification)
        val password = check("▣  كلمة المرور", "بديل احتياطي واحد بدل PIN والنقش", repo.allowPasswordFallback)
        val phone = check("◉  بصمة/وجه هاتف الموظف", "Android BiometricPrompt على الجهاز المرتبط", repo.allowEmployeeCompanion && repo.requirePhoneBiometric)
        val qr = check("▦  QR مباشر", "رمز مؤقت يفتح طلب الموافقة في هاتف الموظف", repo.allowEmployeeCompanion)
        val gps = check("⌖  حماية الموقع", "عامل تحقق إضافي وليس طريقة حضور مستقلة", repo.allowGpsVerification)

        AlertDialog.Builder(activity)
            .setTitle("الحضور والتحقق")
            .setView(root)
            .setPositiveButton("حفظ") { _, _ ->
                repo.allowFaceEnrollment = face.isChecked
                repo.allowVoiceVerification = voice.isChecked
                repo.allowPasswordFallback = password.isChecked
                repo.allowPatternFallback = false
                repo.allowPinFallback = false
                repo.allowEmployeeCompanion = phone.isChecked || qr.isChecked
                repo.requirePhoneBiometric = phone.isChecked
                repo.allowGpsVerification = gps.isChecked
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
