package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.widget.EditText
import android.widget.NumberPicker
import java.util.Calendar

object FormPickerHelper {
    fun pickDate(activity: Activity, target: EditText) {
        val c = Calendar.getInstance()
        DatePickerDialog(activity, { _, y, m, d ->
            target.setText(String.format("%04d-%02d-%02d", y, m + 1, d))
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    fun pickNumber(activity: Activity, target: EditText, min: Int, max: Int, title: String) {
        val picker = NumberPicker(activity).apply {
            minValue = min
            maxValue = max
            wrapSelectorWheel = true
            value = target.text.toString().toIntOrNull()?.coerceIn(min, max) ?: min
        }
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(picker)
            .setPositiveButton("اختيار") { _, _ -> target.setText(picker.value.toString()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
