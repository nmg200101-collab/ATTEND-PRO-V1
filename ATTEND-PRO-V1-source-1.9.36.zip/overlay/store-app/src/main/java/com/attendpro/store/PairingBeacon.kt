package com.attendpro.store

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.pm.PackageManager
import android.os.Build
import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.util.UUID

class PairingBeacon(private val activity: Activity, private val status: (String) -> Unit) {
    companion object {
        const val REQUEST_ADVERTISE = 5191
        const val UDP_PORT = 45993
        val PROVISION_CHARACTERISTIC_UUID: UUID = UUID.fromString("0000A772-0000-1000-8000-00805F9B34FB")
    }

    private val manager = activity.getSystemService(BluetoothManager::class.java)
    private val adapter = manager?.adapter
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var currentBleMessage = ByteArray(0)
    private var currentCode = ""
    private var provisionText = ""
    private var fallbackStarted = false
    private var gattServer: BluetoothGattServer? = null

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            status(if (provisionText.startsWith("AP3P:")) "Bluetooth مباشر + Hotspot جاهزان بدون إنترنت" else "Bluetooth/Hotspot يعملان؛ الربط الكامل يحتاج ملف الموظف")
        }

        override fun onStartFailure(errorCode: Int) {
            if (!fallbackStarted && running && currentBleMessage.isNotEmpty()) {
                fallbackStarted = true
                startCompatibleBleFallback()
            } else {
                status("تعذر بث Bluetooth ($errorCode) — Hotspot والرمز المحلي مستمران")
            }
        }
    }

    private val gattCallback = object : BluetoothGattServerCallback() {
        override fun onCharacteristicReadRequest(
            device: BluetoothDevice?,
            requestId: Int,
            offset: Int,
            characteristic: BluetoothGattCharacteristic?
        ) {
            val server = gattServer ?: return
            if (characteristic?.uuid != PROVISION_CHARACTERISTIC_UUID || !provisionText.startsWith("AP3P:")) {
                runCatching { server.sendResponse(device, requestId, BluetoothGatt.GATT_FAILURE, 0, null) }
                return
            }
            val all = provisionText.toByteArray(Charsets.UTF_8)
            if (offset < 0 || offset > all.size) {
                runCatching { server.sendResponse(device, requestId, BluetoothGatt.GATT_INVALID_OFFSET, offset, null) }
                return
            }
            val value = all.copyOfRange(offset, all.size)
            runCatching { server.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value) }
        }
    }

    private fun hasBlePermissions(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || (
        activity.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        )

    @SuppressLint("MissingPermission")
    fun start(code: String) {
        stop()
        running = true
        fallbackStarted = false
        currentCode = code.trim().uppercase().take(8)
        provisionText = OfflinePairingCache.activate(currentCode)
        val shortMessage = "APPAIR:$currentCode".toByteArray(Charsets.UTF_8)
        val bleMessage = "P$currentCode".toByteArray(Charsets.UTF_8)
        currentBleMessage = bleMessage

        Thread({
            runCatching {
                DatagramSocket(null).also {
                    socket = it
                    it.reuseAddress = true
                    it.broadcast = true
                    it.soTimeout = 180
                    it.bind(InetSocketAddress(UDP_PORT))
                }.use { s ->
                    val incoming = ByteArray(512)
                    while (running) {
                        broadcastTargets().forEach { target ->
                            runCatching { s.send(DatagramPacket(shortMessage, shortMessage.size, target, UDP_PORT)) }
                            if (provisionText.startsWith("AP3P:")) {
                                val full = provisionText.toByteArray(Charsets.UTF_8)
                                runCatching { s.send(DatagramPacket(full, full.size, target, UDP_PORT)) }
                            }
                        }
                        try {
                            val p = DatagramPacket(incoming, incoming.size)
                            s.receive(p)
                            val text = String(p.data, 0, p.length, Charsets.UTF_8)
                            if (text == "APGET:$currentCode" && provisionText.startsWith("AP3P:")) {
                                val full = provisionText.toByteArray(Charsets.UTF_8)
                                runCatching { s.send(DatagramPacket(full, full.size, p.address, p.port)) }
                            }
                        } catch (_: SocketTimeoutException) {
                        }
                        try { Thread.sleep(420L) } catch (_: InterruptedException) { break }
                    }
                }
            }
        }, "attend-pairing-hotspot").apply { isDaemon = true }.start()

        if (!hasBlePermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                activity.requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT), REQUEST_ADVERTISE)
            }
            status("اسمح بالأجهزة القريبة؛ Hotspot المحلي يعمل بدون إنترنت")
            return
        }
        val bt = adapter
        if (bt?.isEnabled != true) {
            status("Bluetooth مغلق — Hotspot المحلي والـQR يعملان بدون إنترنت")
            return
        }
        startGattServer()
        val advertiser = runCatching { bt.bluetoothLeAdvertiser }.getOrNull() ?: run {
            status("BLE Advertising غير مدعوم — Hotspot المحلي يعمل")
            return
        }
        val data = AdvertiseData.Builder()
            .addManufacturerData(BleProtocol.MANUFACTURER_ID, bleMessage)
            .setIncludeDeviceName(false)
            .build()
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .build()
        runCatching { advertiser.startAdvertising(settings, data, advertiseCallback) }
            .onFailure { status("Hotspot المحلي يعمل؛ تعذر بدء Bluetooth") }
    }

    @SuppressLint("MissingPermission")
    private fun startGattServer() {
        if (!hasBlePermissions() || !provisionText.startsWith("AP3P:")) return
        runCatching {
            val server = manager?.openGattServer(activity, gattCallback) ?: return
            gattServer = server
            val service = BluetoothGattService(BleProtocol.SERVICE_UUID.uuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            val characteristic = BluetoothGattCharacteristic(
                PROVISION_CHARACTERISTIC_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_READ
            )
            service.addCharacteristic(characteristic)
            server.addService(service)
        }.onFailure { status("BLE ظاهر، لكن قناة نقل ملف الاقتران لم تبدأ؛ Hotspot المحلي مستمر") }
    }

    @SuppressLint("MissingPermission")
    private fun startCompatibleBleFallback() {
        if (!hasBlePermissions()) return
        val advertiser = runCatching { adapter?.bluetoothLeAdvertiser }.getOrNull() ?: return
        val data = AdvertiseData.Builder()
            .addManufacturerData(BleProtocol.MANUFACTURER_ID, currentBleMessage)
            .setIncludeDeviceName(false)
            .build()
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
            .setConnectable(true)
            .setTimeout(0)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .build()
        runCatching { advertiser.startAdvertising(settings, data, advertiseCallback) }
            .onFailure { status("Hotspot المحلي يعمل؛ BLE غير متاح على هذا الجهاز") }
    }

    private fun broadcastTargets(): Set<InetAddress> {
        val result = linkedSetOf<InetAddress>()
        fun add(text: String) { runCatching { result.add(InetAddress.getByName(text)) } }
        add("255.255.255.255")
        add("192.168.43.255")
        add("192.168.232.255")
        add("192.168.137.255")
        add("192.168.49.255")
        runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { network ->
                if (network.isUp && !network.isLoopback) {
                    network.interfaceAddresses.forEach { item ->
                        val broadcast = item.broadcast
                        if (broadcast is Inet4Address) result.add(broadcast)
                        val local = item.address
                        if (local is Inet4Address && !local.isLoopbackAddress) {
                            val b = local.address.clone()
                            b[3] = 0xff.toByte()
                            runCatching { result.add(InetAddress.getByAddress(b)) }
                        }
                    }
                }
            }
        }
        return result
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        currentBleMessage = ByteArray(0)
        runCatching { socket?.close() }
        socket = null
        if (hasBlePermissions()) runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(advertiseCallback) }
        runCatching { gattServer?.clearServices() }
        runCatching { gattServer?.close() }
        gattServer = null
        OfflinePairingCache.clearActive()
    }
}
