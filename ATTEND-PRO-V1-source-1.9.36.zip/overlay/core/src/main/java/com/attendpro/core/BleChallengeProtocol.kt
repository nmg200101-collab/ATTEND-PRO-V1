package com.attendpro.core

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object BleChallengeProtocol {
    const val MANUFACTURER_ID = 0x0772
    private const val VERSION: Byte = 1
    private const val MAX_FUTURE_SECONDS = 180L
    private const val MAX_PAST_SECONDS = 15L

    data class Decoded(
        val challengeId: String,
        val method: AttendanceMethod,
        val expiresAt: Long
    )

    fun encode(employeeId: String, secret: ByteArray, method: AttendanceMethod, expiresAt: Long): ByteArray {
        val employeeHash = MessageDigest.getInstance("SHA-256")
            .digest(employeeId.toByteArray(Charsets.UTF_8)).copyOfRange(0, 4)
        val expirySec = (expiresAt / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val nonce = java.security.SecureRandom().nextInt()
        val unsigned = ByteBuffer.allocate(14).order(ByteOrder.BIG_ENDIAN).apply {
            put(VERSION)
            put(employeeHash)
            put(method.ordinal.toByte())
            putInt(expirySec)
            putInt(nonce)
        }.array()
        val mac = hmac(secret, unsigned).copyOfRange(0, 8)
        return unsigned + mac
    }

    fun decode(payload: ByteArray, employeeId: String, secret: ByteArray, now: Long = System.currentTimeMillis()): Decoded? {
        if (payload.size != 22 || payload[0] != VERSION) return null
        val expectedHash = MessageDigest.getInstance("SHA-256")
            .digest(employeeId.toByteArray(Charsets.UTF_8)).copyOfRange(0, 4)
        if (!MessageDigest.isEqual(expectedHash, payload.copyOfRange(1, 5))) return null
        val expectedMac = hmac(secret, payload.copyOfRange(0, 14)).copyOfRange(0, 8)
        if (!MessageDigest.isEqual(expectedMac, payload.copyOfRange(14, 22))) return null
        val buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
        buf.position(5)
        val ordinal = buf.get().toInt() and 0xff
        val expirySec = buf.int.toLong()
        val nonce = buf.int
        val nowSec = now / 1000L
        if (expirySec < nowSec - MAX_PAST_SECONDS || expirySec > nowSec + MAX_FUTURE_SECONDS) return null
        val method = AttendanceMethod.values().getOrNull(ordinal) ?: return null
        val challengeId = "BLE-${nonce.toUInt().toString(16)}"
        return Decoded(challengeId, method, expirySec * 1000L)
    }

    private fun hmac(secret: ByteArray, data: ByteArray): ByteArray {
        val key = if (secret.isNotEmpty()) secret else byteArrayOf(0)
        return Mac.getInstance("HmacSHA256").apply {
            init(SecretKeySpec(key, "HmacSHA256"))
        }.doFinal(data)
    }
}
