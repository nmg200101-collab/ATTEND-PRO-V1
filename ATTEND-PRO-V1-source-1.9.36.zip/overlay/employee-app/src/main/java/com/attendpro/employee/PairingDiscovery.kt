package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.UUID

class PairingDiscovery(
    private val activity: Activity,
    private val found: (String, String) -> Unit,
    private val status: (String) -> Unit
) {
    companion object {
        const val REQUEST_SCAN = 8110
        const val UDP_PORT = 45993
        private val PROVISION_CHARACTERISTIC_UUID: UUID = UUID.fromString("0000A772-0000-1000-8000-00805F9B34FB")
    }

    private val adapter = activity.getSystemService(BluetoothManager::class.java)?.adapter
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var gatt: BluetoothGatt? = null
    private var pendingCode = ""
    private var pendingChannel = ""
    private var connectingGatt = false

    private val fallback = Runnable {
        if (!running || pendingCode.length != 8) return@Runnable
        val code = pendingCode
        val channel = pendingChannel.ifBlank { "Bluetooth" }
        finishFound("APPAIR:$code", "$channel — رمز قصير")
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            if (!running) return
            val record = result.scanRecord ?: return
            val bytes = record.getManufacturerSpecificData(BleProtocol.MANUFACTURER_ID)
                ?: record.getServiceData(BleProtocol.SERVICE_UUID)
                ?: return
            val text = bytes.toString(Charsets.UTF_8)
            if (text.startsWith("P") && text.length >= 9) {
                val code = text.substring(1, 9).uppercase()
                pendingCode = code
                pendingChannel = "Bluetooth"
                status("تم العثور على جهاز المحل عبر Bluetooth — جارٍ نقل ملف الاقتران محليًا…")
                requestProvisionOverGatt(result.device, code)
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { onScanResult(0, it) }
        }

        override fun onScanFailed(code: Int) {
            status("تعذر بحث Bluetooth ($code) — يستمر Hotspot/QR")
        }
    }

    private fun hasBlePermissions(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else {
        activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun start() {
        stop()
        running = true
        status("جاري الربط المحلي عبر Bluetooth وHotspot بدون إنترنت…")

        Thread({
            runCatching {
                DatagramSocket(null).also {
                    socket = it
                    it.reuseAddress = true
                    it.broadcast = true
                    it.soTimeout = 1_200
                    it.bind(InetSocketAddress(UDP_PORT))
                }.use { s ->
                    val buffer = ByteArray(4096)
                    while (running) {
                        runCatching {
                            val p = DatagramPacket(buffer, buffer.size)
                            s.receive(p)
                            val text = String(p.data, 0, p.length, Charsets.UTF_8).trim()
                            when {
                                text.startsWith("AP3P:") -> finishFound(text, "Wi‑Fi/Hotspot مباشر")
                                text.startsWith("APPAIR:") -> {
                                    val code = text.removePrefix("APPAIR:").take(8).uppercase()
                                    if (code.length == 8) {
                                        pendingCode = code
                                        pendingChannel = "Wi‑Fi/Hotspot"
                                        val request = "APGET:$code".toByteArray(Charsets.UTF_8)
                                        runCatching { s.send(DatagramPacket(request, request.size, p.address, p.port)) }
                                        handler.removeCallbacks(fallback)
                                        handler.postDelayed(fallback, 2_500L)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, "attend-pairing-discovery").apply { isDaemon = true }.start()

        if (!hasBlePermissions()) {
            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            } else {
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            activity.requestPermissions(permissions, REQUEST_SCAN)
            status("اسمح بالأجهزة القريبة؛ Hotspot/QR يستمران بدون إنترنت")
            return
        }
        val bt = adapter
        if (bt?.isEnabled != true) {
            status("Bluetooth مغلق — يستمر الربط عبر Hotspot/QR بدون إنترنت")
            return
        }
        val scanner = bt.bluetoothLeScanner ?: run {
            status("BLE غير مدعوم — يستمر الربط عبر Hotspot/QR")
            return
        }
        runCatching {
            scanner.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback)
        }.onFailure { status("تعذر بدء BLE — يستمر Hotspot/QR") }
    }

    @SuppressLint("MissingPermission")
    private fun requestProvisionOverGatt(device: BluetoothDevice, code: String) {
        if (!running || connectingGatt || !hasBlePermissions()) return
        connectingGatt = true
        handler.removeCallbacks(fallback)
        handler.postDelayed(fallback, 4_500L)
        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
                if (!running) { runCatching { g.close() }; return }
                if (statusCode == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    runCatching { g.requestMtu(517) }
                    handler.postDelayed({ runCatching { g.discoverServices() } }, 250L)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connectingGatt = false
                    runCatching { g.close() }
                }
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
                if (running) runCatching { g.discoverServices() }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
                if (statusCode != BluetoothGatt.GATT_SUCCESS) return
                val service: BluetoothGattService = g.getService(BleProtocol.SERVICE_UUID.uuid) ?: return
                val characteristic: BluetoothGattCharacteristic = service.getCharacteristic(PROVISION_CHARACTERISTIC_UUID) ?: return
                runCatching { g.readCharacteristic(characteristic) }
            }

            @Deprecated("Deprecated in Java")
            override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
                if (statusCode == BluetoothGatt.GATT_SUCCESS && characteristic.uuid == PROVISION_CHARACTERISTIC_UUID) {
                    val text = characteristic.value?.toString(Charsets.UTF_8).orEmpty()
                    if (text.startsWith("AP3P:")) {
                        handler.removeCallbacks(fallback)
                        finishFound(text, "Bluetooth مباشر")
                    }
                }
                connectingGatt = false
                runCatching { g.disconnect() }
                runCatching { g.close() }
            }
        }
        gatt = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(activity, false, callback)
        }.getOrNull()
        if (gatt == null) connectingGatt = false
    }

    private fun finishFound(value: String, channel: String) {
        if (!running) return
        running = false
        handler.removeCallbacks(fallback)
        activity.runOnUiThread {
            stop()
            found(value, channel)
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        handler.removeCallbacks(fallback)
        runCatching { socket?.close() }
        socket = null
        if (hasBlePermissions()) runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCallback) }
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
        connectingGatt = false
    }
}
