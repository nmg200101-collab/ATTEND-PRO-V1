package com.attendpro.employee

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.PhoneAttendancePolicy

object AttendanceRequestNotifier {
    const val CHANNEL_ID = "attend_presence_requests_v2"
    const val EXTRA_OPEN_CHALLENGE = "open_presence_challenge"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build()
        val channel = NotificationChannel(CHANNEL_ID, "طلبات إثبات الحضور", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "تنبيه فوري عند طلب المحل إثبات حضور أو انصراف"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 250, 120, 250, 120, 400)
            setSound(sound, attrs)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }

    fun notifyChallenge(context: Context, challengeId: String, method: AttendanceMethod, expiresAt: Long) {
        ensureChannel(context)
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_OPEN_CHALLENGE, true)
        }
        val pending = PendingIntent.getActivity(
            context,
            challengeId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val ttl = ((expiresAt - System.currentTimeMillis()) / 1000L).coerceAtLeast(1L)
        val title = "طلب إثبات حضور"
        val shortText = "${PhoneAttendancePolicy.label(method)} — وافق خلال ${ttl}ث"
        val longText = "جهاز المحل يطلب إثبات وجودك الآن. الطريقة المطلوبة: ${PhoneAttendancePolicy.label(method)}. يعمل هذا التنبيه محليًا ولا يحتاج إنترنت."

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
        @Suppress("DEPRECATION")
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(shortText)
            .setStyle(Notification.BigTextStyle().bigText(longText))
            .setPriority(Notification.PRIORITY_MAX)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(pending)
            .addAction(android.R.drawable.ic_menu_view, "فتح الطلب", pending)
            .build()

        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(31000 + (challengeId.hashCode() and 0x3ff), notification)
    }
}
