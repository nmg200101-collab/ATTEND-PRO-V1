package com.attendpro.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Offline-capable activation protocol for ATTEND PRO.
 *
 * Store devices create an unsigned activation request. The owner device signs a license
 * with the ATTEND PRO owner signing key. Store devices verify the license using only the
 * embedded public key, so the owner code/private key never needs to be shared with a store.
 *
 * Remote revocation/usage monitoring still requires the central server. The same signed
 * license token can be presented to that server as a Bearer token later.
 */
object ActivationProtocol {
    private const val REQUEST_PREFIX = "APREQ1"
    private const val LICENSE_PREFIX = "APLIC1"

    // Public verification key. It is safe and necessary for every app installation to have it.
    private const val ROOT_PUBLIC_KEY_B64 = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEcA-BOb9dIfOOTeoVn38ov0FJLZ30uJUKotjhwbnj2h1omEImtXtqo13K8aiwZ7FL7DV66FIXjInB1S8i_CnrMA"

    data class ActivationRequest(
        val storeId: String,
        val storeName: String,
        val branchId: String,
        val createdAt: Long
    )

    data class StoreLicense(
        val licenseId: String,
        val storeId: String,
        val storeName: String,
        val branchId: String,
        val issuedAt: Long,
        val expiresAt: Long,
        val maxEmployees: Int,
        val allowEmployeeCompanion: Boolean = true,
        val allowPin: Boolean = true,
        val allowFaceCapture: Boolean = true,
        val allowExternalFingerprint: Boolean = true
    )

    data class LicenseValidation(val valid: Boolean, val reason: String, val license: StoreLicense? = null)

    fun createRequest(storeId: String, storeName: String, branchId: String): String {
        val payload = JSONObject().apply {
            put("v", 1)
            put("storeId", storeId)
            put("storeName", storeName)
            put("branchId", branchId)
            put("createdAt", System.currentTimeMillis())
        }.toString().toByteArray(StandardCharsets.UTF_8)
        return "$REQUEST_PREFIX.${b64(payload)}"
    }

    fun parseRequest(text: String): Result<ActivationRequest> = runCatching {
        val raw = text.trim()
        require(raw.startsWith("$REQUEST_PREFIX.")) { "رمز طلب التفعيل غير صحيح" }
        val parts = raw.split('.')
        require(parts.size == 2) { "صيغة طلب التفعيل غير صحيحة" }
        val o = JSONObject(String(b64d(parts[1]), StandardCharsets.UTF_8))
        require(o.optInt("v", 0) == 1) { "إصدار طلب التفعيل غير مدعوم" }
        val storeId = o.optString("storeId", "").trim()
        require(storeId.startsWith("STORE-")) { "معرّف جهاز المحل غير صحيح" }
        ActivationRequest(
            storeId = storeId,
            storeName = o.optString("storeName", "محل").trim().ifBlank { "محل" },
            branchId = o.optString("branchId", "MAIN").trim().ifBlank { "MAIN" },
            createdAt = o.optLong("createdAt", 0L)
        )
    }

    fun issueLicense(privateKey: PrivateKey, license: StoreLicense): String {
        val payload = JSONObject().apply {
            put("v", 1)
            put("licenseId", license.licenseId)
            put("storeId", license.storeId)
            put("storeName", license.storeName)
            put("branchId", license.branchId)
            put("issuedAt", license.issuedAt)
            put("expiresAt", license.expiresAt)
            put("maxEmployees", license.maxEmployees.coerceIn(1, 10000))
            put("allowEmployeeCompanion", license.allowEmployeeCompanion)
            put("allowPin", license.allowPin)
            put("allowFaceCapture", license.allowFaceCapture)
            put("allowExternalFingerprint", license.allowExternalFingerprint)
        }.toString().toByteArray(StandardCharsets.UTF_8)

        val signature = Signature.getInstance("SHA256withECDSA").apply {
            initSign(privateKey)
            update(payload)
        }.sign()
        return "$LICENSE_PREFIX.${b64(payload)}.${b64(signature)}"
    }

    fun validateLicense(token: String, expectedStoreId: String, now: Long = System.currentTimeMillis()): LicenseValidation {
        return try {
            val raw = token.trim()
            if (!raw.startsWith("$LICENSE_PREFIX.")) return LicenseValidation(false, "رمز التفعيل غير معروف")
            val parts = raw.split('.')
            if (parts.size != 3) return LicenseValidation(false, "صيغة رمز التفعيل غير صحيحة")
            val payload = b64d(parts[1])
            val signatureBytes = b64d(parts[2])
            val publicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(b64d(ROOT_PUBLIC_KEY_B64)))
            val verified = Signature.getInstance("SHA256withECDSA").run {
                initVerify(publicKey)
                update(payload)
                verify(signatureBytes)
            }
            if (!verified) return LicenseValidation(false, "توقيع التفعيل غير صالح")
            val o = JSONObject(String(payload, StandardCharsets.UTF_8))
            if (o.optInt("v", 0) != 1) return LicenseValidation(false, "إصدار الترخيص غير مدعوم")
            val license = StoreLicense(
                licenseId = o.optString("licenseId", ""),
                storeId = o.optString("storeId", ""),
                storeName = o.optString("storeName", "محل"),
                branchId = o.optString("branchId", "MAIN"),
                issuedAt = o.optLong("issuedAt", 0L),
                expiresAt = o.optLong("expiresAt", 0L),
                maxEmployees = o.optInt("maxEmployees", 1).coerceIn(1, 10000),
                allowEmployeeCompanion = o.optBoolean("allowEmployeeCompanion", true),
                allowPin = o.optBoolean("allowPin", true),
                allowFaceCapture = o.optBoolean("allowFaceCapture", true),
                allowExternalFingerprint = o.optBoolean("allowExternalFingerprint", true)
            )
            if (license.licenseId.isBlank()) return LicenseValidation(false, "معرّف الترخيص مفقود")
            if (license.storeId != expectedStoreId) return LicenseValidation(false, "هذا الرمز صادر لجهاز محل آخر")
            if (license.expiresAt <= now) return LicenseValidation(false, "انتهت صلاحية الترخيص", license)
            LicenseValidation(true, "الترخيص صالح", license)
        } catch (e: Exception) {
            LicenseValidation(false, e.message ?: "تعذر قراءة رمز التفعيل")
        }
    }

    fun newLicense(request: ActivationRequest, days: Int, maxEmployees: Int): StoreLicense {
        val now = System.currentTimeMillis()
        val safeDays = days.coerceIn(1, 3650)
        return StoreLicense(
            licenseId = "LIC-${UUID.randomUUID()}",
            storeId = request.storeId,
            storeName = request.storeName,
            branchId = request.branchId,
            issuedAt = now,
            expiresAt = now + safeDays * 86_400_000L,
            maxEmployees = maxEmployees.coerceIn(1, 10000)
        )
    }

    private fun b64(bytes: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    internal fun b64d(value: String): ByteArray {
        val padded = value + "=".repeat((4 - value.length % 4) % 4)
        return Base64.getUrlDecoder().decode(padded)
    }
}

/**
 * Keeps the license-signing private key owner-only.
 * The APK contains an encrypted bootstrap copy; the initial owner code unlocks it once.
 * After bootstrap, the key is wrapped by an Android Keystore AES key bound to that owner device.
 */
class OwnerSigningKeyStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("owner_signing_key", Context.MODE_PRIVATE)
    private val keyAlias = "attend_pro_owner_signer_wrap_v1"

    private val bootstrapEncrypted = "v1.T_SqvVRfuc7c1cmw9LVtlA.BaeK1RLheUDf5WhZ.MfAg_VtblbZU4eJ3AHkm1V-wYrBhQFwN0zdOTneEWz00MMBbxeLcaIYdrRls-s874kWJp0vMSHbcCRjPPvq_enJtvD7Y68s4m-bGaMOdbqhEeQPlJ7K0rmfEulxBMuXwv7iNa5XUNvpOiqkbJp9uGvSgPr-X0GETkL3ZQlPQSKBKSSOo14jO0Sl1ODXPimu_X29rM0b8mUP5HA"
    private val aad = "ATTEND-PRO-OWNER-ROOT-v1".toByteArray(StandardCharsets.UTF_8)

    fun getOrBootstrap(ownerCode: String): Result<PrivateKey> = runCatching {
        val saved = prefs.getString("wrappedPrivateKey", "").orEmpty()
        val der = if (saved.isNotBlank()) unwrapWithKeystore(saved) else {
            require(ownerCode.isNotBlank()) { "أدخل رمز المالك لتهيئة توقيع التراخيص" }
            val raw = decryptBootstrap(ownerCode)
            prefs.edit().putString("wrappedPrivateKey", wrapWithKeystore(raw)).apply()
            raw
        }
        KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(der))
    }

    fun isInitialized(): Boolean = prefs.getString("wrappedPrivateKey", "").orEmpty().isNotBlank()

    private fun decryptBootstrap(ownerCode: String): ByteArray {
        val parts = bootstrapEncrypted.split('.')
        require(parts.size == 4 && parts[0] == "v1") { "بيانات مفتاح المالك غير صحيحة" }
        val salt = ActivationProtocol.b64d(parts[1])
        val iv = ActivationProtocol.b64d(parts[2])
        val cipherText = ActivationProtocol.b64d(parts[3])
        val spec = PBEKeySpec(ownerCode.toCharArray(), salt, 150_000, 256)
        val derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        val key = SecretKeySpec(derived, "AES")
        return try {
            Cipher.getInstance("AES/GCM/NoPadding").run {
                init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                updateAAD(aad)
                doFinal(cipherText)
            }
        } catch (_: Exception) {
            throw IllegalArgumentException("تعذر تهيئة توقيع التراخيص. استخدم رمز المالك الأساسي للنظام مرة واحدة.")
        }
    }

    private fun androidKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun wrapWithKeystore(raw: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, androidKey())
        cipher.updateAAD(aad)
        val encrypted = cipher.doFinal(raw)
        return "v1.${Base64.getUrlEncoder().withoutPadding().encodeToString(cipher.iv)}.${Base64.getUrlEncoder().withoutPadding().encodeToString(encrypted)}"
    }

    private fun unwrapWithKeystore(blob: String): ByteArray {
        val parts = blob.split('.')
        require(parts.size == 3 && parts[0] == "v1") { "مفتاح التوقيع المحلي تالف" }
        val iv = ActivationProtocol.b64d(parts[1])
        val encrypted = ActivationProtocol.b64d(parts[2])
        return Cipher.getInstance("AES/GCM/NoPadding").run {
            init(Cipher.DECRYPT_MODE, androidKey(), GCMParameterSpec(128, iv))
            updateAAD(aad)
            doFinal(encrypted)
        }
    }
}
