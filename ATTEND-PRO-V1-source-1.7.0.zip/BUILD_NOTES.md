ATTEND PRO 1.7.0 — BUILD NOTES

Target: Android 35
Min SDK: 26
JDK: 17
Gradle CI: 8.9

Versions:
- store-app: versionCode 18 / versionName 1.7.0
- employee-app: versionCode 18 / versionName 1.7.0

Main changes:
- New AttendanceMethod values: PASSWORD, PATTERN, VOICE_PHRASE, GPS, PHONE_PROXIMITY.
- Per-employee allowedMethods persisted backward-compatibly; empty legacy set means unrestricted by method list.
- Per-employee password/pattern/voice phrase values are stored only as SHA-256 hashes.
- Store owner can globally enable/disable attendance methods and then restrict them per employee.
- Main Store screen has a central attendance hub and no public shortcut that bypasses Store-owner administration for employee management or reports.
- Store-owner section has local PIN protection, 5-failure/60-second lockout, and a short-lived administration session token.
- ReportsActivity validates owner-session access when Store-owner PIN protection is active.
- Report-transfer confirmation uses a random transfer id and 6-digit SecureRandom confirmation code; only its hash is persisted.

BLE protocol:
- Version 2 adds signed proof flags: VERIFIED, BIOMETRIC, GPS.
- HMAC includes the full flags byte, employee hash and rolling 15-second window.
- Store accepts legacy version-1 BLE payloads for backward compatibility.
- Phone biometric and phone GPS are distinguished when recording AttendanceMethod.
- Proof events are deduplicated by HMAC token and a short event interval.

GPS:
- Store coordinates and radius are persisted locally.
- Employee QR provisioning optionally includes Store coordinates/radius only when Store GPS is configured and the employee is allowed GPS.
- Employee app verifies its phone location inside the Store radius before broadcasting a short-lived GPS proof.
- Store-terminal GPS path uses employee PIN as the identity factor.
- Locations older than 10 minutes are rejected.
- Android-declared mock locations are rejected.

Voice:
- Uses Android speech recognition to compare a normalized spoken phrase against a stored phrase hash.
- This is phrase verification, not speaker-biometric identity verification. Do not market it as true voice biometrics until a speaker-verification engine and anti-replay/liveness are added.

Face / fingerprint limitations:
- Shared Store-device face recognition is not yet automatic; reference face capture remains enrollment only.
- External fingerprint TCP connectivity exists; vendor-specific event/template drivers are still required.

Offline / sync:
- Attendance events remain local until a successful sync.
- Automatic sync requires reportAutoSync, HTTPS server URL, valid activation license and pending events.
- Remote dashboard/live owner monitoring still requires deployment of the central backend.

CI verification required:
- This source package must be built by GitHub Actions before claiming APK build success.
