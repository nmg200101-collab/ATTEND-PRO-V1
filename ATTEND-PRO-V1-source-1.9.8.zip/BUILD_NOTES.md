ATTEND PRO 1.9.2 — BUILD NOTES
================================
Android:
- store-app: versionCode 21 / versionName 1.9.2
- employee-app: versionCode 21 / versionName 1.9.2
- compileSdk/targetSdk: 35
- minSdk: 26
- JDK: 17

Central server:
- Node.js >= 22
- No npm dependencies
- Requires ATTEND_PRO_OWNER_API_KEY (>=32 chars) and ATTEND_PRO_DATA_KEY environment secrets
- Must be published behind HTTPS
- ATTEND_PRO_OFFLINE_LEASE_HOURS defaults to 72 and is clamped to 1..168

Secure Activation Lock:
- Store operational authorization is central-only.
- Trial/local legacy license validation no longer unlocks attendance, employees, Store Settings or Store Reports.
- Embedded local owner signing-key bootstrap was removed from the Android APK source.
- Central credentials are bound to the Store device P-256 Android Keystore identity.
- Central lease must be valid; clock rollback detection is applied.
- Central owner can approve, suspend, reactivate and renew subscription/max-employees.
- Report Receiver role remains independent of Store activation by design.

Security:
- Android Keystore AES-GCM protects central store access token, activation polling secret, central owner API key and receiver-secret migration.
- Central access tokens are random 256-bit values; server stores only SHA-256 token hashes.
- Store requests use ECDSA P-256 signatures, timestamps, body hashes and replay nonces.
- Activation polling/receiver secrets use scrypt hashes server-side.
- Pending activation tokens are AES-GCM encrypted at rest using the server-only data key.
- Report packages remain receiver-specific AES-GCM encrypted before upload.

Validation performed before packaging:
- Node server syntax check passed.
- Central activation integration passed: request -> owner approval -> signed activation -> ACTIVE validation -> suspension -> SUSPENDED validation -> renewal/reactivation.
- Security regression passed: wrong owner key blocked; stolen bearer token used with another EC device key blocked; replayed signed request blocked.
- Remote workflow regression passed: signed attendance sync -> receiver registration -> encrypted inbox -> remote dashboard/report -> receipt confirmation -> receiver revocation blocks access.
- All Android XML resources parsed successfully.
- Kotlin source parser/preflight found no syntax/parser errors in introduced code. A full Android Gradle compile is intentionally left for the repository GitHub Actions workflow, which is the authoritative APK build environment.


1.9.2 compile fix
- Restored UI compatibility accessors for lastSyncAt / lastSyncMessage.
- isActivationActive now aliases central activation only.
- effectiveEmployeeLimit now comes only from active central license.
- No local/offline license path restored.
