package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.AttendanceAction
import com.attendpro.core.BleDirectProtocol
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.SecretCodec

/** Employee-side GATT endpoint. Only a signed ping/ack round-trip establishes presence. */
class BleDirectLinkServer(
    private val context: Context,
    private val identity: EmployeeIdentityStore,
    private val onStatus: (String) -> Unit,
    private val onChallenge: (String, AttendanceMethod, Long, AttendanceAction) -> Unit
) {
    private data class AuthState(var lastAuthenticatedAt: Long, var lastPingNonce: Int)
    private var server: BluetoothGattServer? = null
    private var running = false
    private val authenticatedDevices = mutableMapOf<String, AuthState>()
    private val handler = Handler(Looper.getMainLooper())
    private val staleTask = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            authenticatedDevices.entries.removeAll { now - it.value.lastAuthenticatedAt > AUTH_SESSION_MILLIS }
            val last = identity.lastBleDirectSeenAt
            if (last > 0L && now - last > HEARTBEAT_STALE_MILLIS && identity.lastBleDirectState.contains("متصل")) {
                identity.lastBleDirectState = "انقطع ACK المباشر — يستمر BLE/Wi‑Fi"
                onStatus("انقطع Heartbeat/ACK من جهاز المحل — يستمر الاكتشاف التلقائي")
            }
            if (running) handler.postDelayed(this, 2_000L)
        }
    }

    private fun hasConnectPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (running || !identity.isConfigured || !hasConnectPermission()) return
        val manager = context.getSystemService(BluetoothManager::class.java) ?: return
        val gatt = runCatching { manager.openGattServer(context, callback) }.getOrNull() ?: return
        val service = BluetoothGattService(BleDirectProtocol.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val command = BluetoothGattCharacteristic(
            BleDirectProtocol.COMMAND_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_READ,
            BluetoothGattCharacteristic.PERMISSION_WRITE or BluetoothGattCharacteristic.PERMISSION_READ
        )
        service.addCharacteristic(command)
        if (!gatt.addService(service)) { gatt.close(); return }
        server = gatt; running = true
        handler.removeCallbacks(staleTask); handler.post(staleTask)
        onStatus("Bluetooth BLE المباشر جاهز للتحقق عبر Heartbeat/ACK")
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false; handler.removeCallbacks(staleTask); authenticatedDevices.clear()
        runCatching { server?.close() }; server = null
    }

    fun isRunning(): Boolean = running

    private fun authFor(device: BluetoothDevice?): AuthState? {
        val address = device?.address ?: return null
        val state = authenticatedDevices[address] ?: return null
        return state.takeIf { System.currentTimeMillis() - it.lastAuthenticatedAt <= AUTH_SESSION_MILLIS }
    }

    private val callback = object : BluetoothGattServerCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(device: BluetoothDevice?, status: Int, newState: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                identity.lastBleDirectState = "تم فتح Bluetooth — بانتظار Heartbeat موثق"
                onStatus("تم فتح قناة Bluetooth؛ لن تُعتبر متصلة قبل ACK الموثق")
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                device?.address?.let { authenticatedDevices.remove(it) }
                identity.lastBleDirectState = "انقطع الاتصال المباشر — يستمر BLE/Wi‑Fi"
                onStatus("انقطع Bluetooth المباشر — يستمر BLE/Wi‑Fi تلقائيًا")
            }
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice?, requestId: Int, characteristic: BluetoothGattCharacteristic?,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            val bytes = value ?: ByteArray(0)
            val secret = SecretCodec.decode(identity.pairingSecret) ?: ByteArray(0)
            var ok = false
            if (characteristic?.uuid == BleDirectProtocol.COMMAND_UUID && offset == 0 && secret.isNotEmpty()) {
                val ping = BleDirectProtocol.decodePing(bytes, secret)
                if (ping != null) {
                    ok = true
                    device?.address?.let { authenticatedDevices[it] = AuthState(System.currentTimeMillis(), ping.nonce) }
                    identity.lastBleDirectSeenAt = System.currentTimeMillis()
                    identity.lastBleDirectState = "متصل بالمحل عبر Bluetooth BLE • ACK موثق"
                    onStatus("✓ Heartbeat موثق من جهاز المحل؛ ACK جاهز")
                } else if (authFor(device) != null) {
                    val config = BleDirectProtocol.decodeConfig(bytes)
                    if (config != null) {
                        ok = true
                        if (config.gpsConfigured) {
                            identity.trustedStoreLatitude = config.latitude; identity.trustedStoreLongitude = config.longitude
                        } else {
                            identity.trustedStoreLatitude = Double.NaN; identity.trustedStoreLongitude = Double.NaN
                        }
                        identity.trustedStoreGpsRadius = config.radiusMeters
                        identity.employeeVoicePromptsEnabled = config.voicePromptsEnabled
                        identity.geoArrivalAlertsEnabled = config.geoAlertsEnabled
                        identity.shiftStartHour = config.shiftStartHour; identity.shiftStartMinute = config.shiftStartMinute
                        identity.shiftEndHour = config.shiftEndHour; identity.shiftEndMinute = config.shiftEndMinute
                        identity.lastBleDirectSeenAt = System.currentTimeMillis()
                        onStatus("✓ تمت مزامنة إعدادات المحل عبر Bluetooth بدون إنترنت")
                    } else {
                        val challenge = BleDirectProtocol.decodeChallenge(bytes, secret)
                        if (challenge != null) {
                            ok = true
                            identity.lastBleDirectSeenAt = System.currentTimeMillis()
                            identity.lastBleDirectState = "استقبل طلب إثبات عبر Bluetooth مباشر"
                            onChallenge("local:${challenge.challengeId}", challenge.method, challenge.expiresAt, challenge.action)
                        }
                    }
                }
            }
            if (responseNeeded) runCatching {
                server?.sendResponse(device, requestId, if (ok) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null)
            }
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicReadRequest(device: BluetoothDevice?, requestId: Int, offset: Int, characteristic: BluetoothGattCharacteristic?) {
            val secret = SecretCodec.decode(identity.pairingSecret) ?: ByteArray(0)
            val auth = authFor(device)
            val payload = if (characteristic?.uuid == BleDirectProtocol.COMMAND_UUID && secret.isNotEmpty() && auth != null) {
                BleDirectProtocol.encodeAck(secret, auth.lastPingNonce)
            } else ByteArray(0)
            val safeOffset = offset.coerceIn(0, payload.size)
            val status = if (payload.isNotEmpty()) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
            runCatching { server?.sendResponse(device, requestId, status, safeOffset, if (payload.isEmpty()) null else payload.copyOfRange(safeOffset, payload.size)) }
        }
    }

    companion object {
        private const val AUTH_SESSION_MILLIS = 15_000L
        private const val HEARTBEAT_STALE_MILLIS = 12_000L
    }
}
