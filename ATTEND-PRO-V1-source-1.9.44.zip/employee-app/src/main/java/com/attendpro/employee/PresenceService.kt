package com.attendpro.employee

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.content.pm.ServiceInfo
import android.content.pm.PackageManager
import android.Manifest
import com.attendpro.core.PhoneAttendancePolicy
import com.attendpro.core.CentralServerClient
import com.attendpro.core.EmployeeIdentityStore
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.AttendanceAction

class PresenceService : Service() {
    companion object {
        const val ACTION_START = "com.attendpro.employee.PRESENCE_START"
        const val ACTION_PROOF = "com.attendpro.employee.PRESENCE_PROOF"
        const val ACTION_STOP = "com.attendpro.employee.PRESENCE_STOP"
        const val ACTION_LATE_ALERT = "com.attendpro.employee.PRESENCE_LATE_ALERT"
        const val EXTRA_VOICE_TEXT = "voice_text"
        const val EXTRA_FLAGS = "flags"
        const val EXTRA_DURATION = "duration"
        const val EXTRA_BACKGROUND_RESTART = "background_restart"
        private const val CHANNEL = "attend_presence"
        private const val NOTIFICATION_ID = 771
    }
    private lateinit var identity: EmployeeIdentityStore
    private lateinit var network: NetworkPresenceBroadcaster
    private lateinit var bluetooth: BlePresenceAdvertiser
    private lateinit var localChallenges: LocalChallengeListener
    private lateinit var directBle: BleDirectLinkServer
    private lateinit var geoMonitor: OfflineGeoMonitor
    private lateinit var voicePrompter: EmployeeVoicePrompter
    private val handler = Handler(Looper.getMainLooper())
    private var locationMonitoringAllowedForRun: Boolean = false
    private var lastLocalChallengeMethod: String = ""
    private var lastLocalChallengeAt: Long = 0L
    @Volatile private var serverLinkInFlight = false
    private var lastServerLinkAttemptAt = 0L
    private val challengePoller = object : Runnable {
        override fun run() {
            ensurePresenceChannels()
            if (identity.isConfigured) {
                if (identity.serverLinked) pollChallenge() else ensureServerLinkWhenAvailable()
            }
            handler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        AttendanceRequestNotifier.ensureChannel(this); identity = EmployeeIdentityStore(this)
        network = NetworkPresenceBroadcaster { message ->
            identity.lastLanState = message
            if (message.contains("متصل بالمحل")) identity.lastLanStoreSeenAt = System.currentTimeMillis()
        }
        bluetooth = BlePresenceAdvertiser(this) { message ->
            if (message.contains("BLE يعمل")) identity.lastBleDirectState = identity.lastBleDirectState.ifBlank { "الهاتف يبث عبر BLE بانتظار اتصال المحل المباشر" }
        }
        localChallenges = LocalChallengeListener { id, method, expires, action -> receiveLocalChallenge(id, method, expires, action) }
        voicePrompter = EmployeeVoicePrompter(this)
        directBle = BleDirectLinkServer(this, identity, { message -> identity.lastBleDirectState = message }) { id, method, expires, action ->
            receiveLocalChallenge(id, method, expires, action)
        }
        geoMonitor = OfflineGeoMonitor(this, identity, { distance, accuracy ->
            network.markVerified(60_000L, com.attendpro.core.BleProtocol.FLAG_GPS)
            bluetooth.markVerified(60_000L, com.attendpro.core.BleProtocol.FLAG_GPS)
            AttendanceRequestNotifier.notifyGeoArrival(this, identity.displayName, identity.trustedStoreName, distance)
            if (identity.employeeVoicePromptsEnabled) voicePrompter.speak("يا ${identity.displayName}، تم التعرف على وصولك إلى نطاق ${identity.trustedStoreName}. يرجى إثبات الحضور الآن")
            identity.lastGpsDistanceMeters = distance
        }, { })
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL,"اكتشاف جهاز المحل",NotificationManager.IMPORTANCE_LOW).apply {
            description = "يحافظ على التعرف الآمن على هاتف الموظف عبر الشبكة المحلية"
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !identity.isConfigured) {
            network.stop(); bluetooth.stop(); localChallenges.stop(); directBle.stop(); geoMonitor.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        val hasForegroundLocation = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasBackgroundLocation = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        val backgroundRestart = intent == null || intent.getBooleanExtra(EXTRA_BACKGROUND_RESTART, false)
        locationMonitoringAllowedForRun = identity.geoArrivalAlertsEnabled && identity.isTrustedStoreGpsConfigured && hasForegroundLocation &&
            (!backgroundRestart || hasBackgroundLocation)
        val foregroundStarted = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or if (locationMonitoringAllowedForRun) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
                startForeground(NOTIFICATION_ID, notification(), types)
            } else startForeground(NOTIFICATION_ID, notification())
        }.isSuccess
        if (!foregroundStarted) {
            // Android 14/15 or OEM policy may reject a background FGS when runtime prerequisites are unavailable.
            network.stop(); bluetooth.stop(); localChallenges.stop(); directBle.stop(); geoMonitor.stop(); stopSelf(startId)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_LATE_ALERT) {
            val voice = intent.getStringExtra(EXTRA_VOICE_TEXT).orEmpty().trim()
            if (voice.isNotBlank() && identity.employeeVoicePromptsEnabled) voicePrompter.speak(voice)
        }
        EmployeeLateAlertScheduler.sync(this, identity)
        if (identity.autoPresence) {
            network.start(identity.employeeId, identity.pairingSecret)
            bluetooth.start(identity.employeeId, identity.pairingSecret)
            localChallenges.start(identity.employeeId, identity.pairingSecret)
            directBle.start()
            if (locationMonitoringAllowedForRun) geoMonitor.start() else geoMonitor.stop()
        } else {
            network.stop(); bluetooth.stop(); localChallenges.stop(); directBle.stop(); geoMonitor.stop()
        }
        handler.removeCallbacks(challengePoller); handler.post(challengePoller)
        if (intent?.action == ACTION_PROOF) {
            val duration = intent.getLongExtra(EXTRA_DURATION,45_000L)
            val proof = intent.getIntExtra(EXTRA_FLAGS,0)
            network.markVerified(duration, proof)
            bluetooth.markVerified(duration, proof)
        }
        return START_STICKY
    }

    private fun ensurePresenceChannels() {
        val bleEmployeeId = identity.employeeId
        val bleSecret = com.attendpro.core.SecretCodec.decode(identity.pairingSecret) ?: ByteArray(0)
        BleChallengeInbox.start(this, bleEmployeeId, bleSecret) { id, method, expires, action -> receiveLocalChallenge(id, method, expires, action) }
        if (!identity.isConfigured || !identity.autoPresence) return
        if (!network.isRunning()) network.start(identity.employeeId, identity.pairingSecret)
        if (!bluetooth.isRunning()) bluetooth.start(identity.employeeId, identity.pairingSecret)
        if (!localChallenges.isRunning()) localChallenges.start(identity.employeeId, identity.pairingSecret)
        if (!directBle.isRunning()) directBle.start()
        if (locationMonitoringAllowedForRun && !geoMonitor.isRunning()) geoMonitor.start()
        if (!locationMonitoringAllowedForRun && geoMonitor.isRunning()) geoMonitor.stop()
    }

    private fun receiveLocalChallenge(id: String, method: AttendanceMethod, expires: Long, action: AttendanceAction) {
        val now = System.currentTimeMillis()
        if (id == identity.pendingChallengeId || expires <= now) return
        if (!identity.acceptChallengeOnce(id, expires)) return
        // BLE direct, BLE advertisement and LAN may deliver the same user request nearly together.
        if (lastLocalChallengeMethod == method.name && now - lastLocalChallengeAt < 2_500L) return
        lastLocalChallengeMethod = method.name; lastLocalChallengeAt = now
        AttendanceRequestNotifier.notifyChallenge(this, id, method, expires, action)
        if (identity.employeeVoicePromptsEnabled) {
            val configured = identity.employeeRequestVoiceText.replace("{name}", identity.displayName).trim()
            voicePrompter.speak(configured.ifBlank { "${identity.displayName}، يرجى إثبات ${if (action == AttendanceAction.CHECK_IN) "حضورك" else "انصرافك"}" })
        }
        identity.pendingChallengeId = id
        identity.pendingChallengeMethod = method.name
        identity.pendingChallengeExpiresAt = expires
        identity.pendingChallengeAction = action.name
    }


    private fun ensureServerLinkWhenAvailable() {
        val now = System.currentTimeMillis()
        if (serverLinkInFlight || now - lastServerLinkAttemptAt < 45_000L || !identity.isConfigured) return
        lastServerLinkAttemptAt = now
        serverLinkInFlight = true
        Thread {
            val result = CentralServerClient.registerEmployeePhone(
                identity.serverUrl, identity.trustedStoreId, identity.employeeId, identity.displayName,
                identity.branchId, identity.pairingSecret, identity.installationId, identity.allowedMethods
            )
            result.onSuccess { link ->
                if (link.linked) {
                    identity.serverLinked = true
                    identity.linkedAt = link.linkedAt.takeIf { it > 0L } ?: System.currentTimeMillis()
                }
            }
            serverLinkInFlight = false
        }.start()
    }

    private fun pollChallenge() {
        Thread {
            val challenge=CentralServerClient.pollEmployeePresenceChallenge(identity.serverUrl,identity.trustedStoreId,identity.employeeId,identity.pairingSecret,identity.installationId).getOrNull() ?: return@Thread
            if(challenge.challengeId==identity.pendingChallengeId || challenge.expiresAt<=System.currentTimeMillis()) return@Thread
            if (!identity.acceptChallengeOnce(challenge.challengeId, challenge.expiresAt)) return@Thread
            val action = challenge.action ?: AttendanceAction.CHECK_IN
            identity.pendingChallengeId=challenge.challengeId;identity.pendingChallengeMethod=challenge.requiredMethod.name;identity.pendingChallengeExpiresAt=challenge.expiresAt;identity.pendingChallengeAction=action.name
            AttendanceRequestNotifier.notifyChallenge(this, challenge.challengeId, challenge.requiredMethod, challenge.expiresAt, action)
            if (identity.employeeVoicePromptsEnabled) {
                val configured = identity.employeeRequestVoiceText.replace("{name}", identity.displayName).trim()
                voicePrompter.speak(configured.ifBlank { "${identity.displayName}، يرجى إثبات ${if (action == AttendanceAction.CHECK_IN) "حضورك" else "انصرافك"}" })
            }
        }.start()
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_attend_pro)
            .setContentTitle("ATTEND PRO — هاتف الموظف")
            .setContentText(if(identity.autoPresence) "Bluetooth مباشر وBLE وWi‑Fi وGPS المحلي تعمل" else "طلبات إثبات الوجود مفعلة لهذا الهاتف")
            .setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy(){handler.removeCallbacks(challengePoller);network.stop();bluetooth.stop();localChallenges.stop();directBle.stop();geoMonitor.stop();BleChallengeInbox.stop();voicePrompter.shutdown()
        super.onDestroy()}
    override fun onBind(intent: Intent?): IBinder? = null
}
