package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.BleProtocol
import com.attendpro.core.PairingAckProtocol
import com.attendpro.core.PairingProtocol
import com.attendpro.core.SecretCodec
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.util.UUID

class PairingDiscovery(
    private val activity: Activity,
    private val found: (String, String) -> Unit,
    private val status: (String) -> Unit
) {
    enum class Mode { ALL, BLUETOOTH_ONLY, WIFI_HOTSPOT_ONLY }

    companion object {
        const val REQUEST_SCAN = 8110
        const val UDP_PORT = 45993
        private const val MAX_GATT_BUFFER = 16_384
        private val PROVISION_CHARACTERISTIC_UUID: UUID = UUID.fromString("0000A772-0000-1000-8000-00805F9B34FB")
    }

    private val adapter = activity.getSystemService(BluetoothManager::class.java)?.adapter
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var gatt: BluetoothGatt? = null
    private var pendingCode = ""
    private var targetCode = ""
    private var mode = Mode.ALL
    private var connectingGatt = false
    private var gattOffset = 0
    private val gattBuffer = ByteArrayOutputStream()
    private var lastGattDevice: BluetoothDevice? = null
    private var lastGattCode = ""
    private var gattAttempt = 0
    private var gattServicesRequested = false
    private var gattAwaitingAck = false
    private var gattProvisionReady = ""
    private var pendingLanProvision = ""
    private var pendingLanCode = ""

    private val gattTimeout = Runnable {
        if (!running || !connectingGatt) return@Runnable
        failGatt(gatt, "لم يكتمل تأكيد الربط عبر Bluetooth")
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            if (!running || mode == Mode.WIFI_HOTSPOT_ONLY) return
            val record = result.scanRecord ?: return
            val bytes = record.getServiceData(BleProtocol.SERVICE_UUID)
                ?: record.getManufacturerSpecificData(BleProtocol.MANUFACTURER_ID)
                ?: return
            val text = bytes.toString(Charsets.UTF_8)
            if (text.startsWith("P") && text.length >= 9) {
                val code = text.substring(1, 9).uppercase()
                if (targetCode.isNotBlank() && code != targetCode) return
                pendingCode = code
                status("تم العثور على جهاز المحل عبر Bluetooth — جارٍ استلام الملف ثم إرسال ACK مشفّر…")
                requestProvisionOverGatt(result.device, code)
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) = results.forEach { onScanResult(0, it) }
        override fun onScanFailed(code: Int) { status("تعذر بحث Bluetooth ($code) — مسار Wi‑Fi/Hotspot وQR يظل مستقلًا") }
    }

    private fun hasBlePermissions(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    } else {
        activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    fun start(expectedCode: String = "", requestedMode: Mode = Mode.ALL) {
        stop()
        mode = requestedMode
        targetCode = expectedCode.replace(Regex("[^A-Za-z0-9]"), "").uppercase().take(8)
        running = true
        status(
            when (mode) {
                Mode.BLUETOOTH_ONLY -> "جاري الربط عبر Bluetooth فقط — لا يحتاج إنترنت…"
                Mode.WIFI_HOTSPOT_ONLY -> "جاري الربط عبر Wi‑Fi/نقطة الاتصال فقط — لا يحتاج إنترنت…"
                Mode.ALL -> "جاري الربط المحلي عبر Bluetooth وWi‑Fi/Hotspot — لا يحتاج إنترنت…"
            }
        )

        if (mode != Mode.BLUETOOTH_ONLY) startLanDiscovery()
        if (mode != Mode.WIFI_HOTSPOT_ONLY) startBleDiscovery()
    }

    private fun startLanDiscovery() {
        Thread({
            runCatching {
                DatagramSocket(null).also {
                    socket = it
                    it.reuseAddress = true
                    it.broadcast = true
                    it.soTimeout = 280
                    it.bind(InetSocketAddress(UDP_PORT))
                }.use { s ->
                    val buffer = ByteArray(8192)
                    var lastProbeAt = 0L
                    while (running && mode != Mode.BLUETOOTH_ONLY) {
                        val now = System.currentTimeMillis()
                        if (now - lastProbeAt >= 550L) {
                            val requested = targetCode.ifBlank { "*" }
                            val discover = "APDISCOVER:$requested".toByteArray(Charsets.UTF_8)
                            discoveryTargets().forEach { address ->
                                runCatching { s.send(DatagramPacket(discover, discover.size, address, UDP_PORT)) }
                            }
                            lastProbeAt = now
                        }
                        try {
                            val p = DatagramPacket(buffer, buffer.size)
                            s.receive(p)
                            val text = String(p.data, 0, p.length, Charsets.UTF_8).trim()
                            when {
                                text.startsWith("APFULL:") -> handleLanProvision(s, p, text)
                                text.startsWith("APPAIR:") -> {
                                    val code = text.removePrefix("APPAIR:").take(8).uppercase()
                                    if (code.length == 8 && (targetCode.isBlank() || code == targetCode)) {
                                        pendingCode = code
                                        val request = "APGET:$code".toByteArray(Charsets.UTF_8)
                                        runCatching { s.send(DatagramPacket(request, request.size, p.address, p.port)) }
                                    }
                                }
                                text.startsWith("APOK:") -> {
                                    val code = text.removePrefix("APOK:").take(8).uppercase()
                                    if (pendingLanProvision.isNotBlank() && code == pendingLanCode) {
                                        finishFound(pendingLanProvision, "Wi‑Fi/Hotspot مباشر • ACK")
                                    }
                                }
                                text.startsWith("AP3P:") || text.startsWith("AP4P:") -> {
                                    // Legacy store compatibility: validate the full provision, but only complete
                                    // pairing after the new authenticated ACK handshake when a code is known.
                                    val provision = PairingProtocol.decodeEmployeeProvision(text)
                                    val code = pendingCode.ifBlank { targetCode }
                                    if (provision != null && code.isNotBlank()) sendLanAck(s, p.address, p.port, code, text, provision.pairingSecret)
                                }
                            }
                        } catch (_: SocketTimeoutException) {
                        } catch (_: Exception) {
                        }
                    }
                }
            }.onFailure { if (running) status("تعذر فتح قناة Wi‑Fi/Hotspot المحلية — Bluetooth وQR يظلان متاحين") }
        }, "attend-pairing-discovery").apply { isDaemon = true }.start()
    }

    private fun handleLanProvision(s: DatagramSocket, packet: DatagramPacket, text: String) {
        val first = text.indexOf(':', 7)
        if (first <= 7) return
        val code = text.substring(7, first).uppercase()
        val provisionText = text.substring(first + 1)
        if (targetCode.isNotBlank() && code != targetCode) return
        val provision = PairingProtocol.decodeEmployeeProvision(provisionText) ?: return
        pendingCode = code
        sendLanAck(s, packet.address, packet.port, code, provisionText, provision.pairingSecret)
    }

    private fun sendLanAck(s: DatagramSocket, address: InetAddress, port: Int, code: String, provisionText: String, secretText: String) {
        val secret = SecretCodec.decode(secretText) ?: return
        val frame = PairingAckProtocol.encode(code, secret)
        val encoded = PairingAckProtocol.toText(frame).removePrefix(PairingAckProtocol.TEXT_PREFIX)
        val ack = "${PairingAckProtocol.TEXT_PREFIX}$code:$encoded".toByteArray(Charsets.UTF_8)
        pendingLanProvision = provisionText
        pendingLanCode = code
        status("تم استلام ملف الربط عبر Wi‑Fi/Hotspot — انتظار ACK مؤكد من جهاز المحل…")
        runCatching { s.send(DatagramPacket(ack, ack.size, address, port)) }
    }

    @SuppressLint("MissingPermission")
    private fun startBleDiscovery() {
        if (!hasBlePermissions()) {
            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            activity.requestPermissions(permissions, REQUEST_SCAN)
            status("اسمح بالأجهزة القريبة لإكمال Bluetooth؛ QR وWi‑Fi/Hotspot لا ينتظران الإنترنت")
            return
        }
        val bt = adapter
        if (bt?.isEnabled != true) { status("Bluetooth مغلق — استخدم Wi‑Fi/Hotspot أو QR بدون إنترنت"); return }
        val scanner = bt.bluetoothLeScanner ?: run { status("BLE غير مدعوم — استخدم Wi‑Fi/Hotspot أو QR"); return }
        runCatching { scanner.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback) }
            .onFailure { status("تعذر بدء BLE — Wi‑Fi/Hotspot وQR يظلان متاحين") }
    }

    @SuppressLint("MissingPermission")
    private fun requestProvisionOverGatt(device: BluetoothDevice, code: String) {
        if (!running || connectingGatt || !hasBlePermissions() || mode == Mode.WIFI_HOTSPOT_ONLY) return
        if (lastGattDevice?.address != device.address || !lastGattCode.equals(code, true)) gattAttempt = 0
        lastGattDevice = device
        lastGattCode = code
        gattAttempt += 1
        connectingGatt = true
        gattServicesRequested = false
        gattAwaitingAck = false
        gattProvisionReady = ""
        status("Bluetooth وجد جهاز المحل — ربط كامل (محاولة $gattAttempt/3)…")
        gattOffset = 0
        gattBuffer.reset()
        handler.removeCallbacks(gattTimeout)
        handler.postDelayed(gattTimeout, 12_000L)

        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
                if (!running) { runCatching { g.close() }; return }
                if (statusCode == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    val mtuRequested = runCatching { g.requestMtu(247) }.getOrDefault(false)
                    handler.postDelayed({ discoverServicesOnce(g) }, if (mtuRequested) 700L else 120L)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED || statusCode != BluetoothGatt.GATT_SUCCESS) {
                    failGatt(g, "انقطع الربط عبر Bluetooth")
                }
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) { discoverServicesOnce(g) }

            override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
                if (statusCode != BluetoothGatt.GATT_SUCCESS) { failGatt(g, "تعذر اكتشاف خدمة الربط عبر Bluetooth"); return }
                val service: BluetoothGattService = g.getService(BleProtocol.SERVICE_UUID.uuid)
                    ?: run { failGatt(g, "جهاز المحل لا يعرض خدمة الربط المطلوبة"); return }
                val characteristic = service.getCharacteristic(PROVISION_CHARACTERISTIC_UUID)
                    ?: run { failGatt(g, "قناة الربط غير متاحة عبر Bluetooth"); return }
                requestChunk(g, characteristic, code, 0)
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
                if (characteristic.uuid != PROVISION_CHARACTERISTIC_UUID) return
                if (statusCode != BluetoothGatt.GATT_SUCCESS) { failGatt(g, "رفض جهاز المحل رسالة الربط عبر Bluetooth"); return }
                if (gattAwaitingAck) {
                    val provision = gattProvisionReady
                    if (provision.isBlank()) { failGatt(g, "تأكيد Bluetooth غير مكتمل"); return }
                    handler.removeCallbacks(gattTimeout)
                    gattAwaitingAck = false
                    connectingGatt = false
                    gattAttempt = 0
                    finishFound(provision, "Bluetooth مباشر • ACK")
                } else {
                    runCatching { g.readCharacteristic(characteristic) }.onFailure { failGatt(g, "تعذر قراءة ملف الربط عبر Bluetooth") }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
                handleGattChunk(g, characteristic, characteristic.value ?: ByteArray(0), statusCode, code)
            }

            override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, statusCode: Int) {
                handleGattChunk(g, characteristic, value, statusCode, code)
            }
        }
        gatt = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(activity, false, callback)
        }.getOrNull()
        if (gatt == null) { connectingGatt = false; handler.removeCallbacks(gattTimeout) }
    }

    @SuppressLint("MissingPermission")
    private fun discoverServicesOnce(g: BluetoothGatt) {
        if (!running || !connectingGatt || gattServicesRequested) return
        gattServicesRequested = true
        if (!runCatching { g.discoverServices() }.getOrDefault(false)) failGatt(g, "تعذر بدء اكتشاف خدمة Bluetooth")
    }

    @SuppressLint("MissingPermission")
    private fun requestChunk(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, code: String, offset: Int) {
        if (!running) return
        gattOffset = offset
        val command = "APGET:$code:$offset".toByteArray(Charsets.UTF_8)
        handler.removeCallbacks(gattTimeout)
        handler.postDelayed(gattTimeout, 7_000L)
        writeGatt(g, characteristic, command, "تعذر طلب ملف الربط عبر Bluetooth")
    }

    @SuppressLint("MissingPermission")
    private fun writeGatt(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, error: String) {
        val started = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeCharacteristic(characteristic, value, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                characteristic.value = value
                @Suppress("DEPRECATION")
                g.writeCharacteristic(characteristic)
            }
        }.getOrDefault(false)
        if (!started) failGatt(g, error)
    }

    @SuppressLint("MissingPermission")
    private fun handleGattChunk(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, statusCode: Int, code: String) {
        if (!running || characteristic.uuid != PROVISION_CHARACTERISTIC_UUID || gattAwaitingAck) return
        if (statusCode != BluetoothGatt.GATT_SUCCESS || value.isEmpty()) { failGatt(g, "وصل جزء غير صالح من ملف الربط عبر Bluetooth"); return }
        gattBuffer.write(value)
        val text = gattBuffer.toByteArray().toString(Charsets.UTF_8)
        val provision = PairingProtocol.decodeEmployeeProvision(text)
        if (provision != null) {
            val secret = SecretCodec.decode(provision.pairingSecret) ?: run { failGatt(g, "مفتاح الربط المستلم غير صالح"); return }
            gattProvisionReady = text
            gattAwaitingAck = true
            handler.removeCallbacks(gattTimeout)
            handler.postDelayed(gattTimeout, 6_000L)
            writeGatt(g, characteristic, PairingAckProtocol.encode(code, secret), "تعذر إرسال ACK الربط عبر Bluetooth")
            return
        }
        if (gattBuffer.size() < MAX_GATT_BUFFER) requestChunk(g, characteristic, code, gattOffset + value.size)
        else failGatt(g, "ملف الربط عبر Bluetooth أكبر من الحد الآمن")
    }

    @SuppressLint("MissingPermission")
    private fun failGatt(g: BluetoothGatt?, message: String) {
        handler.removeCallbacks(gattTimeout)
        connectingGatt = false
        gattServicesRequested = false
        gattAwaitingAck = false
        gattProvisionReady = ""
        runCatching { g?.disconnect() }; runCatching { g?.close() }
        if (g === gatt) gatt = null
        val retryDevice = lastGattDevice
        val retryCode = lastGattCode
        if (running && gattAttempt < 3 && retryDevice != null && retryCode.isNotBlank() && mode != Mode.WIFI_HOTSPOT_ONLY) {
            status("$message — إعادة المحاولة تلقائيًا دون إنترنت…")
            handler.postDelayed({ if (running && !connectingGatt) requestProvisionOverGatt(retryDevice, retryCode) }, 500L * gattAttempt.coerceAtLeast(1))
        } else status("$message — يمكنك استخدام QR أو Wi‑Fi/Hotspot مباشرة")
    }

    private fun discoveryTargets(): Set<InetAddress> {
        val result = linkedSetOf<InetAddress>()
        fun add(value: String) { runCatching { result.add(InetAddress.getByName(value)) } }
        add("255.255.255.255")
        listOf("192.168.43.1", "192.168.232.1", "192.168.137.1", "192.168.49.1", "192.168.4.1").forEach(::add)
        listOf("192.168.43.255", "192.168.232.255", "192.168.137.255", "192.168.49.255", "192.168.4.255").forEach(::add)
        runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { network ->
                if (network.isUp && !network.isLoopback) network.interfaceAddresses.forEach { item ->
                    (item.broadcast as? Inet4Address)?.let { result.add(it) }
                    val local = item.address as? Inet4Address
                    if (local != null && !local.isLoopbackAddress) {
                        val bytes = local.address.clone()
                        bytes[3] = 0xff.toByte(); runCatching { result.add(InetAddress.getByAddress(bytes)) }
                        bytes[3] = 1; runCatching { result.add(InetAddress.getByAddress(bytes)) }
                    }
                }
            }
        }
        return result
    }

    private fun finishFound(value: String, channel: String) {
        if (!running) return
        running = false
        handler.removeCallbacks(gattTimeout)
        activity.runOnUiThread { stop(); found(value, channel) }
    }

    fun resumeAfterPermission() { val code = targetCode; val selected = mode; start(code, selected) }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        handler.removeCallbacks(gattTimeout)
        runCatching { socket?.close() }; socket = null
        if (hasBlePermissions()) runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCallback) }
        runCatching { gatt?.disconnect() }; runCatching { gatt?.close() }; gatt = null
        connectingGatt = false; gattOffset = 0; gattBuffer.reset(); gattServicesRequested = false
        gattAwaitingAck = false; gattProvisionReady = ""
        lastGattDevice = null; lastGattCode = ""; gattAttempt = 0
        pendingCode = ""; targetCode = ""; pendingLanProvision = ""; pendingLanCode = ""
    }
}
