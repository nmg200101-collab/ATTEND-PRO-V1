package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import com.attendpro.core.EmployeeIdentityStore

class OfflineGeoMonitor(
    private val context: Context,
    private val identity: EmployeeIdentityStore,
    private val onEntered: (distanceMeters: Int, accuracyMeters: Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val manager = context.getSystemService(LocationManager::class.java)
    private var running = false
    private var inside: Boolean? = null
    private var lastArrivalAlertAt = 0L

    private fun hasPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (running || !identity.geoArrivalAlertsEnabled || !identity.isTrustedStoreGpsConfigured || !hasPermission()) return
        val lm = manager ?: return
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) { onStatus("GPS جاهز لكن خدمات الموقع متوقفة"); return }
        running = true
        providers.forEach { provider ->
            runCatching { lm.requestLocationUpdates(provider, 45_000L, 20f, listener, Looper.getMainLooper()) }
        }
        onStatus("مراقبة نطاق المحل عبر GPS تعمل محليًا بدون إنترنت")
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        runCatching { manager?.removeUpdates(listener) }
    }

    fun isRunning(): Boolean = running

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (!running || !identity.isTrustedStoreGpsConfigured) return
            if (System.currentTimeMillis() - location.time > 5 * 60_000L) return
            if (isMock(location)) { onStatus("تم تجاهل موقع تجريبي/مزيف"); return }
            if (location.hasAccuracy() && location.accuracy > 250f) return
            val target = Location("ATTEND_PRO_STORE").apply {
                latitude = identity.trustedStoreLatitude
                longitude = identity.trustedStoreLongitude
            }
            val distance = location.distanceTo(target)
            val allowance = if (location.hasAccuracy()) location.accuracy.coerceIn(0f, 100f) else 0f
            val nowInside = distance <= identity.trustedStoreGpsRadius + allowance
            identity.lastGpsDistanceMeters = distance.toInt()
            if (nowInside) identity.lastGpsInsideAt = System.currentTimeMillis()
            if (nowInside && inside != true) {
                val now = System.currentTimeMillis()
                if (now - lastArrivalAlertAt > 10 * 60_000L) {
                    lastArrivalAlertAt = now
                    onEntered(distance.toInt(), location.accuracy.toInt().coerceAtLeast(0))
                }
            }
            inside = nowInside
        }
        @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
        override fun onProviderEnabled(provider: String) = Unit
        override fun onProviderDisabled(provider: String) = Unit
    }

    private fun isMock(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider
}
