package com.attendpro.store

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.AttendanceAction
import com.attendpro.core.BleDirectProtocol
import java.security.SecureRandom
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap

/** Store-side authenticated GATT link. A session becomes connected only after signed ACK. */
class BleDirectLinkClient(
    private val context: Context,
    private val onState: (employeeId: String, connected: Boolean, message: String) -> Unit
) {
    private enum class Kind { HEARTBEAT, CONFIG, CHALLENGE }
    private data class Operation(val bytes: ByteArray, val kind: Kind, val pingNonce: Int? = null)
    private data class Session(
        val employeeId: String,
        val secret: ByteArray,
        val deviceAddress: String,
        var config: BleDirectProtocol.Config,
        var gatt: BluetoothGatt? = null,
        var command: BluetoothGattCharacteristic? = null,
        var transportConnected: Boolean = false,
        var authenticated: Boolean = false,
        var lastAdvertisementAt: Long = 0L,
        var lastAckAt: Long = 0L,
        var lastHeartbeatSentAt: Long = 0L,
        var writing: Boolean = false,
        var readingAck: Boolean = false,
        var activeOperation: Operation? = null,
        var awaitingPingNonce: Int? = null,
        val queue: ArrayDeque<Operation> = ArrayDeque()
    )

    private val sessions = ConcurrentHashMap<String, Session>()
    private val handler = Handler(Looper.getMainLooper())
    private val random = SecureRandom()
    private val heartbeatTask = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            sessions.values.toList().forEach { s ->
                if (s.authenticated && now - s.lastAckAt > ACK_STALE_MILLIS) {
                    failAndReconnect(s, "انقطع ACK الحقيقي عبر Bluetooth — جارٍ إعادة الاكتشاف")
                } else if (s.transportConnected && s.command != null && !s.writing && !s.readingAck && now - s.lastHeartbeatSentAt >= HEARTBEAT_INTERVAL_MILLIS) {
                    enqueueHeartbeat(s)
                }
            }
            handler.postDelayed(this, HEARTBEAT_TICK_MILLIS)
        }
    }

    init { handler.post(heartbeatTask) }

    private fun hasPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun touch(employeeId: String, secret: ByteArray, device: BluetoothDevice, config: BleDirectProtocol.Config) {
        if (employeeId.isBlank() || secret.isEmpty() || !hasPermission()) return
        val now = System.currentTimeMillis()
        val existing = sessions[employeeId]
        if (existing != null && existing.deviceAddress == device.address && existing.gatt != null) {
            existing.lastAdvertisementAt = now
            existing.config = config
            return
        }
        existing?.let { closeSession(it, notify = false) }
        val session = Session(employeeId, secret.copyOf(), device.address, config, lastAdvertisementAt = now)
        sessions[employeeId] = session
        session.gatt = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) device.connectGatt(context, false, callbackFor(session), BluetoothDevice.TRANSPORT_LE)
            else @Suppress("DEPRECATION") device.connectGatt(context, false, callbackFor(session))
        }.getOrNull()
        if (session.gatt == null) onState(employeeId, false, "تعذر فتح Bluetooth مباشر — يستمر BLE/Wi‑Fi")
    }

    fun isConnected(employeeId: String): Boolean = sessions[employeeId]?.let {
        it.authenticated && it.command != null && System.currentTimeMillis() - it.lastAckAt <= ACK_STALE_MILLIS
    } == true

    fun lastAckAt(employeeId: String): Long = sessions[employeeId]?.lastAckAt ?: 0L

    fun sendChallenge(employeeId: String, method: AttendanceMethod, expiresAt: Long = System.currentTimeMillis() + 60_000L, requestToken: Int = SecureRandom().nextInt(), action: AttendanceAction = AttendanceAction.CHECK_IN): Boolean {
        val s = sessions[employeeId] ?: return false
        if (!isConnected(employeeId)) return false
        enqueue(s, Operation(BleDirectProtocol.encodeChallenge(s.secret, method, expiresAt, requestToken, action), Kind.CHALLENGE))
        return true
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        handler.removeCallbacks(heartbeatTask)
        sessions.values.toList().forEach { closeSession(it, notify = false) }
        sessions.clear()
    }

    private fun callbackFor(session: Session) = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                session.transportConnected = true
                session.authenticated = false
                runCatching { gatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH) }
                val discoveryStarted = runCatching { gatt.discoverServices() }.getOrDefault(false)
                if (!discoveryStarted) {
                    failAndReconnect(session, "تعذر اكتشاف خدمات Bluetooth — جارٍ إعادة الاكتشاف")
                    return
                }
                onState(session.employeeId, false, "تم فتح Bluetooth — جارٍ التحقق من ACK")
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                failAndReconnect(session, "انقطع Bluetooth المباشر — جارٍ إعادة الاكتشاف")
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                failAndReconnect(session, "فشل اكتشاف خدمات Bluetooth — جارٍ إعادة الاكتشاف")
                return
            }
            val service: BluetoothGattService = gatt.getService(BleDirectProtocol.SERVICE_UUID) ?: run {
                failAndReconnect(session, "خدمة ATTEND-PRO غير متاحة على الهاتف — جارٍ إعادة الاكتشاف")
                return
            }
            session.command = service.getCharacteristic(BleDirectProtocol.COMMAND_UUID) ?: run {
                failAndReconnect(session, "قناة ATTEND-PRO المباشرة غير متاحة — جارٍ إعادة الاكتشاف")
                return
            }
            enqueueHeartbeat(session)
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (characteristic.uuid != BleDirectProtocol.COMMAND_UUID) return
            val op = session.activeOperation
            session.writing = false
            session.activeOperation = null
            if (status != BluetoothGatt.GATT_SUCCESS) {
                if (op?.kind == Kind.HEARTBEAT) failAndReconnect(session, "فشل heartbeat عبر Bluetooth — يستمر BLE/Wi‑Fi")
                else { session.queue.clear(); onState(session.employeeId, isConnected(session.employeeId), "تعذر إرسال الطلب عبر Bluetooth المباشر") }
                return
            }
            when (op?.kind) {
                Kind.HEARTBEAT -> {
                    session.awaitingPingNonce = op.pingNonce
                    session.readingAck = true
                    val started = runCatching {
                        @Suppress("DEPRECATION")
                        gatt.readCharacteristic(characteristic)
                    }.getOrDefault(false)
                    if (!started) failAndReconnect(session, "تعذر قراءة ACK عبر Bluetooth")
                }
                Kind.CONFIG, Kind.CHALLENGE, null -> drain(session)
            }
        }

        @Deprecated("Deprecated by Android 13 callback API")
        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            @Suppress("DEPRECATION")
            processAck(session, characteristic, characteristic.value ?: ByteArray(0), status)
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            processAck(session, characteristic, value, status)
        }
    }

    private fun processAck(session: Session, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
        if (characteristic.uuid != BleDirectProtocol.COMMAND_UUID) return
        session.readingAck = false
        val nonce = session.awaitingPingNonce
        session.awaitingPingNonce = null
        if (status != BluetoothGatt.GATT_SUCCESS || nonce == null || !BleDirectProtocol.verifyAck(value, session.secret, nonce)) {
            failAndReconnect(session, "ACK Bluetooth غير صالح أو منقطع — لن يُعرض الموظف كمتصل")
            return
        }
        val wasAuthenticated = session.authenticated
        session.authenticated = true
        session.lastAckAt = System.currentTimeMillis()
        onState(session.employeeId, true, "✓ Bluetooth BLE مؤكد عبر Heartbeat/ACK")
        if (!wasAuthenticated) enqueue(session, Operation(BleDirectProtocol.encodeConfig(session.config), Kind.CONFIG))
        drain(session)
    }

    private fun enqueueHeartbeat(session: Session) {
        if (!session.transportConnected || session.command == null || session.readingAck || session.writing) return
        val nonce = random.nextInt()
        session.lastHeartbeatSentAt = System.currentTimeMillis()
        enqueue(session, Operation(BleDirectProtocol.encodePing(session.secret, nonce = nonce), Kind.HEARTBEAT, nonce))
    }

    private fun enqueue(session: Session, op: Operation) {
        synchronized(session) {
            // Never accumulate stale heartbeats behind real commands.
            if (op.kind == Kind.HEARTBEAT && session.queue.any { it.kind == Kind.HEARTBEAT }) return
            session.queue.addLast(op)
        }
        drain(session)
    }

    @SuppressLint("MissingPermission")
    private fun drain(session: Session) {
        val c = session.command ?: return
        val gatt = session.gatt ?: return
        val op: Operation = synchronized(session) {
            if (session.writing || session.readingAck || session.queue.isEmpty()) return

            // Authentication always has priority.  A CONFIG/CHALLENGE is never allowed to
            // sit in front of the heartbeat that must authenticate the GATT session.
            if (!session.authenticated && session.queue.first().kind != Kind.HEARTBEAT) {
                val pendingHeartbeat = session.queue.firstOrNull { it.kind == Kind.HEARTBEAT }
                if (pendingHeartbeat != null) {
                    session.queue.remove(pendingHeartbeat)
                    session.queue.addFirst(pendingHeartbeat)
                } else {
                    val nonce = random.nextInt()
                    session.lastHeartbeatSentAt = System.currentTimeMillis()
                    session.queue.addFirst(Operation(BleDirectProtocol.encodePing(session.secret, nonce = nonce), Kind.HEARTBEAT, nonce))
                }
            }

            session.queue.removeFirst().also {
                session.activeOperation = it
                session.writing = true
            }
        }

        // Do not hold the session monitor while entering the Android Bluetooth stack; callbacks
        // may arrive immediately on some OEM implementations.
        val started = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeCharacteristic(c, op.bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION") c.value = op.bytes
                @Suppress("DEPRECATION") gatt.writeCharacteristic(c)
            }
        }.getOrDefault(false)
        if (!started) {
            synchronized(session) {
                session.writing = false
                session.activeOperation = null
            }
            if (op.kind == Kind.HEARTBEAT) failAndReconnect(session, "تعذر بدء Heartbeat Bluetooth")
            else onState(session.employeeId, isConnected(session.employeeId), "تعذر بدء إرسال Bluetooth مباشر")
        }
    }

    private fun failAndReconnect(session: Session, message: String) {
        val wasCurrent = sessions[session.employeeId] === session
        closeSession(session, notify = false)
        if (wasCurrent) sessions.remove(session.employeeId)
        onState(session.employeeId, false, message)
    }

    @SuppressLint("MissingPermission")
    private fun closeSession(session: Session, notify: Boolean) {
        session.authenticated = false; session.transportConnected = false; session.command = null
        session.writing = false; session.readingAck = false; session.queue.clear()
        runCatching { session.gatt?.disconnect() }; runCatching { session.gatt?.close() }; session.gatt = null
        if (notify) onState(session.employeeId, false, "Bluetooth غير متصل")
    }

    companion object {
        private const val HEARTBEAT_INTERVAL_MILLIS = 4_000L
        private const val HEARTBEAT_TICK_MILLIS = 2_000L
        private const val ACK_STALE_MILLIS = 11_000L
    }
}
