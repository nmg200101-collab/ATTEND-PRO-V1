package com.attendpro.store

import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import kotlin.concurrent.thread

class NetworkPresenceListener(
    private val onPayload: (BleProtocol.Payload, Int) -> ByteArray?,
    private val onStatus: (String) -> Unit
) {
    companion object { const val PORT = 47717 }

    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true
        worker = thread(name = "attend-lan-listener", isDaemon = true) {
            runCatching {
                DatagramSocket(null).also {
                    socket = it
                    it.reuseAddress = true
                    it.broadcast = true
                    it.soTimeout = 1_200
                    it.bind(InetSocketAddress(PORT))
                }.use { s ->
                    onStatus("اكتشاف Wi‑Fi/Hotspot المحلي يعمل بدون إنترنت")
                    val buffer = ByteArray(256)
                    while (running) {
                        try {
                            val packet = DatagramPacket(buffer, buffer.size)
                            s.receive(packet)
                            if (packet.length < 14) continue
                            val data = packet.data
                            val off = packet.offset
                            if (data[off] != 0x41.toByte() || data[off + 1] != 0x50.toByte() || data[off + 2] != 0x4c.toByte() || data[off + 3] != 0x31.toByte()) continue
                            val raw = data.copyOfRange(off + 4, off + 14)
                            val parsed = BleProtocol.parse(raw) ?: continue
                            val ack = onPayload(parsed, -45)
                            if (ack != null) {
                                runCatching { s.send(DatagramPacket(ack, ack.size, packet.address, packet.port)) }
                            }
                        } catch (_: SocketTimeoutException) {
                        } catch (_: Exception) {
                        }
                    }
                }
            }.onFailure {
                if (running) onStatus("تعذر استقبال Wi‑Fi/Hotspot المحلي؛ BLE يستمر بالعمل")
            }
        }
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        socket = null
        worker?.interrupt()
        worker = null
    }

    fun isRunning(): Boolean = running
}
