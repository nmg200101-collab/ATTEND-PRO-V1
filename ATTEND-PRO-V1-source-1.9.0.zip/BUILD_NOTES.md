ATTEND PRO 1.9.0 — BUILD NOTES
================================
Android:
- store-app: versionCode 20 / versionName 1.9.0
- employee-app: versionCode 20 / versionName 1.9.0
- compileSdk/targetSdk: 35
- minSdk: 26
- JDK: 17

Central server:
- Node.js >= 22
- No npm dependencies
- Requires ATTEND_PRO_OWNER_API_KEY and ATTEND_PRO_DATA_KEY environment secrets
- Must be published behind HTTPS

Security additions:
- Android Keystore AES-GCM vault for central store access token, activation poll secret, server-owner API key, and report receiver secret migration.
- Central access tokens are random 256-bit values; server stores only SHA-256 token hashes.
- Central store requests are bound to a non-exportable Android Keystore P-256 device key with ECDSA request signatures, timestamps, body hashes, and replay nonces.
- Activation poll secrets and report receiver secrets use scrypt hashes server-side.
- Activation tokens waiting for device retrieval are AES-GCM encrypted at rest using the server-only data key.
- Report packages remain receiver-specific AES-GCM encrypted before server upload.
- Separate server admin key; do not reuse the local in-app owner credential.

Validation performed before packaging:
- Node server syntax check.
- End-to-end local API integration test: activation request -> owner approval -> signed device activation -> signed attendance sync -> receiver registration -> encrypted report queue -> receiver inbox -> remote dashboard/report -> receipt confirmation -> central suspension blocks store access.
- Kotlin source syntax preflight (no parser/syntax errors; full Android compile remains GitHub Actions verification).
