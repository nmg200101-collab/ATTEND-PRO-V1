package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.AgentRecord
import com.attendpro.core.ManagedStoreRecord
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairingProtocol
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SystemSettingsActivity : Activity() {
    private lateinit var repo: StoreRepository
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        repo.ensureCurrentStoreInManagement()
        showGateway()
    }

    private fun baseRoot(title: String, subtitle: String): LinearLayout {
        window.statusBarColor = p.bg
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@SystemSettingsActivity, 18), UiKit.dp(this@SystemSettingsActivity, 20), UiKit.dp(this@SystemSettingsActivity, 18), UiKit.dp(this@SystemSettingsActivity, 34))
            setBackgroundColor(p.bg)
            addView(UiKit.title(this@SystemSettingsActivity, p, title, 25f).apply { gravity = Gravity.CENTER })
            addView(UiKit.subtitle(this@SystemSettingsActivity, p, subtitle).apply {
                gravity = Gravity.CENTER
                setPadding(0, UiKit.dp(this@SystemSettingsActivity, 4), 0, UiKit.dp(this@SystemSettingsActivity, 18))
            })
        }
    }

    private fun display(root: LinearLayout) {
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun showGateway() {
        val root = baseRoot("إعدادات النظام", "منطقة الإدارة العليا — منفصلة عن التشغيل اليومي")

        val owner = UiKit.card(this, p)
        owner.addView(UiKit.sectionLabel(this, p, "مدير النظام"))
        owner.addView(UiKit.title(this, p, "المالك", 21f))
        owner.addView(UiKit.subtitle(this, p, "تحكم كامل في الوكلاء والمحلات والصلاحيات وإعدادات التطبيق. الدخول برمز المالك فقط."))
        owner.addView(UiKit.button(this, p, "دخول قسم المالك").apply { setOnClickListener { ownerLogin() } })
        root.addView(owner)

        val agent = UiKit.card(this, p)
        agent.addView(UiKit.sectionLabel(this, p, "القسم الثاني"))
        agent.addView(UiKit.title(this, p, "الوكيل", 21f))
        agent.addView(UiKit.subtitle(this, p, "يدخل الوكيل بالرمز الذي يمنحه المالك، ويستطيع تجهيز طلب محل جديد فقط وفق الصلاحيات المحددة."))
        agent.addView(UiKit.button(this, p, "دخول قسم الوكيل", false).apply { setOnClickListener { agentLogin() } })
        root.addView(agent)

        val note = UiKit.card(this, p, 13)
        note.addView(UiKit.subtitle(this, p, "رمز المالك لا يظهر داخل الواجهة ولا يُحفظ كنص صريح؛ يتم التحقق منه محليًا بصورة مشفرة، ويمكن تغييره من لوحة المالك."))
        root.addView(note)
        root.addView(UiKit.button(this, p, "رجوع", false).apply { setOnClickListener { finish() } })
        display(root)
    }

    private fun ownerLogin() {
        if (repo.ownerLockUntil > System.currentTimeMillis()) {
            toastDialog("حماية الدخول", "تم إيقاف محاولات دخول المالك مؤقتًا بعد محاولات خاطئة. حاول بعد دقيقة.")
            return
        }
        val input = UiKit.field(this, p, "رمز المالك").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("دخول المالك").setView(input).setPositiveButton("دخول") { _, _ ->
            if (repo.verifyOwnerCode(input.text.toString())) showOwnerDashboard()
            else toastDialog("تعذر الدخول", "رمز المالك غير صحيح.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showOwnerDashboard() {
        repo.ensureCurrentStoreInManagement()
        val root = baseRoot("لوحة المالك", "مدير النظام الرئيسي • صلاحية كاملة")

        val summary = UiKit.card(this, p)
        summary.addView(UiKit.sectionLabel(this, p, "ملخص الإدارة"))
        val activeAgents = repo.agents().count { it.active }
        val stores = repo.managedStores()
        val pending = stores.count { it.status == "PENDING" }
        summary.addView(UiKit.title(this, p, "الوكلاء $activeAgents   •   المحلات ${stores.size}", 18f))
        summary.addView(UiKit.subtitle(this, p, "طلبات بانتظار الموافقة: $pending   •   عمليات هذا الجهاز: ${repo.events().size}"))
        root.addView(summary)

        val access = UiKit.card(this, p)
        access.addView(UiKit.sectionLabel(this, p, "الصلاحيات والأمان"))
        access.addView(UiKit.button(this, p, "صلاحية مدير النظام (المالك)", false).apply { setOnClickListener { showOwnerAuthority() } })
        access.addView(UiKit.button(this, p, "تغيير رمز المالك", false).apply { setOnClickListener { changeOwnerCode() } })
        root.addView(access)

        val network = UiKit.card(this, p)
        network.addView(UiKit.sectionLabel(this, p, "الإدارة المركزية"))
        network.addView(UiKit.button(this, p, "إدارة الوكلاء").apply { setOnClickListener { showAgents() } })
        network.addView(UiKit.button(this, p, "إدارة المحلات ومتابعة الاستخدام", false).apply { setOnClickListener { showManagedStores() } })
        root.addView(network)

        val app = UiKit.card(this, p)
        app.addView(UiKit.sectionLabel(this, p, "التحكم بالتطبيق"))
        app.addView(UiKit.button(this, p, "إعدادات التطبيق", false).apply { setOnClickListener { showAppSettings() } })
        app.addView(UiKit.button(this, p, "معلومات المحل وإعداداته", false).apply { setOnClickListener { showStoreSettings() } })
        app.addView(UiKit.button(this, p, "الدوام والسماح", false).apply { setOnClickListener { showShiftSettings() } })
        app.addView(UiKit.button(this, p, "قارئ البصمة الخارجي", false).apply { setOnClickListener { showFingerprintSettings() } })
        app.addView(UiKit.button(this, p, "الخادم والتفعيل والمزامنة", false).apply { setOnClickListener { showSyncSettings() } })
        app.addView(UiKit.button(this, p, "فحص جاهزية النظام", false).apply { setOnClickListener { runHealthCheck() } })
        root.addView(app)

        root.addView(UiKit.button(this, p, "خروج من قسم المالك", false).apply { setOnClickListener { showGateway() } })
        display(root)
    }

    private fun showOwnerAuthority() {
        toastDialog("صلاحية مدير النظام — المالك", "• إضافة الوكلاء وإيقافهم وتغيير رموزهم\n• إضافة المحلات واعتماد طلبات الوكلاء وتعليقها\n• متابعة بيانات الاستخدام المتاحة من المزامنة\n• التحكم بطرق الحضور وBLE وPIN وتطبيق الموظف\n• التحكم بالدوام والفروع وأجهزة البصمة والخادم\n• تغيير رمز المالك\n\nلا يستطيع الوكيل تغيير صلاحيات المالك أو اعتماد نفسه.")
    }

    private fun changeOwnerCode() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val a = UiKit.field(this, p, "رمز مالك جديد — 8 أحرف/أرقام على الأقل").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val b = UiKit.field(this, p, "تأكيد الرمز الجديد").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(a); box.addView(b)
        AlertDialog.Builder(this).setTitle("تغيير رمز المالك").setView(box).setPositiveButton("حفظ") { _, _ ->
            val code = a.text.toString().trim()
            if (code.length < 8 || code != b.text.toString().trim()) toastDialog("لم يتم التغيير", "يجب أن يتطابق الرمزان وألا يقل الرمز عن 8 أحرف/أرقام.")
            else { repo.setOwnerCode(code); toastDialog("تم", "تم تغيير رمز المالك بنجاح. استخدم الرمز الجديد من الآن.") }
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showAgents() {
        val agents = repo.agents()
        val labels = mutableListOf("＋ إضافة وكيل جديد")
        labels.addAll(agents.map { "${if (it.active) "●" else "○"} ${it.name}   •   ${it.agentId.takeLast(6)}" })
        AlertDialog.Builder(this).setTitle("إدارة الوكلاء (${agents.size})").setItems(labels.toTypedArray()) { _, which ->
            if (which == 0) addAgent() else agentDetails(agents[which - 1])
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun addAgent() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val name = UiKit.field(this, p, "اسم الوكيل")
        val custom = UiKit.field(this, p, "رمز مخصص — اختياري، اتركه فارغًا للتوليد التلقائي")
        box.addView(name); box.addView(custom)
        AlertDialog.Builder(this).setTitle("إضافة وكيل").setView(box).setPositiveButton("إنشاء") { _, _ ->
            val n = name.text.toString().trim()
            if (n.isBlank()) { toastDialog("تنبيه", "اكتب اسم الوكيل."); return@setPositiveButton }
            val code = custom.text.toString().trim().ifBlank { generateAgentCode() }
            if (code.length < 6) { toastDialog("تنبيه", "رمز الوكيل يجب ألا يقل عن 6 أحرف/أرقام."); return@setPositiveButton }
            val record = AgentRecord("AG-${UUID.randomUUID()}", n, PairingProtocol.pinHash(code), true)
            repo.upsertAgent(record)
            showNewAgentCode(record, code)
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun generateAgentCode(): String = "AP-" + UUID.randomUUID().toString().replace("-", "").take(8).uppercase(Locale.US)

    private fun showNewAgentCode(agent: AgentRecord, code: String) {
        AlertDialog.Builder(this).setTitle("تم إنشاء الوكيل").setMessage("الوكيل: ${agent.name}\n\nرمز الوكيل:\n$code\n\nيظهر الرمز الكامل الآن فقط. أرسله للوكيل واحفظه في مكان آمن.")
            .setPositiveButton("نسخ الرمز") { _, _ -> copyText(code) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun agentDetails(agent: AgentRecord) {
        val assigned = repo.managedStores().count { it.agentId == agent.agentId }
        val items = arrayOf(
            "الحالة: ${if (agent.active) "نشط" else "موقوف"}",
            "المحلات المرتبطة: $assigned",
            if (agent.active) "إيقاف الوكيل" else "إعادة تفعيل الوكيل",
            "إنشاء رمز جديد للوكيل",
            "حذف الوكيل"
        )
        AlertDialog.Builder(this).setTitle(agent.name).setItems(items) { _, which ->
            when (which) {
                2 -> { repo.upsertAgent(agent.copy(active = !agent.active)); showAgents() }
                3 -> {
                    val code = generateAgentCode(); val updated = agent.copy(codeHash = PairingProtocol.pinHash(code), active = true)
                    repo.upsertAgent(updated); showNewAgentCode(updated, code)
                }
                4 -> AlertDialog.Builder(this).setTitle("حذف الوكيل؟").setMessage("لن تُحذف سجلات المحلات، لكن سيُحذف حساب الوكيل.").setPositiveButton("حذف") { _, _ -> repo.removeAgent(agent.agentId); showAgents() }.setNegativeButton("إلغاء", null).show()
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun agentLogin() {
        val code = UiKit.field(this, p, "رمز الوكيل").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("دخول الوكيل").setView(code).setPositiveButton("دخول") { _, _ ->
            val agent = repo.findAgentByCode(code.text.toString().trim())
            if (agent == null) toastDialog("تعذر الدخول", "رمز الوكيل غير صحيح أو أن الوكيل موقوف.") else showAgentDashboard(agent)
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showAgentDashboard(agent: AgentRecord) {
        val root = baseRoot("قسم الوكيل", "${agent.name} • صلاحيات محدودة بموافقة المالك")
        val info = UiKit.card(this, p)
        info.addView(UiKit.title(this, p, agent.name, 20f))
        info.addView(UiKit.subtitle(this, p, "يمكنك تجهيز طلب محل جديد ومتابعة المحلات التابعة لك. الاعتماد النهائي بيد المالك."))
        root.addView(info)
        val stores = repo.managedStores().filter { it.agentId == agent.agentId }
        val actions = UiKit.card(this, p)
        actions.addView(UiKit.button(this, p, "إضافة طلب محل جديد").apply { setOnClickListener { agentAddStore(agent) } })
        actions.addView(UiKit.button(this, p, "محلاتي (${stores.size})", false).apply { setOnClickListener { showAgentStores(agent) } })
        root.addView(actions)
        root.addView(UiKit.button(this, p, "خروج", false).apply { setOnClickListener { showGateway() } })
        display(root)
    }

    private fun agentAddStore(agent: AgentRecord) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val name = UiKit.field(this, p, "اسم المحل")
        val branch = UiKit.field(this, p, "رمز الفرع").apply { setText("MAIN") }
        box.addView(name); box.addView(branch)
        AlertDialog.Builder(this).setTitle("طلب محل جديد").setView(box).setPositiveButton("إرسال للمالك") { _, _ ->
            val n = name.text.toString().trim()
            if (n.isBlank()) { toastDialog("تنبيه", "اسم المحل مطلوب."); return@setPositiveButton }
            repo.upsertManagedStore(ManagedStoreRecord("REQ-${UUID.randomUUID()}", n, branch.text.toString().trim().ifBlank { "MAIN" }, agent.agentId, "PENDING"))
            toastDialog("تم", "تم إنشاء طلب المحل. حالته: بانتظار موافقة المالك.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showAgentStores(agent: AgentRecord) {
        val stores = repo.managedStores().filter { it.agentId == agent.agentId }
        val text = if (stores.isEmpty()) "لا توجد محلات بعد" else stores.joinToString("\n\n") { "• ${it.name} / ${it.branchId}\nالحالة: ${storeStatusAr(it.status)}" }
        toastDialog("محلات ${agent.name}", text)
    }

    private fun showManagedStores() {
        repo.ensureCurrentStoreInManagement()
        val stores = repo.managedStores()
        val labels = mutableListOf("＋ إضافة محل بواسطة المالك")
        labels.addAll(stores.map { "${statusDot(it.status)} ${it.name} • ${it.branchId} • ${storeStatusAr(it.status)}" })
        AlertDialog.Builder(this).setTitle("إدارة المحلات (${stores.size})").setItems(labels.toTypedArray()) { _, which ->
            if (which == 0) ownerAddStore() else managedStoreDetails(stores[which - 1])
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun ownerAddStore() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val name = UiKit.field(this, p, "اسم المحل")
        val branch = UiKit.field(this, p, "رمز الفرع").apply { setText("MAIN") }
        box.addView(name); box.addView(branch)
        AlertDialog.Builder(this).setTitle("إضافة محل").setView(box).setPositiveButton("إضافة واعتماد") { _, _ ->
            val n = name.text.toString().trim(); if (n.isBlank()) return@setPositiveButton
            repo.upsertManagedStore(ManagedStoreRecord("STORE-${UUID.randomUUID()}", n, branch.text.toString().trim().ifBlank { "MAIN" }, "", "APPROVED"))
            showManagedStores()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun managedStoreDetails(store: ManagedStoreRecord) {
        val agent = repo.agents().firstOrNull { it.agentId == store.agentId }?.name ?: if (store.agentId.isBlank()) "المالك" else "وكيل غير موجود"
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val last = if (store.lastSeenAt > 0) fmt.format(Date(store.lastSeenAt)) else "لم تصل مزامنة استخدام بعد"
        val items = mutableListOf(
            "الوكيل/المنشئ: $agent",
            "الحالة: ${storeStatusAr(store.status)}",
            "آخر استخدام معروف: $last",
            "عدد العمليات المعروف: ${store.usageCount}"
        )
        if (store.status == "PENDING") items.add("✓ الموافقة على المحل")
        if (store.status == "APPROVED") items.add("تعليق المحل")
        if (store.status == "SUSPENDED") items.add("إعادة تفعيل المحل")
        items.add("حذف سجل المحل")
        AlertDialog.Builder(this).setTitle(store.name).setItems(items.toTypedArray()) { _, which ->
            val selected = items[which]
            when {
                selected.startsWith("✓") -> { repo.upsertManagedStore(store.copy(status = "APPROVED")); showManagedStores() }
                selected == "تعليق المحل" -> { repo.upsertManagedStore(store.copy(status = "SUSPENDED")); showManagedStores() }
                selected == "إعادة تفعيل المحل" -> { repo.upsertManagedStore(store.copy(status = "APPROVED")); showManagedStores() }
                selected == "حذف سجل المحل" -> { repo.removeManagedStore(store.managedStoreId); showManagedStores() }
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun showAppSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val auto = CheckBox(this).apply { text = "تشغيل BLE تلقائيًا"; setTextColor(p.text); isChecked = repo.autoScan }
        val companion = CheckBox(this).apply { text = "السماح بتطبيق الموظف كميزة إضافية"; setTextColor(p.text); isChecked = repo.allowEmployeeCompanion }
        val pin = CheckBox(this).apply { text = "السماح بـ PIN كطريقة احتياطية"; setTextColor(p.text); isChecked = repo.allowPinFallback }
        val bio = CheckBox(this).apply { text = "اشتراط بصمة/وجه الهاتف عند حضور الموظف عبر جواله"; setTextColor(p.text); isChecked = repo.requirePhoneBiometric }
        listOf(auto, companion, pin, bio).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("إعدادات التطبيق").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.autoScan = auto.isChecked; repo.allowEmployeeCompanion = companion.isChecked; repo.allowPinFallback = pin.isChecked; repo.requirePhoneBiometric = bio.isChecked
            toastDialog("تم", "تم حفظ إعدادات التطبيق.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showStoreSettings() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)
        val name = UiKit.field(this, p, "اسم المحل").apply { setText(repo.storeName) }
        val branch = UiKit.field(this, p, "رمز الفرع").apply { setText(repo.branchId) }
        val phone = UiKit.field(this, p, "هاتف المحل - اختياري").apply { setText(repo.storePhone) }
        val address = UiKit.field(this, p, "العنوان - اختياري").apply { setText(repo.storeAddress) }
        val manager = UiKit.field(this, p, "اسم مدير المحل - اختياري").apply { setText(repo.storeManagerName) }
        val commercial = UiKit.field(this, p, "السجل / المعرف التجاري - اختياري").apply { setText(repo.storeCommercialId) }
        val notes = UiKit.field(this, p, "ملاحظات المحل - اختياري").apply { setText(repo.storeNotes); minLines = 2 }
        listOf(name, branch, phone, address, manager, commercial, notes).forEach { box.addView(it) }

        val dialog = AlertDialog.Builder(this).setTitle("معلومات المحل وإعداداته").setView(scroll)
            .setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val storeName = name.text.toString().trim()
                val branchId = branch.text.toString().trim()
                if (storeName.isBlank() || branchId.isBlank()) {
                    name.error = if (storeName.isBlank()) "اسم المحل مطلوب" else null
                    branch.error = if (branchId.isBlank()) "رمز الفرع مطلوب" else null
                    return@setOnClickListener
                }
                repo.storeName = storeName
                repo.branchId = branchId
                repo.storePhone = phone.text.toString()
                repo.storeAddress = address.text.toString()
                repo.storeManagerName = manager.text.toString()
                repo.storeCommercialId = commercial.text.toString()
                repo.storeNotes = notes.text.toString()
                repo.ensureCurrentStoreInManagement()
                dialog.dismiss()
                toastDialog("تم", "تم حفظ معلومات المحل بنجاح.")
            }
        }
        dialog.show()
    }

    private fun showShiftSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val hour = UiKit.field(this, p, "ساعة البداية 0-23", true).apply { setText(repo.shiftHour.toString()) }
        val minute = UiKit.field(this, p, "الدقيقة", true).apply { setText(repo.shiftMinute.toString()) }
        val grace = UiKit.field(this, p, "دقائق السماح", true).apply { setText(repo.graceMinutes.toString()) }
        listOf(hour, minute, grace).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("الدوام والسماح").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.shiftHour = hour.text.toString().toIntOrNull() ?: 8; repo.shiftMinute = minute.text.toString().toIntOrNull() ?: 0; repo.graceMinutes = grace.text.toString().toIntOrNull() ?: 10
            toastDialog("تم", "تم تحديث إعداد الدوام.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showFingerprintSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val host = UiKit.field(this, p, "IP جهاز البصمة").apply { setText(repo.fingerprintHost) }
        val port = UiKit.field(this, p, "Port مثل 4370", true).apply { setText(repo.fingerprintPort.toString()) }
        box.addView(host); box.addView(port)
        AlertDialog.Builder(this).setTitle("قارئ البصمة الخارجي").setView(box).setPositiveButton("حفظ واختبار") { _, _ ->
            repo.fingerprintHost = host.text.toString(); repo.fingerprintPort = port.text.toString().toIntOrNull() ?: 4370
            Thread { val result = NetworkTools.probeTcp(repo.fingerprintHost, repo.fingerprintPort); runOnUiThread { toastDialog("نتيجة الاتصال", if (result.isSuccess) "تم الاتصال بالجهاز بنجاح. جلب السجلات يحتاج Driver حسب الشركة والموديل." else "تعذر الاتصال: ${result.exceptionOrNull()?.message ?: "خطأ"}") } }.start()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun showSyncSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val url = UiKit.field(this, p, "https://server.example.com").apply { setText(repo.serverUrl) }
        val tenant = UiKit.field(this, p, "Business / Tenant ID").apply { setText(repo.tenantId) }
        val token = UiKit.field(this, p, "رمز التفعيل").apply { setText(repo.activationToken) }
        listOf(url, tenant, token).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("الخادم والتفعيل والمزامنة").setView(box).setPositiveButton("حفظ") { _, _ ->
            repo.serverUrl = url.text.toString(); repo.tenantId = tenant.text.toString(); repo.activationToken = token.text.toString(); toastDialog("تم", "تم حفظ إعدادات الخادم والتفعيل.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun runHealthCheck() {
        repo.ensureCurrentStoreInManagement()
        val bt = getSystemService(BluetoothManager::class.java)?.adapter
        val bluetooth = when { bt == null -> "غير مدعوم"; !bt.isEnabled -> "متوقف"; else -> "يعمل" }
        val employees = repo.employees()
        val faces = employees.count { it.faceProfileRef.isNotBlank() }
        val pins = employees.count { it.pin.isNotBlank() }
        val external = employees.count { it.externalFingerprintId.isNotBlank() }
        val msg = buildString {
            append("معلومات المحل: ${if (repo.isStoreProfileComplete) "مكتملة" else "تحتاج إكمال"}\n")
            append("Bluetooth: $bluetooth\n")
            append("الموظفون النشطون: ${employees.count { it.active }}\n")
            append("صور وجه أولية: $faces\n")
            append("PIN مفعّل: $pins\n")
            append("مرتبطون بقارئ بصمة: $external\n")
            append("الوكلاء النشطون: ${repo.agents().count { it.active }}\n")
            append("المحلات المسجلة: ${repo.managedStores().size}\n")
            append("أحداث غير مزامنة: ${repo.pendingEvents().size}\n")
            append("الفرع: ${repo.branchId}")
        }
        toastDialog("فحص جاهزية النظام", msg)
    }

    private fun statusDot(status: String) = when (status) { "APPROVED" -> "●"; "PENDING" -> "◐"; "SUSPENDED" -> "○"; else -> "•" }
    private fun storeStatusAr(status: String) = when (status) { "APPROVED" -> "معتمد"; "PENDING" -> "بانتظار موافقة المالك"; "SUSPENDED" -> "معلق"; else -> status }

    private fun copyText(text: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("ATTEND PRO", text))
        toastDialog("تم النسخ", "تم نسخ الرمز.")
    }

    private fun toastDialog(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }

    override fun onBackPressed() {
        showGateway()
    }
}
