package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var storeSummary: TextView
    private var pendingFaceEmployeeId: String? = null
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        pendingFaceEmployeeId = savedInstanceState?.getString("pendingFaceEmployeeId")
        scanner = BleEmployeeScanner(this, ::handleBlePayload) { msg ->
            runOnUiThread { if (::status.isInitialized) status.text = msg }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingFaceEmployeeId?.let { outState.putString("pendingFaceEmployeeId", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        buildUi()
        refreshDashboard()
        if (repo.autoScan && repo.employees().any { it.active && it.companionEnabled }) {
            runCatching { scanner.start() }.onFailure { if (::status.isInitialized) status.text = "تعذر تشغيل BLE: ${it.message ?: "خطأ"}" }
        }
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val header = UiKit.card(this, p).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 68), UiKit.dp(this@MainActivity, 68))
        })
        header.addView(UiKit.title(this, p, "ATTEND PRO", 27f).apply { gravity = Gravity.CENTER })
        header.addView(UiKit.subtitle(this, p, "نظام حضور المحل • الإصدار 1.4.0").apply { gravity = Gravity.CENTER })
        storeSummary = UiKit.subtitle(this, p, storeSummaryText()).apply {
            gravity = Gravity.CENTER
            setPadding(0, UiKit.dp(this@MainActivity, 5), 0, 0)
        }
        header.addView(storeSummary)
        root.addView(header)

        if (!repo.isStoreProfileComplete) {
            val setup = UiKit.card(this, p, 13)
            setup.addView(UiKit.sectionLabel(this, p, "إكمال إعداد المحل"))
            setup.addView(UiKit.subtitle(this, p, "معلومات المحل غير مكتملة. أكمل الاسم والفرع والهاتف والعنوان من إدارة النظام ← قسم المالك.").apply { gravity = Gravity.CENTER })
            root.addView(setup)
        }

        val dash = UiKit.card(this, p)
        dash.addView(UiKit.sectionLabel(this, p, "ملخص اليوم"))
        counts = TextView(this).apply { textSize = 18f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        dash.addView(counts)
        root.addView(dash)

        val main = UiKit.card(this, p)
        main.addView(UiKit.sectionLabel(this, p, "العمل اليومي"))
        main.addView(UiKit.button(this, p, "تسجيل حضور / انصراف").apply { setOnClickListener { showAttendanceMethods() } })
        main.addView(UiKit.button(this, p, "الموظفون", false).apply { setOnClickListener { showEmployeesDialog() } })
        main.addView(UiKit.button(this, p, "سجل اليوم والتقارير", false).apply { setOnClickListener { showReportsDialog() } })
        root.addView(main)

        val live = UiKit.card(this, p)
        live.addView(UiKit.sectionLabel(this, p, "حالة النظام"))
        status = TextView(this).apply { text = "جاهز"; textSize = 16f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { textSize = 14f; setTextColor(p.muted); setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0); gravity = Gravity.CENTER }
        live.addView(status)
        live.addView(nearbyView)
        root.addView(live)

        val system = UiKit.card(this, p, 12)
        system.addView(UiKit.subtitle(this, p, "الإدارة العليا والوكلاء وإعدادات المحل بعيدة عن الواجهة اليومية.").apply { gravity = Gravity.CENTER })
        system.addView(UiKit.button(this, p, "إدارة النظام 🔒", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, SystemSettingsActivity::class.java)) }
        })
        root.addView(system)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun storeSummaryText(): String {
        val parts = mutableListOf<String>()
        parts.add(repo.storeName)
        parts.add("فرع ${repo.branchId}")
        if (repo.storePhone.isNotBlank()) parts.add(repo.storePhone)
        return parts.joinToString(" • ")
    }

    private fun showAttendanceMethods(){
        val actions=mutableListOf<Pair<String,()->Unit>>()
        if(repo.allowPinFallback) actions.add("تسجيل عبر PIN" to { showPinDialog() })
        if(repo.allowEmployeeCompanion) actions.add("التعرف من هاتف الموظف عبر BLE" to { if(scanner.isScanning()){scanner.stop();status.text="تم إيقاف البحث عن هواتف الموظفين"}else{scanner.start();status.text="جاري البحث عن هواتف الموظفين الموثوقة"} })
        actions.add("قارئ البصمة الخارجي" to { quickFingerprintCheck() })
        actions.add("بصمة الوجه على جهاز المحل" to { showFaceEngineInfo() })
        AlertDialog.Builder(this).setTitle("طريقة تسجيل الحضور").setItems(actions.map{it.first}.toTypedArray()){_,which->actions[which].second()}.setNegativeButton("إغلاق",null).show()
    }

    private fun showFaceEngineInfo(){
        AlertDialog.Builder(this).setTitle("التعرف بالوجه على جهاز المحل")
            .setMessage("يمكن الآن تسجيل صورة وجه أولية اختيارية لكل موظف من ملفه. الصورة تحفظ داخل مساحة التطبيق الخاصة لتجهيز ملف الوجه، لكن المطابقة التلقائية للهوية لن تُفعّل إلا بعد إضافة محرك تعرف وجوه موثوق. لذلك لن يسجل النظام حضورًا بالوجه اعتمادًا على صورة فقط.")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun quickFingerprintCheck(){
        if(repo.fingerprintHost.isBlank()){status.text="أدخل بيانات قارئ البصمة من إدارة النظام أولًا";return}
        status.text="جاري اختبار قارئ البصمة..."
        Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{
            status.text=if(r.isSuccess)"✓ قارئ البصمة متصل — استيراد البصمات يحتاج Driver الموديل" else "تعذر الاتصال بالقارئ: ${r.exceptionOrNull()?.message ?: "خطأ"}"
        }}.start()
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees()
        val labels=mutableListOf("＋ إضافة موظف جديد")
        labels.addAll(employees.map{"${if(it.active)"●" else "○"} ${it.displayName} (${it.employeeId})${if(it.jobTitle.isNotBlank())" • ${it.jobTitle}" else ""}"})
        AlertDialog.Builder(this).setTitle("الموظفون (${employees.size})").setItems(labels.toTypedArray()){_,which->
            if(which==0) showEmployeeEditor(null) else showEmployeeDetails(employees[which-1])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showEmployeeEditor(existing: PairedEmployee?) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)

        val id = UiKit.field(this, p, "رقم الموظف").apply { setText(existing?.employeeId.orEmpty()); isEnabled = existing == null }
        val name = UiKit.field(this, p, "اسم الموظف").apply { setText(existing?.displayName.orEmpty()) }
        val phone = UiKit.field(this, p, "رقم الهاتف - اختياري").apply { setText(existing?.phone.orEmpty()) }
        val job = UiKit.field(this, p, "المسمى الوظيفي").apply { setText(existing?.jobTitle.orEmpty()) }
        val department = UiKit.field(this, p, "القسم / الإدارة - اختياري").apply { setText(existing?.department.orEmpty()) }
        val nationalId = UiKit.field(this, p, "رقم الهوية - اختياري").apply { setText(existing?.nationalId.orEmpty()) }
        val hireDate = UiKit.field(this, p, "تاريخ التعيين - اختياري").apply { setText(existing?.hireDate.orEmpty()) }
        val branch = UiKit.field(this, p, "الفرع").apply { setText(existing?.branchId ?: repo.branchId) }
        val pin = UiKit.field(this, p, "PIN احتياطي جديد - اتركه فارغًا للإبقاء الحالي", true)
        val fingerprint = UiKit.field(this, p, "معرف الموظف في قارئ البصمة - اختياري").apply { setText(existing?.externalFingerprintId.orEmpty()) }
        val notes = UiKit.field(this, p, "ملاحظات - اختياري").apply { setText(existing?.notes.orEmpty()); minLines = 2 }
        val faceEnroll = CheckBox(this).apply {
            text = if (existing?.faceProfileRef.isNullOrBlank()) "تسجيل صورة الوجه الأولية بعد الحفظ — اختياري" else "تحديث صورة الوجه الأولية بعد الحفظ — اختياري"
            setTextColor(p.text)
            isChecked = false
        }
        val companion = CheckBox(this).apply { text = "السماح بتطبيق الموظف المساند"; setTextColor(p.text); isChecked = existing?.companionEnabled ?: true }
        listOf(id, name, phone, job, department, nationalId, hireDate, branch, pin, fingerprint, notes).forEach { box.addView(it) }
        box.addView(faceEnroll)
        box.addView(companion)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة موظف" else "تعديل الموظف")
            .setView(scroll)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employeeId = id.text.toString().trim()
                val displayName = name.text.toString().trim()
                if (employeeId.isBlank() || displayName.isBlank()) {
                    status.text = "رقم الموظف والاسم مطلوبان"
                    id.error = if (employeeId.isBlank()) "مطلوب" else null
                    name.error = if (displayName.isBlank()) "مطلوب" else null
                    return@setOnClickListener
                }
                if (existing == null && repo.employees().any { it.employeeId.equals(employeeId, true) }) {
                    id.error = "رقم الموظف مستخدم بالفعل"
                    return@setOnClickListener
                }
                val secret = existing?.pairingSecret?.takeIf { SecretCodec.isValid(it) } ?: SecretCodec.encode(SecretCodec.generate())
                val pinHash = if (pin.text.toString().isBlank()) existing?.pin.orEmpty() else PairingProtocol.pinHash(pin.text.toString())
                val employee = PairedEmployee(
                    employeeId = employeeId,
                    displayName = displayName,
                    branchId = branch.text.toString().trim().ifBlank { repo.branchId },
                    pairingSecret = secret,
                    pin = pinHash,
                    phone = phone.text.toString().trim(),
                    jobTitle = job.text.toString().trim(),
                    externalFingerprintId = fingerprint.text.toString().trim(),
                    faceProfileRef = existing?.faceProfileRef.orEmpty(),
                    companionEnabled = companion.isChecked,
                    active = existing?.active ?: true,
                    department = department.text.toString().trim(),
                    nationalId = nationalId.text.toString().trim(),
                    hireDate = hireDate.text.toString().trim(),
                    notes = notes.text.toString().trim(),
                    faceCapturedAt = existing?.faceCapturedAt ?: 0L
                )
                repo.upsertEmployee(employee)
                status.text = "✓ تم حفظ ${employee.displayName}"
                refreshDashboard()
                dialog.dismiss()
                when {
                    faceEnroll.isChecked -> requestFaceCapture(employee)
                    employee.companionEnabled -> askShowProvision(employee)
                }
            }
        }
        dialog.show()
    }

    private fun askShowProvision(e:PairedEmployee){
        AlertDialog.Builder(this).setTitle("تم حفظ الموظف").setMessage("هل تريد الآن عرض QR تطبيق الموظف؟ هذه الخطوة اختيارية؛ الموظف مسجل في جهاز المحل حتى لو لم يستخدم التطبيق.")
            .setPositiveButton("عرض QR"){_,_->showProvisionQr(e)}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showEmployeeDetails(e: PairedEmployee) {
        val faceDate = if (e.faceCapturedAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(e.faceCapturedAt)) else ""
        val msg = buildString {
            append("الرقم: ${e.employeeId}\nالاسم: ${e.displayName}\nالفرع: ${e.branchId}")
            if (e.jobTitle.isNotBlank()) append("\nالمسمى: ${e.jobTitle}")
            if (e.department.isNotBlank()) append("\nالقسم: ${e.department}")
            if (e.phone.isNotBlank()) append("\nالهاتف: ${e.phone}")
            if (e.nationalId.isNotBlank()) append("\nالهوية: ${e.nationalId}")
            if (e.hireDate.isNotBlank()) append("\nتاريخ التعيين: ${e.hireDate}")
            append("\nPIN: ${if (e.pin.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nقارئ البصمة: ${e.externalFingerprintId.ifBlank { "غير مربوط" }}")
            append("\nالوجه الأولي: ${if (e.faceProfileRef.isBlank()) "غير مسجل" else "مسجل${if (faceDate.isNotBlank()) " • $faceDate" else ""}"}")
            append("\nتطبيق الموظف: ${if (e.companionEnabled) "مسموح" else "معطل"}")
            append("\nالحالة: ${if (e.active) "نشط" else "موقوف"}")
            if (e.notes.isNotBlank()) append("\nملاحظات: ${e.notes}")
        }

        val options = mutableListOf("تعديل البيانات", "تسجيل / تحديث الوجه الأولي")
        if (e.faceProfileRef.isNotBlank()) options.add("عرض صورة الوجه الأولية")
        if (e.faceProfileRef.isNotBlank()) options.add("حذف صورة الوجه الأولية")
        if (e.companionEnabled) options.add("عرض QR تطبيق الموظف")
        options.add("تسجيل يدوي بإشراف")
        options.add(if (e.active) "إيقاف الموظف" else "تفعيل الموظف")
        options.add("حذف الموظف")

        AlertDialog.Builder(this).setTitle(e.displayName).setMessage(msg).setItems(options.toTypedArray()) { _, which ->
            when (options[which]) {
                "تعديل البيانات" -> showEmployeeEditor(e)
                "تسجيل / تحديث الوجه الأولي" -> requestFaceCapture(e)
                "عرض صورة الوجه الأولية" -> showFaceReference(e)
                "حذف صورة الوجه الأولية" -> deleteFaceReference(e)
                "عرض QR تطبيق الموظف" -> showProvisionQr(e)
                "تسجيل يدوي بإشراف" -> recordManual(e)
                "إيقاف الموظف", "تفعيل الموظف" -> { repo.upsertEmployee(e.copy(active = !e.active)); status.text = "تم تحديث حالة ${e.displayName}"; refreshDashboard() }
                "حذف الموظف" -> AlertDialog.Builder(this).setTitle("حذف الموظف").setMessage("حذف ${e.displayName} من جهاز المحل؟ لن تحذف سجلات الحضور السابقة.")
                    .setPositiveButton("حذف") { _, _ -> deleteFaceFile(e.faceProfileRef); repo.removeEmployee(e.employeeId); status.text = "تم حذف الموظف"; refreshDashboard() }
                    .setNegativeButton("إلغاء", null).show()
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun requestFaceCapture(employee: PairedEmployee) {
        pendingFaceEmployeeId = employee.employeeId
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra("android.intent.extras.CAMERA_FACING", 1)
        }
        val canOpen = cameraIntent.resolveActivity(packageManager) != null
        if (!canOpen) {
            pendingFaceEmployeeId = null
            status.text = "لا يوجد تطبيق كاميرا متاح"
            AlertDialog.Builder(this).setTitle("تعذر فتح الكاميرا").setMessage("لا يوجد تطبيق كاميرا متوافق على هذا الجهاز. يمكنك متابعة استخدام الموظف بدون تسجيل الوجه.").setPositiveButton("حسنًا", null).show()
            return
        }
        runCatching { startActivityForResult(cameraIntent, REQUEST_FACE_CAPTURE) }.onFailure {
            pendingFaceEmployeeId = null
            status.text = "تعذر فتح الكاميرا: ${it.message ?: "خطأ"}"
            AlertDialog.Builder(this).setTitle("تعذر تسجيل الوجه").setMessage("لم يتم فتح الكاميرا. لم تتأثر بيانات الموظف ويمكن المحاولة مرة أخرى لاحقًا.").setPositiveButton("حسنًا", null).show()
        }
    }

    private fun showFaceReference(employee: PairedEmployee) {
        val path = employee.faceProfileRef
        val bitmap = if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        if (bitmap == null) {
            status.text = "صورة الوجه غير متاحة"
            return
        }
        val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; setPadding(12, 12, 12, 12) }
        AlertDialog.Builder(this).setTitle("صورة الوجه الأولية — ${employee.displayName}").setView(image)
            .setMessage("هذه صورة مرجعية أولية محفوظة محليًا داخل التطبيق وليست مطابقة بيومترية نهائية بحد ذاتها.")
            .setPositiveButton("إغلاق", null).show()
    }

    private fun deleteFaceReference(employee: PairedEmployee) {
        deleteFaceFile(employee.faceProfileRef)
        repo.upsertEmployee(employee.copy(faceProfileRef = "", faceCapturedAt = 0L))
        status.text = "تم حذف صورة الوجه الأولية لـ ${employee.displayName}"
    }

    private fun deleteFaceFile(path: String) {
        if (path.isNotBlank()) runCatching { File(path).takeIf { it.exists() }?.delete() }
    }

    private fun showProvisionQr(employee:PairedEmployee){
        val provision=repo.newProvision(employee)
        val content=PairingProtocol.encodeEmployeeProvision(provision)
        val qr=runCatching{QrCodeTools.bitmap(content,680)}.getOrElse{status.text="تعذر إنشاء QR: ${it.message ?: "خطأ"}";return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(20,12,20,8)}
        box.addView(TextView(this).apply{text="افتح تطبيق الموظف → مسح باركود الموظف. سيتم إدخال البيانات والربط تلقائيًا. الرمز صالح 30 دقيقة.";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.text)})
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        AlertDialog.Builder(this).setTitle("رمز ${employee.displayName}").setView(box).setPositiveButton("إغلاق",null).show()
    }

    private fun recordManual(e:PairedEmployee){
        val action=nextAction(e.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=e.employeeId,employeeName=e.displayName,branchId=e.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.SUPERVISOR_OVERRIDE,deviceId=deviceId(),verified=true))
        status.text="✓ ${e.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} بإشراف";refreshDashboard()
    }

    private fun showPinDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val pin = UiKit.field(this, p, "PIN", true)
        box.addView(id); box.addView(pin)
        val dialog = AlertDialog.Builder(this).setTitle("التسجيل عبر PIN").setView(box)
            .setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = repo.employees().firstOrNull { it.active && it.employeeId.equals(id.text.toString().trim(), true) }
                if (employee == null) { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (employee.pin.isBlank()) { pin.error = "لم يتم تعيين PIN لهذا الموظف"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(employee.pin, pin.text.toString())) { pin.error = "PIN غير صحيح"; return@setOnClickListener }
                val action = nextAction(employee.employeeId)
                repo.addEvent(AttendanceEvent(employeeId = employee.employeeId, employeeName = employee.displayName, branchId = employee.branchId, timestampEpochMillis = System.currentTimeMillis(), action = action, method = AttendanceMethod.PIN, deviceId = deviceId(), verified = true))
                status.text = "✓ ${employee.displayName}: ${if (action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"}"
                refreshDashboard()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showReportsDialog(){
        val recent=repo.events().takeLast(30).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        val text=if(recent.isEmpty())"لا توجد عمليات بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))} — ${e.method.name}\n")}}
        AlertDialog.Builder(this).setTitle("السجل والتقارير").setMessage(text).setPositiveButton("مشاركة CSV"){_,_->shareTodayCsv()}.setNegativeButton("إغلاق",null).show()
    }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int){
        val employees=repo.employees().filter{it.active&&it.companionEnabled&&BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){val secret=SecretCodec.decode(employee.pairingSecret)?:continue;if(!BleProtocol.verify(payload,employee.employeeId,secret))continue;nearby[employee.employeeId]=System.currentTimeMillis() to rssi;if(payload.verified)maybeRecordVerified(employee,payload.token);runOnUiThread{refreshDashboard()};return}
    }

    private fun maybeRecordVerified(employee:PairedEmployee,token:Int){
        if(repo.lastProofToken(employee.employeeId)==token)return;val last=repo.lastEvent(employee.employeeId);if(last!=null&&System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return;val action=nextAction(employee.employeeId);repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PHONE_BLE_BIOMETRIC,deviceId=deviceId(),verified=true));repo.setLastProofToken(employee.employeeId,token);runOnUiThread{status.text="✓ ${employee.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"}"}
    }

    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        if (::storeSummary.isInitialized) storeSummary.text = storeSummaryText()
        val now=System.currentTimeMillis();nearby.entries.removeIf{now-it.value.first>45_000L};val employees=repo.employees().filter{it.active};val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet();val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis())e.employeeId else null}.toSet();counts.text="الموظفون ${employees.size}   •   الحاضرون ${present.size}\nالمتأخرون ${late.size}   •   غير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}";nearbyView.text=if(nearby.isEmpty())"لا توجد هواتف موظفين قريبة الآن" else "هواتف قريبة: ${nearby.keys.joinToString("، "){id->employees.firstOrNull{it.employeeId==id}?.displayName?:id}}"
    }

    private fun shareTodayCsv(){val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))}
    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,repo.shiftHour);set(Calendar.MINUTE,repo.shiftMinute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);add(Calendar.MINUTE,repo.graceMinutes)}.timeInMillis
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_FACE_CAPTURE) return
        if (!::status.isInitialized) { buildUi(); refreshDashboard() }
        val employeeId = pendingFaceEmployeeId
        pendingFaceEmployeeId = null
        if (resultCode != RESULT_OK || employeeId.isNullOrBlank()) {
            status.text = "تم إلغاء تسجيل الوجه — لم تتغير بيانات الموظف"
            return
        }
        val bitmap = runCatching { data?.extras?.get("data") as? Bitmap }.getOrNull()
        if (bitmap == null) {
            status.text = "لم تصل صورة صالحة من الكاميرا"
            AlertDialog.Builder(this).setTitle("لم يتم حفظ الوجه").setMessage("لم تُرجع الكاميرا صورة صالحة. لم تتأثر بيانات الموظف ويمكن المحاولة مرة أخرى.").setPositiveButton("حسنًا", null).show()
            return
        }
        val employee = repo.employees().firstOrNull { it.employeeId.equals(employeeId, true) }
        if (employee == null) {
            status.text = "تعذر العثور على الموظف بعد التقاط الصورة"
            return
        }
        runCatching {
            val dir = File(filesDir, "face_profiles").apply { mkdirs() }
            val safeId = employee.employeeId.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(dir, "$safeId.jpg")
            file.outputStream().use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) error("تعذر ضغط الصورة")
            }
            deleteFaceFile(employee.faceProfileRef.takeIf { it != file.absolutePath }.orEmpty())
            repo.upsertEmployee(employee.copy(faceProfileRef = file.absolutePath, faceCapturedAt = System.currentTimeMillis()))
            status.text = "✓ تم تسجيل صورة الوجه الأولية لـ ${employee.displayName}"
            AlertDialog.Builder(this).setTitle("تم تسجيل الوجه الأولي").setMessage("تم حفظ الصورة داخل مساحة ATTEND PRO الخاصة. هذه الخطوة اختيارية ولا تمنع بقية طرق الحضور. المطابقة التلقائية بالوجه ستُفعّل فقط عند إضافة محرك التعرف الموثوق.").setPositiveButton("حسنًا", null).show()
        }.onFailure {
            status.text = "تعذر حفظ صورة الوجه: ${it.message ?: "خطأ"}"
        }
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==BleEmployeeScanner.REQUEST_PERMISSIONS){if(grantResults.isNotEmpty()&&grantResults.all{it==android.content.pm.PackageManager.PERMISSION_GRANTED}){status.text="تم منح صلاحيات BLE";if(repo.autoScan)scanner.start()}else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"}}
    override fun onDestroy(){scanner.stop();super.onDestroy()}
    companion object {
        private const val REQUEST_FACE_CAPTURE = 6201
    }

}
