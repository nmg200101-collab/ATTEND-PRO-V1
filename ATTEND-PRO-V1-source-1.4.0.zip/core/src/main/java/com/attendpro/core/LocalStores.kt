package com.attendpro.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class EmployeeIdentityStore(context: Context) {
    private val prefs = context.getSharedPreferences("employee_identity", Context.MODE_PRIVATE)

    var employeeId: String get() = prefs.getString("employeeId", "") ?: ""; set(value) = prefs.edit().putString("employeeId", value.trim()).apply()
    var displayName: String get() = prefs.getString("displayName", "") ?: ""; set(value) = prefs.edit().putString("displayName", value.trim()).apply()
    var branchId: String get() = prefs.getString("branchId", "MAIN") ?: "MAIN"; set(value) = prefs.edit().putString("branchId", value.trim().ifBlank { "MAIN" }).apply()
    var phone: String get() = prefs.getString("phone", "") ?: ""; set(value) = prefs.edit().putString("phone", value.trim()).apply()
    var jobTitle: String get() = prefs.getString("jobTitle", "") ?: ""; set(value) = prefs.edit().putString("jobTitle", value.trim()).apply()
    var pin: String get() = prefs.getString("pin", "") ?: ""; set(value) = prefs.edit().putString("pin", value.trim()).apply()
    var pairingSecret: String
        get() {
            val existing = prefs.getString("pairingSecret", "") ?: ""
            if (SecretCodec.isValid(existing)) return existing
            val generated = SecretCodec.encode(SecretCodec.generate())
            prefs.edit().putString("pairingSecret", generated).apply()
            return generated
        }
        set(value) = prefs.edit().putString("pairingSecret", value).apply()

    var trustedStoreId: String get() = prefs.getString("trustedStoreId", "") ?: ""; set(value) = prefs.edit().putString("trustedStoreId", value.trim()).apply()
    var trustedStoreName: String get() = prefs.getString("trustedStoreName", "") ?: ""; set(value) = prefs.edit().putString("trustedStoreName", value.trim()).apply()
    var trustedStoreBranch: String get() = prefs.getString("trustedStoreBranch", "") ?: ""; set(value) = prefs.edit().putString("trustedStoreBranch", value.trim()).apply()
    var pendingNonce: String get() = prefs.getString("pendingNonce", "") ?: ""; set(value) = prefs.edit().putString("pendingNonce", value.trim()).apply()
    var pendingExpiresAt: Long get() = prefs.getLong("pendingExpiresAt", 0L); set(value) = prefs.edit().putLong("pendingExpiresAt", value).apply()
    var autoPresence: Boolean get() = prefs.getBoolean("autoPresence", true); set(value) = prefs.edit().putBoolean("autoPresence", value).apply()

    val isConfigured: Boolean get() = employeeId.isNotBlank() && displayName.isNotBlank() && trustedStoreId.isNotBlank()
    val hasPendingInvite: Boolean get() = trustedStoreId.isNotBlank() && pendingNonce.isNotBlank() && pendingExpiresAt > System.currentTimeMillis()

    fun applyProvision(provision: PairingProtocol.EmployeeProvision) {
        trustedStoreId = provision.storeId
        trustedStoreName = provision.storeName
        trustedStoreBranch = provision.branchId
        employeeId = provision.employeeId
        displayName = provision.displayName
        branchId = provision.branchId
        phone = provision.phone
        jobTitle = provision.jobTitle
        pairingSecret = provision.pairingSecret
        pin = ""
        pendingNonce = ""
        pendingExpiresAt = 0L
    }

    fun acceptInvite(invite: PairingProtocol.StoreInvite) {
        trustedStoreId = invite.storeId; trustedStoreName = invite.storeName; trustedStoreBranch = invite.branchId
        pendingNonce = invite.nonce; pendingExpiresAt = invite.expiresAt
    }

    fun clearStoreLink() {
        trustedStoreId = ""; trustedStoreName = ""; trustedStoreBranch = ""; pendingNonce = ""; pendingExpiresAt = 0L
    }
}


data class AgentRecord(
    val agentId: String,
    val name: String,
    val codeHash: String,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class ManagedStoreRecord(
    val managedStoreId: String,
    val name: String,
    val branchId: String,
    val agentId: String = "",
    val status: String = "APPROVED",
    val createdAt: Long = System.currentTimeMillis(),
    val lastSeenAt: Long = 0L,
    val usageCount: Int = 0
)

class StoreRepository(context: Context) {
    private val prefs = context.getSharedPreferences("store_repository", Context.MODE_PRIVATE)

    val storeId: String
        get() {
            val old = prefs.getString("storeId", "") ?: ""
            if (old.isNotBlank()) return old
            val id = "STORE-${UUID.randomUUID()}"
            prefs.edit().putString("storeId", id).apply(); return id
        }
    var storeName: String get() = prefs.getString("storeName", "جهاز المحل") ?: "جهاز المحل"; set(value) = prefs.edit().putString("storeName", value.trim().ifBlank { "جهاز المحل" }).apply()
    var branchId: String get() = prefs.getString("branchId", "MAIN") ?: "MAIN"; set(value) = prefs.edit().putString("branchId", value.trim().ifBlank { "MAIN" }).apply()
    var storePhone: String get() = prefs.getString("storePhone", "") ?: ""; set(value) = prefs.edit().putString("storePhone", value.trim()).apply()
    var storeAddress: String get() = prefs.getString("storeAddress", "") ?: ""; set(value) = prefs.edit().putString("storeAddress", value.trim()).apply()
    var storeManagerName: String get() = prefs.getString("storeManagerName", "") ?: ""; set(value) = prefs.edit().putString("storeManagerName", value.trim()).apply()
    var storeCommercialId: String get() = prefs.getString("storeCommercialId", "") ?: ""; set(value) = prefs.edit().putString("storeCommercialId", value.trim()).apply()
    var storeNotes: String get() = prefs.getString("storeNotes", "") ?: ""; set(value) = prefs.edit().putString("storeNotes", value.trim()).apply()
    val isStoreProfileComplete: Boolean get() = storeName.isNotBlank() && storeName != "جهاز المحل" && branchId.isNotBlank()
    var pairingNonce: String get() = prefs.getString("pairingNonce", "") ?: ""; set(value) = prefs.edit().putString("pairingNonce", value).apply()
    var pairingExpiresAt: Long get() = prefs.getLong("pairingExpiresAt", 0L); set(value) = prefs.edit().putLong("pairingExpiresAt", value).apply()
    var autoScan: Boolean get() = prefs.getBoolean("autoScan", true); set(value) = prefs.edit().putBoolean("autoScan", value).apply()

    // Legacy local admin password retained for backward compatibility with 1.2.x.
    var systemPasswordHash: String get() = prefs.getString("systemPasswordHash", "") ?: ""; set(value) = prefs.edit().putString("systemPasswordHash", value).apply()
    var failedSystemAttempts: Int get() = prefs.getInt("failedSystemAttempts", 0); set(value) = prefs.edit().putInt("failedSystemAttempts", value.coerceAtLeast(0)).apply()
    var systemLockUntil: Long get() = prefs.getLong("systemLockUntil", 0L); set(value) = prefs.edit().putLong("systemLockUntil", value).apply()
    var installationRole: String get() = prefs.getString("installationRole", "OWNER") ?: "OWNER"; set(value) = prefs.edit().putString("installationRole", value).apply()
    var agentName: String get() = prefs.getString("agentName", "") ?: ""; set(value) = prefs.edit().putString("agentName", value.trim()).apply()
    var approvalStatus: String get() = prefs.getString("approvalStatus", "APPROVED") ?: "APPROVED"; set(value) = prefs.edit().putString("approvalStatus", value).apply()

    // Owner control plane. The official initial owner code is stored only as a one-way SHA-256 hash.
    private val officialOwnerCodeHash = "sha256:JRMZgtCWaqTpeXe4VTkvZCiI_zmsdVe1MouRnpPLdok"
    var ownerCodeHash: String
        get() = prefs.getString("ownerCodeHash", "")?.takeIf { it.isNotBlank() } ?: officialOwnerCodeHash
        set(value) = prefs.edit().putString("ownerCodeHash", value).apply()
    var failedOwnerAttempts: Int get() = prefs.getInt("failedOwnerAttempts", 0); set(value) = prefs.edit().putInt("failedOwnerAttempts", value.coerceAtLeast(0)).apply()
    var ownerLockUntil: Long get() = prefs.getLong("ownerLockUntil", 0L); set(value) = prefs.edit().putLong("ownerLockUntil", value).apply()

    var allowEmployeeCompanion: Boolean get() = prefs.getBoolean("allowEmployeeCompanion", true); set(value) = prefs.edit().putBoolean("allowEmployeeCompanion", value).apply()
    var allowPinFallback: Boolean get() = prefs.getBoolean("allowPinFallback", true); set(value) = prefs.edit().putBoolean("allowPinFallback", value).apply()
    var requirePhoneBiometric: Boolean get() = prefs.getBoolean("requirePhoneBiometric", true); set(value) = prefs.edit().putBoolean("requirePhoneBiometric", value).apply()

    fun verifySystemPassword(entered: String): Boolean {
        if (systemPasswordHash.isBlank()) return false
        val ok = PairingProtocol.matchesPin(systemPasswordHash, entered)
        if (ok) { failedSystemAttempts = 0; systemLockUntil = 0L }
        else {
            failedSystemAttempts += 1
            if (failedSystemAttempts >= 5) { systemLockUntil = System.currentTimeMillis() + 60_000L; failedSystemAttempts = 0 }
        }
        return ok
    }

    fun setSystemPassword(password: String) { systemPasswordHash = PairingProtocol.pinHash(password); failedSystemAttempts = 0; systemLockUntil = 0L }

    fun verifyOwnerCode(entered: String): Boolean {
        if (ownerLockUntil > System.currentTimeMillis()) return false
        val ok = PairingProtocol.matchesPin(ownerCodeHash, entered)
        if (ok) { failedOwnerAttempts = 0; ownerLockUntil = 0L }
        else {
            failedOwnerAttempts += 1
            if (failedOwnerAttempts >= 5) { ownerLockUntil = System.currentTimeMillis() + 60_000L; failedOwnerAttempts = 0 }
        }
        return ok
    }

    fun setOwnerCode(newCode: String) {
        ownerCodeHash = PairingProtocol.pinHash(newCode)
        failedOwnerAttempts = 0
        ownerLockUntil = 0L
    }

    fun agents(): List<AgentRecord> {
        val array = JSONArray(prefs.getString("agents", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i -> runCatching {
            val o = array.getJSONObject(i)
            AgentRecord(
                agentId = o.getString("agentId"),
                name = o.optString("name", "وكيل"),
                codeHash = o.optString("codeHash", ""),
                active = o.optBoolean("active", true),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
        }.getOrNull() }
    }

    fun upsertAgent(agent: AgentRecord) {
        val items = agents().toMutableList()
        val index = items.indexOfFirst { it.agentId == agent.agentId }
        if (index >= 0) items[index] = agent else items.add(agent)
        saveAgents(items)
    }

    fun removeAgent(agentId: String) = saveAgents(agents().filterNot { it.agentId == agentId })

    private fun saveAgents(items: List<AgentRecord>) {
        val array = JSONArray()
        items.forEach { a -> array.put(JSONObject().apply {
            put("agentId", a.agentId); put("name", a.name); put("codeHash", a.codeHash); put("active", a.active); put("createdAt", a.createdAt)
        }) }
        prefs.edit().putString("agents", array.toString()).apply()
    }

    fun findAgentByCode(code: String): AgentRecord? = agents().firstOrNull { it.active && PairingProtocol.matchesPin(it.codeHash, code) }

    fun managedStores(): List<ManagedStoreRecord> {
        val array = JSONArray(prefs.getString("managedStores", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i -> runCatching {
            val o = array.getJSONObject(i)
            ManagedStoreRecord(
                managedStoreId = o.getString("managedStoreId"),
                name = o.optString("name", "محل"),
                branchId = o.optString("branchId", "MAIN"),
                agentId = o.optString("agentId", ""),
                status = o.optString("status", "APPROVED"),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                lastSeenAt = o.optLong("lastSeenAt", 0L),
                usageCount = o.optInt("usageCount", 0)
            )
        }.getOrNull() }
    }

    fun upsertManagedStore(store: ManagedStoreRecord) {
        val items = managedStores().toMutableList()
        val index = items.indexOfFirst { it.managedStoreId == store.managedStoreId }
        if (index >= 0) items[index] = store else items.add(store)
        saveManagedStores(items)
    }

    fun removeManagedStore(id: String) = saveManagedStores(managedStores().filterNot { it.managedStoreId == id })

    private fun saveManagedStores(items: List<ManagedStoreRecord>) {
        val array = JSONArray()
        items.forEach { m -> array.put(JSONObject().apply {
            put("managedStoreId", m.managedStoreId); put("name", m.name); put("branchId", m.branchId); put("agentId", m.agentId)
            put("status", m.status); put("createdAt", m.createdAt); put("lastSeenAt", m.lastSeenAt); put("usageCount", m.usageCount)
        }) }
        prefs.edit().putString("managedStores", array.toString()).apply()
    }

    fun ensureCurrentStoreInManagement() {
        val existing = managedStores().firstOrNull { it.managedStoreId == storeId }
        val snapshot = ManagedStoreRecord(
            managedStoreId = storeId,
            name = storeName,
            branchId = branchId,
            agentId = existing?.agentId.orEmpty(),
            status = existing?.status ?: "APPROVED",
            createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            lastSeenAt = System.currentTimeMillis(),
            usageCount = events().size
        )
        upsertManagedStore(snapshot)
    }

    fun employees(): List<PairedEmployee> {
        val array = JSONArray(prefs.getString("employees", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                PairedEmployee(
                    employeeId = o.getString("employeeId"),
                    displayName = o.optString("displayName", o.getString("employeeId")),
                    branchId = o.optString("branchId", "MAIN"),
                    pairingSecret = o.optString("pairingSecret", SecretCodec.encode(SecretCodec.generate())),
                    pin = o.optString("pinHash", o.optString("pin", "")),
                    phone = o.optString("phone", ""),
                    jobTitle = o.optString("jobTitle", ""),
                    externalFingerprintId = o.optString("externalFingerprintId", ""),
                    faceProfileRef = o.optString("faceProfileRef", ""),
                    companionEnabled = o.optBoolean("companionEnabled", true),
                    active = o.optBoolean("active", true),
                    department = o.optString("department", ""),
                    nationalId = o.optString("nationalId", ""),
                    hireDate = o.optString("hireDate", ""),
                    notes = o.optString("notes", ""),
                    faceCapturedAt = o.optLong("faceCapturedAt", 0L)
                )
            }.getOrNull()
        }
    }

    fun upsertEmployee(employee: PairedEmployee) {
        val items = employees().toMutableList()
        val index = items.indexOfFirst { it.employeeId.equals(employee.employeeId, true) }
        if (index >= 0) items[index] = employee else items.add(employee)
        saveEmployees(items)
    }

    fun removeEmployee(employeeId: String) = saveEmployees(employees().filterNot { it.employeeId.equals(employeeId, true) })

    private fun saveEmployees(items: List<PairedEmployee>) {
        val array = JSONArray()
        items.forEach { e -> array.put(JSONObject().apply {
            put("employeeId", e.employeeId); put("displayName", e.displayName); put("branchId", e.branchId)
            put("pairingSecret", e.pairingSecret); put("pinHash", e.pin); put("phone", e.phone); put("jobTitle", e.jobTitle)
            put("externalFingerprintId", e.externalFingerprintId); put("faceProfileRef", e.faceProfileRef)
            put("companionEnabled", e.companionEnabled); put("active", e.active)
            put("department", e.department); put("nationalId", e.nationalId); put("hireDate", e.hireDate); put("notes", e.notes); put("faceCapturedAt", e.faceCapturedAt)
        }) }
        prefs.edit().putString("employees", array.toString()).apply()
    }

    fun ensureCompanionSecret(employee: PairedEmployee): PairedEmployee {
        if (SecretCodec.isValid(employee.pairingSecret)) return employee
        val updated = employee.copy(pairingSecret = SecretCodec.encode(SecretCodec.generate()))
        upsertEmployee(updated); return updated
    }

    fun newProvision(employee: PairedEmployee): PairingProtocol.EmployeeProvision {
        val e = ensureCompanionSecret(employee)
        return PairingProtocol.EmployeeProvision(
            storeId, storeName, e.employeeId, e.displayName, e.branchId, e.phone, e.jobTitle,
            e.pairingSecret, e.pin, System.currentTimeMillis() + 30 * 60_000L
        )
    }

    fun newPairingInvite(): PairingProtocol.StoreInvite {
        pairingNonce = PairingProtocol.randomNonce(); pairingExpiresAt = System.currentTimeMillis() + PairingProtocol.DEFAULT_TTL_MILLIS
        return PairingProtocol.StoreInvite(storeId, storeName, branchId, pairingNonce, pairingExpiresAt)
    }

    fun isValidPairingResponse(response: PairingProtocol.EmployeeResponse): Boolean =
        response.storeId == storeId && response.nonce == pairingNonce && pairingExpiresAt > System.currentTimeMillis() && response.expiresAt > System.currentTimeMillis()

    fun events(): List<AttendanceEvent> {
        val array = JSONArray(prefs.getString("events", "[]") ?: "[]")
        return (0 until array.length()).mapNotNull { i -> runCatching { AttendanceEvent.fromJson(array.getJSONObject(i)) }.getOrNull() }.sortedBy { it.timestampEpochMillis }
    }
    fun addEvent(event: AttendanceEvent) { val current = events().toMutableList(); current.add(event); saveEvents(current.takeLast(3000)) }
    fun markSynced(ids: Set<String>) { saveEvents(events().map { if (it.eventId in ids) it.copy(synced = true) else it }) }
    fun pendingEvents(): List<AttendanceEvent> = events().filter { !it.synced }
    private fun saveEvents(items: List<AttendanceEvent>) { val array = JSONArray(); items.forEach { array.put(it.toJson()) }; prefs.edit().putString("events", array.toString()).apply() }
    fun lastEvent(employeeId: String): AttendanceEvent? = events().lastOrNull { it.employeeId.equals(employeeId, true) }
    fun lastEventToday(employeeId: String, dayStart: Long): AttendanceEvent? = events().lastOrNull { it.employeeId.equals(employeeId, true) && it.timestampEpochMillis >= dayStart }
    fun lastProofToken(employeeId: String): Int = prefs.getInt("proof_${employeeId.lowercase()}", Int.MIN_VALUE)
    fun setLastProofToken(employeeId: String, token: Int) = prefs.edit().putInt("proof_${employeeId.lowercase()}", token).apply()

    var shiftHour: Int get() = prefs.getInt("shiftHour", 8); set(value) = prefs.edit().putInt("shiftHour", value.coerceIn(0,23)).apply()
    var shiftMinute: Int get() = prefs.getInt("shiftMinute", 0); set(value) = prefs.edit().putInt("shiftMinute", value.coerceIn(0,59)).apply()
    var graceMinutes: Int get() = prefs.getInt("graceMinutes", 10); set(value) = prefs.edit().putInt("graceMinutes", value.coerceIn(0,180)).apply()
    var serverUrl: String get() = prefs.getString("serverUrl", "") ?: ""; set(value) = prefs.edit().putString("serverUrl", value.trim()).apply()
    var tenantId: String get() = prefs.getString("tenantId", "") ?: ""; set(value) = prefs.edit().putString("tenantId", value.trim()).apply()
    var activationToken: String get() = prefs.getString("activationToken", "") ?: ""; set(value) = prefs.edit().putString("activationToken", value.trim()).apply()
    var fingerprintHost: String get() = prefs.getString("fingerprintHost", "") ?: ""; set(value) = prefs.edit().putString("fingerprintHost", value.trim()).apply()
    var fingerprintPort: Int get() = prefs.getInt("fingerprintPort", 4370); set(value) = prefs.edit().putInt("fingerprintPort", value.coerceIn(1,65535)).apply()
}
