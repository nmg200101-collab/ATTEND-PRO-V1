# ATTEND PRO 1.4.0 — BUILD NOTES

- Version code: 14
- Compile/target SDK: 35
- JDK: 17
- Store app remains the operational core.
- Added full local store information fields and owner-only editing UI.
- Added extended employee information fields with backward-compatible JSON loading.
- Added optional initial face reference capture using the device camera app and app-private storage.
- Face reference capture is enrollment only; automatic identity matching is intentionally not claimed until a trusted face-recognition engine is integrated.
- Removed CAMERA runtime permission from Store app because face enrollment uses ACTION_IMAGE_CAPTURE through the installed camera app; failures are handled without crashing.
- Improved PIN and employee save validation to prevent accidental dialog dismissal.
- Removed legacy duplicate local system-settings flow from Store MainActivity; protected SystemSettingsActivity is the single administration path.
- Main screen refreshes after returning from system settings, so store information updates immediately.
- Existing 1.3.0 owner/agent control, BLE, offline storage, QR employee provisioning, reports, and external fingerprint TCP probe retained.
