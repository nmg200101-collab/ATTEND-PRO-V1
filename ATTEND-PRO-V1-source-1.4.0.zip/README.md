# ATTEND PRO 1.4.0

Store-first attendance system focused on daily user experience and stability.

## Main changes
- Store profile expanded: name, branch, phone, address, manager, commercial identifier, notes.
- Employee profile expanded: phone, job title, department, national ID, hire date, branch, PIN, external fingerprint ID, notes.
- Optional initial face enrollment from the employee profile. The captured reference photo is stored in app-private storage and does not by itself perform biometric recognition.
- Safer employee and PIN forms: validation remains on screen instead of dismissing dialogs on invalid input.
- Camera failures/cancellation do not close the app or lose employee data.
- Main Store screen simplified for daily attendance use; administrative settings stay under the protected System Management area.
- Existing BLE companion, external fingerprint connectivity test, offline events, reports, owner/agent management, and activation settings retained.
