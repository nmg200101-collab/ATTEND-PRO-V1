package com.attendpro.core

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object UiKit {
    data class Palette(
        val bg: Int,
        val surface: Int,
        val surface2: Int,
        val text: Int,
        val muted: Int,
        val primary: Int,
        val accent: Int,
        val success: Int,
        val danger: Int
    )

    fun palette(context: Context): Palette {
        val dark = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        return if (dark) Palette(
            Color.rgb(4, 17, 29),
            Color.rgb(10, 31, 48),
            Color.rgb(17, 45, 65),
            Color.rgb(242, 248, 252),
            Color.rgb(176, 198, 211),
            Color.rgb(14, 126, 207),
            Color.rgb(24, 184, 177),
            Color.rgb(42, 185, 116),
            Color.rgb(235, 83, 83)
        ) else Palette(
            Color.rgb(244, 248, 252),
            Color.rgb(255, 255, 255),
            Color.rgb(235, 243, 248),
            Color.rgb(18, 39, 54),
            Color.rgb(89, 108, 121),
            Color.rgb(13, 111, 187),
            Color.rgb(18, 164, 157),
            Color.rgb(31, 151, 91),
            Color.rgb(203, 59, 64)
        )
    }

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun round(color: Int, radius: Int, context: Context, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(context, radius).toFloat()
        if (stroke != null) setStroke(dp(context, 1), stroke)
    }

    fun card(context: Context, palette: Palette, padding: Int = 16): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(context, padding), dp(context, padding), dp(context, padding), dp(context, padding))
        background = round(
            palette.surface,
            20,
            context,
            if (palette.bg == Color.rgb(244, 248, 252)) Color.rgb(220, 231, 238) else Color.rgb(30, 62, 82)
        )
        elevation = dp(context, 2).toFloat()
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(context, 12)
        }
    }

    fun heroCard(context: Context, palette: Palette, padding: Int = 20): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(context, padding), dp(context, padding), dp(context, padding), dp(context, padding))
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(palette.primary, palette.accent)
        ).apply { cornerRadius = dp(context, 24).toFloat() }
        elevation = dp(context, 5).toFloat()
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(context, 14)
        }
    }

    fun title(context: Context, palette: Palette, text: String, size: Float = 21f): TextView = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(palette.text)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.START
        includeFontPadding = false
    }

    fun subtitle(context: Context, palette: Palette, text: String): TextView = TextView(context).apply {
        this.text = text
        textSize = 14.5f
        setTextColor(palette.muted)
        gravity = Gravity.START
        setLineSpacing(0f, 1.12f)
    }

    fun field(context: Context, palette: Palette, hintText: String, numeric: Boolean = false): EditText = EditText(context).apply {
        hint = hintText
        textSize = 16f
        setTextColor(palette.text)
        setHintTextColor(palette.muted)
        background = round(palette.surface2, 15, context, Color.argb(45, Color.red(palette.muted), Color.green(palette.muted), Color.blue(palette.muted)))
        setPadding(dp(context, 14), dp(context, 12), dp(context, 14), dp(context, 12))
        inputType = if (numeric) android.text.InputType.TYPE_CLASS_NUMBER else android.text.InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(context, 10)
        }
    }

    fun button(context: Context, palette: Palette, label: String, primary: Boolean = true): Button = Button(context).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setTypeface(typeface, if (primary) Typeface.BOLD else Typeface.NORMAL)
        setTextColor(if (primary) Color.WHITE else palette.text)
        background = if (primary) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(palette.primary, palette.accent)).apply {
                cornerRadius = dp(context, 15).toFloat()
            }
        } else {
            round(palette.surface2, 15, context, Color.argb(55, Color.red(palette.muted), Color.green(palette.muted), Color.blue(palette.muted)))
        }
        elevation = dp(context, if (primary) 2 else 0).toFloat()
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 52)).apply {
            bottomMargin = dp(context, 9)
        }
    }

    fun sectionLabel(context: Context, palette: Palette, label: String): TextView = TextView(context).apply {
        text = label
        textSize = 13f
        setTextColor(palette.accent)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(context, 4), 0, dp(context, 8))
    }

    fun statusBadge(context: Context, palette: Palette, label: String, positive: Boolean): TextView = TextView(context).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        val base = if (positive) palette.success else palette.danger
        setTextColor(base)
        background = round(Color.argb(28, Color.red(base), Color.green(base), Color.blue(base)), 999, context, Color.argb(90, Color.red(base), Color.green(base), Color.blue(base)))
        setPadding(dp(context, 14), dp(context, 7), dp(context, 14), dp(context, 7))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(context, 10)
        }
    }
}
