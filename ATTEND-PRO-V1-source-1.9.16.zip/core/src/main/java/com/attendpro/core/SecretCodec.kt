package com.attendpro.core

import android.util.Base64
import java.security.SecureRandom

object SecretCodec {
    fun generate(size: Int = 16): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    fun encode(bytes: ByteArray): String = Base64.encodeToString(
        bytes,
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    )

    fun decode(text: String): ByteArray? = try {
        Base64.decode(text.trim(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    } catch (_: IllegalArgumentException) {
        null
    }

    fun isValid(text: String): Boolean = decode(text)?.size?.let { it >= 16 } == true
}
