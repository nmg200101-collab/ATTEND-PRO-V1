package com.attendpro.core

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

object PairingProtocol {
    private const val PREFIX_PROVISION_V3 = "AP3P:"
    private const val PREFIX_STORE_V2 = "AP2S:"
    private const val PREFIX_EMPLOYEE_V2 = "AP2E:"
    private const val PREFIX_STORE_V1 = "ATTENDPRO1:S:"
    private const val PREFIX_EMPLOYEE_V1 = "ATTENDPRO1:E:"
    const val DEFAULT_TTL_MILLIS = 10 * 60_000L

    data class StoreInvite(
        val storeId: String,
        val storeName: String,
        val branchId: String,
        val nonce: String,
        val expiresAt: Long
    )

    data class EmployeeResponse(
        val storeId: String,
        val nonce: String,
        val employeeId: String,
        val displayName: String,
        val branchId: String,
        val pairingSecret: String,
        val pinHash: String,
        val expiresAt: Long
    )

    data class EmployeeProvision(
        val storeId: String,
        val storeName: String,
        val employeeId: String,
        val displayName: String,
        val branchId: String,
        val phone: String,
        val jobTitle: String,
        val pairingSecret: String,
        val pinHash: String,
        val expiresAt: Long,
        val storeLatitude: Double = Double.NaN,
        val storeLongitude: Double = Double.NaN,
        val gpsRadiusMeters: Int = 150,
        val allowedMethods: Set<String> = emptySet(),
        val shiftStartHour: Int = 8,
        val shiftStartMinute: Int = 0,
        val shiftEndHour: Int = 16,
        val shiftEndMinute: Int = 0,
        val serverUrl: String = "https://attend-pro-central.nmg200101.workers.dev"
    )

    fun randomNonce(): String = SecretCodec.encode(ByteArray(8).also { SecureRandom().nextBytes(it) })

    fun encodeEmployeeProvision(p: EmployeeProvision): String = PREFIX_PROVISION_V3 + encodeJson(JSONObject().apply {
        put("v", 3); put("s", p.storeId); put("m", p.storeName); put("i", p.employeeId); put("d", p.displayName)
        put("b", p.branchId); put("t", p.phone); put("j", p.jobTitle); put("k", p.pairingSecret); put("p", p.pinHash); put("e", p.expiresAt)
        if (p.storeLatitude.isFinite() && p.storeLongitude.isFinite()) { put("la", p.storeLatitude); put("lo", p.storeLongitude); put("gr", p.gpsRadiusMeters) }
        put("am", JSONArray().apply { p.allowedMethods.sorted().forEach { put(it) } })
        put("sh", p.shiftStartHour); put("sm", p.shiftStartMinute); put("eh", p.shiftEndHour); put("em", p.shiftEndMinute)
        put("u", p.serverUrl)
    })

    fun decodeEmployeeProvision(text: String): EmployeeProvision? = runCatching {
        val clean = text.trim()
        if (!clean.startsWith(PREFIX_PROVISION_V3)) return@runCatching null
        val o = decodeJson(clean.removePrefix(PREFIX_PROVISION_V3))
        EmployeeProvision(
            o.getString("s"), o.optString("m", "جهاز المحل"), o.getString("i"), o.optString("d", o.getString("i")),
            o.optString("b", "MAIN"), o.optString("t", ""), o.optString("j", ""), o.getString("k"), o.optString("p", ""), o.getLong("e"),
            o.optDouble("la", Double.NaN), o.optDouble("lo", Double.NaN), o.optInt("gr", 150),
            o.optJSONArray("am")?.let { a -> (0 until a.length()).mapNotNull { i -> a.optString(i).takeIf { it.isNotBlank() } }.toSet() } ?: emptySet(),
            o.optInt("sh", 8), o.optInt("sm", 0), o.optInt("eh", 16), o.optInt("em", 0),
            o.optString("u", "https://attend-pro-central.nmg200101.workers.dev")
        )
    }.getOrNull()

    fun encodeStoreInvite(invite: StoreInvite): String = PREFIX_STORE_V2 + encodeJson(JSONObject().apply {
        put("v", 2); put("s", invite.storeId); put("m", invite.storeName); put("b", invite.branchId); put("n", invite.nonce); put("e", invite.expiresAt)
    })

    fun decodeStoreInvite(text: String): StoreInvite? = runCatching {
        val clean = text.trim()
        when {
            clean.startsWith(PREFIX_STORE_V2) -> {
                val o = decodeJson(clean.removePrefix(PREFIX_STORE_V2))
                StoreInvite(o.getString("s"), o.optString("m", "جهاز المحل"), o.optString("b", "MAIN"), o.getString("n"), o.getLong("e"))
            }
            clean.startsWith(PREFIX_STORE_V1) -> {
                val o = decodeJson(clean.removePrefix(PREFIX_STORE_V1))
                StoreInvite(o.getString("storeId"), o.optString("storeName", "جهاز المحل"), o.optString("branchId", "MAIN"), o.getString("nonce"), o.getLong("expiresAt"))
            }
            else -> null
        }
    }.getOrNull()

    fun encodeEmployeeResponse(response: EmployeeResponse): String = PREFIX_EMPLOYEE_V2 + encodeJson(JSONObject().apply {
        put("v", 2); put("s", response.storeId); put("n", response.nonce); put("i", response.employeeId); put("d", response.displayName)
        put("b", response.branchId); put("k", response.pairingSecret); put("p", response.pinHash); put("e", response.expiresAt)
    })

    fun decodeEmployeeResponse(text: String): EmployeeResponse? = runCatching {
        val clean = text.trim()
        when {
            clean.startsWith(PREFIX_EMPLOYEE_V2) -> {
                val o = decodeJson(clean.removePrefix(PREFIX_EMPLOYEE_V2))
                EmployeeResponse(o.getString("s"), o.getString("n"), o.getString("i"), o.optString("d", o.getString("i")), o.optString("b", "MAIN"), o.getString("k"), o.optString("p", ""), o.getLong("e"))
            }
            clean.startsWith(PREFIX_EMPLOYEE_V1) -> {
                val o = decodeJson(clean.removePrefix(PREFIX_EMPLOYEE_V1))
                EmployeeResponse(o.getString("storeId"), o.getString("nonce"), o.getString("employeeId"), o.optString("displayName", o.getString("employeeId")), o.optString("branchId", "MAIN"), o.getString("pairingSecret"), o.optString("pinHash", ""), o.getLong("expiresAt"))
            }
            else -> null
        }
    }.getOrNull()

    fun pinHash(pin: String): String {
        if (pin.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(pin.trim().toByteArray(Charsets.UTF_8))
        return "sha256:" + Base64.encodeToString(digest, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    }

    fun matchesPin(stored: String, entered: String): Boolean {
        if (stored.isBlank() || entered.isBlank()) return false
        return if (stored.startsWith("sha256:")) stored == pinHash(entered) else stored == entered.trim()
    }

    private fun encodeJson(o: JSONObject): String = Base64.encodeToString(
        o.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
    )

    private fun decodeJson(text: String): JSONObject {
        val bytes = Base64.decode(text, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
        return JSONObject(bytes.toString(Charsets.UTF_8))
    }
}
