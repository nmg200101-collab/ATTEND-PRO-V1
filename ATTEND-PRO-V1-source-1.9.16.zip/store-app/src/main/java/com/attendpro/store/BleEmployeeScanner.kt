package com.attendpro.store

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import com.attendpro.core.BleProtocol

class BleEmployeeScanner(
    private val activity: Activity,
    private val onPayload: (BleProtocol.Payload, Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object { const val REQUEST_PERMISSIONS = 5101 }
    private val manager = activity.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private var scanning = false

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val bytes = result.scanRecord?.getServiceData(BleProtocol.SERVICE_UUID)
                ?: result.scanRecord?.getManufacturerSpecificData(BleProtocol.MANUFACTURER_ID)
            val payload = BleProtocol.parse(bytes) ?: return
            onPayload(payload, result.rssi)
        }
        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, it) }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            onStatus("تعذر بدء البحث BLE (رمز $errorCode)")
        }
    }

    fun hasPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        activity.requestPermissions(permissions, REQUEST_PERMISSIONS)
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (!hasPermissions()) {
            requestPermissions()
            onStatus("اسمح بصلاحيات البلوتوث/الموقع ثم أعد البحث")
            return
        }
        val bt = adapter
        if (bt == null || !bt.isEnabled) {
            onStatus("فعّل Bluetooth في جهاز المحل")
            return
        }
        if (scanning) return
        val scanner = bt.bluetoothLeScanner ?: run {
            onStatus("BLE Scan غير مدعوم على هذا الجهاز")
            return
        }
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0L)
            .build()
        // بعض شرائح Samsung/OEM لا تطبق مرشح UUID على Service Data بصورة صحيحة.
        // نمسح دون مرشح ثم نقبل داخل callback حزم ATTEND PRO الموقعة فقط.
        scanner.startScan(null, settings, callback)
        scanning = true
        onStatus("جاري البحث عن هواتف الموظفين...")
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        if (!scanning || !hasPermissions()) return
        runCatching { adapter?.bluetoothLeScanner?.stopScan(callback) }
        scanning = false
        onStatus("تم إيقاف البحث")
    }

    fun isScanning(): Boolean = scanning
}
