package com.attendpro.store

import com.attendpro.core.BleProtocol
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import kotlin.concurrent.thread

class NetworkPresenceListener(
    private val onPayload: (BleProtocol.Payload, Int) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object { const val PORT = 47717 }
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true
        worker = thread(name = "attend-lan-listener", isDaemon = true) {
            try {
                val local = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(PORT))
                    soTimeout = 5_000
                }
                socket = local
                onStatus("اكتشاف الهواتف يعمل عبر Wi‑Fi/نقطة الاتصال وBLE")
                val buffer = ByteArray(64)
                while (running) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        local.receive(packet)
                        if (packet.length < 14 || buffer[0] != 0x41.toByte() || buffer[1] != 0x50.toByte() || buffer[2] != 0x4c.toByte() || buffer[3] != 0x31.toByte()) continue
                        BleProtocol.parse(buffer.copyOfRange(4, 14))?.let { onPayload(it, -48) }
                    } catch (_: java.net.SocketTimeoutException) { }
                }
            } catch (e: Exception) {
                if (running) onStatus("تعذر استقبال اكتشاف Wi‑Fi: ${e.message ?: "خطأ"}")
            } finally { socket?.close(); socket = null; running = false }
        }
    }

    fun stop() { running = false; socket?.close(); worker?.interrupt(); worker = null }
    fun isRunning(): Boolean = running
}
