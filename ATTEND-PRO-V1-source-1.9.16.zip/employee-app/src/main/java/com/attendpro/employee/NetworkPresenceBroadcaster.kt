package com.attendpro.employee

import com.attendpro.core.BleProtocol
import com.attendpro.core.SecretCodec
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import kotlin.concurrent.thread

class NetworkPresenceBroadcaster(private val onStatus: (String) -> Unit) {
    companion object { const val PORT = 47717 }
    @Volatile private var running = false
    @Volatile private var employeeId = ""
    @Volatile private var secret = ByteArray(0)
    @Volatile private var proofUntil = 0L
    @Volatile private var proofFlags = 0
    private var worker: Thread? = null

    fun start(id: String, encodedSecret: String) {
        val decoded = SecretCodec.decode(encodedSecret)
        if (id.isBlank() || decoded == null) return
        employeeId = id; secret = decoded
        if (running) return
        running = true
        worker = thread(name = "attend-lan-presence", isDaemon = true) {
            var announced = false
            while (running) {
                try {
                    DatagramSocket().use { socket ->
                        socket.broadcast = true
                        val payload = BleProtocol.buildPayload(employeeId, secret, currentFlags())
                        val message = byteArrayOf(0x41, 0x50, 0x4c, 0x31) + payload
                        broadcastAddresses().forEach { address ->
                            runCatching { socket.send(DatagramPacket(message, message.size, address, PORT)) }
                        }
                        if (!announced) { announced = true; onStatus("الهاتف ظاهر عبر Wi‑Fi/نقطة الاتصال وBLE") }
                    }
                } catch (_: Exception) { }
                try { Thread.sleep(3_000L) } catch (_: InterruptedException) { break }
            }
        }
    }

    fun markVerified(durationMillis: Long, proofType: Int) {
        proofUntil = System.currentTimeMillis() + durationMillis
        proofFlags = BleProtocol.FLAG_VERIFIED or proofType
    }

    fun stop() { running = false; worker?.interrupt(); worker = null }
    fun isRunning(): Boolean = running
    private fun currentFlags(): Int = if (System.currentTimeMillis() < proofUntil) proofFlags else 0

    private fun broadcastAddresses(): Set<InetAddress> {
        val addresses = linkedSetOf<InetAddress>(InetAddress.getByName("255.255.255.255"))
        runCatching {
            NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }.forEach { network ->
                network.interfaceAddresses.forEach { item ->
                    val broadcast = item.broadcast
                    if (broadcast is Inet4Address) addresses.add(broadcast)
                }
            }
        }
        return addresses
    }
}
