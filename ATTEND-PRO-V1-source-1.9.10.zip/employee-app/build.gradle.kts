plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.attendpro.employee"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.attendpro.employee"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "1.9.10"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":core"))
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
