package com.attendpro.employee

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.attendpro.core.BleProtocol
import com.attendpro.core.SecretCodec

class BlePresenceAdvertiser(
    private val activity: Activity,
    private val onStatus: (String) -> Unit
) {
    companion object { const val REQUEST_BLUETOOTH = 4101 }

    private val handler = Handler(Looper.getMainLooper())
    private val manager = activity.getSystemService(BluetoothManager::class.java)
    private val adapter get() = manager?.adapter
    private var running = false
    private var employeeId = ""
    private var secret = ByteArray(0)
    private var proofUntil = 0L
    private var proofFlags = 0
    private var advertising = false

    private val callback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            advertising = true
            onStatus(if (currentFlags() != 0) "تم بث إثبات التحقق للمحل" else "الهاتف ظاهر لجهاز المحل عبر BLE")
        }
        override fun onStartFailure(errorCode: Int) {
            advertising = false
            if (errorCode == ADVERTISE_FAILED_ALREADY_STARTED) {
                onStatus("BLE يعمل ويُبث هوية الموظف")
            } else {
                onStatus("تعذر تشغيل BLE (رمز $errorCode) — أوقف البلوتوث وشغله ثم أعد المحاولة")
            }
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (!running) return
            restartInternal()
            handler.postDelayed(this, 25_000L)
        }
    }

    fun hasPermissions(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED &&
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity.requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT),
                REQUEST_BLUETOOTH
            )
        }
    }

    fun start(employeeId: String, secretText: String) {
        val decoded = SecretCodec.decode(secretText)
        if (employeeId.isBlank() || decoded == null) {
            onStatus("أكمل بيانات الموظف أولاً")
            return
        }
        if (!hasPermissions()) {
            requestPermissions()
            onStatus("اسمح بصلاحية البلوتوث ثم أعد المحاولة")
            return
        }
        this.employeeId = employeeId
        this.secret = decoded
        running = true
        handler.removeCallbacks(refresher)
        restartInternal()
        handler.postDelayed(refresher, 25_000L)
    }

    fun stop() {
        running = false
        advertising = false
        handler.removeCallbacks(refresher)
        stopInternal()
        onStatus("تم إيقاف الظهور للمحل")
    }

    fun markVerified(durationMillis: Long = 30_000L, proofType: Int = BleProtocol.FLAG_BIOMETRIC) {
        proofUntil = System.currentTimeMillis() + durationMillis
        proofFlags = BleProtocol.FLAG_VERIFIED or proofType
        if (running) restartInternal()
    }

    fun isRunning(): Boolean = running
    fun isAdvertising(): Boolean = advertising
    private fun currentFlags(): Int = if (System.currentTimeMillis() < proofUntil) proofFlags else 0

    @SuppressLint("MissingPermission")
    private fun restartInternal() {
        if (!running || !hasPermissions()) return
        val bt = adapter
        if (bt == null || !bt.isEnabled) {
            running = false
            onStatus("فعّل Bluetooth في الهاتف")
            return
        }
        if (!bt.isMultipleAdvertisementSupported) {
            running = false
            onStatus("هذا الهاتف لا يدعم إرسال BLE المطلوب للحضور")
            return
        }
        val advertiser = bt.bluetoothLeAdvertiser
        if (advertiser == null) {
            running = false
            onStatus("هذا الهاتف لا يدعم BLE Advertising")
            return
        }
        runCatching { advertiser.stopAdvertising(callback) }
        advertising = false
        val payload = BleProtocol.buildPayload(employeeId, secret, currentFlags())
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .setTimeout(0)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .setIncludeTxPowerLevel(false)
            .addManufacturerData(BleProtocol.MANUFACTURER_ID, payload)
            .build()
        advertiser.startAdvertising(settings, data, callback)
    }

    @SuppressLint("MissingPermission")
    private fun stopInternal() {
        if (!hasPermissions()) return
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback) }
    }
}
