package com.attendpro.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom

object CentralServerClient {
    data class ActivationApplicant(
        val ownerName: String,
        val storeName: String,
        val subscriptionType: String,
        val phone: String = "",
        val address: String = "",
        val commercialId: String = "",
        val notes: String = ""
    )
    data class ActivationRequestResult(val requestId: String, val pollSecret: String, val status: String)
    data class ActivationRecovery(
        val storeId: String, val storeName: String, val branchId: String,
        val licenseId: String, val accessToken: String, val expiresAt: Long,
        val maxEmployees: Int, val leaseUntil: Long, val serverTime: Long
    )
    data class ActivationStatus(
        val status: String,
        val licenseId: String = "",
        val accessToken: String = "",
        val expiresAt: Long = 0L,
        val maxEmployees: Int = 10,
        val leaseUntil: Long = 0L,
        val serverTime: Long = 0L,
        val reason: String = ""
    )
    data class StoreValidation(
        val status: String,
        val expiresAt: Long,
        val maxEmployees: Int,
        val leaseUntil: Long,
        val serverTime: Long,
        val reason: String = ""
    )
    data class PendingActivation(
        val requestId: String, val storeId: String, val storeName: String, val branchId: String, val createdAt: Long,
        val ownerName: String = "", val subscriptionType: String = "YEARLY", val phone: String = "",
        val address: String = "", val commercialId: String = "", val notes: String = ""
    )
    data class CentralStore(val storeId: String, val storeName: String, val branchId: String, val status: String, val expiresAt: Long, val maxEmployees: Int, val lastSeenAt: Long)
    data class RemoteInboxItem(val transferId: String, val packageText: String)
    data class RemoteDashboard(val storeName: String, val branchId: String, val text: String)

    fun requestActivation(serverUrl: String, storeId: String, branchId: String, applicant: ActivationApplicant, identity: DeviceIdentity): Result<ActivationRequestResult> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/activation/request", "POST", JSONObject().apply {
            put("storeId", storeId); put("storeName", applicant.storeName); put("branchId", branchId)
            put("ownerName", applicant.ownerName); put("subscriptionType", applicant.subscriptionType)
            put("phone", applicant.phone); put("address", applicant.address)
            put("commercialId", applicant.commercialId); put("notes", applicant.notes)
            put("devicePublicKey", identity.publicKeyB64()); put("recoveryFingerprint", identity.recoveryFingerprint())
        })
        ActivationRequestResult(o.getString("requestId"), o.getString("pollSecret"), o.optString("status", "PENDING"))
    }

    fun recoverActivation(serverUrl: String, identity: DeviceIdentity): Result<ActivationRecovery> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/activation/recover", "POST", JSONObject().apply {
            put("devicePublicKey", identity.publicKeyB64())
            put("recoveryFingerprint", identity.recoveryFingerprint())
        }, deviceIdentity = identity, storeId = "RECOVERY")
        ActivationRecovery(
            storeId = o.getString("storeId"), storeName = o.optString("storeName", "جهاز المحل"),
            branchId = o.optString("branchId", "MAIN"), licenseId = o.getString("licenseId"),
            accessToken = o.getString("accessToken"), expiresAt = o.getLong("expiresAt"),
            maxEmployees = o.optInt("maxEmployees", 10).coerceIn(1, 10000),
            leaseUntil = o.getLong("leaseUntil"), serverTime = o.getLong("serverTime")
        )
    }

    fun activationStatus(serverUrl: String, requestId: String, pollSecret: String, storeId: String, identity: DeviceIdentity): Result<ActivationStatus> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/activation/status", "POST", JSONObject().apply {
            put("requestId", requestId); put("pollSecret", pollSecret)
        }, deviceIdentity = identity, storeId = storeId)
        ActivationStatus(
            status = o.optString("status", "PENDING"), licenseId = o.optString("licenseId", ""), accessToken = o.optString("accessToken", ""),
            expiresAt = o.optLong("expiresAt", 0L), maxEmployees = o.optInt("maxEmployees", 10).coerceIn(1, 10000),
            leaseUntil = o.optLong("leaseUntil", 0L), serverTime = o.optLong("serverTime", 0L), reason = o.optString("reason", "")
        )
    }

    fun validateStore(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity): Result<StoreValidation> = runCatching {
        requireHttps(serverUrl)
        require(storeToken.isNotBlank()) { "بيانات التفعيل المركزي غير مكتملة" }
        val o = request(serverUrl, "/api/v1/store/validate", "GET", null, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        StoreValidation(
            status = o.optString("status", "UNKNOWN"),
            expiresAt = o.optLong("expiresAt", 0L),
            maxEmployees = o.optInt("maxEmployees", 0).coerceAtLeast(0),
            leaseUntil = o.optLong("leaseUntil", 0L),
            serverTime = o.optLong("serverTime", 0L),
            reason = o.optString("reason", "")
        )
    }

    fun enrollRecovery(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/store/recovery/enroll", "POST", JSONObject().apply {
            put("recoveryFingerprint", identity.recoveryFingerprint())
        }, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        Unit
    }

    fun listPendingActivations(serverUrl: String, ownerApiKey: String): Result<List<PendingActivation>> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/admin/activation/pending", "GET", null, bearer = ownerApiKey)
        val a = o.optJSONArray("requests") ?: JSONArray()
        (0 until a.length()).map { i -> val x = a.getJSONObject(i); PendingActivation(
            x.getString("requestId"), x.getString("storeId"), x.optString("storeName", "محل"), x.optString("branchId", "MAIN"), x.optLong("createdAt", 0L),
            x.optString("ownerName", ""), x.optString("subscriptionType", "YEARLY"), x.optString("phone", ""),
            x.optString("address", ""), x.optString("commercialId", ""), x.optString("notes", "")
        ) }
    }

    fun listCentralStores(serverUrl: String, ownerApiKey: String): Result<List<CentralStore>> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/admin/stores", "GET", null, bearer = ownerApiKey)
        val a = o.optJSONArray("stores") ?: JSONArray()
        (0 until a.length()).map { i -> val x = a.getJSONObject(i); CentralStore(x.getString("storeId"), x.optString("storeName", "محل"), x.optString("branchId", "MAIN"), x.optString("status", "ACTIVE"), x.optLong("expiresAt", 0L), x.optInt("maxEmployees", 10), x.optLong("lastSeenAt", 0L)) }
    }

    fun approveActivation(serverUrl: String, ownerApiKey: String, requestId: String, days: Int, maxEmployees: Int): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/admin/activation/approve", "POST", JSONObject().apply { put("requestId", requestId); put("days", days.coerceIn(1, 3650)); put("maxEmployees", maxEmployees.coerceIn(1, 10000)) }, bearer = ownerApiKey)
        Unit
    }

    fun suspendStore(serverUrl: String, ownerApiKey: String, storeId: String, suspended: Boolean): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/admin/stores/status", "POST", JSONObject().apply { put("storeId", storeId); put("status", if (suspended) "SUSPENDED" else "ACTIVE") }, bearer = ownerApiKey)
        Unit
    }

    fun renewStore(serverUrl: String, ownerApiKey: String, storeId: String, days: Int, maxEmployees: Int): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/admin/stores/renew", "POST", JSONObject().apply {
            put("storeId", storeId)
            put("days", days.coerceIn(1, 3650))
            put("maxEmployees", maxEmployees.coerceIn(1, 10000))
        }, bearer = ownerApiKey)
        Unit
    }

    fun registerReceiver(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity, receiverId: String, name: String, secret: String): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/report-receivers/register", "POST", JSONObject().apply { put("receiverId", receiverId); put("name", name); put("secret", secret) }, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        Unit
    }

    fun setReceiverActive(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity, receiverId: String, active: Boolean): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/report-receivers/status", "POST", JSONObject().apply { put("receiverId", receiverId); put("active", active) }, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        Unit
    }

    fun pushReport(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity, receiverId: String, transferId: String, packageText: String, confirmationHash: String): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/reports/push", "POST", JSONObject().apply { put("receiverId", receiverId); put("transferId", transferId); put("packageText", packageText); put("confirmationHash", confirmationHash) }, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        Unit
    }

    fun receiverInbox(serverUrl: String, receiverId: String, secret: String): Result<List<RemoteInboxItem>> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/reports/inbox", "POST", JSONObject().apply { put("receiverId", receiverId); put("secret", secret) })
        val a = o.optJSONArray("reports") ?: JSONArray()
        (0 until a.length()).map { i -> val x = a.getJSONObject(i); RemoteInboxItem(x.getString("transferId"), x.getString("packageText")) }
    }

    fun confirmRemoteReport(serverUrl: String, receiverId: String, secret: String, transferId: String, confirmationCode: String): Result<Unit> = runCatching {
        requireHttps(serverUrl)
        request(serverUrl, "/api/v1/reports/confirm", "POST", JSONObject().apply { put("receiverId", receiverId); put("secret", secret); put("transferId", transferId); put("confirmationCode", confirmationCode) })
        Unit
    }

    fun confirmedTransfers(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity): Result<Set<String>> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/reports/confirmations", "GET", null, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        val a = o.optJSONArray("transferIds") ?: JSONArray()
        (0 until a.length()).map { a.getString(it) }.toSet()
    }

    fun remoteReport(serverUrl: String, receiverId: String, secret: String, period: String): Result<String> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/monitor/report", "POST", JSONObject().apply { put("receiverId", receiverId); put("secret", secret); put("period", period) })
        o.optString("reportText", "لا توجد بيانات")
    }

    fun remoteDashboard(serverUrl: String, receiverId: String, secret: String): Result<RemoteDashboard> = runCatching {
        requireHttps(serverUrl)
        val o = request(serverUrl, "/api/v1/monitor/summary", "POST", JSONObject().apply { put("receiverId", receiverId); put("secret", secret) })
        val recent = o.optJSONArray("recent") ?: JSONArray()
        val lines = mutableListOf<String>()
        lines += "الحضور اليوم: ${o.optInt("checkIns", 0)} • الانصراف: ${o.optInt("checkOuts", 0)}"
        lines += "حركات اليوم: ${o.optInt("todayEvents", 0)} • آخر اتصال: ${o.optString("lastSeen", "-")}"
        if (recent.length() > 0) {
            lines += ""; lines += "آخر الحركات:"
            for (i in 0 until minOf(recent.length(), 10)) { val e = recent.getJSONObject(i); lines += "• ${e.optString("employeeName", e.optString("employeeId", ""))} — ${e.optString("action", "")} — ${e.optString("time", "")}" }
        }
        RemoteDashboard(o.optString("storeName", "ATTEND PRO"), o.optString("branchId", "MAIN"), lines.joinToString("\n"))
    }

    fun syncEventsCentral(serverUrl: String, storeToken: String, storeId: String, identity: DeviceIdentity, events: List<AttendanceEvent>): Result<Set<String>> = runCatching {
        requireHttps(serverUrl)
        if (events.isEmpty()) return@runCatching emptySet()
        val body = JSONObject().apply { put("events", JSONArray().apply { events.forEach { event -> put(event.toJson()) } }) }
        val o = request(serverUrl, "/api/v1/attendance/events/batch", "POST", body, bearer = storeToken, deviceIdentity = identity, storeId = storeId)
        val a = o.optJSONArray("acceptedIds") ?: JSONArray()
        if (a.length() == 0) events.map { it.eventId }.toSet() else (0 until a.length()).map { a.getString(it) }.toSet()
    }

    private fun requireHttps(serverUrl: String) { require(serverUrl.trim().startsWith("https://")) { "عنوان الخادم يجب أن يبدأ بـ https://" } }

    private fun request(serverUrl: String, path: String, method: String, body: JSONObject?, bearer: String = "", deviceIdentity: DeviceIdentity? = null, storeId: String = ""): JSONObject {
        val bodyText = body?.toString().orEmpty()
        val connection = (URL(serverUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 10_000; readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
            if (bearer.isNotBlank()) setRequestProperty("Authorization", "Bearer $bearer")
            if (deviceIdentity != null && storeId.isNotBlank()) {
                val ts = System.currentTimeMillis().toString()
                val nonce = randomToken(18)
                val bodyHash = sha256Hex(bodyText)
                val canonical = "$method\n$path\n$ts\n$nonce\n$bodyHash"
                setRequestProperty("X-AP-Store", storeId)
                setRequestProperty("X-AP-Time", ts)
                setRequestProperty("X-AP-Nonce", nonce)
                setRequestProperty("X-AP-Body-SHA256", bodyHash)
                setRequestProperty("X-AP-Signature", deviceIdentity.sign(canonical))
            }
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        if (body != null) OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(bodyText) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() } }.orEmpty()
        connection.disconnect()
        val parsed = runCatching { JSONObject(text.ifBlank { "{}" }) }.getOrElse { JSONObject() }
        if (code !in 200..299) error(parsed.optString("error", "HTTP $code"))
        return parsed
    }

    private fun randomToken(bytes: Int): String {
        val raw = ByteArray(bytes).also { SecureRandom().nextBytes(it) }
        return android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING)
    }
    private fun sha256Hex(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
