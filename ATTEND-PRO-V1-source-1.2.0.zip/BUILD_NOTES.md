ATTEND PRO 1.2.0
- Store-first architecture
- One-way employee companion provisioning QR (AP3P)
- Simplified store home
- Employee master data managed only from store app
- System settings password with 5-attempt lockout
- Owner/Agent local role and approval state
- PIN, BLE biometric companion, external fingerprint ID/preflight
- Face profile hook prepared; actual multi-user face engine intentionally not faked
