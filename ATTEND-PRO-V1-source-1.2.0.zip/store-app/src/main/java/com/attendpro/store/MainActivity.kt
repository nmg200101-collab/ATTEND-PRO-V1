package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.BleProtocol
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.QrCodeTools
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private val nearby = linkedMapOf<String, Pair<Long, Int>>()
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        scanner = BleEmployeeScanner(this,::handleBlePayload){ msg -> runOnUiThread { if(::status.isInitialized) status.text=msg } }
        buildUi()
        refreshDashboard()
        if(repo.autoScan && repo.employees().any{it.active && it.companionEnabled}) scanner.start()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,22),UiKit.dp(this@MainActivity,18),UiKit.dp(this@MainActivity,34)); setBackgroundColor(p.bg)
        }

        val header=UiKit.card(this,p).apply{gravity=Gravity.CENTER_HORIZONTAL}
        header.addView(ImageView(this).apply{setImageResource(R.drawable.ic_attend_pro);layoutParams=LinearLayout.LayoutParams(UiKit.dp(this@MainActivity,78),UiKit.dp(this@MainActivity,78))})
        header.addView(UiKit.title(this,p,"ATTEND PRO",28f).apply{gravity=Gravity.CENTER})
        header.addView(UiKit.subtitle(this,p,"جهاز المحل • النظام الأساسي • الإصدار 1.2.0").apply{gravity=Gravity.CENTER})
        header.addView(UiKit.subtitle(this,p,"إدارة الموظفين والحضور محليًا — تطبيق الموظف ميزة إضافية فقط").apply{gravity=Gravity.CENTER})
        root.addView(header)

        val dash=UiKit.card(this,p)
        dash.addView(UiKit.sectionLabel(this,p,"اليوم"))
        counts=TextView(this).apply{textSize=18f;setTextColor(p.text);setTypeface(typeface,Typeface.BOLD);gravity=Gravity.CENTER}
        dash.addView(counts)
        root.addView(dash)

        val main=UiKit.card(this,p)
        main.addView(UiKit.sectionLabel(this,p,"العمليات الرئيسية"))
        main.addView(UiKit.button(this,p,"تسجيل حضور / انصراف").apply{setOnClickListener{showAttendanceMethods()}})
        main.addView(UiKit.button(this,p,"الموظفون",false).apply{setOnClickListener{showEmployeesDialog()}})
        main.addView(UiKit.button(this,p,"التقارير والسجل",false).apply{setOnClickListener{showReportsDialog()}})
        root.addView(main)

        val live=UiKit.card(this,p)
        live.addView(UiKit.sectionLabel(this,p,"الحالة المباشرة"))
        status=TextView(this).apply{text="جاهز";textSize=16f;setTextColor(p.text);setTypeface(typeface,Typeface.BOLD);gravity=Gravity.CENTER}
        nearbyView=TextView(this).apply{textSize=14f;setTextColor(p.muted);setPadding(0,UiKit.dp(this@MainActivity,8),0,0);gravity=Gravity.CENTER}
        live.addView(status);live.addView(nearbyView)
        root.addView(live)

        val system=UiKit.card(this,p,12)
        system.addView(UiKit.subtitle(this,p,"الإعدادات والصلاحيات بعيدة عن التشغيل اليومي ومحمية بكلمة مرور.").apply{gravity=Gravity.CENTER})
        system.addView(UiKit.button(this,p,"إدارة النظام 🔒",false).apply{setOnClickListener{openSystemSettings()}})
        root.addView(system)

        setContentView(ScrollView(this).apply{setBackgroundColor(p.bg);addView(root)})
    }

    private fun showAttendanceMethods(){
        val items=arrayOf("تسجيل عبر PIN","التعرف من هاتف الموظف عبر BLE","قارئ البصمة الخارجي","بصمة الوجه على جهاز المحل")
        AlertDialog.Builder(this).setTitle("طريقة تسجيل الحضور").setItems(items){_,which->
            when(which){
                0->showPinDialog()
                1->{ if(scanner.isScanning()){scanner.stop();status.text="تم إيقاف البحث عن هواتف الموظفين"}else{scanner.start();status.text="جاري البحث عن هواتف الموظفين الموثوقة"} }
                2->quickFingerprintCheck()
                3->showFaceEngineInfo()
            }
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showFaceEngineInfo(){
        AlertDialog.Builder(this).setTitle("بصمة الوجه على جهاز المحل")
            .setMessage("هيكل الموظف أصبح جاهزًا لحفظ مرجع قالب وجه آمن، لكن التعرف التلقائي على عدة موظفين لا توفره واجهة Android البيومترية القياسية. لن أعتمد مقارنة غير دقيقة أو أخزن صور الوجوه كبديل مزيف. سيتم توصيل محرك Face Recognition محلي مشفر في مرحلة مستقلة، مع بقاء PIN وقارئ البصمة والهاتف بدائل كاملة.")
            .setPositiveButton("حسنًا",null).show()
    }

    private fun quickFingerprintCheck(){
        if(repo.fingerprintHost.isBlank()){status.text="أدخل بيانات قارئ البصمة من إدارة النظام أولًا";return}
        status.text="جاري اختبار قارئ البصمة..."
        Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{
            status.text=if(r.isSuccess)"✓ قارئ البصمة متصل — استيراد البصمات يحتاج Driver الموديل" else "تعذر الاتصال بالقارئ: ${r.exceptionOrNull()?.message ?: "خطأ"}"
        }}.start()
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees()
        val labels=mutableListOf("＋ إضافة موظف جديد")
        labels.addAll(employees.map{"${if(it.active)"●" else "○"} ${it.displayName} (${it.employeeId})${if(it.jobTitle.isNotBlank())" • ${it.jobTitle}" else ""}"})
        AlertDialog.Builder(this).setTitle("الموظفون (${employees.size})").setItems(labels.toTypedArray()){_,which->
            if(which==0) showEmployeeEditor(null) else showEmployeeDetails(employees[which-1])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showEmployeeEditor(existing: PairedEmployee?){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)}
        val id=UiKit.field(this,p,"رقم الموظف").apply{setText(existing?.employeeId.orEmpty());isEnabled=existing==null}
        val name=UiKit.field(this,p,"اسم الموظف").apply{setText(existing?.displayName.orEmpty())}
        val phone=UiKit.field(this,p,"رقم الهاتف - اختياري").apply{setText(existing?.phone.orEmpty())}
        val job=UiKit.field(this,p,"المسمى الوظيفي").apply{setText(existing?.jobTitle.orEmpty())}
        val branch=UiKit.field(this,p,"الفرع").apply{setText(existing?.branchId ?: repo.branchId)}
        val pin=UiKit.field(this,p,"PIN احتياطي جديد - اتركه فارغًا للإبقاء الحالي",true)
        val fingerprint=UiKit.field(this,p,"معرف الموظف في قارئ البصمة - اختياري").apply{setText(existing?.externalFingerprintId.orEmpty())}
        val companion=CheckBox(this).apply{text="السماح بتطبيق الموظف المساند";setTextColor(p.text);isChecked=existing?.companionEnabled ?: true}
        listOf(id,name,phone,job,branch,pin,fingerprint).forEach{box.addView(it)};box.addView(companion)
        AlertDialog.Builder(this).setTitle(if(existing==null)"إضافة موظف" else "تعديل الموظف").setView(box).setPositiveButton("حفظ"){_,_->
            val employeeId=id.text.toString().trim();val displayName=name.text.toString().trim()
            if(employeeId.isBlank()||displayName.isBlank()){status.text="رقم الموظف والاسم مطلوبان";return@setPositiveButton}
            val secret=existing?.pairingSecret?.takeIf{SecretCodec.isValid(it)} ?: SecretCodec.encode(SecretCodec.generate())
            val pinHash=if(pin.text.toString().isBlank()) existing?.pin.orEmpty() else PairingProtocol.pinHash(pin.text.toString())
            val e=PairedEmployee(employeeId,displayName,branch.text.toString().trim().ifBlank{repo.branchId},secret,pinHash,phone.text.toString().trim(),job.text.toString().trim(),fingerprint.text.toString().trim(),existing?.faceProfileRef.orEmpty(),companion.isChecked,existing?.active ?: true)
            repo.upsertEmployee(e);status.text="✓ تم حفظ ${e.displayName}";refreshDashboard()
            if(e.companionEnabled) askShowProvision(e)
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun askShowProvision(e:PairedEmployee){
        AlertDialog.Builder(this).setTitle("تم حفظ الموظف").setMessage("هل تريد الآن عرض QR تطبيق الموظف؟ هذه الخطوة اختيارية؛ الموظف مسجل في جهاز المحل حتى لو لم يستخدم التطبيق.")
            .setPositiveButton("عرض QR"){_,_->showProvisionQr(e)}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showEmployeeDetails(e:PairedEmployee){
        val msg=buildString{
            append("الرقم: ${e.employeeId}\nالاسم: ${e.displayName}\nالفرع: ${e.branchId}")
            if(e.jobTitle.isNotBlank())append("\nالمسمى: ${e.jobTitle}")
            if(e.phone.isNotBlank())append("\nالهاتف: ${e.phone}")
            append("\nPIN: ${if(e.pin.isBlank())"غير مضاف" else "مضاف"}")
            append("\nقارئ البصمة: ${e.externalFingerprintId.ifBlank{"غير مربوط"}}")
            append("\nتطبيق الموظف: ${if(e.companionEnabled)"مسموح" else "معطل"}")
            append("\nبصمة الوجه: ${if(e.faceProfileRef.isBlank())"بانتظار محرك الوجه" else "مضافة"}")
            append("\nالحالة: ${if(e.active)"نشط" else "موقوف"}")
        }
        val options=arrayOf("تعديل البيانات","عرض QR تطبيق الموظف","تسجيل يدوي بإشراف","${if(e.active)"إيقاف الموظف" else "تفعيل الموظف"}","حذف الموظف")
        AlertDialog.Builder(this).setTitle(e.displayName).setMessage(msg).setItems(options){_,which->
            when(which){
                0->showEmployeeEditor(e)
                1->if(e.companionEnabled)showProvisionQr(e) else status.text="ميزة تطبيق الموظف معطلة لهذا الموظف"
                2->recordManual(e)
                3->{repo.upsertEmployee(e.copy(active=!e.active));status.text="تم تحديث حالة ${e.displayName}";refreshDashboard()}
                4->AlertDialog.Builder(this).setTitle("حذف الموظف").setMessage("حذف ${e.displayName} من جهاز المحل؟").setPositiveButton("حذف"){_,_->repo.removeEmployee(e.employeeId);status.text="تم حذف الموظف";refreshDashboard()}.setNegativeButton("إلغاء",null).show()
            }
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showProvisionQr(employee:PairedEmployee){
        val provision=repo.newProvision(employee)
        val content=PairingProtocol.encodeEmployeeProvision(provision)
        val qr=runCatching{QrCodeTools.bitmap(content,680)}.getOrElse{status.text="تعذر إنشاء QR: ${it.message ?: "خطأ"}";return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(20,12,20,8)}
        box.addView(TextView(this).apply{text="افتح تطبيق الموظف → مسح باركود الموظف. سيتم إدخال البيانات والربط تلقائيًا. الرمز صالح 30 دقيقة.";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.text)})
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        AlertDialog.Builder(this).setTitle("رمز ${employee.displayName}").setView(box).setPositiveButton("إغلاق",null).show()
    }

    private fun recordManual(e:PairedEmployee){
        val action=nextAction(e.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=e.employeeId,employeeName=e.displayName,branchId=e.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.SUPERVISOR_OVERRIDE,deviceId=deviceId(),verified=true))
        status.text="✓ ${e.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} بإشراف";refreshDashboard()
    }

    private fun showPinDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)}
        val id=UiKit.field(this,p,"رقم الموظف");val pin=UiKit.field(this,p,"PIN",true);box.addView(id);box.addView(pin)
        AlertDialog.Builder(this).setTitle("التسجيل عبر PIN").setView(box).setPositiveButton("تسجيل"){_,_->
            val employee=repo.employees().firstOrNull{it.active&&it.employeeId.equals(id.text.toString().trim(),true)}
            if(employee==null||!PairingProtocol.matchesPin(employee.pin,pin.text.toString()))status.text="رقم الموظف أو PIN غير صحيح" else {
                val action=nextAction(employee.employeeId);repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PIN,deviceId=deviceId(),verified=true));status.text="✓ ${employee.displayName}: تم التسجيل";refreshDashboard()
            }
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun showReportsDialog(){
        val recent=repo.events().takeLast(30).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        val text=if(recent.isEmpty())"لا توجد عمليات بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))} — ${e.method.name}\n")}}
        AlertDialog.Builder(this).setTitle("السجل والتقارير").setMessage(text).setPositiveButton("مشاركة CSV"){_,_->shareTodayCsv()}.setNegativeButton("إغلاق",null).show()
    }

    private fun openSystemSettings(){
        if(repo.systemLockUntil>System.currentTimeMillis()){status.text="إدارة النظام مقفلة مؤقتًا. حاول بعد دقيقة";return}
        if(repo.systemPasswordHash.isBlank()) { createSystemPassword(); return }
        val input=UiKit.field(this,p,"كلمة مرور إدارة النظام").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialog.Builder(this).setTitle("إدارة النظام 🔒").setView(input).setPositiveButton("دخول"){_,_->
            if(repo.verifySystemPassword(input.text.toString())) showSystemMenu() else status.text="كلمة المرور غير صحيحة"
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun createSystemPassword(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)}
        val a=UiKit.field(this,p,"كلمة مرور جديدة - 6 أحرف/أرقام على الأقل").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        val b=UiKit.field(this,p,"تأكيد كلمة المرور").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};box.addView(a);box.addView(b)
        AlertDialog.Builder(this).setTitle("إنشاء كلمة مرور إدارة النظام").setView(box).setPositiveButton("حفظ"){_,_->
            val x=a.text.toString();if(x.length<6||x!=b.text.toString()){status.text="كلمة المرور يجب أن تتطابق وألا تقل عن 6"}else{repo.setSystemPassword(x);status.text="✓ تم تأمين إدارة النظام";showSystemMenu()}
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun showSystemMenu(){
        val roleLabel=if(repo.installationRole=="AGENT")"وكيل • ${repo.approvalStatus}" else "مالك"
        val items=arrayOf("بيانات المحل والفرع","الدوام والسماح","قارئ البصمة الخارجي","التفعيل والخادم والمزامنة","الصلاحيات والوكيل ($roleLabel)","تشغيل BLE تلقائيًا: ${if(repo.autoScan)"نعم" else "لا"}","فحص جاهزية النظام","تغيير كلمة مرور النظام")
        AlertDialog.Builder(this).setTitle("إدارة النظام 🔒").setItems(items){_,which->when(which){
            0->showStoreSettings();1->showShiftDialog();2->showFingerprintDialog();3->showSyncDialog();4->showRoleSettings();5->{repo.autoScan=!repo.autoScan;if(repo.autoScan)scanner.start()else scanner.stop();status.text="تم تحديث تشغيل BLE"};6->runHealthCheck();7->changeSystemPassword()
        }}.setNegativeButton("إغلاق",null).show()
    }

    private fun showRoleSettings(){
        val options=arrayOf("مالك النظام — تحكم كامل","وكيل — إنشاء محل بانتظار موافقة المالك")
        AlertDialog.Builder(this).setTitle("الصلاحيات").setSingleChoiceItems(options,if(repo.installationRole=="AGENT")1 else 0){dialog,which->
            if(which==0){repo.installationRole="OWNER";repo.approvalStatus="APPROVED";repo.agentName="";status.text="تم تعيين هذه النسخة كمالك";dialog.dismiss()}
            else{dialog.dismiss();val name=UiKit.field(this,p,"اسم الوكيل").apply{setText(repo.agentName)};AlertDialog.Builder(this).setTitle("صلاحية وكيل").setView(name).setPositiveButton("حفظ"){_,_->repo.installationRole="AGENT";repo.agentName=name.text.toString();repo.approvalStatus=if(repo.activationToken.isBlank())"PENDING" else "APPROVED";status.text=if(repo.approvalStatus=="PENDING")"تم إنشاء المحل بصفة وكيل — بانتظار رمز/موافقة المالك" else "الوكيل معتمد"}.setNegativeButton("إلغاء",null).show()}
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun changeSystemPassword(){repo.systemPasswordHash="";createSystemPassword()}

    private fun showStoreSettings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val name=UiKit.field(this,p,"اسم المحل").apply{setText(repo.storeName)};val branch=UiKit.field(this,p,"رمز الفرع").apply{setText(repo.branchId)};box.addView(name);box.addView(branch)
        AlertDialog.Builder(this).setTitle("بيانات المحل").setView(box).setPositiveButton("حفظ"){_,_->repo.storeName=name.text.toString();repo.branchId=branch.text.toString();status.text="✓ تم حفظ بيانات المحل"}.setNegativeButton("إلغاء",null).show()
    }

    private fun showShiftDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val hour=UiKit.field(this,p,"ساعة البداية 0-23",true).apply{setText(repo.shiftHour.toString())};val minute=UiKit.field(this,p,"الدقيقة",true).apply{setText(repo.shiftMinute.toString())};val grace=UiKit.field(this,p,"دقائق السماح",true).apply{setText(repo.graceMinutes.toString())};listOf(hour,minute,grace).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("إعداد الدوام").setView(box).setPositiveButton("حفظ"){_,_->repo.shiftHour=hour.text.toString().toIntOrNull()?:8;repo.shiftMinute=minute.text.toString().toIntOrNull()?:0;repo.graceMinutes=grace.text.toString().toIntOrNull()?:10;status.text="✓ تم تحديث الدوام";refreshDashboard()}.setNegativeButton("إلغاء",null).show()
    }

    private fun showFingerprintDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val host=UiKit.field(this,p,"IP جهاز البصمة").apply{setText(repo.fingerprintHost)};val port=UiKit.field(this,p,"Port مثل 4370",true).apply{setText(repo.fingerprintPort.toString())};box.addView(host);box.addView(port)
        AlertDialog.Builder(this).setTitle("قارئ البصمة الخارجي").setView(box).setPositiveButton("حفظ واختبار"){_,_->repo.fingerprintHost=host.text.toString();repo.fingerprintPort=port.text.toString().toIntOrNull()?:4370;quickFingerprintCheck()}.setNegativeButton("إلغاء",null).show()
    }

    private fun showSyncDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,0)};val url=UiKit.field(this,p,"https://server.example.com").apply{setText(repo.serverUrl)};val tenant=UiKit.field(this,p,"Business / Tenant ID").apply{setText(repo.tenantId)};val token=UiKit.field(this,p,"رمز موافقة/تفعيل المالك").apply{setText(repo.activationToken)};listOf(url,tenant,token).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("التفعيل والخادم").setView(box).setPositiveButton("حفظ ومزامنة"){_,_->repo.serverUrl=url.text.toString();repo.tenantId=tenant.text.toString();repo.activationToken=token.text.toString();if(repo.installationRole=="AGENT")repo.approvalStatus=if(repo.activationToken.isBlank())"PENDING" else "APPROVED";val pending=repo.pendingEvents();if(pending.isEmpty()){status.text="تم الحفظ — لا توجد أحداث معلقة";return@setPositiveButton};status.text="جاري مزامنة ${pending.size} عملية...";Thread{val r=NetworkTools.syncEvents(repo.serverUrl,repo.tenantId,repo.activationToken,pending);runOnUiThread{if(r.isSuccess){repo.markSynced(r.getOrThrow());status.text="✓ تمت المزامنة";refreshDashboard()}else status.text="فشلت المزامنة: ${r.exceptionOrNull()?.message ?: "خطأ"}"}}.start()}.setNegativeButton("إلغاء",null).show()
    }

    private fun runHealthCheck(){
        val bt=getSystemService(BluetoothManager::class.java)?.adapter;val bluetoothState=when{bt==null->"غير مدعوم";!bt.isEnabled->"متوقف";else->"يعمل"};val paired=repo.employees().count{it.active};val pending=repo.pendingEvents().size
        AlertDialog.Builder(this).setTitle("فحص الجاهزية").setMessage("Bluetooth: $bluetoothState\nالموظفون النشطون: $paired\nأحداث غير مزامنة: $pending\nالدور: ${repo.installationRole}\nحالة الموافقة: ${repo.approvalStatus}\nالفرع: ${repo.branchId}").setPositiveButton("حسنًا",null).show()
    }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int){
        val employees=repo.employees().filter{it.active&&it.companionEnabled&&BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){val secret=SecretCodec.decode(employee.pairingSecret)?:continue;if(!BleProtocol.verify(payload,employee.employeeId,secret))continue;nearby[employee.employeeId]=System.currentTimeMillis() to rssi;if(payload.verified)maybeRecordVerified(employee,payload.token);runOnUiThread{refreshDashboard()};return}
    }

    private fun maybeRecordVerified(employee:PairedEmployee,token:Int){
        if(repo.lastProofToken(employee.employeeId)==token)return;val last=repo.lastEvent(employee.employeeId);if(last!=null&&System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return;val action=nextAction(employee.employeeId);repo.addEvent(AttendanceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,branchId=employee.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.PHONE_BLE_BIOMETRIC,deviceId=deviceId(),verified=true));repo.setLastProofToken(employee.employeeId,token);runOnUiThread{status.text="✓ ${employee.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"}"}
    }

    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        val now=System.currentTimeMillis();nearby.entries.removeIf{now-it.value.first>45_000L};val employees=repo.employees().filter{it.active};val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet();val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis())e.employeeId else null}.toSet();counts.text="الموظفون ${employees.size}   •   الحاضرون ${present.size}\nالمتأخرون ${late.size}   •   غير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}";nearbyView.text=if(nearby.isEmpty())"لا توجد هواتف موظفين قريبة الآن" else "هواتف قريبة: ${nearby.keys.joinToString("، "){id->employees.firstOrNull{it.employeeId==id}?.displayName?:id}}"
    }

    private fun shareTodayCsv(){val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))}
    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,repo.shiftHour);set(Calendar.MINUTE,repo.shiftMinute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);add(Calendar.MINUTE,repo.graceMinutes)}.timeInMillis
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==BleEmployeeScanner.REQUEST_PERMISSIONS){if(grantResults.isNotEmpty()&&grantResults.all{it==android.content.pm.PackageManager.PERMISSION_GRANTED}){status.text="تم منح صلاحيات BLE";if(repo.autoScan)scanner.start()}else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"}}
    override fun onDestroy(){scanner.stop();super.onDestroy()}
}
