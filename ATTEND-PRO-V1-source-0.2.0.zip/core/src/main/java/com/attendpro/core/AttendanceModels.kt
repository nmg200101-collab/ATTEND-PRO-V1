package com.attendpro.core

enum class AttendanceMethod {
    EXTERNAL_FINGERPRINT,
    PHONE_BIOMETRIC,
    SHARED_DEVICE_FACE,
    PIN,
    SUPERVISOR_OVERRIDE,
    MANUAL_ADMIN
}

enum class AttendanceAction { CHECK_IN, CHECK_OUT }

data class AttendanceEvent(
    val employeeId: String,
    val branchId: String,
    val timestampEpochMillis: Long,
    val action: AttendanceAction,
    val method: AttendanceMethod,
    val deviceId: String,
    val verified: Boolean
)

interface FingerprintDeviceAdapter {
    val vendorName: String
    suspend fun connect(): Result<Unit>
    suspend fun pullEvents(): Result<List<AttendanceEvent>>
    suspend fun disconnect()
}
