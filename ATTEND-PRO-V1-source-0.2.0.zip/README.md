# ATTEND-PRO-V1 Android Source 0.2.0

Clean Android source for the first official GitHub Actions build.

Modules:
- `employee-app`: employee phone app with platform biometric authentication.
- `store-app`: store/kiosk app startup-safe dashboard.
- `core`: shared attendance models and external fingerprint adapter contract.

This milestone intentionally keeps BLE/network/fingerprint-driver runtime logic disabled until the official build is proven stable on the target phone.
