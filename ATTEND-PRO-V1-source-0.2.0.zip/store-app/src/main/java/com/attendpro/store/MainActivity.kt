package com.attendpro.store

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 70, 40, 40)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(TextView(this).apply {
            text = "ATTEND PRO\nجهاز المحل"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "الحاضرون: 0    المتأخرون: 0    الغائبون: 0"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 45, 0, 35)
        })
        root.addView(Button(this).apply {
            text = "البحث عن هواتف الموظفين"
            isEnabled = false
        })
        root.addView(Button(this).apply {
            text = "جهاز البصمة الخارجي"
            isEnabled = false
        })
        root.addView(TextView(this).apply {
            text = "نسخة البناء الأولى المستقرة. سيتم تفعيل BLE وجهاز البصمة الخارجي في المرحلة التالية بعد نجاح أول Build رسمي."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 0)
        })
        setContentView(root)
    }
}
