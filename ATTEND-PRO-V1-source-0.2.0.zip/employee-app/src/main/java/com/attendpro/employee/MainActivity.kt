package com.attendpro.employee

import android.app.Activity
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Attend Pro - Employee"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 80, 40, 40)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val titleView = TextView(this).apply {
            text = "ATTEND PRO\nتطبيق الموظف"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "الجهاز جاهز للربط\nالإصدار 0.2.0"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 50, 0, 40)
        }
        val biometric = Button(this).apply {
            text = "تأكيد الهوية بالبصمة / الوجه"
            setOnClickListener { requestBiometric() }
        }
        val info = TextView(this).apply {
            text = "المرحلة التالية: ربط الهاتف بالمحل عبر BLE المشفر ثم إرسال إثبات التحقق."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 0)
        }

        root.addView(titleView)
        root.addView(status)
        root.addView(biometric)
        root.addView(info)
        setContentView(root)
    }

    private fun requestBiometric() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "هذا الإصدار يحتاج Android 9 أو أحدث للمصادقة البيومترية المدمجة."
            return
        }

        val prompt = BiometricPrompt.Builder(this)
            .setTitle("تأكيد الحضور")
            .setSubtitle("استخدم البصمة أو وسيلة القياسات الحيوية المسجلة في الهاتف")
            .setNegativeButton("إلغاء", mainExecutor) { _, _ ->
                status.text = "تم إلغاء التحقق"
            }
            .build()

        prompt.authenticate(
            CancellationSignal(),
            mainExecutor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    super.onAuthenticationSucceeded(result)
                    status.text = "✓ تم التحقق من الهوية بنجاح"
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    status.text = "لم يتم التعرف على الهوية، حاول مرة أخرى"
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    super.onAuthenticationError(errorCode, errString)
                    status.text = "تعذر التحقق: ${errString ?: "خطأ غير معروف"}"
                }
            }
        )
    }
}
