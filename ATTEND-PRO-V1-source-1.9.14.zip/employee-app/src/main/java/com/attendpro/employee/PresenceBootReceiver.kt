package com.attendpro.employee

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.attendpro.core.EmployeeIdentityStore

class PresenceBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val identity = EmployeeIdentityStore(context)
        if (!identity.isConfigured || !identity.autoPresence) return
        if (intent?.action == android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED &&
            intent.getIntExtra(android.bluetooth.BluetoothAdapter.EXTRA_STATE, -1) != android.bluetooth.BluetoothAdapter.STATE_ON) return
        val service = Intent(context, PresenceService::class.java).setAction(PresenceService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service) else context.startService(service)
    }
}
