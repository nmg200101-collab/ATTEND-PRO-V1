package com.attendpro.employee

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.attendpro.core.EmployeeIdentityStore

class PresenceService : Service() {
    companion object {
        const val ACTION_START = "com.attendpro.employee.PRESENCE_START"
        const val ACTION_PROOF = "com.attendpro.employee.PRESENCE_PROOF"
        const val ACTION_STOP = "com.attendpro.employee.PRESENCE_STOP"
        const val EXTRA_FLAGS = "flags"
        const val EXTRA_DURATION = "duration"
        private const val CHANNEL = "attend_presence"
        private const val NOTIFICATION_ID = 771
    }
    private lateinit var identity: EmployeeIdentityStore
    private lateinit var network: NetworkPresenceBroadcaster
    private lateinit var bluetooth: BlePresenceAdvertiser

    override fun onCreate() {
        super.onCreate(); identity = EmployeeIdentityStore(this)
        network = NetworkPresenceBroadcaster { }
        bluetooth = BlePresenceAdvertiser(this) { }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL,"اكتشاف جهاز المحل",NotificationManager.IMPORTANCE_LOW).apply {
            description = "يحافظ على التعرف الآمن على هاتف الموظف عبر الشبكة المحلية"
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !identity.autoPresence || !identity.isConfigured) {
            network.stop(); bluetooth.stop(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification())
        network.start(identity.employeeId, identity.pairingSecret)
        bluetooth.start(identity.employeeId, identity.pairingSecret)
        if (intent?.action == ACTION_PROOF) {
            val duration = intent.getLongExtra(EXTRA_DURATION,45_000L)
            val proof = intent.getIntExtra(EXTRA_FLAGS,0)
            network.markVerified(duration, proof)
            bluetooth.markVerified(duration, proof)
        }
        return START_STICKY
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_attend_pro)
            .setContentTitle("ATTEND PRO — هاتف الموظف")
            .setContentText("الظهور عبر Bluetooth وWi‑Fi يعمل حتى عند قفل الهاتف")
            .setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy(){network.stop();bluetooth.stop();super.onDestroy()}
    override fun onBind(intent: Intent?): IBinder? = null
}
