package com.attendpro.core

import org.json.JSONObject
import java.util.UUID

enum class AttendanceMethod {
    EXTERNAL_FINGERPRINT,
    PHONE_BLE_BIOMETRIC,
    PHONE_BIOMETRIC,
    SHARED_DEVICE_FACE,
    PIN,
    SUPERVISOR_OVERRIDE,
    MANUAL_ADMIN
}

enum class AttendanceAction { CHECK_IN, CHECK_OUT }

data class AttendanceEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val employeeId: String,
    val employeeName: String = "",
    val branchId: String,
    val timestampEpochMillis: Long,
    val action: AttendanceAction,
    val method: AttendanceMethod,
    val deviceId: String,
    val verified: Boolean,
    val synced: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("eventId", eventId)
        put("employeeId", employeeId)
        put("employeeName", employeeName)
        put("branchId", branchId)
        put("timestampEpochMillis", timestampEpochMillis)
        put("action", action.name)
        put("method", method.name)
        put("deviceId", deviceId)
        put("verified", verified)
        put("synced", synced)
    }

    companion object {
        fun fromJson(obj: JSONObject): AttendanceEvent = AttendanceEvent(
            eventId = obj.optString("eventId", UUID.randomUUID().toString()),
            employeeId = obj.getString("employeeId"),
            employeeName = obj.optString("employeeName", ""),
            branchId = obj.optString("branchId", "MAIN"),
            timestampEpochMillis = obj.getLong("timestampEpochMillis"),
            action = AttendanceAction.valueOf(obj.getString("action")),
            method = AttendanceMethod.valueOf(obj.getString("method")),
            deviceId = obj.optString("deviceId", "unknown"),
            verified = obj.optBoolean("verified", false),
            synced = obj.optBoolean("synced", false)
        )
    }
}

data class PairedEmployee(
    val employeeId: String,
    val displayName: String,
    val branchId: String,
    val pairingSecret: String,
    val pin: String = "",
    val phone: String = "",
    val jobTitle: String = "",
    val externalFingerprintId: String = "",
    val faceProfileRef: String = "",
    val companionEnabled: Boolean = true,
    val active: Boolean = true,
    val department: String = "",
    val nationalId: String = "",
    val hireDate: String = "",
    val notes: String = "",
    val faceCapturedAt: Long = 0L
)

interface FingerprintDeviceAdapter {
    val vendorName: String
    suspend fun connect(): Result<Unit>
    suspend fun pullEvents(): Result<List<AttendanceEvent>>
    suspend fun disconnect()
}
