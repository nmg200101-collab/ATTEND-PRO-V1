ATTEND PRO 1.5.0 — BUILD NOTES

Target:
- Android compileSdk/targetSdk 35
- Java 17
- Gradle workflow unchanged
- Modules: core, store-app, employee-app

Version:
- store-app: versionCode 15 / versionName 1.5.0
- employee-app: versionCode 15 / versionName 1.5.0

Key functional changes:
- ActivationProtocol.kt: request + ECDSA-signed device-bound license verification.
- OwnerSigningKeyStore: one-time bootstrap, then Android Keystore wrapping.
- StoreRepository: persistent license state, validation, employee limit, sync status.
- Store MainActivity: activation card, request QR, activation QR scan/paste, auto sync guard.
- SystemSettingsActivity: owner licensing center, QR request scanner, license issuance, QR response, license overview.
- Store manifest: CAMERA permission for the internal QR scanner.

Stability notes:
- No network call runs on the UI thread.
- Auto sync is guarded against duplicate concurrent runs.
- Invalid/expired/wrong-device activation tokens are rejected without closing the app.
- Existing 1.4.0 employee/store data remains backward-compatible.
- If no license is present, the app remains usable in local trial mode (10 employees) for testing.

Commercial limitation:
- Remote revocation, live usage analytics, agent/store cloud approval, and cross-device owner dashboard require deployment of the central server. They are not falsely simulated locally.
