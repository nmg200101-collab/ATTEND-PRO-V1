import org.gradle.api.initialization.resolve.RepositoriesMode

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

val baseArchive = file("../ATTEND-PRO-V1-source-1.9.23.zip")
require(baseArchive.exists()) {
    "Base source archive ATTEND-PRO-V1-source-1.9.23.zip was not found in repository root"
}

// Rehydrate the complete 1.9.23 project directly into the current build root.
// Keep this bootstrap settings file active; all other original project files are restored.
copy {
    from(zipTree(baseArchive)) {
        exclude("settings.gradle.kts")
    }
    into(rootDir)
}

val overlayDir = file("overlay")
require(overlayDir.exists()) { "1.9.26 connection overlay is missing" }
copy {
    from(overlayDir)
    into(rootDir)
}

println("ATTEND_PRO_PATCH: 1.9.26 connection fix overlay applied over 1.9.23")

rootProject.name = "ATTEND-PRO-V1"
include(":core", ":employee-app", ":store-app")
