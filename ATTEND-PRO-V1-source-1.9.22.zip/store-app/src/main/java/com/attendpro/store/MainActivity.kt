package com.attendpro.store

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.content.FileProvider
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.attendpro.core.AttendanceAction
import com.attendpro.core.AttendanceEvent
import com.attendpro.core.AttendanceMethod
import com.attendpro.core.AppUpdateManager
import com.attendpro.core.BleProtocol
import com.attendpro.core.CentralServerClient
import com.attendpro.core.DeviceIdentity
import com.attendpro.core.NetworkTools
import com.attendpro.core.PairedEmployee
import com.attendpro.core.PairingProtocol
import com.attendpro.core.PresenceEvent
import com.attendpro.core.QrCodeTools
import com.attendpro.core.SecretCodec
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var repo: StoreRepository
    private lateinit var scanner: BleEmployeeScanner
    private lateinit var networkListener: NetworkPresenceListener
    private lateinit var counts: TextView
    private lateinit var status: TextView
    private lateinit var nearbyView: TextView
    private lateinit var activityTimelineView: TextView
    private lateinit var attendanceTodayView: TextView
    private lateinit var storeSummary: TextView
    private lateinit var connectionSummaryView: TextView
    private lateinit var recentAttendanceSummaryView: TextView
    private var pendingFaceEmployeeId: String? = null
    private var pendingFaceRecognition: Boolean = false
    private var pendingFaceCapturePath: String? = null
    private val faceEnrollmentTemplates = mutableListOf<String>()
    private val faceEnrollmentQualities = mutableListOf<Int>()
    private var pendingLivenessEmployeeId: String? = null
    private var pendingLivenessFirstTemplate: String? = null
    private var pendingLivenessFirstScore: Float = 0f
    private var pendingVoiceEmployeeId: String? = null
    private var pendingVoiceChallenge: String? = null
    private var pendingVoicePrintScore: Float = -1f
    private var pendingVoiceEnrollmentEmployeeId: String? = null
    private val voiceEnrollmentTemplates = mutableListOf<String>()
    private val voiceEnrollmentQualities = mutableListOf<Int>()
    private val autoPresenceRecorded = mutableSetOf<String>()
    @Volatile private var syncInProgress = false
    private var employeeManagerMode = false
    private var recoveryAttempted = false
    private data class NearbyPhone(val seenAt: Long, val rssi: Int, val channelTimes: Map<String, Long>)
    private val nearby = linkedMapOf<String, NearbyPhone>()
    private val nearbyRefreshHandler = Handler(Looper.getMainLooper())
    private val nearbyRefreshTask = object : Runnable {
        override fun run() {
            if (::nearbyView.isInitialized) refreshDashboard()
            autoSyncIfReady()
            nearbyRefreshHandler.postDelayed(this, 5_000L)
        }
    }
    private val p by lazy { UiKit.palette(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = StoreRepository(this)
        val employeeManagerRequested = intent?.getBooleanExtra(EXTRA_EMPLOYEE_MANAGER, false) == true
        employeeManagerMode = employeeManagerRequested && repo.validateStoreAdminSession(intent?.getStringExtra(EXTRA_STORE_ADMIN_SESSION).orEmpty())
        pendingFaceEmployeeId = savedInstanceState?.getString("pendingFaceEmployeeId")
        pendingFaceRecognition = savedInstanceState?.getBoolean("pendingFaceRecognition", false) ?: false
        pendingFaceCapturePath = savedInstanceState?.getString("pendingFaceCapturePath")
        pendingLivenessEmployeeId = savedInstanceState?.getString("pendingLivenessEmployeeId")
        pendingLivenessFirstTemplate = savedInstanceState?.getString("pendingLivenessFirstTemplate")
        pendingLivenessFirstScore = savedInstanceState?.getFloat("pendingLivenessFirstScore", 0f) ?: 0f
        pendingVoiceEmployeeId = savedInstanceState?.getString("pendingVoiceEmployeeId")
        pendingVoiceChallenge = savedInstanceState?.getString("pendingVoiceChallenge")
        pendingVoicePrintScore = savedInstanceState?.getFloat("pendingVoicePrintScore", -1f) ?: -1f
        pendingVoiceEnrollmentEmployeeId = savedInstanceState?.getString("pendingVoiceEnrollmentEmployeeId")
        scanner = BleEmployeeScanner(this, { payload, rssi -> handleBlePayload(payload, rssi, "Bluetooth") }) { msg ->
            runOnUiThread { if (::status.isInitialized) status.text = msg }
        }
        networkListener = NetworkPresenceListener({ payload, rssi -> handleBlePayload(payload, rssi, "Wi‑Fi/Hotspot") }) { msg ->
            runOnUiThread { if (::status.isInitialized) status.text = msg }
        }
        AppUpdateManager.check(this, repo.serverUrl.ifBlank { AppUpdateManager.DEFAULT_SERVER }, "store")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingFaceEmployeeId?.let { outState.putString("pendingFaceEmployeeId", it) }
        outState.putBoolean("pendingFaceRecognition", pendingFaceRecognition)
        pendingFaceCapturePath?.let { outState.putString("pendingFaceCapturePath", it) }
        pendingLivenessEmployeeId?.let { outState.putString("pendingLivenessEmployeeId", it) }
        pendingLivenessFirstTemplate?.let { outState.putString("pendingLivenessFirstTemplate", it) }
        outState.putFloat("pendingLivenessFirstScore", pendingLivenessFirstScore)
        pendingVoiceEmployeeId?.let { outState.putString("pendingVoiceEmployeeId", it) }
        pendingVoiceChallenge?.let { outState.putString("pendingVoiceChallenge", it) }
        outState.putFloat("pendingVoicePrintScore", pendingVoicePrintScore)
        pendingVoiceEnrollmentEmployeeId?.let { outState.putString("pendingVoiceEnrollmentEmployeeId", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()
        nearbyRefreshHandler.removeCallbacks(nearbyRefreshTask)
        nearbyRefreshHandler.post(nearbyRefreshTask)
        if (!repo.isCentralActivationActive()) {
            runCatching { scanner.stop() }
            runCatching { networkListener.stop() }
            buildActivationLockUi()
            if (repo.hasCentralCredentials() && repo.serverUrl.isNotBlank()) validateCentralActivation(silent = true)
            else if (!recoveryAttempted && repo.serverUrl.isNotBlank()) {
                recoveryAttempted = true
                recoverCentralActivation(silent = true)
            }
            return
        }
        if (employeeManagerMode) {
            buildEmployeeManagerUi()
            refreshDashboard()
            validateCentralActivation(silent = true)
            return
        }
        buildElegantUi()
        refreshDashboard()
        if (repo.allowEmployeeCompanion && repo.autoScan && repo.employees().any { it.active && it.companionEnabled }) {
            runCatching { scanner.start() }.onFailure { if (::status.isInitialized) status.text = "تعذر تشغيل BLE: ${it.message ?: "خطأ"}" }
            runCatching { networkListener.start() }.onFailure { if (::status.isInitialized) status.text = "تعذر تشغيل اكتشاف Wi‑Fi: ${it.message ?: "خطأ"}" }
        }
        validateCentralActivation(silent = true)
        autoSyncIfReady()
    }

    private fun buildActivationLockUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val hero = UiKit.heroCard(this, p)
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 72), UiKit.dp(this@MainActivity, 72)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        hero.addView(UiKit.title(this, p, "ATTEND PRO", 28f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        hero.addView(UiKit.subtitle(this, p, "تفعيل مركزي محمي • الإصدار 1.9.22").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        root.addView(hero)

        val lock = UiKit.card(this, p)
        lock.addView(UiKit.statusBadge(this, p, "المحل غير مفعّل", false))
        lock.addView(UiKit.title(this, p, "يتطلب موافقة صاحب النظام", 23f).apply { gravity = Gravity.CENTER })
        val reason = when {
            repo.centralClockRollbackDetected() -> "تم اكتشاف اختلاف غير آمن في ساعة الجهاز. صحح التاريخ والوقت ثم أعد التحقق من الخادم."
            repo.centralServerStatus == "SUSPENDED" -> "تم تعليق هذا المحل مركزيًا من صاحب النظام. لا يمكن تسجيل حضور أو إدارة الموظفين حتى إعادة التفعيل."
            repo.centralServerStatus == "EXPIRED" -> "انتهت مدة التفعيل المركزي لهذا المحل. يلزم تجديدها من صاحب النظام."
            repo.hasCentralCredentials() && repo.centralLeaseUntil <= System.currentTimeMillis() -> "انتهت مهلة العمل دون اتصال. يلزم الاتصال بالخادم للتحقق من صلاحية المحل."
            repo.centralActivationRequestId.isNotBlank() -> "تم إرسال طلب التفعيل وهو بانتظار اعتماد صاحب النظام."
            else -> "لن تعمل الحضور والموظفون والتقارير التشغيلية قبل اعتماد هذا الجهاز من الخادم المركزي."
        }
        lock.addView(UiKit.subtitle(this, p, reason).apply { gravity = Gravity.CENTER; setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0) })
        root.addView(lock)

        val identity = UiKit.card(this, p)
        identity.addView(UiKit.sectionLabel(this, p, "بيانات طلب التفعيل"))
        identity.addView(UiKit.title(this, p, repo.storeName, 20f))
        identity.addView(UiKit.subtitle(this, p, "الفرع: ${repo.branchId}\nمعرف الجهاز: ${repo.storeId}\nالخادم: ${repo.serverUrl.ifBlank { "غير محدد" }}"))
        identity.addView(UiKit.button(this, p, "إعداد بيانات المحل والخادم", false).apply { setOnClickListener { editActivationSetup() } })
        root.addView(identity)

        val activation = UiKit.card(this, p)
        activation.addView(UiKit.sectionLabel(this, p, "التفعيل المركزي"))
        if (repo.centralActivationRequestId.isBlank() && !repo.hasCentralCredentials()) {
            activation.addView(UiKit.button(this, p, "استعادة تفعيل هذا الجهاز", false).apply { setOnClickListener { recoverCentralActivation(silent = false) } })
            activation.addView(UiKit.button(this, p, "إرسال طلب التفعيل لصاحب النظام").apply { setOnClickListener { requestCentralActivation() } })
        } else if (repo.centralActivationRequestId.isNotBlank()) {
            activation.addView(UiKit.button(this, p, "فحص موافقة صاحب النظام").apply { setOnClickListener { checkCentralActivation() } })
            activation.addView(UiKit.subtitle(this, p, "رقم الطلب: ${repo.centralActivationRequestId}"))
        }
        if (repo.hasCentralCredentials()) {
            activation.addView(UiKit.button(this, p, "التحقق من صلاحية المحل الآن").apply { setOnClickListener { validateCentralActivation(silent = false) } })
        }
        status = TextView(this).apply { text = "بانتظار التفعيل المركزي"; textSize = 15f; setTextColor(p.muted); gravity = Gravity.CENTER; setPadding(0, UiKit.dp(this@MainActivity, 8), 0, 0) }
        activation.addView(status)
        activation.addView(UiKit.button(this, p, "فحص تحديث التطبيق", false).apply {
            setOnClickListener { AppUpdateManager.check(this@MainActivity, repo.serverUrl.ifBlank { AppUpdateManager.DEFAULT_SERVER }, "store", manual = true) }
        })
        root.addView(activation)

        val receiverCard = UiKit.card(this, p, 13)
        receiverCard.addView(UiKit.sectionLabel(this, p, "هاتف المراقبة"))
        receiverCard.addView(UiKit.subtitle(this, p, "يمكن استخدام هذا الهاتف لاستلام تقارير محل آخر دون تفعيله كجهاز محل."))
        receiverCard.addView(UiKit.button(this, p, "فتح استلام التقارير", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, ReportReceiverActivity::class.java)) } })
        root.addView(receiverCard)

        val systemOwner = UiKit.card(this, p, 12)
        systemOwner.addView(UiKit.sectionLabel(this, p, "صاحب نظام ATTEND PRO"))
        systemOwner.addView(UiKit.subtitle(this, p, "إدارة الاعتمادات المركزية تتطلب مفتاح إدارة الخادم، وهي منفصلة عن صلاحيات صاحب المحل."))
        systemOwner.addView(UiKit.button(this, p, "دخول إدارة صاحب النظام", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, SystemSettingsActivity::class.java)) } })
        root.addView(systemOwner)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun editActivationSetup() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), 0) }
        val name = UiKit.field(this, p, "اسم المحل").apply { setText(if (repo.storeName == "جهاز المحل") "" else repo.storeName) }
        val branch = UiKit.field(this, p, "اسم / رمز الفرع").apply { setText(repo.branchId) }
        val server = UiKit.field(this, p, "https://your-server.example.com").apply { setText(repo.serverUrl) }
        box.addView(name); box.addView(branch); box.addView(server)
        val d = AlertDialog.Builder(this).setTitle("إعداد التفعيل المركزي").setView(box).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()
        d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val n = name.text.toString().trim(); val b = branch.text.toString().trim(); val u = server.text.toString().trim()
            if (n.length < 2) { name.error = "أدخل اسم المحل"; return@setOnClickListener }
            if (b.isBlank()) { branch.error = "أدخل الفرع"; return@setOnClickListener }
            if (!u.startsWith("https://")) { server.error = "الخادم يجب أن يستخدم HTTPS"; return@setOnClickListener }
            repo.storeName = n; repo.branchId = b; repo.serverUrl = u
            d.dismiss(); buildActivationLockUi()
        } }
        d.show()
    }

    private fun validateCentralActivation(silent: Boolean) {
        if (repo.serverUrl.isBlank() || !repo.hasCentralCredentials()) { if (!silent) info("التفعيل المركزي", "بيانات الخادم أو الترخيص المركزي غير مكتملة."); return }
        if (::status.isInitialized && !silent) status.text = "جاري التحقق الآمن من الخادم..."
        Thread {
            val identity = DeviceIdentity(this)
            val result = CentralServerClient.validateStore(repo.serverUrl, repo.centralAccessToken, repo.storeId, identity)
            if (result.getOrNull()?.status.equals("ACTIVE", true)) {
                CentralServerClient.enrollRecovery(repo.serverUrl, repo.centralAccessToken, repo.storeId, identity)
            }
            runOnUiThread {
                if (result.isFailure) {
                    if (!silent && ::status.isInitialized) status.text = "تعذر التحقق: ${result.exceptionOrNull()?.message ?: "خطأ اتصال"}"
                    return@runOnUiThread
                }
                val v = result.getOrThrow()
                if (v.status.equals("ACTIVE", true)) {
                    val wasLocked = !repo.isCentralActivationActive()
                    repo.refreshCentralLease("ACTIVE", v.expiresAt, v.maxEmployees, v.leaseUntil, v.serverTime)
                    if (!repo.isCentralActivationActive()) {
                        repo.markCentralInactive("VALIDATION_REQUIRED", v.serverTime)
                        buildActivationLockUi()
                        if (!silent) info("التفعيل المركزي", "استجابة الخادم لم تمنح مهلة تشغيل صالحة. حدّث الخادم المركزي إلى الإصدار المتوافق مع 1.9.2.")
                    } else if (wasLocked || !silent) {
                        employeeManagerMode = false
                        buildElegantUi(); refreshDashboard()
                        if (!silent) info("التفعيل المركزي", "تم التحقق من صلاحية المحل بنجاح.")
                    }
                } else {
                    repo.markCentralInactive(v.status, v.serverTime)
                    runCatching { scanner.stop() }
                    runCatching { networkListener.stop() }
                    buildActivationLockUi()
                    if (!silent) info("تم إيقاف التشغيل", v.reason.ifBlank { "حالة المحل على الخادم: ${v.status}" })
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun buildUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 14), UiKit.dp(this@MainActivity, 14), UiKit.dp(this@MainActivity, 14), UiKit.dp(this@MainActivity, 30))
            setBackgroundColor(p.bg)
        }

        val header = UiKit.heroCard(this, p, 16).apply { gravity = Gravity.CENTER_HORIZONTAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_attend_pro)
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 52), UiKit.dp(this@MainActivity, 52))
        })
        header.addView(UiKit.title(this, p, "ATTEND PRO", 25f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        header.addView(UiKit.subtitle(this, p, "نظام حضور المحل • الإصدار 1.9.22").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(225,255,255,255)) })
        storeSummary = UiKit.subtitle(this, p, storeSummaryText()).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(235,255,255,255)); setPadding(0, UiKit.dp(this@MainActivity, 5), 0, 0) }
        header.addView(storeSummary)
        root.addView(header)

        if (!repo.isStoreProfileComplete) {
            val setup = UiKit.card(this, p, 13)
            setup.addView(UiKit.sectionLabel(this, p, "إكمال إعداد المحل"))
            setup.addView(UiKit.subtitle(this, p, "أكمل معلومات المحل من «قسم مالك العمل» قبل التشغيل الفعلي.").apply { gravity = Gravity.CENTER })
            setup.addView(UiKit.button(this, p, "فتح قسم مالك العمل", false).apply { setOnClickListener { startActivity(Intent(this@MainActivity, StoreSettingsActivity::class.java)) } })
            root.addView(setup)
        }

        status = TextView(this).apply { text = "النظام جاهز"; textSize = 14f; setTextColor(p.muted); gravity = Gravity.CENTER }

        val connectionCard = UiKit.card(this, p, 14).apply {
            isClickable = true
            isFocusable = true
            setOnClickListener { showConnectionCenter() }
        }
        val connectionTitle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        connectionTitle.addView(UiKit.title(this, p, "حالة الاتصال والأجهزة", 19f).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        connectionTitle.addView(UiKit.statusBadge(this, p, "● مباشر", true).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
        connectionCard.addView(connectionTitle)
        connectionSummaryView = UiKit.subtitle(this, p, "جاري فحص الأجهزة المتصلة…").apply { textSize = 15f; setTextColor(p.text); setPadding(0, UiKit.dp(this@MainActivity, 6), 0, UiKit.dp(this@MainActivity, 5)) }
        connectionCard.addView(connectionSummaryView)
        connectionCard.addView(UiKit.subtitle(this, p, "اضغط لعرض أسماء الأجهزة ونوع الاتصال وآخر وقت ظهور"))
        root.addView(connectionCard)

        val attendanceHub = UiKit.card(this, p, 18).apply { gravity = Gravity.CENTER_HORIZONTAL }
        attendanceHub.addView(UiKit.title(this, p, "تسجيل الحضور والانصراف", 22f).apply { gravity = Gravity.CENTER })
        attendanceHub.addView(UiKit.subtitle(this, p, "اضغط على البصمة واختر طريقة التحقق المعتمدة للموظف").apply { gravity = Gravity.CENTER })
        val attendanceButton = TextView(this).apply {
            text = "◎\nتسجيل الحضور"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(p.primary)
                setStroke(UiKit.dp(this@MainActivity, 4), p.accent)
            }
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 190), UiKit.dp(this@MainActivity, 190)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = UiKit.dp(this@MainActivity, 14)
                bottomMargin = UiKit.dp(this@MainActivity, 14)
            }
            setOnClickListener { showAttendanceMethods() }
        }
        attendanceHub.addView(attendanceButton)
        attendanceHub.addView(UiKit.subtitle(this, p, "وجه • صوت • بصمة الهاتف • GPS • رمز شخصي • جهاز بصمة").apply { gravity = Gravity.CENTER })
        val attendanceActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        attendanceActions.addView(UiKit.button(this, p, "كل طرق التحقق", false).apply { layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 50), 1f).apply { marginEnd = UiKit.dp(this@MainActivity, 4) }; setOnClickListener { showAttendanceMethods() } })
        attendanceActions.addView(UiKit.button(this, p, "إثبات الوجود", false).apply { layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 50), 1f).apply { marginStart = UiKit.dp(this@MainActivity, 4) }; setOnClickListener { showPresenceChallenge() } })
        attendanceHub.addView(attendanceActions)
        root.addView(attendanceHub)

        val dash = UiKit.card(this, p, 14)
        dash.addView(UiKit.sectionLabel(this, p, "ملخص اليوم"))
        counts = TextView(this).apply { textSize = 17f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER; setLineSpacing(0f, 1.2f) }
        dash.addView(counts)
        root.addView(dash)

        val nearbyCard = UiKit.card(this, p, 14)
        nearbyCard.addView(UiKit.sectionLabel(this, p, "الأجهزة الموجودة الآن"))
        nearbyView = TextView(this).apply { textSize = 15f; setTextColor(p.text); setPadding(0, UiKit.dp(this@MainActivity, 10), 0, UiKit.dp(this@MainActivity, 8)); gravity = Gravity.CENTER }
        nearbyCard.addView(nearbyView)
        nearbyCard.addView(UiKit.button(this, p, "فتح مركز الاتصال", false).apply { setOnClickListener { showConnectionCenter() } })
        root.addView(nearbyCard)

        val attendanceListCard = UiKit.card(this, p, 14)
        attendanceListCard.addView(UiKit.sectionLabel(this, p, "آخر عمليات الحضور اليوم"))
        attendanceTodayView = TextView(this).apply {
            textSize = 15f; setTextColor(p.text); setPadding(0, UiKit.dp(this@MainActivity, 10), 0, UiKit.dp(this@MainActivity, 8)); gravity = Gravity.START
        }
        attendanceListCard.addView(attendanceTodayView)
        attendanceListCard.addView(UiKit.button(this, p, "عرض سجل الحضور والاتصال", false).apply { setOnClickListener { showConnectionAttendanceHistory() } })
        root.addView(attendanceListCard)

        val services = UiKit.card(this, p, 14)
        services.addView(UiKit.sectionLabel(this, p, "الخدمات والإدارة"))
        fun serviceRow(first: Pair<String, () -> Unit>, second: Pair<String, () -> Unit>) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            listOf(first, second).forEach { item -> row.addView(UiKit.button(this, p, item.first, false).apply { layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 54), 1f).apply { marginStart = UiKit.dp(this@MainActivity, 4); marginEnd = UiKit.dp(this@MainActivity, 4); bottomMargin = UiKit.dp(this@MainActivity, 8) }; setOnClickListener { item.second() } }) }
            services.addView(row)
        }
        serviceRow("الموظفون والإعدادات" to { startActivity(Intent(this, StoreSettingsActivity::class.java)) }, "التقارير" to { startActivity(Intent(this, ReportsActivity::class.java)) })
        serviceRow("استلام التقارير" to { startActivity(Intent(this, ReportReceiverActivity::class.java)) }, "بيانات التفعيل" to { showLicenseDetails() })
        serviceRow("فحص التحديث" to { AppUpdateManager.check(this, repo.serverUrl.ifBlank { AppUpdateManager.DEFAULT_SERVER }, "store", manual = true) }, "إثبات وجود" to { showPresenceChallenge() })
        services.addView(status)
        root.addView(services)

        val timelineCard = UiKit.card(this, p, 12)
        timelineCard.addView(UiKit.sectionLabel(this, p, "آخر نشاط للنظام"))
        activityTimelineView = TextView(this).apply {
            textSize = 14f; setTextColor(p.text); setPadding(0, UiKit.dp(this@MainActivity, 10), 0, UiKit.dp(this@MainActivity, 8)); gravity = Gravity.START
        }
        timelineCard.addView(activityTimelineView)
        root.addView(timelineCard)

        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun buildElegantUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 13), UiKit.dp(this@MainActivity, 13), UiKit.dp(this@MainActivity, 13), UiKit.dp(this@MainActivity, 28))
            setBackgroundColor(p.bg)
        }

        fun tile(title: String, subtitle: String, action: () -> Unit): LinearLayout = UiKit.card(this, p, 12).apply {
            isClickable = true; isFocusable = true
            addView(UiKit.title(this@MainActivity, p, title, 16.5f).apply { gravity = Gravity.CENTER })
            addView(UiKit.subtitle(this@MainActivity, p, subtitle).apply { gravity = Gravity.CENTER; textSize = 12.5f; maxLines = 3 })
            setOnClickListener { action() }
        }

        fun tileRow(first: LinearLayout, second: LinearLayout) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            first.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = UiKit.dp(this@MainActivity, 4) }
            second.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = UiKit.dp(this@MainActivity, 4) }
            row.addView(first); row.addView(second)
            row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            root.addView(row)
        }

        val header = UiKit.heroCard(this, p, 14)
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_attend_pro); layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 48), UiKit.dp(this@MainActivity, 48)) })
        header.addView(UiKit.title(this, p, "ATTEND PRO", 23f).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) })
        storeSummary = UiKit.subtitle(this, p, storeSummaryText()).apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.WHITE) }
        header.addView(storeSummary)
        header.addView(UiKit.subtitle(this, p, "الإصدار 1.9.22").apply { gravity = Gravity.CENTER; setTextColor(android.graphics.Color.argb(215,255,255,255)) })
        root.addView(header)

        status = TextView(this).apply { text = "النظام جاهز"; textSize = 13f; setTextColor(p.muted); gravity = Gravity.CENTER }
        connectionSummaryView = UiKit.subtitle(this, p, "جاري فحص الأجهزة…").apply { gravity = Gravity.CENTER; textSize = 12.5f; maxLines = 3 }
        recentAttendanceSummaryView = UiKit.subtitle(this, p, "لا توجد عملية حضور اليوم").apply { gravity = Gravity.CENTER; textSize = 12.5f; maxLines = 3 }
        val connectionTile = tile("◉ الاتصال الآن", "الخادم والأجهزة القريبة") { showConnectionCenter() }.apply {
            removeViewAt(1); addView(connectionSummaryView)
        }
        val recentTile = tile("✓ آخر حضور", "عرض آخر عمليات اليوم") { showConnectionAttendanceHistory() }.apply {
            removeViewAt(1); addView(recentAttendanceSummaryView)
        }
        tileRow(connectionTile, recentTile)

        val summary = UiKit.card(this, p, 10)
        counts = TextView(this).apply { textSize = 15f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER; setLineSpacing(0f, 1.12f) }
        summary.addView(counts)
        root.addView(summary)

        val attendance = UiKit.card(this, p, 14).apply { gravity = Gravity.CENTER_HORIZONTAL }
        attendance.addView(UiKit.title(this, p, "تسجيل الحضور والانصراف", 19f).apply { gravity = Gravity.CENTER })
        val finger = TextView(this).apply {
            text = "◎\nحضور"
            textSize = 18f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD); setTextColor(android.graphics.Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.primary, p.accent)).apply { shape = GradientDrawable.OVAL; setStroke(UiKit.dp(this@MainActivity, 3), android.graphics.Color.argb(120,255,255,255)) }
            layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 132), UiKit.dp(this@MainActivity, 132)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = UiKit.dp(this@MainActivity, 10); bottomMargin = UiKit.dp(this@MainActivity, 10) }
            elevation = UiKit.dp(this@MainActivity, 5).toFloat()
            setOnClickListener { showAttendanceMethods() }
        }
        attendance.addView(finger)
        attendance.addView(UiKit.subtitle(this, p, "اضغط لاختيار طريقة التحقق المسموح بها").apply { gravity = Gravity.CENTER })
        root.addView(attendance)

        root.addView(UiKit.sectionLabel(this, p, "الأقسام الرئيسية").apply { textSize = 15f })
        tileRow(
            tile("🔒 مالك المحل", "بيانات المحل والموظفون وطرق الحضور") { startActivity(Intent(this, StoreSettingsActivity::class.java)) },
            tile("◆ صاحب النظام", "التفعيل المركزي وإدارة المحلات") { startActivity(Intent(this, SystemSettingsActivity::class.java)) }
        )
        tileRow(
            tile("الموظفون", "إضافة وربط وملفات التعرف") { startActivity(Intent(this, StoreSettingsActivity::class.java)) },
            tile("التقارير", "الحضور والانصراف والمشاركة") { startActivity(Intent(this, ReportsActivity::class.java)) }
        )
        tileRow(
            tile("الأجهزة المتصلة", "Bluetooth وWi‑Fi والخادم") { showConnectionCenter() },
            tile("إثبات الوجود", "إرسال طلب تحقق للموظف") { showPresenceChallenge() }
        )
        tileRow(
            tile("طرق الحضور", "الوجه والصوت والبصمة والرموز") { showAttendanceMethods() },
            tile("التفعيل", "الاشتراك وصلاحية هذا الجهاز") { showLicenseDetails() }
        )
        tileRow(
            tile("استلام التقارير", "استقبال تقرير من محل آخر") { startActivity(Intent(this, ReportReceiverActivity::class.java)) },
            tile("تحديث التطبيق", "فحص أحدث إصدار متاح") { AppUpdateManager.check(this, repo.serverUrl.ifBlank { AppUpdateManager.DEFAULT_SERVER }, "store", manual = true) }
        )

        val footer = UiKit.card(this, p, 9)
        footer.addView(status)
        root.addView(footer)
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(p.bg); addView(root) })
    }

    private fun buildEmployeeManagerUi() {
        window.statusBarColor = p.bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 16), UiKit.dp(this@MainActivity, 28)); setBackgroundColor(p.bg)
        }
        val header = UiKit.card(this, p)
        header.addView(UiKit.sectionLabel(this, p, "قسم مالك العمل"))
        header.addView(UiKit.title(this, p, "الموظفون وملفات التعرف", 24f))
        header.addView(UiKit.subtitle(this, p, "إضافة وتعديل الموظفين وتحديد طرق حضور مستقلة لكل موظف: PIN، كلمة مرور، نقش، تحقق صوتي، GPS، بصمة خارجية، الوجه، وهاتف الموظف."))
        root.addView(header)

        val summaryCard = UiKit.card(this, p)
        counts = TextView(this).apply { textSize = 17f; setTextColor(p.text); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER }
        summaryCard.addView(counts)
        root.addView(summaryCard)

        val actions = UiKit.card(this, p)
        actions.addView(UiKit.button(this, p, "＋ إضافة موظف جديد").apply { setOnClickListener { showEmployeeEditor(null) } })
        actions.addView(UiKit.button(this, p, "عرض الموظفين وتعديلهم", false).apply { setOnClickListener { showEmployeesDialog() } })
        actions.addView(UiKit.button(this, p, "شرح طرق التعرف", false).apply { setOnClickListener { showFaceEngineInfo() } })
        root.addView(actions)

        val recognitions = UiKit.card(this, p)
        val employees = repo.employees().filter { it.active }
        recognitions.addView(UiKit.sectionLabel(this, p, "جاهزية طرق التعرف"))
        recognitions.addView(UiKit.subtitle(this, p, "PIN ${employees.count { it.pin.isNotBlank() }} • كلمة مرور ${employees.count { it.passwordHash.isNotBlank() }} • نقش ${employees.count { it.patternHash.isNotBlank() }} • صوت ${employees.count { it.voicePhraseHash.isNotBlank() }}\nوجه أولي ${employees.count { it.faceProfileRef.isNotBlank() }} • بصمة خارجية ${employees.count { it.externalFingerprintId.isNotBlank() }} • هاتف ${employees.count { it.companionEnabled }}"))
        root.addView(recognitions)

        val state = UiKit.card(this, p, 10)
        status = TextView(this).apply { text = "جاهز لإدارة الموظفين"; textSize = 15f; setTextColor(p.text); gravity = Gravity.CENTER }
        nearbyView = TextView(this).apply { text = ""; textSize = 13f; setTextColor(p.muted); gravity = Gravity.CENTER }
        state.addView(status); state.addView(nearbyView)
        state.addView(UiKit.button(this, p, "رجوع إلى إعدادات المحل", false).apply { setOnClickListener { finish() } })
        root.addView(state)
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) })
    }

    private fun autoSyncIfReady() {
        if (!repo.reportAutoSync || syncInProgress || repo.serverUrl.isBlank() || !repo.isCentralActivationActive()) return
        val pending = repo.pendingEvents()
        syncInProgress = true
        Thread {
            val identity = DeviceIdentity(this)
            val result = CentralServerClient.syncEventsCentral(repo.serverUrl, repo.centralAccessToken, repo.storeId, identity, pending.take(200))
            val pulled = if (result.isSuccess) CentralServerClient.pullEmployeeAttendance(
                repo.serverUrl, repo.centralAccessToken, repo.storeId, identity, repo.attendancePullCursor
            ) else Result.failure<CentralServerClient.AttendancePull>(result.exceptionOrNull() ?: IllegalStateException("تعذر رفع العمليات المحلية"))
            if (repo.isCentralActivationActive()) {
                CentralServerClient.confirmedTransfers(repo.serverUrl, repo.centralAccessToken, repo.storeId, identity).getOrNull()?.forEach { repo.confirmReportTransferTrusted(it) }
            }
            runOnUiThread {
                syncInProgress = false
                if (result.isSuccess) {
                    repo.markSynced(result.getOrThrow())
                    val pull = pulled.getOrNull()
                    val received = if (pull != null) repo.mergeServerEvents(pull.events) else 0
                    if (pull != null) repo.attendancePullCursor = pull.cursor
                    repo.lastSyncAt = System.currentTimeMillis()
                    repo.lastSyncMessage = "تمت المزامنة"
                    if (::status.isInitialized && (result.getOrThrow().isNotEmpty() || received > 0)) status.text =
                        "✓ تمت المزامنة${if (received > 0) " • وصل $received تسجيل من هواتف الموظفين" else ""}"
                    refreshDashboard()
                } else {
                    val message = result.exceptionOrNull()?.message ?: "خطأ"
                    repo.lastSyncMessage = "فشلت: $message"
                    if (message.contains("موقوف") || message.contains("غير صالح") || message.contains("انتهت")) {
                        repo.markCentralInactive(if (message.contains("انتهت")) "EXPIRED" else "SUSPENDED")
                        runCatching { scanner.stop() }
                        runCatching { networkListener.stop() }
                        buildActivationLockUi()
                    }
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun storeSummaryText(): String {
        val parts = mutableListOf<String>()
        parts.add(repo.storeName)
        parts.add("فرع ${repo.branchId}")
        if (repo.storePhone.isNotBlank()) parts.add(repo.storePhone)
        return parts.joinToString(" • ")
    }

    private fun showActivationCenter() {
        val items = mutableListOf<String>()
        if (repo.centralActivationRequestId.isBlank() && !repo.hasCentralCredentials()) items.add("إرسال طلب تفعيل مركزي")
        if (repo.centralActivationRequestId.isNotBlank()) items.add("فحص موافقة صاحب النظام")
        if (repo.hasCentralCredentials()) items.add("التحقق من صلاحية المحل الآن")
        if (repo.isCentralActivationActive()) items.add("عرض بيانات التفعيل المركزي")
        items.add("إعداد بيانات المحل والخادم")
        items.add("نسخ معرّف جهاز المحل")
        AlertDialog.Builder(this).setTitle("التفعيل المركزي — ATTEND PRO").setItems(items.toTypedArray()) { _, which ->
            when (items[which]) {
                "إرسال طلب تفعيل مركزي" -> requestCentralActivation()
                "فحص موافقة صاحب النظام" -> checkCentralActivation()
                "التحقق من صلاحية المحل الآن" -> validateCentralActivation(silent = false)
                "عرض بيانات التفعيل المركزي" -> showLicenseDetails()
                "إعداد بيانات المحل والخادم" -> editActivationSetup()
                "نسخ معرّف جهاز المحل" -> copyActivationText(repo.storeId, "تم نسخ معرّف الجهاز")
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun requestCentralActivation() {
        if (repo.serverUrl.isBlank()) {
            val field = UiKit.field(this, p, "https://server.example.com")
            val d = AlertDialog.Builder(this).setTitle("عنوان الخادم المركزي").setMessage("أدخل رابط HTTPS الذي زودك به مدير نظام ATTEND PRO.").setView(field).setPositiveButton("متابعة", null).setNegativeButton("إلغاء", null).create()
            d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val url = field.text.toString().trim()
                if (!url.startsWith("https://")) { field.error = "يجب استخدام HTTPS"; return@setOnClickListener }
                repo.serverUrl = url; d.dismiss(); showActivationRequestForm()
            } }
            d.show(); return
        }
        showActivationRequestForm()
    }

    private fun showActivationRequestForm() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 12, 28, 4) }
        scroll.addView(box)
        val owner = UiKit.field(this, p, "اسم صاحب المحل").apply { setText(repo.storeManagerName) }
        val store = UiKit.field(this, p, "اسم المحل").apply { setText(repo.storeName.takeUnless { it == "محلي" }.orEmpty()) }
        val subscription = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("اشتراك شهري", "اشتراك سنوي", "تجربة 3 أيام"))
        }
        val phone = UiKit.field(this, p, "رقم الهاتف — اختياري").apply { setText(repo.storePhone) }
        val address = UiKit.field(this, p, "العنوان — اختياري").apply { setText(repo.storeAddress) }
        val commercial = UiKit.field(this, p, "السجل / الرقم التجاري — اختياري").apply { setText(repo.storeCommercialId) }
        val notes = UiKit.field(this, p, "معلومات إضافية — اختياري").apply { setText(repo.storeNotes); minLines = 2 }
        box.addView(UiKit.subtitle(this, p, "أدخل البيانات الأساسية للطلب. تجربة 3 أيام لا تبدأ إلا بعد موافقة صاحب النظام."))
        listOf(owner, store).forEach { box.addView(it) }
        box.addView(UiKit.sectionLabel(this, p, "نوع الاشتراك")); box.addView(subscription)
        listOf(phone, address, commercial, notes).forEach { box.addView(it) }
        val dialog = AlertDialog.Builder(this).setTitle("طلب تفعيل ATTEND PRO").setView(scroll)
            .setPositiveButton("إرسال الطلب", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val ownerName = owner.text.toString().trim(); val storeName = store.text.toString().trim()
                if (ownerName.isBlank() || storeName.isBlank()) {
                    owner.error = if (ownerName.isBlank()) "اسم صاحب المحل مطلوب" else null
                    store.error = if (storeName.isBlank()) "اسم المحل مطلوب" else null
                    return@setOnClickListener
                }
                val type = arrayOf("MONTHLY", "YEARLY", "TRIAL_3_DAYS")[subscription.selectedItemPosition]
                repo.storeManagerName = ownerName; repo.storeName = storeName; repo.storePhone = phone.text.toString().trim()
                repo.storeAddress = address.text.toString().trim(); repo.storeCommercialId = commercial.text.toString().trim(); repo.storeNotes = notes.text.toString().trim()
                dialog.dismiss()
                submitCentralActivationRequest(CentralServerClient.ActivationApplicant(ownerName, storeName, type,
                    repo.storePhone, repo.storeAddress, repo.storeCommercialId, repo.storeNotes))
            }
        }
        dialog.show()
    }

    private fun recoverCentralActivation(silent: Boolean) {
        if (!silent && ::status.isInitialized) status.text = "جاري البحث عن تفعيل سابق لهذا الجهاز..."
        Thread {
            val result = CentralServerClient.recoverActivation(repo.serverUrl, DeviceIdentity(this))
            runOnUiThread {
                if (result.isFailure) {
                    if (!silent) info("استعادة التفعيل", result.exceptionOrNull()?.message ?: "لا يوجد تفعيل سابق مطابق وآمن لهذا الجهاز")
                    return@runOnUiThread
                }
                val x = result.getOrThrow()
                repo.adoptRecoveredStore(x.storeId, x.storeName, x.branchId)
                repo.saveCentralActivation(x.licenseId, x.accessToken, x.expiresAt, x.maxEmployees, x.leaseUntil, x.serverTime)
                buildElegantUi(); refreshDashboard()
                info("تمت استعادة التفعيل ✓", "تعرف الخادم على الجهاز واستبدل مفتاح التثبيت السابق بأمان. لا يلزم إنشاء اشتراك أو محل جديد.")
            }
        }.apply { isDaemon = true }.start()
    }

    private fun submitCentralActivationRequest(applicant: CentralServerClient.ActivationApplicant) {
        status.text = "جاري إرسال طلب التفعيل المركزي..."
        Thread {
            val r = CentralServerClient.requestActivation(repo.serverUrl, repo.storeId, repo.branchId, applicant, DeviceIdentity(this))
            runOnUiThread {
                if (r.isSuccess) {
                    val x = r.getOrThrow(); repo.centralActivationRequestId = x.requestId; repo.centralActivationPollSecret = x.pollSecret
                    status.text = "✓ تم إرسال طلب التفعيل المركزي"
                    AlertDialog.Builder(this).setTitle("تم إرسال الطلب").setMessage("رقم الطلب: ${x.requestId}\n\nسيظهر الطلب في لوحة صاحب النظام. بعد اعتماده اضغط «فحص حالة طلب التفعيل المركزي». لا ترسل سر الطلب لأي شخص.").setPositiveButton("حسنًا", null).show()
                    buildActivationLockUi()
                } else {
                    status.text = "تعذر إرسال طلب التفعيل"
                    AlertDialog.Builder(this).setTitle("تعذر الاتصال بالخادم").setMessage(r.exceptionOrNull()?.message ?: "خطأ").setPositiveButton("حسنًا", null).show()
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun checkCentralActivation() {
        val requestId = repo.centralActivationRequestId; val pollSecret = repo.centralActivationPollSecret
        if (requestId.isBlank() || pollSecret.isBlank()) { AlertDialog.Builder(this).setTitle("التفعيل المركزي").setMessage("لا يوجد طلب مركزي محفوظ على هذا الجهاز.").setPositiveButton("حسنًا", null).show(); return }
        status.text = "جاري التحقق من التفعيل..."
        Thread {
            val r = CentralServerClient.activationStatus(repo.serverUrl, requestId, pollSecret, repo.storeId, DeviceIdentity(this))
            runOnUiThread {
                if (r.isFailure) { status.text = "تعذر فحص التفعيل"; AlertDialog.Builder(this).setTitle("الخادم المركزي").setMessage(r.exceptionOrNull()?.message ?: "خطأ").setPositiveButton("حسنًا", null).show(); return@runOnUiThread }
                val x = r.getOrThrow()
                when (x.status.uppercase(Locale.US)) {
                    "APPROVED", "ACTIVE" -> {
                        if (x.accessToken.isBlank() || x.licenseId.isBlank() || x.leaseUntil <= System.currentTimeMillis() || x.serverTime <= 0L) {
                            status.text = "استجابة تفعيل غير مكتملة"
                            AlertDialog.Builder(this).setTitle("تحديث الخادم مطلوب").setMessage("الخادم لم يرسل مهلة تشغيل آمنة. استخدم خادم ATTEND PRO المركزي المتوافق مع الإصدار 1.9.2.").setPositiveButton("حسنًا", null).show()
                            return@runOnUiThread
                        }
                        repo.saveCentralActivation(x.licenseId, x.accessToken, x.expiresAt, x.maxEmployees, x.leaseUntil, x.serverTime)
                        status.text = "✓ تم تفعيل المحل مركزيًا"; buildElegantUi(); refreshDashboard()
                        AlertDialog.Builder(this).setTitle("تم التفعيل المركزي ✓").setMessage("أصبح هذا الجهاز مرتبطًا بالخادم. ستعمل مزامنة الحضور والتقارير عن بعد مع استمرار التسجيل محليًا عند انقطاع الإنترنت.").setPositiveButton("حسنًا", null).show()
                    }
                    "REJECTED", "SUSPENDED" -> { status.text = "طلب التفعيل غير نشط"; AlertDialog.Builder(this).setTitle("حالة التفعيل").setMessage(x.reason.ifBlank { x.status }).setPositiveButton("حسنًا", null).show() }
                    else -> { status.text = "طلب التفعيل بانتظار اعتماد صاحب النظام"; AlertDialog.Builder(this).setTitle("بانتظار الاعتماد").setMessage("لم يعتمد صاحب النظام الطلب بعد.").setPositiveButton("حسنًا", null).show() }
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun showLicenseDetails() {
        if (!repo.hasCentralCredentials()) {
            AlertDialog.Builder(this).setTitle("حالة التفعيل").setMessage("لا يوجد تفعيل مركزي محفوظ على هذا الجهاز.").setPositiveButton("حسنًا", null).show()
            return
        }
        val expires = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(repo.centralActivationExpiresAt))
        val lease = if (repo.centralLeaseUntil > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(repo.centralLeaseUntil)) else "غير متاح"
        AlertDialog.Builder(this).setTitle("بيانات التفعيل المركزي")
            .setMessage("المحل: ${repo.storeName}\nالفرع: ${repo.branchId}\nرقم الترخيص: ${repo.centralLicenseId}\nالحالة: ${repo.centralServerStatus}\nانتهاء الاشتراك: $expires\nمهلة العمل دون اتصال: $lease\nحد الموظفين: ${repo.centralMaxEmployees}\nالجهاز: ${repo.storeId}\nالخادم: ${repo.serverUrl}\n\nرمز الوصول محفوظ مشفرًا داخل Android Keystore ولا يظهر في الواجهة.")
            .setPositiveButton("تحقق الآن") { _, _ -> validateCentralActivation(silent = false) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun copyActivationText(text: String, message: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("ATTEND PRO", text))
        if (::status.isInitialized) status.text = message
    }

    private fun showAttendanceMethods(){
        val actions=mutableListOf<Pair<String,()->Unit>>()
        if(repo.allowPinFallback) actions.add("PIN" to { showPinDialog() })
        if(repo.allowPasswordFallback) actions.add("كلمة المرور" to { showPasswordDialog() })
        if(repo.allowPatternFallback) actions.add("النقش 3×3" to { showPatternDialog() })
        if(repo.allowVoiceVerification) actions.add("العبارة الصوتية (تعرف على الكلام)" to { showVoiceDialog() })
        if(repo.allowGpsVerification) actions.add("GPS + PIN" to { showGpsDialog() })
        if(repo.allowEmployeeCompanion) actions.add("التعرف على هاتف الموظف" to {
            if(scanner.isScanning() || networkListener.isRunning()){scanner.stop();networkListener.stop();status.text="تم إيقاف اكتشاف الهواتف"}
            else{scanner.start();networkListener.start();status.text="جاري الاكتشاف عبر Wi‑Fi/نقطة الاتصال وBluetooth"}
        })
        if(repo.allowExternalFingerprint) actions.add("قارئ البصمة الخارجي (يتطلب تعريف الجهاز)" to { quickFingerprintCheck() })
        if(repo.allowFaceEnrollment) actions.add("التعرف المحلي بالوجه (أولي)" to { requestFaceRecognition() })
        if(actions.isEmpty()) {
            AlertDialog.Builder(this).setTitle("طرق الحضور").setMessage("لا توجد طريقة حضور مفعلة. افتح قسم مالك العمل ← طرق الحضور والتحقق.").setPositiveButton("حسنًا",null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("اختر طريقة الحضور").setItems(actions.map{it.first}.toTypedArray()){_,which->actions[which].second()}.setNegativeButton("إغلاق",null).show()
    }

    private fun showFaceEngineInfo(){
        AlertDialog.Builder(this).setTitle("التعرف بالوجه على جهاز المحل")
            .setMessage("في 1.9.8 يُسجل الوجه من خمس وضعيات، ويُطلب تحدٍ حركي وصورة ثانية قبل قبول الحضور. هذا فحص حيوية تفاعلي محلي محسّن، وليس نظام anti-spoof تجاريًا معتمدًا.")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun quickFingerprintCheck(){
        if(repo.fingerprintHost.isBlank()){status.text="أدخل بيانات قارئ البصمة من قسم مالك العمل أولًا";return}
        status.text="جاري اختبار قارئ البصمة..."
        Thread{val r=NetworkTools.probeTcp(repo.fingerprintHost,repo.fingerprintPort);runOnUiThread{
            status.text=if(r.isSuccess)"✓ قارئ البصمة متصل — استيراد البصمات يحتاج Driver الموديل" else "تعذر الاتصال بالقارئ: ${r.exceptionOrNull()?.message ?: "خطأ"}"
        }}.start()
    }

    private fun showEmployeesDialog(){
        val employees=repo.employees()
        val labels=mutableListOf("＋ إضافة موظف جديد")
        labels.addAll(employees.map{"${if(it.active)"●" else "○"} ${it.displayName} (${it.employeeId})${if(it.jobTitle.isNotBlank())" • ${it.jobTitle}" else ""}"})
        AlertDialog.Builder(this).setTitle("الموظفون (${employees.size})").setItems(labels.toTypedArray()){_,which->
            if(which==0) showEmployeeEditor(null) else showEmployeeDetails(employees[which-1])
        }.setNegativeButton("إغلاق",null).show()
    }

    private fun showEmployeeEditor(existing: PairedEmployee?) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 10) }
        scroll.addView(box)

        box.addView(UiKit.subtitle(this, p, "أدخل البيانات الأساسية أولًا، ثم أكمل ملف التعرف: خمس وضعيات للوجه، ثلاث عينات لنبرة الصوت، وربط هاتف الموظف واختباره. الحقول الفارغة عند التعديل تُبقي البيانات الحالية."))
        val id = UiKit.field(this, p, "رقم الموظف").apply { setText(existing?.employeeId.orEmpty()); isEnabled = existing == null }
        val name = UiKit.field(this, p, "اسم الموظف").apply { setText(existing?.displayName.orEmpty()) }
        val phone = UiKit.field(this, p, "رقم الهاتف - اختياري").apply { setText(existing?.phone.orEmpty()) }
        val job = UiKit.field(this, p, "المسمى الوظيفي").apply { setText(existing?.jobTitle.orEmpty()) }
        val department = UiKit.field(this, p, "القسم / الإدارة - اختياري").apply { setText(existing?.department.orEmpty()) }
        val nationalId = UiKit.field(this, p, "رقم الهوية - اختياري").apply { setText(existing?.nationalId.orEmpty()) }
        val hireDate = UiKit.field(this, p, "تاريخ التعيين - اختياري").apply { setText(existing?.hireDate.orEmpty()) }
        val branch = UiKit.field(this, p, "الفرع").apply { setText(existing?.branchId ?: repo.branchId) }
        listOf(id, name, phone, job, department, nationalId, hireDate, branch).forEach { box.addView(it) }

        box.addView(UiKit.sectionLabel(this, p, "وقت دوام الموظف"))
        val customShift = CheckBox(this).apply {
            text = "استخدام دوام مستقل لهذا الموظف"; setTextColor(p.text); isChecked = existing?.useCustomShift ?: false
        }
        val startHour = UiKit.field(this, p, "ساعة بداية الدوام 0-23", true).apply { setText((existing?.shiftStartHour ?: repo.shiftHour).toString()) }
        val startMinute = UiKit.field(this, p, "دقيقة البداية", true).apply { setText((existing?.shiftStartMinute ?: repo.shiftMinute).toString()) }
        val endHour = UiKit.field(this, p, "ساعة انتهاء الدوام 0-23", true).apply { setText((existing?.shiftEndHour ?: repo.shiftEndHour).toString()) }
        val endMinute = UiKit.field(this, p, "دقيقة الانتهاء", true).apply { setText((existing?.shiftEndMinute ?: repo.shiftEndMinute).toString()) }
        box.addView(customShift); listOf(startHour, startMinute, endHour, endMinute).forEach { box.addView(it) }
        box.addView(UiKit.subtitle(this, p, "إذا لم تفعل الدوام المستقل سيستخدم الموظف وقت الدوام العام للمحل."))

        box.addView(UiKit.sectionLabel(this, p, "1 — رموز التحقق الاحتياطية"))
        val pin = UiKit.field(this, p, "PIN جديد 4-8 أرقام - اتركه فارغًا للإبقاء الحالي", true)
        val password = UiKit.field(this, p, "كلمة مرور جديدة - اتركها فارغة للإبقاء الحالي").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val pattern = UiKit.field(this, p, "نقش 3×3 كتسلسل 1-9 مثل 12589 - اتركه فارغًا للإبقاء الحالي", true)
        val voicePhrase = UiKit.field(this, p, "العبارة الأساسية للصوت (مثال: أنا حاضر للعمل) - اتركها فارغة للإبقاء الحالي")
        val fingerprint = UiKit.field(this, p, "معرف الموظف في قارئ البصمة - اختياري").apply { setText(existing?.externalFingerprintId.orEmpty()) }
        listOf(pin, password, pattern, voicePhrase, fingerprint).forEach { box.addView(it) }
        box.addView(UiKit.subtitle(this, p, "العبارة المكتوبة وحدها لا تكفي: بعد الحفظ ستظهر شاشة إعداد واضحة لتسجيل نبرة الموظف ثلاث مرات. عند الحضور يطابق النظام النبرة والعبارة وكلمة تحدٍ متغيرة."))

        box.addView(UiKit.sectionLabel(this, p, "2 — طرق الحضور المسموح بها"))
        fun currentAllowed(method: AttendanceMethod, globalEnabled: Boolean): Boolean {
            if (!globalEnabled) return false
            return existing?.let { it.allowedMethods.isEmpty() || it.allows(method) } ?: true
        }
        fun methodCheck(label: String, method: AttendanceMethod, globalEnabled: Boolean): CheckBox = CheckBox(this).apply {
            text = label; setTextColor(p.text); isChecked = currentAllowed(method, globalEnabled); isEnabled = globalEnabled
            if (!globalEnabled) text = "$label — معطل من إعدادات المحل"
        }
        val methodChecks = linkedMapOf(
            AttendanceMethod.PIN to methodCheck("PIN", AttendanceMethod.PIN, repo.allowPinFallback),
            AttendanceMethod.PASSWORD to methodCheck("كلمة المرور", AttendanceMethod.PASSWORD, repo.allowPasswordFallback),
            AttendanceMethod.PATTERN to methodCheck("النقش 3×3", AttendanceMethod.PATTERN, repo.allowPatternFallback),
            AttendanceMethod.VOICE_PHRASE to methodCheck("بصمة الصوت / العبارة الصوتية", AttendanceMethod.VOICE_PHRASE, repo.allowVoiceVerification),
            AttendanceMethod.GPS to methodCheck("GPS + PIN", AttendanceMethod.GPS, repo.allowGpsVerification),
            AttendanceMethod.SHARED_DEVICE_FACE to methodCheck("ملف الوجه على جهاز المحل", AttendanceMethod.SHARED_DEVICE_FACE, repo.allowFaceEnrollment),
            AttendanceMethod.EXTERNAL_FINGERPRINT to methodCheck("بصمة الإصبع عبر الجهاز الخارجي", AttendanceMethod.EXTERNAL_FINGERPRINT, repo.allowExternalFingerprint),
            AttendanceMethod.PHONE_BLE_BIOMETRIC to methodCheck("بصمة/وجه هاتف الموظف", AttendanceMethod.PHONE_BLE_BIOMETRIC, repo.allowEmployeeCompanion),
            AttendanceMethod.PHONE_FINGERPRINT to methodCheck("بصمة إصبع هاتف الموظف فقط", AttendanceMethod.PHONE_FINGERPRINT, repo.allowEmployeeCompanion),
            AttendanceMethod.PHONE_BIOMETRIC to methodCheck("تأكيد PIN/كلمة مرور من هاتف الموظف", AttendanceMethod.PHONE_BIOMETRIC, repo.allowEmployeeCompanion),
            AttendanceMethod.PHONE_PROXIMITY to methodCheck("التعرف التلقائي على هاتف الموظف", AttendanceMethod.PHONE_PROXIMITY, repo.allowEmployeeCompanion)
        )
        methodChecks.values.forEach { box.addView(it) }

        val faceEnroll = CheckBox(this).apply {
            text = if (existing?.faceProfileRef.isNullOrBlank()) "تسجيل بصمة الوجه بعد الحفظ" else "تحديث بصمة الوجه بعد الحفظ"
            setTextColor(p.text); isChecked = existing == null && repo.allowFaceEnrollment; isEnabled = repo.allowFaceEnrollment
        }
        val voiceEnroll = CheckBox(this).apply {
            text = if (existing?.voiceTemplate.isNullOrBlank()) "تسجيل بصمة نبرة الصوت بعد الحفظ (3 تسجيلات)" else "تحديث بصمة نبرة الصوت بعد الحفظ (3 تسجيلات)"
            setTextColor(p.text); isChecked = existing == null && repo.allowVoiceVerification; isEnabled = repo.allowVoiceVerification
        }
        val companion = CheckBox(this).apply {
            text = "السماح بربط تطبيق الموظف بهذا الهاتف"; setTextColor(p.text)
            isChecked = (existing?.companionEnabled ?: true) && repo.allowEmployeeCompanion
            isEnabled = repo.allowEmployeeCompanion
        }
        box.addView(UiKit.sectionLabel(this, p, "3 — تجهيز ملفات التعرف والربط"))
        box.addView(faceEnroll); box.addView(voiceEnroll); box.addView(companion)
        box.addView(UiKit.subtitle(this, p, "بعد الحفظ يفتح مركز تجهيز الموظف. منه تستطيع أخذ صور الوجه، تسجيل نبرة الصوت، إنشاء QR لهاتف الموظف، ثم اختبار ظهوره فعليًا عبر Bluetooth وWi‑Fi/نقطة الاتصال. GPS يُنقل في QR من موقع المحل المضبوط."))
        val notes = UiKit.field(this, p, "ملاحظات - اختياري").apply { setText(existing?.notes.orEmpty()); minLines = 2 }
        box.addView(notes)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة موظف" else "تعديل الموظف")
            .setView(scroll).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employeeId = id.text.toString().trim(); val displayName = name.text.toString().trim()
                if (employeeId.isBlank() || displayName.isBlank()) {
                    id.error = if (employeeId.isBlank()) "مطلوب" else null; name.error = if (displayName.isBlank()) "مطلوب" else null; return@setOnClickListener
                }
                if (existing == null && repo.employees().size >= repo.effectiveEmployeeLimit()) {
                    AlertDialog.Builder(this).setTitle("حد الموظفين").setMessage("الترخيص الحالي يسمح بحد أقصى ${repo.effectiveEmployeeLimit()} موظفين.").setPositiveButton("حسنًا", null).show(); return@setOnClickListener
                }
                if (existing == null && repo.employees().any { it.employeeId.equals(employeeId, true) }) { id.error = "رقم الموظف مستخدم بالفعل"; return@setOnClickListener }
                val newPin = pin.text.toString().trim()
                if (newPin.isNotBlank() && (newPin.length !in 4..8 || newPin.any { !it.isDigit() })) { pin.error = "استخدم 4 إلى 8 أرقام"; return@setOnClickListener }
                val newPassword = password.text.toString()
                if (newPassword.isNotBlank() && newPassword.length < 4) { password.error = "استخدم 4 أحرف/أرقام على الأقل"; return@setOnClickListener }
                val sh = startHour.text.toString().toIntOrNull(); val sm = startMinute.text.toString().toIntOrNull()
                val eh = endHour.text.toString().toIntOrNull(); val em = endMinute.text.toString().toIntOrNull()
                if (sh == null || sh !in 0..23) { startHour.error = "0 إلى 23"; return@setOnClickListener }
                if (sm == null || sm !in 0..59) { startMinute.error = "0 إلى 59"; return@setOnClickListener }
                if (eh == null || eh !in 0..23) { endHour.error = "0 إلى 23"; return@setOnClickListener }
                if (em == null || em !in 0..59) { endMinute.error = "0 إلى 59"; return@setOnClickListener }
                val newPattern = pattern.text.toString().trim()
                if (newPattern.isNotBlank() && (newPattern.length !in 4..9 || newPattern.any { it !in '1'..'9' } || newPattern.toSet().size != newPattern.length)) {
                    pattern.error = "استخدم 4-9 نقاط مختلفة من 1 إلى 9"; return@setOnClickListener
                }
                val selectedMethods = methodChecks.filterValues { it.isChecked }.keys.map { it.name }.toSet()
                if (selectedMethods.isEmpty()) { info("طرق الحضور", "فعّل طريقة حضور واحدة على الأقل لهذا الموظف."); return@setOnClickListener }

                val secret = existing?.pairingSecret?.takeIf { SecretCodec.isValid(it) } ?: SecretCodec.encode(SecretCodec.generate())
                val pinHash = if (newPin.isBlank()) existing?.pin.orEmpty() else PairingProtocol.pinHash(newPin)
                val passwordHash = if (newPassword.isBlank()) existing?.passwordHash.orEmpty() else PairingProtocol.pinHash(newPassword)
                val patternHash = if (newPattern.isBlank()) existing?.patternHash.orEmpty() else PairingProtocol.pinHash(newPattern)
                val phraseNormalized = normalizeVoicePhrase(voicePhrase.text.toString())
                val voiceHash = if (phraseNormalized.isBlank()) existing?.voicePhraseHash.orEmpty() else PairingProtocol.pinHash(phraseNormalized)
                if (AttendanceMethod.PIN.name in selectedMethods && pinHash.isBlank()) { pin.error = "أدخل PIN لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.PASSWORD.name in selectedMethods && passwordHash.isBlank()) { password.error = "أدخل كلمة مرور لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.PATTERN.name in selectedMethods && patternHash.isBlank()) { pattern.error = "أدخل نقشًا لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.VOICE_PHRASE.name in selectedMethods && voiceHash.isBlank()) { voicePhrase.error = "أدخل العبارة الصوتية لأن هذه الطريقة مفعلة"; return@setOnClickListener }
                if (AttendanceMethod.EXTERNAL_FINGERPRINT.name in selectedMethods && fingerprint.text.toString().trim().isBlank()) { fingerprint.error = "أدخل معرف البصمة الخارجية أو عطّل هذه الطريقة مؤقتًا"; return@setOnClickListener }
                val phoneMethodSelected = AttendanceMethod.PHONE_BLE_BIOMETRIC.name in selectedMethods || AttendanceMethod.PHONE_FINGERPRINT.name in selectedMethods || AttendanceMethod.PHONE_BIOMETRIC.name in selectedMethods || AttendanceMethod.PHONE_PROXIMITY.name in selectedMethods
                if (phoneMethodSelected && !companion.isChecked) { info("هاتف الموظف", "فعّل «السماح بربط تطبيق الموظف» لأن إحدى طرق الهاتف مفعلة لهذا الموظف."); return@setOnClickListener }
                if (AttendanceMethod.GPS.name in selectedMethods && !companion.isChecked && pinHash.isBlank()) { pin.error = "GPS على جهاز المحل يحتاج PIN؛ أو فعّل تطبيق الموظف لاستخدام GPS من هاتفه"; return@setOnClickListener }
                val employee = PairedEmployee(
                    employeeId = employeeId, displayName = displayName,
                    branchId = branch.text.toString().trim().ifBlank { repo.branchId }, pairingSecret = secret,
                    pin = pinHash, phone = phone.text.toString().trim(), jobTitle = job.text.toString().trim(),
                    externalFingerprintId = fingerprint.text.toString().trim(), faceProfileRef = existing?.faceProfileRef.orEmpty(),
                    companionEnabled = companion.isChecked, active = existing?.active ?: true,
                    department = department.text.toString().trim(), nationalId = nationalId.text.toString().trim(), hireDate = hireDate.text.toString().trim(),
                    notes = notes.text.toString().trim(), faceCapturedAt = existing?.faceCapturedAt ?: 0L,
                    passwordHash = passwordHash, patternHash = patternHash, voicePhraseHash = voiceHash, allowedMethods = selectedMethods,
                    useCustomShift = customShift.isChecked, shiftStartHour = sh, shiftStartMinute = sm, shiftEndHour = eh, shiftEndMinute = em,
                    faceTemplate = existing?.faceTemplate.orEmpty(), faceQualityScore = existing?.faceQualityScore ?: 0,
                    voiceTemplate = existing?.voiceTemplate.orEmpty(), voiceQualityScore = existing?.voiceQualityScore ?: 0,
                    voicePhraseText = if (phraseNormalized.isBlank()) existing?.voicePhraseText.orEmpty() else phraseNormalized
                )
                repo.upsertEmployee(employee); status.text = "✓ تم حفظ ${employee.displayName}"; refreshDashboard(); dialog.dismiss()
                showEmployeeEnrollmentCenter(employee, faceEnroll.isChecked, voiceEnroll.isChecked)
            }
        }
        dialog.show()
    }

    private fun showEmployeeEnrollmentCenter(employee: PairedEmployee, suggestFace: Boolean = false, suggestVoice: Boolean = false) {
        val current = repo.employees().firstOrNull { it.employeeId.equals(employee.employeeId, true) } ?: employee
        val recentlySeen = nearby[current.employeeId]?.seenAt?.let { System.currentTimeMillis() - it < 90_000L } == true
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 12))
        }
        scroll.addView(box)
        box.addView(UiKit.subtitle(this, p, buildString {
            append("أكمل تجهيز ${current.displayName} بالترتيب التالي:\n")
            append("الوجه: ${if (current.faceTemplate.isNotBlank()) "✓ جاهز (${current.faceQualityScore}/100)" else "غير مسجل"}\n")
            append("نبرة الصوت: ${if (current.voiceTemplate.isNotBlank()) "✓ جاهزة (${current.voiceQualityScore}/100)" else "غير مسجلة"}\n")
            append("تطبيق الموظف: ${if (!current.companionEnabled) "معطل" else if (recentlySeen) "✓ تم اكتشافه الآن" else "بانتظار مسح QR والاختبار"}")
        }))
        lateinit var dialog: AlertDialog
        fun action(label: String, primary: Boolean = false, block: () -> Unit) {
            box.addView(UiKit.button(this, p, label, primary).apply { setOnClickListener { dialog.dismiss(); block() } })
        }
        if (repo.allowFaceEnrollment) action(if (current.faceTemplate.isBlank()) "1 — تسجيل الوجه من خمس وضعيات" else "تحديث صور وبصمة الوجه", suggestFace) { requestFaceCapture(current) }
        if (repo.allowVoiceVerification) action(if (current.voiceTemplate.isBlank()) "2 — تسجيل نبرة الصوت (3 عينات)" else "تحديث نبرة الصوت (3 عينات)", suggestVoice && !suggestFace) { requestVoiceEnrollment(current) }
        if (current.companionEnabled) {
            action("3 — عرض QR ونقل ملف الموظف إلى هاتفه") { showProvisionQr(current) }
            action("4 — اختبار ارتباط الهاتف الآن") { testEmployeePhoneLink(current) }
        }
        dialog = AlertDialog.Builder(this).setTitle("تجهيز الموظف — ${current.displayName}").setView(scroll).setNegativeButton("إغلاق", null).create()
        dialog.show()
    }

    private fun testEmployeePhoneLink(employee: PairedEmployee) {
        if (!employee.companionEnabled) { info("هاتف الموظف", "ربط تطبيق الموظف معطل لهذا الموظف."); return }
        nearby.remove(employee.employeeId)
        runCatching { scanner.start() }
        runCatching { networkListener.start() }
        status.text = "اختبار ${employee.displayName}: افتح تطبيق الموظف وشغّل Bluetooth واتصل بنفس Wi‑Fi أو نقطة الاتصال…"
        info("اختبار ارتباط هاتف الموظف", "افتح تطبيق ATTEND PRO للموظف بعد مسح QR، وفعّل Bluetooth والموقع. اجعل الهاتفين على شبكة Wi‑Fi واحدة أو اربط جهاز المحل بنقطة اتصال هاتف الموظف. سيُفحص الارتباط لمدة 20 ثانية.")
        Handler(Looper.getMainLooper()).postDelayed({
            val seen = nearby[employee.employeeId]
            if (seen != null && System.currentTimeMillis() - seen.seenAt < 25_000L) {
                status.text = "✓ تم اكتشاف وربط هاتف ${employee.displayName} فعليًا"
                info("نجح اختبار الهاتف ✓", "تم التحقق من هوية الربط السرية عبر ${seen.channelTimes.keys.joinToString(" + ")}. قوة الإشارة ${seen.rssi} dBm. أصبح الهاتف جاهزًا للتعرف التلقائي وتأكيد الوجه/البصمة الأصلية.")
            } else {
                status.text = "لم يظهر هاتف ${employee.displayName} في الاختبار"
                info("لم يكتمل اختبار الهاتف", "تحقق من مسح QR الصحيح، وفتح تطبيق الموظف، ومنح الأجهزة القريبة والموقع، وإلغاء تقييد البطارية. فعّل Bluetooth واجعل الهاتفين على Wi‑Fi واحدة أو استخدم نقطة اتصال الموظف، ثم أعد الاختبار.")
            }
        }, 20_000L)
    }

    private fun askShowProvision(e:PairedEmployee){
        AlertDialog.Builder(this).setTitle("تم حفظ الموظف").setMessage("هل تريد الآن عرض QR تطبيق الموظف؟ هذه الخطوة اختيارية؛ الموظف مسجل في جهاز المحل حتى لو لم يستخدم التطبيق.")
            .setPositiveButton("عرض QR"){_,_->showProvisionQr(e)}.setNegativeButton("لاحقًا",null).show()
    }

    private fun showEmployeeDetails(e: PairedEmployee) {
        val faceDate = if (e.faceCapturedAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(e.faceCapturedAt)) else ""
        val msg = buildString {
            append("الرقم: ${e.employeeId}\nالاسم: ${e.displayName}\nالفرع: ${e.branchId}")
            append("\nالدوام: ${employeeShiftLabel(e)}")
            if (e.jobTitle.isNotBlank()) append("\nالمسمى: ${e.jobTitle}")
            if (e.department.isNotBlank()) append("\nالقسم: ${e.department}")
            if (e.phone.isNotBlank()) append("\nالهاتف: ${e.phone}")
            if (e.nationalId.isNotBlank()) append("\nالهوية: ${e.nationalId}")
            if (e.hireDate.isNotBlank()) append("\nتاريخ التعيين: ${e.hireDate}")
            append("\nPIN: ${if (e.pin.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nكلمة المرور: ${if (e.passwordHash.isBlank()) "غير مضافة" else "مضافة"}")
            append("\nالنقش: ${if (e.patternHash.isBlank()) "غير مضاف" else "مضاف"}")
            append("\nالتحقق الصوتي: ${if (e.voiceTemplate.isBlank()) "غير مسجل" else "مسجل • جودة ${e.voiceQualityScore}/100"}")
            append("\nقارئ البصمة: ${e.externalFingerprintId.ifBlank { "غير مربوط" }}")
            append("\nالوجه: ${if (e.faceProfileRef.isBlank()) "غير مسجل" else "مسجل${if (faceDate.isNotBlank()) " • $faceDate" else ""}${if (e.faceTemplate.isNotBlank()) " • قالب جاهز ${e.faceQualityScore}/100" else " • يحتاج تحديث"}"}")
            append("\nتطبيق الموظف: ${if (e.companionEnabled) "مسموح" else "معطل"}")
            append("\nطرق الحضور: ${allowedMethodsArabic(e)}")
            append("\nالحالة: ${if (e.active) "نشط" else "موقوف"}")
            if (e.notes.isNotBlank()) append("\nملاحظات: ${e.notes}")
        }

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 20), UiKit.dp(this@MainActivity, 12))
        }
        scroll.addView(box)
        box.addView(UiKit.subtitle(this, p, msg).apply {
            setPadding(0, 0, 0, UiKit.dp(this@MainActivity, 10))
        })

        lateinit var dialog: AlertDialog
        fun addAction(label: String, primary: Boolean = false, action: () -> Unit) {
            box.addView(UiKit.button(this, p, label, primary).apply {
                setOnClickListener {
                    dialog.dismiss()
                    action()
                }
            })
        }

        addAction("✎ تعديل بيانات الموظف", true) { showEmployeeEditor(e) }
        addAction("مركز إعداد الوجه والصوت وهاتف الموظف", true) { showEmployeeEnrollmentCenter(e) }
        if (repo.allowFaceEnrollment && e.allows(AttendanceMethod.SHARED_DEVICE_FACE)) addAction("تسجيل / تحديث بصمة الوجه") { requestFaceCapture(e) }
        if (repo.allowVoiceVerification && e.allows(AttendanceMethod.VOICE_PHRASE)) addAction("تسجيل / تحديث نبرة الصوت") { requestVoiceEnrollment(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("عرض صورة بصمة الوجه") { showFaceReference(e) }
        if (e.faceProfileRef.isNotBlank()) addAction("حذف بصمة الوجه") { deleteFaceReference(e) }
        if (e.companionEnabled) addAction("عرض QR تطبيق الموظف") { showProvisionQr(e) }
        addAction("تسجيل يدوي بإشراف") { recordManual(e) }
        addAction(if (e.active) "إيقاف الموظف" else "تفعيل الموظف") {
            repo.upsertEmployee(e.copy(active = !e.active))
            status.text = "تم تحديث حالة ${e.displayName}"
            refreshDashboard()
        }
        addAction("حذف الموظف") {
            AlertDialog.Builder(this).setTitle("حذف الموظف").setMessage("حذف ${e.displayName} من جهاز المحل؟ لن تحذف سجلات الحضور السابقة.")
                .setPositiveButton("حذف") { _, _ ->
                    deleteFaceFile(e.faceProfileRef)
                    repo.removeEmployee(e.employeeId)
                    status.text = "تم حذف الموظف"
                    refreshDashboard()
                }
                .setNegativeButton("إلغاء", null).show()
        }

        dialog = AlertDialog.Builder(this)
            .setTitle("ملف الموظف — ${e.displayName}")
            .setView(scroll)
            .setNegativeButton("إغلاق", null)
            .create()
        dialog.show()
    }

    private fun requestFaceCapture(employee: PairedEmployee) {
        faceEnrollmentTemplates.clear()
        faceEnrollmentQualities.clear()
        pendingFaceEmployeeId = employee.employeeId
        pendingFaceRecognition = false
        AlertDialog.Builder(this).setTitle("تسجيل الوجه من 5 وضعيات")
            .setMessage("سنلتقط خمس صور: أمامية، يمين، يسار، لأعلى قليلًا، ولأسفل قليلًا. انزع النظارات الداكنة واجعل الوجه واضحًا وفي إضاءة ثابتة.")
            .setPositiveButton("بدء") { _, _ -> ensureCameraAndLaunch() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun requestFaceRecognition() {
        val candidates = repo.employees().filter { it.active && it.allows(AttendanceMethod.SHARED_DEVICE_FACE) && it.faceTemplate.isNotBlank() }
        if (candidates.isEmpty()) {
            info("بصمة الوجه", "لا يوجد موظف لديه قالب وجه جاهز. افتح قسم مالك العمل ← الموظفون ثم حدّث وجه الموظف مرة واحدة على الأقل.")
            return
        }
        pendingFaceEmployeeId = null
        pendingFaceRecognition = true
        pendingLivenessEmployeeId = null; pendingLivenessFirstTemplate = null; pendingLivenessFirstScore = 0f
        ensureCameraAndLaunch()
    }

    private fun ensureCameraAndLaunch() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
            if (::status.isInitialized) status.text = "اسمح بالكاميرا لإكمال بصمة الوجه"
            return
        }
        launchFaceCamera()
    }

    private fun launchFaceCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val dir = File(cacheDir, "face_capture").apply { mkdirs() }
        val file = File(dir, "face_${System.currentTimeMillis()}.jpg")
        pendingFaceCapturePath = file.absolutePath
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        cameraIntent.clipData = ClipData.newRawUri("ATTEND PRO face capture", uri)
        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // بعض تطبيقات الكاميرا تتجاهل اختيار العدسة؛ هذه الإشارة تفضّل الأمامية دون الاعتماد عليها.
        cameraIntent.putExtra("android.intent.extras.CAMERA_FACING", 1)
        runCatching { startActivityForResult(cameraIntent, REQUEST_FACE_CAPTURE) }.onFailure {
            clearPendingFaceCapture()
            if (::status.isInitialized) status.text = "تعذر فتح الكاميرا: ${it.message ?: "خطأ"}"
            info("تعذر تسجيل الوجه", "لم يتمكن Android من فتح تطبيق الكاميرا. تحقق من وجود تطبيق كاميرا ومنح الصلاحية ثم أعد المحاولة. لم تتأثر بيانات الموظف.")
        }
    }

    private fun clearPendingFaceCapture(deleteTemp: Boolean = true) {
        if (deleteTemp) pendingFaceCapturePath?.let { runCatching { File(it).delete() } }
        pendingFaceCapturePath = null
        pendingFaceEmployeeId = null
        pendingFaceRecognition = false
    }

    private fun decodeFaceBitmap(path: String): Bitmap? {
        val bitmap = BitmapFactory.decodeFile(path) ?: return null
        val orientation = runCatching { android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL) }.getOrDefault(android.media.ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bitmap
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun showFaceReference(employee: PairedEmployee) {
        val path = employee.faceProfileRef
        val bitmap = if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        if (bitmap == null) {
            status.text = "صورة الوجه غير متاحة"
            return
        }
        val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; setPadding(12, 12, 12, 12) }
        AlertDialog.Builder(this).setTitle("بصمة الوجه — ${employee.displayName}").setView(image)
            .setMessage("هذه الصورة المرجعية محفوظة محليًا وتُستخدم مع قالب الوجه للمطابقة المحلية. جودة المطابقة تعتمد على الإضاءة وزاوية الوجه، ولا تُعد بديلًا عن محرك عصبي مع فحص حيوية في النسخة التجارية النهائية.")
            .setPositiveButton("إغلاق", null).show()
    }

    private fun deleteFaceReference(employee: PairedEmployee) {
        deleteFaceFile(employee.faceProfileRef)
        repo.upsertEmployee(employee.copy(faceProfileRef = "", faceCapturedAt = 0L, faceTemplate = "", faceQualityScore = 0))
        status.text = "تم حذف بصمة الوجه لـ ${employee.displayName}"
    }

    private fun deleteFaceFile(path: String) {
        if (path.isNotBlank()) runCatching { File(path).takeIf { it.exists() }?.delete() }
    }

    private fun showProvisionQr(employee:PairedEmployee){
        val provision=repo.newProvision(employee)
        val fullProvision=PairingProtocol.encodeEmployeeProvision(provision)
        status.text="جاري إنشاء تذكرة اقتران آمنة لجميع الأجهزة…"
        Thread {
            val result=CentralServerClient.createEmployeePairingTicket(repo.serverUrl,repo.centralAccessToken,repo.storeId,DeviceIdentity(this),employee.employeeId,fullProvision,provision.pairingSecret)
            runOnUiThread { result.onSuccess { showPairingTicketDialog(employee,it,fullProvision) }
                .onFailure { error -> info("تعذر إنشاء الاقتران",error.message ?: "تحقق من اتصال الخادم") } }
        }.start()
    }

    private fun showPairingTicketDialog(employee:PairedEmployee,ticket:CentralServerClient.EmployeePairingTicket,fallbackProvision:String){
        val content=ticket.transportText
        val qr=runCatching{QrCodeTools.bitmap(ticket.code,680)}.getOrElse{status.text="تعذر إنشاء QR: ${it.message ?: "خطأ"}";return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(20,12,20,8)}
        val linkState = TextView(this).apply{text="بانتظار مسح الرمز وتأكيد الخادم...";textSize=15f;gravity=Gravity.CENTER;setTextColor(p.accent);setPadding(0,8,0,8)}
        val beacon=PairingBeacon(this){message->runOnUiThread{linkState.text=message}}
        box.addView(TextView(this).apply{text="رمز الاقتران: ${ticket.code}\nصالح 15 دقيقة ويُستخدم مرة واحدة. يمكن مسحه أو كتابته أو نقله عبر Bluetooth/Hotspot.";textSize=18f;gravity=Gravity.CENTER;setTextColor(p.text);setTypeface(typeface,Typeface.BOLD)})
        box.addView(linkState)
        box.addView(ImageView(this).apply{setImageBitmap(qr);adjustViewBounds=true;layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,UiKit.dp(this@MainActivity,330))})
        box.addView(UiKit.button(this,p,"نسخ رمز الاقتران القصير",false).apply { setOnClickListener {
            getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("ATTEND PRO",content))
            status.text="تم نسخ رمز ربط ${employee.displayName}"
        } })
        box.addView(UiKit.button(this,p,"إرسال رمز الربط للموظف",false).apply { setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,content) },"إرسال ربط الموظف"))
        } })
        box.addView(UiKit.button(this,p,"بدء الاقتران المباشر Bluetooth / Hotspot",false).apply { setOnClickListener { beacon.start(ticket.code) } })
        box.addView(UiKit.button(this,p,"نسخ ملف الربط الكامل للطوارئ",false).apply { setOnClickListener {
            getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("ATTEND PRO",fallbackProvision));status.text="تم نسخ ملف الربط الكامل"
        } })
        val dialog = AlertDialog.Builder(this).setTitle("رمز ${employee.displayName}").setView(box).setPositiveButton("إغلاق",null).create()
        dialog.setOnDismissListener{beacon.stop()};dialog.show();beacon.start(ticket.code)
        Thread {
            repeat(20) {
                if (!dialog.isShowing) return@Thread
                val result = CentralServerClient.employeeLinkStatus(repo.serverUrl, repo.centralAccessToken, repo.storeId,
                    DeviceIdentity(this), employee.employeeId)
                val linked = result.getOrNull()?.linked == true
                runOnUiThread {
                    if (linked) {
                        linkState.text = "✓ تم الارتباط الحقيقي: نقلت البيانات وثُبت هاتف الموظف في الخادم"
                        status.text = "✓ هاتف ${employee.displayName} مرتبط وجاهز للحضور"
                    } else linkState.text = "بانتظار مسح الرمز وتأكيد الخادم..."
                }
                if (linked) return@Thread
                try { Thread.sleep(3_000L) } catch (_: InterruptedException) { return@Thread }
            }
            runOnUiThread { if (dialog.isShowing) linkState.text = "لم يصل تأكيد الربط بعد — تحقق من الإنترنت في الهاتفين وأعد مسح الرمز" }
        }.start()
    }

    private fun showPresenceChallenge() {
        val employees = repo.employees().filter { it.active && it.companionEnabled }
        if (employees.isEmpty()) { info("إثبات الوجود","لا يوجد موظف نشط مرتبط بتطبيق الموظف."); return }
        val names = employees.map { e ->
            val seen = nearby[e.employeeId]?.let { System.currentTimeMillis()-it.seenAt < 120_000L } == true
            "${e.displayName} ${if(seen) "• قريب الآن" else "• غير ظاهر حاليًا"}"
        }
        AlertDialog.Builder(this).setTitle("اختر الموظف المطلوب منه التحقق").setItems(names.toTypedArray()) { _,i ->
            val e=employees[i]
            val options=mutableListOf<Pair<String,AttendanceMethod>>()
            if(e.allows(AttendanceMethod.PHONE_FINGERPRINT)) options += "بصمة إصبع الهاتف فقط" to AttendanceMethod.PHONE_FINGERPRINT
            if(e.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC)) options += "التحقق الحيوي الأصلي للهاتف" to AttendanceMethod.PHONE_BLE_BIOMETRIC
            if(e.allows(AttendanceMethod.PHONE_BIOMETRIC)) options += "PIN أو كلمة مرور الهاتف" to AttendanceMethod.PHONE_BIOMETRIC
            if(e.allows(AttendanceMethod.GPS)) options += "GPS داخل نطاق المحل" to AttendanceMethod.GPS
            if(options.isEmpty()){info("إثبات الوجود","لا توجد طريقة تحقق مناسبة مفعلة لهذا الموظف.");return@setItems}
            AlertDialog.Builder(this).setTitle("طريقة إثبات وجود ${e.displayName}").setItems(options.map{it.first}.toTypedArray()){_,j->
                val chosen=options[j]
                status.text="جاري إرسال طلب التحقق إلى هاتف ${e.displayName}…"
                Thread {
                    val result=CentralServerClient.createPresenceChallenge(repo.serverUrl,repo.centralAccessToken,repo.storeId,DeviceIdentity(this),e.employeeId,chosen.second)
                    runOnUiThread { result.onSuccess { challenge ->
                        repo.addPresenceEvent(PresenceEvent(employeeId=e.employeeId,employeeName=e.displayName,timestampEpochMillis=System.currentTimeMillis(),channel="طلب تحقق",rssi=nearby[e.employeeId]?.rssi?:-127,details="أُرسل للهاتف عبر الخادم: ${chosen.first}"))
                        status.text="✓ أُرسل طلب التحقق إلى ${e.displayName}"
                        monitorPresenceChallenge(e,challenge)
                        refreshDashboard()
                    }.onFailure { error -> info("تعذر إرسال الطلب",error.message ?: "تحقق من اتصال الخادم") } }
                }.start()
            }.setNegativeButton("إلغاء",null).show()
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun monitorPresenceChallenge(employee: PairedEmployee, challenge: CentralServerClient.PresenceChallenge) {
        info("أُرسل الطلب ✓","سيظهر إشعار في هاتف ${employee.displayName}. الطلب صالح لمدة دقيقتين ولن يُقبل إلا عبر ${methodLabel(challenge.requiredMethod)}.")
        Thread {
            repeat(24) {
                val current=CentralServerClient.presenceChallengeStatus(repo.serverUrl,repo.centralAccessToken,repo.storeId,DeviceIdentity(this),challenge.challengeId).getOrNull()
                if(current?.status=="VERIFIED") {
                    runOnUiThread {
                        repo.addPresenceEvent(PresenceEvent(employeeId=employee.employeeId,employeeName=employee.displayName,timestampEpochMillis=current.verifiedAt,channel="إثبات وجود",rssi=nearby[employee.employeeId]?.rssi?:-127,details="تم عبر ${methodLabel(current.requiredMethod)} • ${current.evidence}"))
                        status.text="✓ أثبت ${employee.displayName} وجوده عبر ${methodLabel(current.requiredMethod)}";refreshDashboard()
                        info("تم إثبات الوجود ✓","تحقق ${employee.displayName} بالطريقة المطلوبة: ${methodLabel(current.requiredMethod)}")
                    };return@Thread
                }
                if(current?.status=="EXPIRED") { runOnUiThread{status.text="انتهت مهلة إثبات وجود ${employee.displayName}"};return@Thread }
                try{Thread.sleep(5_000L)}catch(_:InterruptedException){return@Thread}
            }
        }.start()
    }

    private fun recordManual(e:PairedEmployee){
        if (!ensureOperationalActivation()) return
        val action=nextAction(e.employeeId)
        repo.addEvent(AttendanceEvent(employeeId=e.employeeId,employeeName=e.displayName,branchId=e.branchId,timestampEpochMillis=System.currentTimeMillis(),action=action,method=AttendanceMethod.SUPERVISOR_OVERRIDE,deviceId=deviceId(),verified=true))
        status.text="✓ ${e.displayName}: ${if(action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} بإشراف";refreshDashboard()
    }

    private fun showPinDialog() {
        showCredentialDialog("التسجيل عبر PIN", "PIN", AttendanceMethod.PIN) { e -> e.pin }
    }

    private fun showPasswordDialog() {
        showCredentialDialog("التسجيل بكلمة المرور", "كلمة المرور", AttendanceMethod.PASSWORD) { e -> e.passwordHash }
    }

    private fun showPatternDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val entered = StringBuilder()
        val pointButtons = mutableListOf<android.widget.Button>()
        val indicator = TextView(this).apply {
            text = "النقش: لم يُدخل بعد"; textSize = 16f; setTextColor(p.text); gravity = Gravity.CENTER
            setPadding(0, UiKit.dp(this@MainActivity, 8), 0, UiKit.dp(this@MainActivity, 8))
        }
        fun refreshPattern() {
            indicator.error = null
            indicator.text = if (entered.isEmpty()) "النقش: لم يُدخل بعد" else "النقش: " + "● ".repeat(entered.length).trim()
        }
        box.addView(UiKit.subtitle(this, p, "اضغط نقاط الشبكة بالترتيب. كل نقطة تستخدم مرة واحدة، مثل نقش قفل الهاتف."))
        box.addView(id); box.addView(indicator)
        for (row in 0..2) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            for (col in 0..2) {
                val number = row * 3 + col + 1
                val button = UiKit.button(this, p, "●", false).apply {
                    contentDescription = "النقطة $number"
                    layoutParams = LinearLayout.LayoutParams(0, UiKit.dp(this@MainActivity, 52), 1f).apply {
                        marginStart = UiKit.dp(this@MainActivity, 4); marginEnd = UiKit.dp(this@MainActivity, 4); bottomMargin = UiKit.dp(this@MainActivity, 8)
                    }
                    setOnClickListener {
                        val c = ('0'.code + number).toChar()
                        if (c !in entered) { entered.append(c); isEnabled = false; refreshPattern() }
                    }
                }
                pointButtons.add(button); line.addView(button)
            }
            box.addView(line)
        }
        box.addView(UiKit.button(this, p, "مسح النقش", false).apply {
            setOnClickListener { entered.clear(); pointButtons.forEach { it.isEnabled = true }; refreshPattern() }
        })
        val dialog = AlertDialog.Builder(this).setTitle("التسجيل بالنقش").setView(box).setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.PATTERN)) { id.error = "النقش غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.patternHash.isBlank()) { id.error = "لم يتم تعيين نقش لهذا الموظف"; return@setOnClickListener }
                if (entered.length !in 4..9) { indicator.error = "أدخل 4 نقاط على الأقل"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(employee.patternHash, entered.toString())) { indicator.error = "النقش غير صحيح"; return@setOnClickListener }
                recordVerified(employee, AttendanceMethod.PATTERN); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showCredentialDialog(title: String, credentialLabel: String, method: AttendanceMethod, stored: (PairedEmployee) -> String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val credential = UiKit.field(this, p, credentialLabel, method == AttendanceMethod.PIN).apply {
            if (method == AttendanceMethod.PASSWORD) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(id); box.addView(credential)
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("تسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(method)) { credential.error = "هذه الطريقة غير مسموحة لهذا الموظف"; return@setOnClickListener }
                val saved = stored(employee)
                if (saved.isBlank()) { credential.error = "لم يتم إعداد $credentialLabel لهذا الموظف"; return@setOnClickListener }
                if (!PairingProtocol.matchesPin(saved, credential.text.toString())) { credential.error = "$credentialLabel غير صحيح"; return@setOnClickListener }
                recordVerified(employee, method); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun requestVoiceEnrollment(employee: PairedEmployee) {
        pendingVoiceEnrollmentEmployeeId = employee.employeeId
        voiceEnrollmentTemplates.clear(); voiceEnrollmentQualities.clear()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO_PERMISSION)
            return
        }
        promptVoiceEnrollmentSample()
    }

    private fun promptVoiceEnrollmentSample() {
        val employee = pendingVoiceEnrollmentEmployeeId?.let { id -> repo.employees().firstOrNull { it.employeeId.equals(id, true) } } ?: return
        val number = voiceEnrollmentTemplates.size + 1
        AlertDialog.Builder(this).setTitle("تسجيل نبرة الصوت $number/5")
            .setMessage("قل العبارة نفسها كاملة بصوت طبيعي. سجّل في وضعين هادئين ومسافتين قريبتين حتى يتعلم النظام اختلاف نبرة الصوت الطبيعية.")
            .setPositiveButton("ابدأ التسجيل") { _, _ ->
                status.text = "جارٍ تسجيل نبرة ${employee.displayName}…"
                VoiceSignatureEngine.capture { capture -> runOnUiThread {
                    if (capture.template.isBlank()) {
                        info("جودة التسجيل", capture.error.ifBlank { "تعذر تكوين بصمة صوتية" })
                        promptVoiceEnrollmentSample()
                        return@runOnUiThread
                    }
                    voiceEnrollmentTemplates.add(capture.template); voiceEnrollmentQualities.add(capture.quality)
                    if (voiceEnrollmentTemplates.size < 5) {
                        status.text = "✓ تم التسجيل ${voiceEnrollmentTemplates.size}/5 • جودة ${capture.quality}/100"
                        promptVoiceEnrollmentSample()
                    } else {
                        val pairScores = listOf(
                            VoiceSignatureEngine.similarity(voiceEnrollmentTemplates[0], voiceEnrollmentTemplates[1]),
                            VoiceSignatureEngine.similarity(voiceEnrollmentTemplates[0], voiceEnrollmentTemplates[2]),
                            VoiceSignatureEngine.similarity(voiceEnrollmentTemplates[1], voiceEnrollmentTemplates[2]),
                            VoiceSignatureEngine.similarity(voiceEnrollmentTemplates[2], voiceEnrollmentTemplates[3]),
                            VoiceSignatureEngine.similarity(voiceEnrollmentTemplates[3], voiceEnrollmentTemplates[4])
                        )
                        if (pairScores.sortedDescending().take(3).average() < 0.44) {
                            voiceEnrollmentTemplates.clear(); voiceEnrollmentQualities.clear()
                            info("العينات غير متناسقة", "اختلفت التسجيلات كثيرًا. أعد العبارة نفسها خمس مرات بصوت طبيعي وتأكد من عدم تغطية الميكروفون.")
                            promptVoiceEnrollmentSample(); return@runOnUiThread
                        }
                        val packed = voiceEnrollmentTemplates.fold("") { acc, item -> VoiceSignatureEngine.appendTemplate(acc, item) }
                        val quality = voiceEnrollmentQualities.average().toInt()
                        repo.upsertEmployee(employee.copy(voiceTemplate = packed, voiceQualityScore = quality))
                        pendingVoiceEnrollmentEmployeeId = null; voiceEnrollmentTemplates.clear(); voiceEnrollmentQualities.clear()
                        status.text = "✓ تم حفظ بصمة نبرة ${employee.displayName} • جودة $quality/100"
                        info("تم تسجيل الصوت", "حُفظت 5 عينات صوتية محليًا. يستخدم النظام أفضل تطابقات مع فحص جودة الصوت ثم يتحقق من العبارة وكلمة التحدي المتغيرة.")
                    }
                } }
            }.setNegativeButton("إلغاء") { _, _ -> pendingVoiceEnrollmentEmployeeId = null; voiceEnrollmentTemplates.clear(); voiceEnrollmentQualities.clear() }.show()
    }

    private fun beginVoicePhraseRecognition(employee: PairedEmployee, dialog: AlertDialog? = null) {
        val challenge = listOf("شمس", "قمر", "نهر", "باب", "نور", "كتاب").random()
        pendingVoiceChallenge = challenge
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, resolvedSpeechLanguage())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 8)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "انطق عبارتك المسجلة ثم قل كلمة: $challenge")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        runCatching { startActivityForResult(intent, REQUEST_VOICE_VERIFY) }.onSuccess { dialog?.dismiss() }.onFailure {
            pendingVoiceEmployeeId = null; pendingVoicePrintScore = -1f
            info("التحقق الصوتي", "لا توجد خدمة تعرف صوتي متاحة على هذا الجهاز: ${it.message ?: "خطأ"}")
        }
    }

    private fun captureVoiceForVerification(employee: PairedEmployee, dialog: AlertDialog? = null) {
        status.text = "قل عبارتك الآن — جارٍ تحليل الصوت لمدة 4 ثوانٍ…"
        VoiceSignatureEngine.capture { capture -> runOnUiThread {
            if (capture.template.isBlank()) { info("جودة الصوت", capture.error); return@runOnUiThread }
            val score = VoiceSignatureEngine.similarity(capture.template, employee.voiceTemplate)
            val adaptiveThreshold = when { employee.voiceQualityScore < 40 -> 0.43f; capture.quality < 40 -> 0.45f; else -> VOICE_PRINT_THRESHOLD }
            if (score < adaptiveThreshold) {
                pendingVoiceEmployeeId = null; pendingVoicePrintScore = -1f
                info("لم تتطابق نبرة الصوت", "درجة المطابقة ${(score * 100).toInt()}% (المطلوب ${(adaptiveThreshold*100).toInt()}%). قرّب الهاتف 20-40 سم، تكلم طبيعيًا، أو حدّث بصمة الصوت من ملف الموظف.")
                return@runOnUiThread
            }
            pendingVoicePrintScore = score
            beginVoicePhraseRecognition(employee, dialog)
        } }
    }

    private fun showVoiceDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        box.addView(UiKit.subtitle(this, p, "يطابق النظام نبرة الموظف المسجلة أولًا، ثم يطلب العبارة وكلمة تحدٍ متغيرة. يلزم تسجيل 3 عينات صوتية في ملف الموظف."))
        box.addView(id)
        val dialog = AlertDialog.Builder(this).setTitle("العبارة الصوتية").setView(box).setPositiveButton("بدء الاستماع", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.VOICE_PHRASE)) { id.error = "التحقق الصوتي غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.voicePhraseHash.isBlank()) { id.error = "لم يتم إعداد عبارة صوتية لهذا الموظف"; return@setOnClickListener }
                if (employee.voiceTemplate.isBlank()) { id.error = "لم تُسجل بصمة نبرة هذا الموظف؛ حدّث ملفه وسجل 3 عينات"; return@setOnClickListener }
                if (!employee.voiceTemplate.contains("vs2:")) { id.error = "بصمة الصوت قديمة؛ حدّث ملف الموظف وسجل العينات الجديدة"; return@setOnClickListener }
                pendingVoiceEmployeeId = employee.employeeId
                pendingVoicePrintScore = -1f
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO_PERMISSION)
                } else captureVoiceForVerification(employee, dialog)
            }
        }
        dialog.show()
    }

    private fun showGpsDialog() {
        if (!repo.isGpsConfigured) {
            info("GPS غير مضبوط", "افتح قسم مالك العمل ← إعداد GPS وموقع المحل، ثم أدخل إحداثيات المحل ونطاق السماح.")
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val id = UiKit.field(this, p, "رقم الموظف")
        val pin = UiKit.field(this, p, "PIN", true)
        box.addView(UiKit.subtitle(this, p, "GPS يثبت الموقع فقط ولا يثبت هوية الشخص، لذلك يستخدم هنا مع PIN الموظف."))
        box.addView(id); box.addView(pin)
        val dialog = AlertDialog.Builder(this).setTitle("الحضور عبر GPS + PIN").setView(box).setPositiveButton("تحقق وتسجيل", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val employee = findActiveEmployee(id.text.toString()) ?: run { id.error = "الموظف غير موجود أو موقوف"; return@setOnClickListener }
                if (!employee.allows(AttendanceMethod.GPS)) { pin.error = "GPS غير مسموح لهذا الموظف"; return@setOnClickListener }
                if (employee.pin.isBlank() || !PairingProtocol.matchesPin(employee.pin, pin.text.toString())) { pin.error = "PIN غير صحيح أو غير مضاف"; return@setOnClickListener }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQUEST_GPS_PERMISSION)
                    status.text = "اسمح بالموقع ثم أعد محاولة GPS"
                    return@setOnClickListener
                }
                val locationManager = getSystemService(LocationManager::class.java) ?: run {
                    pin.error = "خدمة الموقع غير متاحة على هذا الجهاز"
                    return@setOnClickListener
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                status.text = "جاري طلب موقع حديث ودقيق..."
                requestFreshLocation(locationManager) { location, error ->
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true
                    if (location == null) { pin.error = error ?: "تعذر الحصول على موقع حديث"; return@requestFreshLocation }
                    if (isMockLocation(location)) { pin.error = "تم رفض موقع تجريبي/مزيف"; return@requestFreshLocation }
                    val target = Location("ATTEND_PRO_STORE").apply { latitude = repo.storeLatitude; longitude = repo.storeLongitude }
                    val distance = location.distanceTo(target)
                    val accuracyAllowance = location.accuracy.takeIf { it.isFinite() }?.coerceIn(0f, 100f) ?: 0f
                    if (distance > repo.gpsRadiusMeters + accuracyAllowance) {
                        pin.error = "أنت خارج نطاق المحل (${distance.toInt()}م، النطاق ${repo.gpsRadiusMeters}م، دقة الهاتف ${location.accuracy.toInt()}م)"
                        return@requestFreshLocation
                    }
                    recordVerified(employee, AttendanceMethod.GPS, "GPS ${distance.toInt()}م • دقة ${location.accuracy.toInt()}م")
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun bestLastLocation(manager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        return providers.mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
    }

    @Suppress("MissingPermission")
    private fun requestFreshLocation(manager: LocationManager, callback: (Location?, String?) -> Unit) {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if (providers.isEmpty()) { callback(null, "فعّل الموقع واختر الدقة العالية ثم أعد المحاولة"); return }
        val delivered = java.util.concurrent.atomic.AtomicBoolean(false)
        var best: Location? = null
        lateinit var listener: LocationListener
        fun finish(location: Location?, error: String? = null) {
            if (delivered.compareAndSet(false, true)) {
                runCatching { manager.removeUpdates(listener) }
                runOnUiThread { callback(location, error) }
            }
        }
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (System.currentTimeMillis() - location.time > 2 * 60_000L) return
                if (best == null || location.accuracy < best!!.accuracy) best = location
                if (location.hasAccuracy() && location.accuracy <= 35f) finish(location)
            }
            @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
            override fun onProviderEnabled(provider: String) = Unit
            override fun onProviderDisabled(provider: String) = Unit
        }
        providers.forEach { provider -> runCatching { manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper()) } }
        Handler(Looper.getMainLooper()).postDelayed({
            val fallback = best ?: bestLastLocation(manager)?.takeIf { System.currentTimeMillis() - it.time <= 10 * 60_000L }
            finish(fallback, if (fallback == null) "لم يصل موقع صالح. فعّل دقة الموقع العالية وافتح GPS خارج المبنى للحظات" else null)
        }, 25_000L)
    }

    private fun isMockLocation(location: Location): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) location.isMock else @Suppress("DEPRECATION") location.isFromMockProvider

    private fun findActiveEmployee(rawId: String): PairedEmployee? = repo.employees().firstOrNull { it.active && it.employeeId.equals(rawId.trim(), true) }


    private fun ensureOperationalActivation(): Boolean {
        if (repo.isCentralActivationActive()) return true
        runCatching { scanner.stop() }
        runCatching { networkListener.stop() }
        buildActivationLockUi()
        info("التشغيل موقوف", "يتطلب تسجيل الحضور تفعيلًا مركزيًا صالحًا من صاحب النظام. إذا كان الجهاز غير متصل بالإنترنت، أعد الاتصال للتحقق من الصلاحية.")
        return false
    }

    private fun recordVerified(employee: PairedEmployee, method: AttendanceMethod, extra: String = "") {
        if (!ensureOperationalActivation()) return
        val now = System.currentTimeMillis()
        val previous = repo.lastEvent(employee.employeeId)
        if (previous != null && now - previous.timestampEpochMillis < 30_000L) {
            status.text = "تم تجاهل محاولة مكررة لـ ${employee.displayName} — انتظر 30 ثانية"
            return
        }
        val action = nextAction(employee.employeeId)
        if (action == AttendanceAction.CHECK_OUT && repo.checkoutSignatureEnabled) {
            requestCheckoutSignature(employee, method, extra)
            return
        }
        commitVerified(employee, method, extra, action)
    }

    private fun commitVerified(employee: PairedEmployee, method: AttendanceMethod, extra: String, action: AttendanceAction) {
        val now = System.currentTimeMillis()
        repo.addEvent(AttendanceEvent(employeeId = employee.employeeId, employeeName = employee.displayName, branchId = employee.branchId,
            timestampEpochMillis = now, action = action, method = method, deviceId = deviceId(), verified = true, evidence = extra))
        status.text = "✓ ${employee.displayName}: ${if (action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"} — ${methodLabel(method)}${if (extra.isNotBlank()) " • $extra" else ""}"
        refreshDashboard()
    }

    private fun requestCheckoutSignature(employee: PairedEmployee, method: AttendanceMethod, extra: String) {
        val signature = SignaturePadView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0)
            addView(UiKit.subtitle(this@MainActivity, p, "وقّع داخل المساحة أدناه لتأكيد الانصراف. لا تُحفظ صورة التوقيع؛ يُحفظ إثبات رقمي مشفر فقط."))
            addView(signature, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 220)))
        }
        val dialog = AlertDialog.Builder(this).setTitle("توقيع الانصراف — ${employee.displayName}").setView(box)
            .setPositiveButton("تأكيد الانصراف", null).setNeutralButton("مسح", null).setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { signature.clear() }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!signature.hasSignature()) { info("التوقيع مطلوب", "وقّع داخل المساحة أولًا، أو عطّل خيار توقيع الانصراف من إعدادات طرق الحضور."); return@setOnClickListener }
                val evidence = listOf(extra, "توقيع انصراف SHA-256:${signature.digest()}").filter { it.isNotBlank() }.joinToString(" • ")
                dialog.dismiss(); commitVerified(employee, method, evidence, AttendanceAction.CHECK_OUT)
            }
        }
        dialog.show()
    }

    private fun showReportsDialog(){
        val recent=repo.events().takeLast(30).reversed();val fmt=SimpleDateFormat("dd/MM HH:mm",Locale.getDefault())
        val text=if(recent.isEmpty())"لا توجد عمليات بعد" else buildString{recent.forEach{e->append("• ${e.employeeName.ifBlank{e.employeeId}} — ${if(e.action==AttendanceAction.CHECK_IN)"حضور" else "انصراف"} — ${fmt.format(Date(e.timestampEpochMillis))} — ${e.method.name}\n")}}
        AlertDialog.Builder(this).setTitle("السجل والتقارير").setMessage(text).setPositiveButton("مشاركة CSV"){_,_->shareTodayCsv()}.setNegativeButton("إغلاق",null).show()
    }

    private fun handleBlePayload(payload:BleProtocol.Payload,rssi:Int,channel:String){
        if(!repo.allowEmployeeCompanion) return
        val employees=repo.employees().filter{it.active&&it.companionEnabled&&BleProtocol.employeeHash(it.employeeId)==payload.employeeHash}
        for(employee in employees){
            val secret=SecretCodec.decode(employee.pairingSecret)?:continue
            if(!BleProtocol.verify(payload,employee.employeeId,secret))continue
            val detectedAt = System.currentTimeMillis()
            val previous = nearby[employee.employeeId]
            val channels = previous?.channelTimes.orEmpty().toMutableMap().apply {
                put(channel, detectedAt)
                if (payload.gpsProof) put("GPS", detectedAt)
            }
            nearby[employee.employeeId]=NearbyPhone(detectedAt,maxOf(rssi, previous?.rssi ?: -127),channels)
            repo.addPresenceEvent(PresenceEvent(employeeId = employee.employeeId, employeeName = employee.displayName,
                timestampEpochMillis = detectedAt, channel = channel, rssi = rssi,
                details = if (payload.gpsProof) "إثبات GPS مرفق" else "تم التحقق من هوية الربط المشفرة"))
            if (payload.gpsProof) repo.addPresenceEvent(PresenceEvent(employeeId = employee.employeeId, employeeName = employee.displayName,
                timestampEpochMillis = detectedAt, channel = "GPS", rssi = rssi, details = "الهاتف داخل نطاق الموقع الموثوق"))
            if (payload.verified) {
                when {
                    payload.gpsProof && repo.allowGpsVerification && employee.allows(AttendanceMethod.GPS) ->
                        maybeRecordPhoneProof(employee, payload.token, AttendanceMethod.GPS)
                    payload.credentialProof && employee.allows(AttendanceMethod.PHONE_BIOMETRIC) ->
                        maybeRecordPhoneProof(employee, payload.token, AttendanceMethod.PHONE_BIOMETRIC)
                    (payload.biometricProof || payload.version == BleProtocol.LEGACY_VERSION) && employee.allows(AttendanceMethod.PHONE_BLE_BIOMETRIC) ->
                        maybeRecordPhoneProof(employee, payload.token, AttendanceMethod.PHONE_BLE_BIOMETRIC)
                }
            } else if (!repo.requirePhoneBiometric && employee.allows(AttendanceMethod.PHONE_PROXIMITY) && employee.employeeId !in autoPresenceRecorded) {
                autoPresenceRecorded.add(employee.employeeId)
                runOnUiThread { recordVerified(employee, AttendanceMethod.PHONE_PROXIMITY) }
            }
            runOnUiThread{refreshDashboard()}
            return
        }
    }

    private fun maybeRecordPhoneProof(employee:PairedEmployee,token:Int,method:AttendanceMethod){
        if(!employee.allows(method)) return
        if(repo.lastProofToken(employee.employeeId)==token)return
        val last=repo.lastEvent(employee.employeeId)
        if(last!=null&&System.currentTimeMillis()-last.timestampEpochMillis<60_000L)return
        repo.setLastProofToken(employee.employeeId,token)
        val evidence = when (method) {
            AttendanceMethod.GPS -> "GPS من هاتف الموظف"
            AttendanceMethod.PHONE_FINGERPRINT -> "بصمة إصبع هاتف الموظف"
            AttendanceMethod.PHONE_BIOMETRIC -> "PIN/كلمة مرور محلية من هاتف الموظف"
            else -> "تحقق بيومتري من هاتف الموظف"
        }
        runOnUiThread{recordVerified(employee, method, evidence) }
    }

    private fun nextAction(employeeId:String):AttendanceAction{val last=repo.lastEventToday(employeeId,dayStartMillis());return if(last?.action==AttendanceAction.CHECK_IN)AttendanceAction.CHECK_OUT else AttendanceAction.CHECK_IN}

    private fun refreshDashboard(){
        if (::storeSummary.isInitialized) storeSummary.text = storeSummaryText()
        val now=System.currentTimeMillis()
        val stale=nearby.filterValues{now-it.seenAt>45_000L}.keys.toList()
        stale.forEach { nearby.remove(it); autoPresenceRecorded.remove(it) }
        val employees=repo.employees().filter{it.active}
        val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()}
        val present=employees.mapNotNull{e->val last=events.lastOrNull{it.employeeId.equals(e.employeeId,true)};if(last?.action==AttendanceAction.CHECK_IN)e.employeeId else null}.toSet()
        val late=employees.mapNotNull{e->val first=events.firstOrNull{it.employeeId.equals(e.employeeId,true)&&it.action==AttendanceAction.CHECK_IN};if(first!=null&&first.timestampEpochMillis>shiftCutoffMillis(e, first.timestampEpochMillis))e.employeeId else null}.toSet()
        val early=employees.mapNotNull { e ->
            val lastOut = events.lastOrNull { it.employeeId.equals(e.employeeId, true) && it.action == AttendanceAction.CHECK_OUT }
            if (lastOut != null && lastOut.timestampEpochMillis < shiftEndMillis(e, lastOut.timestampEpochMillis)) e.employeeId else null
        }.toSet()
        if (::connectionSummaryView.isInitialized) {
            val connectedNames = nearby.keys.map { id -> employees.firstOrNull { it.employeeId == id }?.displayName ?: id }
            val channelCount = nearby.values.flatMap { it.channelTimes.keys }.distinct().size
            connectionSummaryView.text = if (connectedNames.isEmpty()) {
                "لا توجد أجهزة موظفين متصلة الآن • الخادم ${if (repo.hasCentralCredentials()) "مرتبط" else "غير مرتبط"}"
            } else {
                "${connectedNames.size} جهاز متصل الآن: ${connectedNames.take(3).joinToString("، ")}${if (connectedNames.size > 3) " +${connectedNames.size - 3}" else ""}\nقنوات نشطة: $channelCount • الخادم مرتبط"
            }
        }
        if(::counts.isInitialized) counts.text="الموظفون ${employees.size}   •   الحاضرون ${present.size}\nمتأخرون ${late.size}   •   انصراف مبكر ${early.size}\nغير الحاضرين ${(employees.size-present.size).coerceAtLeast(0)}"
        if (::recentAttendanceSummaryView.isInitialized) {
            val last = events.maxByOrNull { it.timestampEpochMillis }
            recentAttendanceSummaryView.text = if (last == null) "لا توجد عملية اليوم\nاضغط لفتح السجل" else {
                val action = if (last.action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(last.timestampEpochMillis))
                "${last.employeeName.ifBlank { last.employeeId }}\n$action • $time • ${methodLabel(last.method)}"
            }
        }
        if(::nearbyView.isInitialized) nearbyView.text=if(nearby.isEmpty()) {
            "لا توجد هواتف مرتبطة قريبة الآن\nشغّل Bluetooth في الهاتفين واترك تطبيق الموظف يعمل في الخلفية"
        } else nearby.entries.joinToString("\n") { (id, phone) ->
            val name = employees.firstOrNull { it.employeeId == id }?.displayName ?: id
            val strength = when { phone.rssi >= -55 -> "قريب جدًا"; phone.rssi >= -70 -> "قريب"; else -> "إشارة ضعيفة" }
            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(phone.seenAt))
            val channels = phone.channelTimes.entries.sortedByDescending { it.value }.joinToString(" + ") { it.key }
            "● $name • $channels • $strength (${phone.rssi} dBm)\n  آخر التقاط: $time"
        }
        if (::activityTimelineView.isInitialized) {
            activityTimelineView.text = activityHistoryLines(8).ifEmpty { listOf("لا توجد عمليات ارتباط أو حضور حتى الآن") }.joinToString("\n\n")
        }
        if (::attendanceTodayView.isInitialized) {
            val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            attendanceTodayView.text = if (events.isEmpty()) "لم يسجل أي موظف حضورًا اليوم" else
                events.sortedByDescending { it.timestampEpochMillis }.take(12).joinToString("\n\n") { event ->
                    val action = if (event.action == AttendanceAction.CHECK_IN) "حضور" else "انصراف"
                    val sync = if (event.synced) "وصل من الخادم" else "مسجل على جهاز المحل"
                    "${if (event.action == AttendanceAction.CHECK_IN) "🟢" else "🟠"} ${event.employeeName.ifBlank { event.employeeId }}\n$action • ${fmt.format(Date(event.timestampEpochMillis))} • ${methodLabel(event.method)} • $sync"
                }
        }
    }

    private fun activityHistoryLines(limit: Int): List<String> {
        val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
        val presence = repo.presenceEvents().map { event ->
            val employee = repo.employees().firstOrNull { it.employeeId.equals(event.employeeId, true) }
            val profile = listOfNotNull(employee?.jobTitle?.takeIf { it.isNotBlank() }, employee?.department?.takeIf { it.isNotBlank() }, employee?.branchId?.takeIf { it.isNotBlank() }).joinToString(" • ")
            event.timestampEpochMillis to "🔵 ${fmt.format(Date(event.timestampEpochMillis))} • ${event.employeeName.ifBlank { event.employeeId }}${if (profile.isNotBlank()) " • $profile" else ""}\nارتباط تلقائي: ${event.channel}${if (event.rssi > -127) " • ${event.rssi} dBm" else ""}${if (event.details.isNotBlank()) " • ${event.details}" else ""}"
        }
        val attendance = repo.events().map { event ->
            val action = if (event.action == AttendanceAction.CHECK_IN) "تسجيل حضور" else "تسجيل انصراف"
            val sync = if (event.synced) "متزامن" else "محفوظ محليًا"
            event.timestampEpochMillis to "🟢 ${fmt.format(Date(event.timestampEpochMillis))} • ${event.employeeName.ifBlank { event.employeeId }} • فرع ${event.branchId}\n$action • ${methodLabel(event.method)} • $sync${if (event.evidence.isNotBlank()) " • ${event.evidence}" else ""}"
        }
        return (presence + attendance).sortedByDescending { it.first }.take(limit).map { it.second }
    }

    private fun showConnectionAttendanceHistory() {
        val lines = activityHistoryLines(100)
        AlertDialog.Builder(this).setTitle("سجل الارتباط والحضور")
            .setMessage(if (lines.isEmpty()) "لا توجد عمليات بعد" else lines.joinToString("\n\n"))
            .setPositiveButton("إغلاق", null).show()
    }

    private fun showConnectionCenter() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 8), UiKit.dp(this@MainActivity, 18), 0)
        }
        val now = System.currentTimeMillis()
        val employees = repo.employees().filter { it.active }
        val live = nearby.filterValues { now - it.seenAt <= 45_000L }
        box.addView(UiKit.statusBadge(this, p, if (live.isEmpty()) "لا توجد أجهزة قريبة" else "${live.size} جهاز متصل الآن", live.isNotEmpty()))
        box.addView(UiKit.subtitle(this, p, "الخادم المركزي: ${if (repo.hasCentralCredentials()) "مرتبط وجاهز للمزامنة" else "غير مرتبط"}\nBluetooth: ${if (scanner.isScanning()) "يعمل" else "متوقف"} • Wi‑Fi/Hotspot: ${if (networkListener.isRunning()) "يعمل" else "متوقف"}").apply { gravity = Gravity.CENTER })
        box.addView(UiKit.sectionLabel(this, p, "الأجهزة الحالية"))
        val detail = if (live.isEmpty()) "لا يوجد هاتف موظف ظاهر خلال آخر 45 ثانية." else live.entries.joinToString("\n\n") { (id, phone) ->
            val employee = employees.firstOrNull { it.employeeId == id }
            val name = employee?.displayName ?: id
            val channels = phone.channelTimes.keys.joinToString(" + ").ifBlank { "غير محدد" }
            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(phone.seenAt))
            "● $name\n$channels • آخر ظهور $time • ${phone.rssi} dBm"
        }
        box.addView(TextView(this).apply { text = detail; textSize = 15f; setTextColor(p.text); setPadding(0, UiKit.dp(this@MainActivity, 8), 0, UiKit.dp(this@MainActivity, 12)) })
        box.addView(UiKit.button(this, p, "إعادة تشغيل اكتشاف الأجهزة", false).apply { setOnClickListener {
            runCatching { scanner.stop() }; runCatching { networkListener.stop() }
            runCatching { scanner.start() }; runCatching { networkListener.start() }
            status.text = "يعمل البحث عبر Bluetooth وWi‑Fi/Hotspot"
            refreshDashboard()
        } })
        box.addView(UiKit.button(this, p, "عرض سجل الاتصال والحضور", false).apply { setOnClickListener { showConnectionAttendanceHistory() } })
        AlertDialog.Builder(this).setTitle("مركز الاتصال والأجهزة").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("إغلاق", null).show()
    }

    private fun shareTodayCsv(){val events=repo.events().filter{it.timestampEpochMillis>=dayStartMillis()};val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);val csv=buildString{append("employee_id,employee_name,branch,time,action,method,synced\n");events.forEach{e->append("${e.employeeId},\"${e.employeeName.replace("\"","\"\"")}\",${e.branchId},${fmt.format(Date(e.timestampEpochMillis))},${e.action.name},${e.method.name},${e.synced}\n")}};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"ATTEND PRO - تقرير اليوم");putExtra(Intent.EXTRA_TEXT,csv)},"مشاركة تقرير اليوم"))}
    private fun dayStartMillis():Long=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
    private fun shiftCutoffMillis(employee: PairedEmployee, baseTime: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
        timeInMillis = baseTime
        set(Calendar.HOUR_OF_DAY, if (employee.useCustomShift) employee.shiftStartHour else repo.shiftHour)
        set(Calendar.MINUTE, if (employee.useCustomShift) employee.shiftStartMinute else repo.shiftMinute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MINUTE, repo.graceMinutes)
    }.timeInMillis
    private fun shiftEndMillis(employee: PairedEmployee, baseTime: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
        timeInMillis = baseTime
        set(Calendar.HOUR_OF_DAY, if (employee.useCustomShift) employee.shiftEndHour else repo.shiftEndHour)
        set(Calendar.MINUTE, if (employee.useCustomShift) employee.shiftEndMinute else repo.shiftEndMinute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    private fun employeeShiftLabel(employee: PairedEmployee): String {
        val sh = if (employee.useCustomShift) employee.shiftStartHour else repo.shiftHour
        val sm = if (employee.useCustomShift) employee.shiftStartMinute else repo.shiftMinute
        val eh = if (employee.useCustomShift) employee.shiftEndHour else repo.shiftEndHour
        val em = if (employee.useCustomShift) employee.shiftEndMinute else repo.shiftEndMinute
        return String.format(Locale.getDefault(), "%02d:%02d - %02d:%02d%s", sh, sm, eh, em, if (employee.useCustomShift) " • خاص" else " • عام")
    }
    private fun deviceId():String{val prefs=getSharedPreferences("device",MODE_PRIVATE);val old=prefs.getString("id",null);if(old!=null)return old;val id="STORE-${UUID.randomUUID()}";prefs.edit().putString("id",id).apply();return id}

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (!repo.isCentralActivationActive()) { buildActivationLockUi(); return }
        if (requestCode == REQUEST_VOICE_VERIFY) {
            if (!::status.isInitialized) { buildElegantUi(); refreshDashboard() }
            val employeeId = pendingVoiceEmployeeId
            val challenge = pendingVoiceChallenge
            val voicePrintScore = pendingVoicePrintScore
            pendingVoiceEmployeeId = null; pendingVoiceChallenge = null
            pendingVoicePrintScore = -1f
            if (resultCode != RESULT_OK || employeeId.isNullOrBlank() || challenge.isNullOrBlank()) { status.text = "تم إلغاء التحقق الصوتي"; return }
            val employee = findActiveEmployee(employeeId)
            if (employee == null || employee.voicePhraseHash.isBlank() || !employee.allows(AttendanceMethod.VOICE_PHRASE)) { status.text = "بيانات التحقق الصوتي غير متاحة"; return }
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty()
            val confidence = data?.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES)
            var acceptedConfidence = -1f
            val matched = results.indices.any { i ->
                val normalized = normalizeVoicePhrase(results[i])
                val challengeNorm = normalizeVoicePhrase(challenge)
                val words = normalized.split(' ').filter { it.isNotBlank() }
                val challengeIndex = words.indexOfFirst { voiceWordDistance(it, challengeNorm) <= 1 }
                if (challengeIndex < 0) return@any false
                val phraseWords = words.filterIndexed { index, _ -> index != challengeIndex }
                val candidates = mutableSetOf<String>()
                for (start in phraseWords.indices) for (end in start + 1..phraseWords.size) {
                    candidates.add(phraseWords.subList(start, end).joinToString(" "))
                }
                val phraseMatch = candidates.any { candidate ->
                    if (employee.voicePhraseText.isNotBlank()) voicePhraseSimilarity(candidate, employee.voicePhraseText) >= 0.60f
                    else voiceCandidateForms(candidate).any { PairingProtocol.matchesPin(employee.voicePhraseHash, it) }
                }
                val c = confidence?.getOrNull(i) ?: -1f
                val confidenceOk = c < 0f || c >= 0.25f
                if (phraseMatch && confidenceOk) { acceptedConfidence = c; true } else false
            }
            if (matched && voicePrintScore >= VOICE_PRINT_THRESHOLD) recordVerified(employee, AttendanceMethod.VOICE_PHRASE,
                "نبرة ${(voicePrintScore * 100).toInt()}% • ${if (acceptedConfidence >= 0f) "ثقة كلام ${(acceptedConfidence * 100).toInt()}%" else "تحدي صوتي"}")
            else info("لم ينجح التحقق الصوتي", "لم تتطابق العبارة مع كلمة التحدي أو كانت ثقة التعرف منخفضة. حاول في مكان أقل ضوضاء.")
            return
        }
        if (requestCode != REQUEST_FACE_CAPTURE) return
        if (!::status.isInitialized) { buildElegantUi(); refreshDashboard() }
        val employeeId = pendingFaceEmployeeId
        val recognitionMode = pendingFaceRecognition
        val tempPath = pendingFaceCapturePath
        pendingFaceEmployeeId = null; pendingFaceRecognition = false; pendingFaceCapturePath = null
        if (resultCode != RESULT_OK || tempPath.isNullOrBlank()) {
            tempPath?.let { runCatching { File(it).delete() } }
            status.text = "تم إلغاء بصمة الوجه — لم تتغير البيانات"
            return
        }
        val bitmap = runCatching { decodeFaceBitmap(tempPath) }.getOrNull()
        runCatching { File(tempPath).delete() }
        if (bitmap == null) { info("بصمة الوجه", "لم تصل صورة صالحة من الكاميرا. أعد المحاولة."); return }
        val analysis = FaceSignatureEngine.analyze(bitmap)
        if (analysis.template.isBlank()) {
            info("جودة الوجه", analysis.error.ifBlank { "تعذر تكوين قالب وجه صالح." }); return
        }
        if (recognitionMode) {
            val candidates = repo.employees().filter { it.active && it.allows(AttendanceMethod.SHARED_DEVICE_FACE) && it.faceTemplate.isNotBlank() }
            val livenessEmployee = pendingLivenessEmployeeId?.let { id -> candidates.firstOrNull { it.employeeId.equals(id, true) } }
            if (livenessEmployee != null && !pendingLivenessFirstTemplate.isNullOrBlank()) {
                val sameEmployeeScore = FaceSignatureEngine.similarity(analysis.template, livenessEmployee.faceTemplate)
                val movementScore = FaceSignatureEngine.similarity(analysis.template, pendingLivenessFirstTemplate.orEmpty())
                val firstScore = pendingLivenessFirstScore
                pendingLivenessEmployeeId = null; pendingLivenessFirstTemplate = null; pendingLivenessFirstScore = 0f
                if (sameEmployeeScore < 0.66f || movementScore > 0.995f || movementScore < 0.45f) {
                    info("فشل فحص الحيوية", "لم يثبت النظام حركة وجه طبيعية لنفس الموظف. مطابقة الهوية ${(sameEmployeeScore * 100).toInt()}% • الحركة ${(movementScore * 100).toInt()}%. أعد المحاولة ونفّذ الحركة المطلوبة بوضوح.")
                    return
                }
                recordVerified(livenessEmployee, AttendanceMethod.SHARED_DEVICE_FACE,
                    "وجه ${(minOf(firstScore, sameEmployeeScore) * 100).toInt()}% • فحص حيوية تفاعلي • جودة ${analysis.quality}/100")
                return
            }
            val ranked = candidates.map { it to FaceSignatureEngine.similarity(analysis.template, it.faceTemplate) }.sortedByDescending { it.second }
            val best = ranked.firstOrNull()
            val second = ranked.getOrNull(1)?.second ?: 0f
            if (best == null || best.second < 0.70f || (ranked.size > 1 && best.second - second < 0.04f)) {
                info("لم يتم التعرف بثقة كافية", "لم يطابق الوجه أي موظف بدرجة آمنة. أفضل درجة ${(best?.second?.times(100)?.toInt() ?: 0)}%. أعد المحاولة بإضاءة جيدة أو حدّث ملف وجه الموظف.")
                return
            }
            pendingLivenessEmployeeId = best.first.employeeId
            pendingLivenessFirstTemplate = analysis.template
            pendingLivenessFirstScore = best.second
            pendingFaceRecognition = true
            val challenge = listOf("أدر وجهك قليلًا إلى اليمين", "أدر وجهك قليلًا إلى اليسار", "ارفع ذقنك قليلًا").random()
            AlertDialog.Builder(this).setTitle("فحص حيوية الوجه")
                .setMessage("تمت مطابقة ${best.first.displayName}. الآن $challenge ثم التقط الصورة الثانية. يجب أن يبقى الوجه نفسه ظاهرًا.")
                .setPositiveButton("التقاط الصورة الثانية") { _, _ -> ensureCameraAndLaunch() }
                .setNegativeButton("إلغاء") { _, _ -> pendingLivenessEmployeeId = null; pendingLivenessFirstTemplate = null }.show()
            return
        }
        if (employeeId.isNullOrBlank()) return
        val employee = repo.employees().firstOrNull { it.employeeId.equals(employeeId, true) } ?: return
        faceEnrollmentTemplates.add(analysis.template)
        faceEnrollmentQualities.add(analysis.quality)
        if (faceEnrollmentTemplates.size < 5) {
            val nextPose = when (faceEnrollmentTemplates.size) {
                1 -> "التفت قليلًا إلى اليمين"
                2 -> "التفت قليلًا إلى اليسار"
                3 -> "ارفع وجهك قليلًا"
                else -> "اخفض وجهك قليلًا"
            }
            pendingFaceEmployeeId = employee.employeeId
            pendingFaceRecognition = false
            status.text = "تمت الصورة ${faceEnrollmentTemplates.size}/5 — $nextPose"
            AlertDialog.Builder(this).setTitle("الصورة التالية").setMessage("$nextPose مع إبقاء العينين ظاهرتين، ثم اضغط متابعة.")
                .setPositiveButton("متابعة") { _, _ -> ensureCameraAndLaunch() }
                .setNegativeButton("إلغاء") { _, _ -> faceEnrollmentTemplates.clear(); faceEnrollmentQualities.clear() }.show()
            return
        }
        runCatching {
            val dir = File(filesDir, "face_profiles").apply { mkdirs() }
            val safeId = employee.employeeId.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(dir, "$safeId.jpg")
            val saveBitmap = analysis.faceCrop ?: bitmap
            file.outputStream().use { out -> if (!saveBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) error("تعذر ضغط الصورة") }
            deleteFaceFile(employee.faceProfileRef.takeIf { it != file.absolutePath }.orEmpty())
            val multiTemplate = faceEnrollmentTemplates.fold("") { acc, template -> FaceSignatureEngine.appendTemplate(acc, template) }
            val averageQuality = faceEnrollmentQualities.average().toInt()
            repo.upsertEmployee(employee.copy(faceProfileRef = file.absolutePath, faceCapturedAt = System.currentTimeMillis(), faceTemplate = multiTemplate, faceQualityScore = averageQuality))
            status.text = "✓ تم إعداد وجه ${employee.displayName} من 5 وضعيات • جودة $averageQuality/100"
            info("تم إعداد الوجه من 5 وضعيات", "تم حفظ خمسة قوالب محلية لتحسين المطابقة عند اختلاف زاوية الوجه. هذه مطابقة محلية محسّنة، وليست بديلًا عن محرك تعرّف عصبي مع فحص حيوية تجاري.")
            faceEnrollmentTemplates.clear(); faceEnrollmentQualities.clear()
        }.onFailure { status.text = "تعذر حفظ بصمة الوجه: ${it.message ?: "خطأ"}" }
        return
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        when(requestCode){
            BleEmployeeScanner.REQUEST_PERMISSIONS -> {
                if(grantResults.isNotEmpty()&&grantResults.all{it==PackageManager.PERMISSION_GRANTED}){status.text="تم منح صلاحيات BLE";if(repo.autoScan)scanner.start()}
                else status.text="يلزم السماح بالأجهزة القريبة/البلوتوث"
            }
            REQUEST_GPS_PERMISSION -> {
                status.text = if(grantResults.any{it==PackageManager.PERMISSION_GRANTED}) "تم منح صلاحية الموقع — أعد اختيار GPS لإكمال الحضور" else "لم يتم السماح بالموقع"
            }
            REQUEST_CAMERA_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    status.text = "تم منح صلاحية الكاميرا"
                    launchFaceCamera()
                } else {
                    clearPendingFaceCapture()
                    status.text = "يلزم السماح بالكاميرا لاستخدام بصمة الوجه"
                }
            }
            REQUEST_AUDIO_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                    val enrolling = pendingVoiceEnrollmentEmployeeId?.let { id -> repo.employees().firstOrNull { it.employeeId.equals(id, true) } }
                    val verifying = pendingVoiceEmployeeId?.let { id -> findActiveEmployee(id) }
                    when { enrolling != null -> promptVoiceEnrollmentSample(); verifying != null -> captureVoiceForVerification(verifying) }
                } else {
                    pendingVoiceEnrollmentEmployeeId = null; pendingVoiceEmployeeId = null
                    info("صلاحية الميكروفون", "يلزم السماح بالميكروفون لتسجيل بصمة نبرة الصوت والتحقق منها.")
                }
            }
        }
    }
    private fun legacyVoicePhrase(value: String): String = value.trim().lowercase(Locale.getDefault())
        .replace(Regex("[\\p{Punct}\\s]+"), " ").trim()

    private fun normalizeVoicePhrase(value: String): String = legacyVoicePhrase(value)
        .replace(Regex("[ًٌٍَُِّْـ]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ؤ', 'و').replace('ئ', 'ي').replace('ة', 'ه')

    private fun voiceCandidateForms(value: String): Set<String> = setOf(legacyVoicePhrase(value), normalizeVoicePhrase(value)).filter { it.isNotBlank() }.toSet()

    private fun voicePhraseSimilarity(candidate: String, expected: String): Float {
        val a = normalizeVoicePhrase(candidate)
        val b = normalizeVoicePhrase(expected)
        if (a.isBlank() || b.isBlank()) return 0f
        if (a.contains(b) || b.contains(a)) return 1f
        val aw = a.split(' ').filter { it.isNotBlank() }.toSet()
        val bw = b.split(' ').filter { it.isNotBlank() }.toSet()
        if (aw.isEmpty() || bw.isEmpty()) return 0f
        val exact = aw.intersect(bw).size.toFloat()
        val fuzzy = aw.count { word -> bw.any { voiceWordDistance(word, it) <= 1 } }.toFloat()
        return maxOf(exact, fuzzy) / maxOf(aw.size, bw.size)
    }

    private fun voiceWordDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (kotlin.math.abs(a.length - b.length) > 1) return 2
        val dp = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            var previous = dp[0]; dp[0] = i + 1
            for (j in b.indices) {
                val old = dp[j + 1]
                dp[j + 1] = minOf(dp[j + 1] + 1, dp[j] + 1, previous + if (a[i] == b[j]) 0 else 1)
                previous = old
            }
        }
        return dp[b.length]
    }

    private fun resolvedSpeechLanguage(): String = when (Locale.getDefault().language.lowercase(Locale.ROOT)) {
        "ar" -> "ar"
        else -> Locale.getDefault().toLanguageTag()
    }

    private fun methodLabel(method: AttendanceMethod): String = when(method){
        AttendanceMethod.PIN -> "PIN"
        AttendanceMethod.PASSWORD -> "كلمة المرور"
        AttendanceMethod.PATTERN -> "النقش"
        AttendanceMethod.VOICE_PHRASE -> "العبارة الصوتية"
        AttendanceMethod.GPS -> "GPS"
        AttendanceMethod.EXTERNAL_FINGERPRINT -> "بصمة خارجية"
        AttendanceMethod.SHARED_DEVICE_FACE -> "الوجه"
        AttendanceMethod.PHONE_BLE_BIOMETRIC -> "هاتف + بصمة/وجه"
        AttendanceMethod.PHONE_FINGERPRINT -> "بصمة إصبع الهاتف فقط"
        AttendanceMethod.PHONE_PROXIMITY -> "التعرف على الهاتف"
        AttendanceMethod.PHONE_BIOMETRIC -> "بيومتري الهاتف"
        AttendanceMethod.SUPERVISOR_OVERRIDE -> "بإشراف"
        AttendanceMethod.MANUAL_ADMIN -> "إداري"
    }

    private fun allowedMethodsArabic(employee: PairedEmployee): String {
        val methods = if (employee.allowedMethods.isEmpty()) {
            listOf(AttendanceMethod.PIN, AttendanceMethod.PASSWORD, AttendanceMethod.PATTERN, AttendanceMethod.VOICE_PHRASE,
                AttendanceMethod.GPS, AttendanceMethod.EXTERNAL_FINGERPRINT, AttendanceMethod.PHONE_BLE_BIOMETRIC, AttendanceMethod.PHONE_FINGERPRINT, AttendanceMethod.PHONE_BIOMETRIC, AttendanceMethod.PHONE_PROXIMITY)
        } else employee.allowedMethods.mapNotNull { runCatching { AttendanceMethod.valueOf(it) }.getOrNull() }
        return methods.joinToString("، ") { methodLabel(it) }.ifBlank { "غير محددة" }
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("حسنًا", null).show()
    }

    override fun onDestroy(){nearbyRefreshHandler.removeCallbacks(nearbyRefreshTask);scanner.stop();networkListener.stop();super.onDestroy()}
    companion object {
        const val EXTRA_EMPLOYEE_MANAGER = "open_employee_manager"
        const val EXTRA_STORE_ADMIN_SESSION = "store_admin_session"
        private const val REQUEST_FACE_CAPTURE = 6201
        private const val REQUEST_VOICE_VERIFY = 6203
        private const val REQUEST_GPS_PERMISSION = 6204
        private const val REQUEST_CAMERA_PERMISSION = 6205
        private const val REQUEST_AUDIO_PERMISSION = 6206
        private const val VOICE_PRINT_THRESHOLD = 0.52f
    }

}

private class SignaturePadView(context: android.content.Context) : View(context) {
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(18, 72, 82); style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 3f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val points = StringBuilder()
    private var strokes = 0

    init { setBackgroundColor(android.graphics.Color.rgb(248, 250, 250)) }

    override fun onDraw(canvas: Canvas) { super.onDraw(canvas); canvas.drawPath(path, paint) }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x.coerceIn(0f, width.toFloat()); val y = event.y.coerceIn(0f, height.toFloat())
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { path.moveTo(x, y); points.append('M'); strokes++; parent?.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> path.lineTo(x, y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
            else -> return true
        }
        points.append((x / width.coerceAtLeast(1) * 1000).toInt()).append(',')
            .append((y / height.coerceAtLeast(1) * 1000).toInt()).append(';')
        invalidate(); return true
    }

    fun hasSignature(): Boolean = strokes > 0 && points.length >= 30
    fun clear() { path.reset(); points.setLength(0); strokes = 0; invalidate() }
    fun digest(): String = MessageDigest.getInstance("SHA-256").digest(points.toString().toByteArray())
        .joinToString("") { "%02x".format(it) }
}
