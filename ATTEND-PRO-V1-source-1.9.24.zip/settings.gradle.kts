import org.gradle.api.initialization.resolve.RepositoriesMode

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

val baseArchive = file("../ATTEND-PRO-V1-source-1.9.23.zip")
require(baseArchive.exists()) {
    "Base source archive ATTEND-PRO-V1-source-1.9.23.zip was not found in repository root"
}

val baseDir = file("base")
if (baseDir.exists()) baseDir.deleteRecursively()
baseDir.mkdirs()
copy {
    from(zipTree(baseArchive))
    into(baseDir)
}

val overlayDir = file("overlay")
require(overlayDir.exists()) { "1.9.24 connection overlay is missing" }
copy {
    from(overlayDir)
    into(baseDir)
}

println("ATTEND_PRO_PATCH: 1.9.24 connection fix overlay applied over 1.9.23")

rootProject.name = "ATTEND-PRO-V1"
rootProject.projectDir = baseDir
include(":core", ":employee-app", ":store-app")
project(":core").projectDir = file("base/core")
project(":employee-app").projectDir = file("base/employee-app")
project(":store-app").projectDir = file("base/store-app")
