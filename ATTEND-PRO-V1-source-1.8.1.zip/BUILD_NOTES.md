ATTEND PRO 1.8.1 — BUILD NOTES
================================

Modules:
- core
- store-app
- employee-app

Version:
- store-app: versionCode 19 / versionName 1.8.1
- employee-app: versionCode 19 / versionName 1.8.1

Build target:
- compileSdk 35 / targetSdk 35 / minSdk 26
- Java 17
- Gradle workflow builds both debug APKs.

1.8.1 changes
-------------
1. Face camera path
- Runtime CAMERA permission.
- Full-size ACTION_IMAGE_CAPTURE output through FileProvider to app cache.
- URI read/write grants + ClipData for camera compatibility.
- EXIF rotation handling.
- No employee data is overwritten when capture is cancelled or fails.

2. Face matching prototype
- Android face detection: exactly one face required.
- Face-distance and crop checks.
- Quality score: detector confidence + brightness + contrast + edge sharpness.
- Local HOG-like normalized signature stored as `fh1:` Base64 float vector.
- Cosine comparison across active face-enabled employees.
- Initial acceptance: score >= 0.79 and, where multiple candidates exist, best/second margin >= 0.025.
- THESE THRESHOLDS ARE EXPERIMENTAL and require field calibration before commercial reliance.
- No liveness model is included yet. Deep recognition/liveness remains a later production hardening task.

3. Voice verification
- Stored normalized phrase hash.
- Random spoken challenge word per verification attempt.
- Speech recognition confidence threshold used when Android supplies confidence scores.
- Designed to reduce fixed-recording replay; not a neural speaker-identity model.

4. Employee schedules
- Optional per-employee start/end time.
- Store-level start/end remains fallback.
- Grace minutes validated.
- Provision QR includes effective employee shift.
- Reports use per-employee start/end for late/early-departure indicators.

5. Authorized report receivers
- Receiver invite prefix APRRI1.
- Encrypted report package prefix APRPT1.
- AES-GCM report encryption with unique receiver secret.
- Owner can authorize, suspend/reactivate, or delete receiver phones.
- Receiver inbox and confirmation code flow included.
- Direct remote revocation cannot erase a package already delivered; suspension prevents selecting that receiver for future shares from this Store app.
- Automatic cloud delivery/monitoring still requires backend deployment.

6. Stability / compatibility
- New JSON fields are optional on read to preserve 1.7 data.
- Invalid camera/GPS/QR/report packages are handled without overwriting existing employee biometrics.
- Network sync remains background-threaded and guarded against concurrent runs.

Security follow-ups before a commercial production release
---------------------------------------------------------
- Move central licensing/signing to backend/HSM.
- Protect receiver secrets with Android Keystore/EncryptedSharedPreferences.
- Add production-grade face embeddings + liveness and calibrate FAR/FRR.
- Add production speaker verification if voice identity is required.
- Add backend device revocation, receiver authorization sync, push notifications, and audit logs.
