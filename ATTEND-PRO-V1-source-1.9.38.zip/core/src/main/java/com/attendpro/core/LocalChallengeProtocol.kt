package com.attendpro.core

import java.nio.ByteBuffer
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object LocalChallengeProtocol {
    const val PORT = 47719
    private val MAGIC = byteArrayOf(0x41, 0x50, 0x43, 0x31)

    data class Challenge(val employeeHash: Int, val method: AttendanceMethod, val nonce: Long)

    fun encode(employeeId: String, secret: ByteArray, method: AttendanceMethod, now: Long = System.currentTimeMillis()): ByteArray {
        val body = ByteBuffer.allocate(17).put(MAGIC).putInt(BleProtocol.employeeHash(employeeId))
            .put(method.ordinal.toByte()).putLong(now).array()
        return body + signature(secret, body)
    }

    fun decode(bytes: ByteArray, secret: ByteArray, now: Long = System.currentTimeMillis()): Challenge? {
        if (bytes.size != 25 || !bytes.copyOfRange(0, 4).contentEquals(MAGIC)) return null
        val body = bytes.copyOfRange(0, 17)
        if (!MessageDigestCompat.equals(bytes.copyOfRange(17, 25), signature(secret, body))) return null
        val buffer = ByteBuffer.wrap(body).apply { position(4) }
        val employeeHash = buffer.int
        val ordinal = buffer.get().toInt() and 0xff
        val nonce = buffer.long
        if (kotlin.math.abs(now - nonce) > 120_000L) return null
        val method = AttendanceMethod.values().getOrNull(ordinal) ?: return null
        return Challenge(employeeHash, method, nonce)
    }

    private fun signature(secret: ByteArray, body: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret, "HmacSHA256"))
        return mac.doFinal(body).copyOfRange(0, 8)
    }

    private object MessageDigestCompat {
        fun equals(a: ByteArray, b: ByteArray): Boolean {
            if (a.size != b.size) return false
            var diff = 0
            for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
            return diff == 0
        }
    }
}
