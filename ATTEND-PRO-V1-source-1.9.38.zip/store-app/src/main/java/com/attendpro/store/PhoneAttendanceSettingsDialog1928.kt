package com.attendpro.store

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.attendpro.core.StoreRepository
import com.attendpro.core.UiKit

object PhoneAttendanceSettingsDialog1928 {
    fun show(activity: Activity, repo: StoreRepository) {
        val p = UiKit.palette(activity)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(UiKit.dp(activity, 14), UiKit.dp(activity, 10), UiKit.dp(activity, 14), UiKit.dp(activity, 8))
        }
        root.addView(UiKit.title(activity, p, "طرق الحضور المعتمدة", 20f).apply { gravity = Gravity.CENTER })
        root.addView(UiKit.subtitle(activity, p, "خمس طرق واضحة فقط. Bluetooth وWi‑Fi وGPS تعمل كطبقات إثبات وحماية في الخلفية، وليست رموز حضور مستقلة.").apply {
            gravity = Gravity.CENTER
            setPadding(0, UiKit.dp(activity, 5), 0, UiKit.dp(activity, 12))
        })

        fun option(icon: String, title: String, subtitle: String, checked: Boolean): CheckBox {
            val box = CheckBox(activity).apply {
                text = "$icon  $title\n$subtitle"
                textSize = 14.6f
                isChecked = checked
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setTextColor(p.text)
                buttonTintList = android.content.res.ColorStateList.valueOf(p.primary)
                background = UiKit.round(p.surface2, p.buttonRadius, activity, p.divider)
                setPadding(UiKit.dp(activity, 12), UiKit.dp(activity, 10), UiKit.dp(activity, 12), UiKit.dp(activity, 10))
            }
            box.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.dp(activity, 8)
            }
            root.addView(box)
            return box
        }

        val face = option("◉", "التعرف بالوجه", "كاميرا جهاز المحل + جودة + فحص حيوية", repo.allowFaceEnrollment)
        val voice = option("◖", "بصمة الصوت", "عدة عينات + النبرة + العبارة + تحدٍ متغير", repo.allowVoiceVerification)
        val password = option("▣", "كلمة المرور", "بديل احتياطي واحد؛ PIN والنقش ملغيان", repo.allowPasswordFallback)
        val phone = option("◎", "بصمة/وجه هاتف الموظف", "التحقق البيومتري الأصلي في Android على الهاتف المرتبط", repo.allowEmployeeCompanion && repo.requirePhoneBiometric)
        val qr = option("▦", "QR مباشر", "رمز مؤقت وموقّع يفتح طلب الموافقة في هاتف الموظف", repo.allowQrAttendance)

        val protection = UiKit.card(activity, p, 11)
        protection.addView(UiKit.sectionLabel(activity, p, "طبقات الحماية الخلفية"))
        protection.addView(UiKit.subtitle(activity, p, "BLE/Wi‑Fi لإثبات القرب • GPS للتحقق من الموقع عند تفعيله • توقيع الطلبات ومنع الإعادة."))
        root.addView(protection)

        AlertDialog.Builder(activity)
            .setTitle("الحضور والتحقق")
            .setView(ScrollView(activity).apply { addView(root) })
            .setPositiveButton("حفظ") { _, _ ->
                repo.allowFaceEnrollment = face.isChecked
                repo.allowVoiceVerification = voice.isChecked
                repo.allowPasswordFallback = password.isChecked
                repo.allowPatternFallback = false
                repo.allowPinFallback = false
                repo.allowQrAttendance = qr.isChecked
                repo.allowEmployeeCompanion = phone.isChecked || qr.isChecked
                repo.requirePhoneBiometric = phone.isChecked
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
